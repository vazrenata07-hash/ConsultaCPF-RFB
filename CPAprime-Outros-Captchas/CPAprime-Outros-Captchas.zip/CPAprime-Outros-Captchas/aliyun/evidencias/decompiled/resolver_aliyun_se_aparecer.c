
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * resolver_aliyun_se_aparecer(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  longlong lVar3;
  int *piVar4;
  longlong *plVar5;
  undefined *puVar6;
  char cVar7;
  int iVar8;
  longlong *plVar9;
  code *pcVar10;
  undefined8 uVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  code *pcVar16;
  bool bVar17;
  longlong lStackX_18;
  longlong *plStackX_20;
  
  plVar5 = _DAT_142dea7d8;
  plVar13 = (longlong *)python_pars[1];
  plVar1 = (longlong *)*python_pars;
  plStackX_20 = plVar13;
  if (_DAT_142dea7d8 == (longlong *)0x0) {
LAB_1408d68f1:
    _DAT_142dea7d8 = (longlong *)FUN_142cd81e0(tstate,_DAT_142dea100,_DAT_142f2aaf0,0x18);
  }
  else if ((1 < *_DAT_142dea7d8) || (_DAT_142dea7d8[2] != 0)) {
    if ((_DAT_142dea7d8 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7d8 && (*_DAT_142dea7d8 = *_DAT_142dea7d8 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408d68f1;
  }
  plVar5 = _DAT_142dea7d8;
  Nuitka_helper_140008a00(tstate,_DAT_142dea7d8);
  plVar9 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
  if (plVar9 == (longlong *)0x0) {
    lVar12 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    pcVar16 = (code *)0x243f;
  }
  else {
    iVar8 = FUN_140004970(plVar9);
    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    if (iVar8 == -1) {
      lVar12 = *(longlong *)(tstate + 0x70);
      pcVar16 = (code *)0x243f;
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      if (iVar8 == 0) {
LAB_1408d69a2:
        pcVar16 = _Py_FalseStruct_exref;
        if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
          *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
        }
LAB_1408d6cca:
        plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
        *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
        *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
        plVar9 = (longlong *)plVar5[2];
        if (((plVar9 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar9)) &&
           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
          (**(code **)(plVar9[1] + 0x30))();
        }
        if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))(plVar5);
        }
        plVar5[0xc] = 0;
        if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
          (**(code **)(plVar1[1] + 0x30))(plVar1);
        }
        if ((int)*plVar13 < 0) {
          return pcVar16;
        }
        *plVar13 = *plVar13 + -1;
        if (*plVar13 != 0) {
          return pcVar16;
        }
        (**(code **)(plVar13[1] + 0x30))(plVar13);
        return pcVar16;
      }
      pcVar16 = (code *)0x2441;
      *(undefined4 *)(plVar5 + 5) = 0x2441;
      plVar9 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1982__aliyun_na_tela);
      if (plVar9 == (longlong *)0x0) {
        lVar12 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
      }
      else {
        iVar8 = FUN_140004970(plVar9);
        if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
          (**(code **)(plVar9[1] + 0x30))(plVar9);
        }
        if (iVar8 == -1) {
          lVar12 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
        }
        else {
          if (iVar8 == 0) goto LAB_1408d69a2;
          *(undefined4 *)(plVar5 + 5) = 0x2444;
          pcVar16 = (code *)FUN_142cd12f0(tstate,plVar1,classes_const_1983__resolver_aliyun,plVar13)
          ;
          if (pcVar16 != (code *)0x0) goto LAB_1408d6cca;
          lVar12 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          piVar4 = *(int **)(tstate + 0xf8);
          lStackX_18 = 0;
          if ((piVar4 != (int *)0x0) && (*piVar4 + 1 != 0)) {
            *piVar4 = *piVar4 + 1;
          }
          piVar2 = *(int **)(lVar12 + 0x28);
          pcVar16 = (code *)FUN_142cd9160(plVar5,0x2444);
          if (piVar2 != (int *)0x0) {
            *(int **)(pcVar16 + 0x10) = piVar2;
            if (*piVar2 + 1 != 0) {
              *piVar2 = *piVar2 + 1;
            }
          }
          plVar9 = *(longlong **)(lVar12 + 0x28);
          pcVar10 = (code *)0x0;
          if (((pcVar16 != _Py_NoneStruct_exref) && (pcVar10 = pcVar16, pcVar16 != (code *)0x0)) &&
             (*(int *)pcVar16 + 1 != 0)) {
            *(int *)pcVar16 = *(int *)pcVar16 + 1;
          }
          *(code **)(lVar12 + 0x28) = pcVar10;
          if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
             (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
            (**(code **)(plVar9[1] + 0x30))();
          }
          if (((pcVar16 != (code *)0x0) && (-1 < *(int *)pcVar16)) &&
             (*(longlong *)pcVar16 = *(longlong *)pcVar16 + -1, *(longlong *)pcVar16 == 0)) {
            (**(code **)(*(longlong *)(pcVar16 + 8) + 0x30))(pcVar16);
          }
          plVar9 = *(longlong **)(tstate + 0xf8);
          *(longlong *)(tstate + 0xf8) = lVar12;
          if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
             (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
            (**(code **)(plVar9[1] + 0x30))();
          }
          iVar8 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                                *(undefined8 *)PyExc_Exception_exref);
          if (iVar8 == 0) {
            cVar7 = FUN_142cded30(tstate,&lStackX_18);
            pcVar16 = (code *)0x2443;
            if (cVar7 != '\0') {
              pcVar16 = (code *)0x0;
            }
            lVar3 = *(longlong *)(lStackX_18 + 0x28);
            lVar12 = lStackX_18;
            if ((lVar3 != 0) && (*(longlong **)(lVar3 + 0x18) == plVar5)) {
              *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar3 + 0x24);
            }
          }
          else {
            plVar9 = *(longlong **)(tstate + 0xf8);
            iVar8 = (int)*plVar9 + 1;
            if (iVar8 != 0) {
              *(int *)plVar9 = iVar8;
            }
            uVar11 = FUN_1400776a0(classes_const_257_print);
            puVar6 = classes_const_1984__s__aliyun__falhei___s;
            pcVar16 = (code *)0x2446;
            *(undefined4 *)(plVar5 + 5) = 0x2446;
            lVar12 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
            if (lVar12 != 0) {
              plVar13 = (longlong *)FUN_142cd9440(tstate,2);
              plVar13[3] = lVar12;
              iVar8 = (int)*plVar9 + 1;
              if (iVar8 != 0) {
                *(int *)plVar9 = iVar8;
              }
              plVar13[4] = (longlong)plVar9;
              plVar14 = (longlong *)FUN_142cbffc0(puVar6,plVar13);
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              plVar13 = plStackX_20;
              if (plVar14 != (longlong *)0x0) {
                *(undefined4 *)(plVar5 + 5) = 0x2446;
                plVar15 = (longlong *)FUN_142ccfd60(tstate,uVar11,plVar14);
                if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                  (**(code **)(plVar14[1] + 0x30))(plVar14);
                }
                plVar13 = plStackX_20;
                if (plVar15 != (longlong *)0x0) {
                  if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                    (**(code **)(plVar15[1] + 0x30))(plVar15);
                  }
                  pcVar16 = _Py_FalseStruct_exref;
                  if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
                    *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
                  }
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  plVar5 = *(longlong **)(tstate + 0xf8);
                  *(int **)(tstate + 0xf8) = piVar4;
                  plVar13 = plStackX_20;
                  if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
                     (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                    (**(code **)(plVar5[1] + 0x30))();
                    plVar13 = plStackX_20;
                  }
                  goto LAB_1408d6cca;
                }
              }
            }
            lVar12 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
          }
          plVar9 = *(longlong **)(tstate + 0xf8);
          lStackX_18 = 0;
          *(int **)(tstate + 0xf8) = piVar4;
          if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
             (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
            (**(code **)(plVar9[1] + 0x30))();
          }
        }
      }
    }
  }
  pcVar10 = (code *)0x0;
  piVar4 = *(int **)(lVar12 + 0x28);
  lStackX_18 = lVar12;
  if (piVar4 == (int *)0x0) {
    pcVar16 = (code *)FUN_142cd9160(plVar5,pcVar16);
    bVar17 = pcVar16 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar4 + 6) == plVar5) goto LAB_1408d6e87;
    pcVar16 = (code *)FUN_142cd9160(plVar5,pcVar16);
    *(int **)(pcVar16 + 0x10) = piVar4;
    if (*piVar4 + 1 != 0) {
      *piVar4 = *piVar4 + 1;
    }
    bVar17 = pcVar16 == _Py_NoneStruct_exref;
  }
  plVar9 = *(longlong **)(lStackX_18 + 0x28);
  if (((!bVar17) && (pcVar10 = pcVar16, pcVar16 != (code *)0x0)) && (*(int *)pcVar16 + 1 != 0)) {
    *(int *)pcVar16 = *(int *)pcVar16 + 1;
  }
  *(code **)(lStackX_18 + 0x28) = pcVar10;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if (((pcVar16 != (code *)0x0) && (-1 < *(int *)pcVar16)) &&
     (*(longlong *)pcVar16 = *(longlong *)pcVar16 + -1, *(longlong *)pcVar16 == 0)) {
    (**(code **)(*(longlong *)(pcVar16 + 8) + 0x30))(pcVar16);
  }
LAB_1408d6e87:
  FUN_142cdb370(plVar5,&UNK_142d0b25c,plVar1,plVar13,0);
  plVar9 = _DAT_142dea7d8;
  if (plVar5 == _DAT_142dea7d8) {
    if ((-1 < (int)*_DAT_142dea7d8) && (*_DAT_142dea7d8 = *_DAT_142dea7d8 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))();
    }
    _DAT_142dea7d8 = (longlong *)0x0;
  }
  plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
  plVar9 = (longlong *)plVar5[2];
  if (((plVar9 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar9)) &&
     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  plVar5[0xc] = 0;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  plVar13 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))();
  }
  return (undefined *)0x0;
}

