
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _toque_cru(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  code *pcVar2;
  longlong *plVar3;
  int *piVar4;
  longlong *plVar5;
  longlong lVar6;
  int *piVar7;
  undefined *puVar8;
  undefined *puVar9;
  char cVar10;
  int iVar11;
  code *pcVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *plVar17;
  code *pcVar18;
  undefined8 uVar19;
  bool bVar20;
  longlong lStackX_18;
  longlong *plStackX_20;
  undefined *puStack_48;
  longlong *plStack_40;
  
  plVar5 = _DAT_142dea7c0;
  plStackX_20 = (longlong *)python_pars[1];
  plVar1 = (longlong *)*python_pars;
  iVar11 = 0;
  pcVar2 = (code *)python_pars[2];
  plVar3 = (longlong *)python_pars[3];
  if (_DAT_142dea7c0 == (longlong *)0x0) {
LAB_1408d22fd:
    _DAT_142dea7c0 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9dd0,_DAT_142f2aaf0,0x28);
  }
  else if ((1 < *_DAT_142dea7c0) || (_DAT_142dea7c0[2] != 0)) {
    if ((_DAT_142dea7c0 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7c0 && (*_DAT_142dea7c0 = *_DAT_142dea7c0 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408d22fd;
  }
  plVar5 = _DAT_142dea7c0;
  Nuitka_helper_140008a00(tstate,_DAT_142dea7c0);
  pcVar12 = (code *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
  plVar17 = (longlong *)0x0;
  if (pcVar12 == (code *)0x0) {
LAB_1408d2350:
    lVar13 = *(longlong *)(tstate + 0x70);
    uVar19 = 0x23e8;
    *(undefined8 *)(tstate + 0x70) = 0;
  }
  else {
    if (pcVar12 == _Py_TrueStruct_exref) {
LAB_1408d236f:
      iVar11 = 1;
    }
    else if ((pcVar12 != _Py_FalseStruct_exref) && (pcVar12 != _Py_NoneStruct_exref)) {
      lVar13 = *(longlong *)(pcVar12 + 8);
      if ((*(longlong *)(lVar13 + 0x60) == 0) ||
         (pcVar18 = *(code **)(*(longlong *)(lVar13 + 0x60) + 0x48), pcVar18 == (code *)0x0)) {
        if ((*(undefined8 **)(lVar13 + 0x70) == (undefined8 *)0x0) ||
           (pcVar18 = (code *)**(undefined8 **)(lVar13 + 0x70), pcVar18 == (code *)0x0)) {
          if ((*(undefined8 **)(lVar13 + 0x68) == (undefined8 *)0x0) ||
             (pcVar18 = (code *)**(undefined8 **)(lVar13 + 0x68), pcVar18 == (code *)0x0))
          goto LAB_1408d236f;
          lVar13 = (*pcVar18)(pcVar12);
        }
        else {
          lVar13 = (*pcVar18)(pcVar12);
        }
      }
      else {
        iVar11 = (*pcVar18)(pcVar12);
        lVar13 = (longlong)iVar11;
      }
      if (lVar13 < 1) {
        iVar11 = -(uint)(lVar13 != 0);
      }
      else {
        iVar11 = 1;
      }
    }
    if ((-1 < *(int *)pcVar12) &&
       (*(longlong *)pcVar12 = *(longlong *)pcVar12 + -1, *(longlong *)pcVar12 == 0)) {
      (**(code **)(*(longlong *)(pcVar12 + 8) + 0x30))(pcVar12);
    }
    pcVar12 = _Py_FalseStruct_exref;
    if (iVar11 == -1) goto LAB_1408d2350;
    if (iVar11 == 0) {
      if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
        *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
        plVar17 = (longlong *)0x0;
      }
LAB_1408d27b6:
      plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
      *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
      *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
      plVar14 = (longlong *)plVar5[2];
      if (((plVar14 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar14)) &&
         (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
        (**(code **)(plVar14[1] + 0x30))();
      }
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
      plVar5[0xc] = 0;
LAB_1408d2805:
      if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
         (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
        (**(code **)(plVar17[1] + 0x30))(plVar17);
      }
      if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
        (**(code **)(plVar1[1] + 0x30))();
      }
      if ((-1 < (int)*plStackX_20) && (*plStackX_20 = *plStackX_20 + -1, *plStackX_20 == 0)) {
        (**(code **)(plStackX_20[1] + 0x30))();
      }
      if ((-1 < *(int *)pcVar2) &&
         (*(longlong *)pcVar2 = *(longlong *)pcVar2 + -1, *(longlong *)pcVar2 == 0)) {
        (**(code **)(*(longlong *)(pcVar2 + 8) + 0x30))();
      }
      if ((int)*plVar3 < 0) {
        return pcVar12;
      }
      *plVar3 = *plVar3 + -1;
      if (*plVar3 != 0) {
        return pcVar12;
      }
      (**(code **)(plVar3[1] + 0x30))(plVar3);
      return pcVar12;
    }
    plVar14 = (longlong *)FUN_142cd8f90(tstate,0);
    puVar8 = classes_const_309_x;
    plVar17 = plVar14;
    if (pcVar2 == _Py_NoneStruct_exref) {
LAB_1408d258d:
      plVar14 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
      puVar9 = classes_const_1743_Input_dispatchTouchEvent;
      puVar8 = classes_const_984_type;
      if (plVar14 != (longlong *)0x0) {
        plVar15 = (longlong *)_PyDict_NewPresized(2);
        PyDict_SetItem(plVar15,puVar8,plStackX_20);
        PyDict_SetItem(plVar15,classes_const_1745_touchPoints,plVar17);
        *(undefined4 *)(plVar5 + 5) = 0x23ef;
        puStack_48 = puVar9;
        plStack_40 = plVar15;
        plVar16 = (longlong *)
                  FUN_142cd07f0(tstate,plVar14,classes_const_300_execute_cdp_cmd,&puStack_48);
        if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
          (**(code **)(plVar14[1] + 0x30))(plVar14);
        }
        if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))(plVar15);
        }
        if (plVar16 != (longlong *)0x0) {
          if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
            (**(code **)(plVar16[1] + 0x30))(plVar16);
          }
          FUN_140008990(tstate);
          pcVar12 = _Py_TrueStruct_exref;
          if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
            *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
          }
          goto LAB_1408d2805;
        }
      }
      lVar13 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      piVar7 = *(int **)(tstate + 0xf8);
      lStackX_18 = 0;
      if ((piVar7 != (int *)0x0) && (*piVar7 + 1 != 0)) {
        *piVar7 = *piVar7 + 1;
      }
      piVar4 = *(int **)(lVar13 + 0x28);
      pcVar12 = (code *)FUN_142cd9160(plVar5,0x23ef);
      if (piVar4 != (int *)0x0) {
        *(int **)(pcVar12 + 0x10) = piVar4;
        if (*piVar4 + 1 != 0) {
          *piVar4 = *piVar4 + 1;
        }
      }
      plVar14 = *(longlong **)(lVar13 + 0x28);
      if (pcVar12 == _Py_NoneStruct_exref) {
        pcVar18 = (code *)0x0;
      }
      else {
        pcVar18 = pcVar12;
        if ((pcVar12 != (code *)0x0) && (*(int *)pcVar12 + 1 != 0)) {
          *(int *)pcVar12 = *(int *)pcVar12 + 1;
        }
      }
      *(code **)(lVar13 + 0x28) = pcVar18;
      if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
         (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
        (**(code **)(plVar14[1] + 0x30))();
      }
      if (((pcVar12 != (code *)0x0) && (-1 < *(int *)pcVar12)) &&
         (*(longlong *)pcVar12 = *(longlong *)pcVar12 + -1, *(longlong *)pcVar12 == 0)) {
        (**(code **)(*(longlong *)(pcVar12 + 8) + 0x30))(pcVar12);
      }
      plVar14 = *(longlong **)(tstate + 0xf8);
      *(longlong *)(tstate + 0xf8) = lVar13;
      if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
         (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
        (**(code **)(plVar14[1] + 0x30))();
      }
      iVar11 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                             *(undefined8 *)PyExc_Exception_exref);
      pcVar12 = _Py_FalseStruct_exref;
      if (iVar11 != 0) {
        if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
          *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
        }
        plVar5 = *(longlong **)(tstate + 0xf8);
        *(int **)(tstate + 0xf8) = piVar7;
        if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
           (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))();
        }
        goto LAB_1408d27b6;
      }
      cVar10 = FUN_142cded30(tstate,&lStackX_18);
      lVar13 = lStackX_18;
      uVar19 = 0x23ee;
      if (cVar10 != '\0') {
        uVar19 = 0;
      }
      lVar6 = *(longlong *)(lStackX_18 + 0x28);
      if ((lVar6 != 0) && (*(longlong **)(lVar6 + 0x18) == plVar5)) {
        *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar6 + 0x24);
      }
      lStackX_18 = 0;
      plVar14 = *(longlong **)(tstate + 0xf8);
      *(int **)(tstate + 0xf8) = piVar7;
      if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
         (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
        (**(code **)(plVar14[1] + 0x30))();
      }
    }
    else {
      plVar15 = (longlong *)Nuitka_helper_142ce5200(pcVar2);
      if (plVar15 == (longlong *)0x0) {
        lVar13 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar19 = 0x23ec;
      }
      else {
        plVar16 = (longlong *)_PyDict_NewPresized(5);
        PyDict_SetItem(plVar16,puVar8,plVar15);
        if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))(plVar15);
        }
        puVar8 = classes_const_310_y;
        plVar15 = (longlong *)Nuitka_helper_142ce5200(plVar3);
        if (plVar15 != (longlong *)0x0) {
          PyDict_SetItem(plVar16,puVar8,plVar15);
          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
            (**(code **)(plVar15[1] + 0x30))(plVar15);
          }
          PyDict_SetItem(plVar16,classes_const_1740_radiusX,classes_const_1250_12);
          PyDict_SetItem(plVar16,classes_const_1741_radiusY,classes_const_1250_12);
          PyDict_SetItem(plVar16,classes_const_1742_force,shared_const_3_1);
          plVar17 = (longlong *)FUN_142cd8f90(tstate,1);
          *(longlong **)plVar17[3] = plVar16;
          if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))(plVar14);
          }
          goto LAB_1408d258d;
        }
        lStackX_18 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar19 = 0x23ec;
        lVar13 = lStackX_18;
        if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
          (**(code **)(plVar16[1] + 0x30))(plVar16);
          lVar13 = lStackX_18;
        }
      }
    }
  }
  lStackX_18 = lVar13;
  piVar7 = *(int **)(lStackX_18 + 0x28);
  if (piVar7 == (int *)0x0) {
    pcVar12 = (code *)FUN_142cd9160(plVar5,uVar19);
    bVar20 = pcVar12 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar7 + 6) == plVar5) goto LAB_1408d298d;
    pcVar12 = (code *)FUN_142cd9160(plVar5,uVar19);
    *(int **)(pcVar12 + 0x10) = piVar7;
    if (*piVar7 + 1 != 0) {
      *piVar7 = *piVar7 + 1;
    }
    bVar20 = pcVar12 == _Py_NoneStruct_exref;
  }
  plVar14 = *(longlong **)(lStackX_18 + 0x28);
  if (bVar20) {
    pcVar18 = (code *)0x0;
  }
  else {
    pcVar18 = pcVar12;
    if ((pcVar12 != (code *)0x0) && (*(int *)pcVar12 + 1 != 0)) {
      *(int *)pcVar12 = *(int *)pcVar12 + 1;
    }
  }
  *(code **)(lStackX_18 + 0x28) = pcVar18;
  if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
     (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
    (**(code **)(plVar14[1] + 0x30))();
  }
  if (((pcVar12 != (code *)0x0) && (-1 < *(int *)pcVar12)) &&
     (*(longlong *)pcVar12 = *(longlong *)pcVar12 + -1, *(longlong *)pcVar12 == 0)) {
    (**(code **)(*(longlong *)(pcVar12 + 8) + 0x30))(pcVar12);
  }
LAB_1408d298d:
  FUN_142cdb370(plVar5,&UNK_142d0b1bc,plVar1,plStackX_20,pcVar2,plVar3,plVar17);
  plVar14 = _DAT_142dea7c0;
  if (plVar5 == _DAT_142dea7c0) {
    if ((-1 < (int)*_DAT_142dea7c0) && (*_DAT_142dea7c0 = *_DAT_142dea7c0 + -1, *plVar14 == 0)) {
      (**(code **)(plVar14[1] + 0x30))();
    }
    _DAT_142dea7c0 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar13 = lStackX_18;
  lStackX_18 = 0;
  if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
     (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
    (**(code **)(plVar17[1] + 0x30))(plVar17);
  }
  lStackX_18 = lVar13;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plStackX_20) && (*plStackX_20 = *plStackX_20 + -1, *plStackX_20 == 0)) {
    (**(code **)(plStackX_20[1] + 0x30))();
  }
  if ((-1 < *(int *)pcVar2) &&
     (*(longlong *)pcVar2 = *(longlong *)pcVar2 + -1, *(longlong *)pcVar2 == 0)) {
    (**(code **)(*(longlong *)(pcVar2 + 8) + 0x30))(pcVar2);
  }
  if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
    (**(code **)(plVar3[1] + 0x30))(plVar3);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

