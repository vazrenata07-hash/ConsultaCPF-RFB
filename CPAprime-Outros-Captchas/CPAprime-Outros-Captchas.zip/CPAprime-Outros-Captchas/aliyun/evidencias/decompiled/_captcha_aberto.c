
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _captcha_aberto(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  int iVar4;
  longlong *plVar5;
  code *pcVar6;
  code *pcVar7;
  longlong lVar8;
  undefined8 uVar9;
  bool bVar10;
  
  plVar3 = _DAT_142dea7f0;
  plVar1 = (longlong *)*python_pars;
  if (_DAT_142dea7f0 == (longlong *)0x0) {
LAB_1408db5b5:
    _DAT_142dea7f0 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de99a8,_DAT_142f2aaf0,8);
  }
  else if ((1 < *_DAT_142dea7f0) || (_DAT_142dea7f0[2] != 0)) {
    if ((_DAT_142dea7f0 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7f0 && (*_DAT_142dea7f0 = *_DAT_142dea7f0 + -1, *plVar3 == 0)))) {
      (**(code **)(plVar3[1] + 0x30))(plVar3);
    }
    goto LAB_1408db5b5;
  }
  plVar3 = _DAT_142dea7f0;
  Nuitka_helper_140008a00(tstate,_DAT_142dea7f0);
  uVar9 = 0x24c9;
  *(undefined4 *)(plVar3 + 5) = 0x24c9;
  plVar5 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1882__geetest_aberto);
  if (plVar5 == (longlong *)0x0) {
LAB_1408db6d8:
    lVar8 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
  }
  else {
    iVar4 = FUN_140004970(plVar5);
    if (iVar4 != -1) {
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
      pcVar6 = _Py_TrueStruct_exref;
      if (iVar4 != 0) {
        if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
          *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
        }
LAB_1408db67d:
        FUN_140008990(tstate);
        if ((int)*plVar1 < 0) {
          return pcVar6;
        }
        *plVar1 = *plVar1 + -1;
        if (*plVar1 != 0) {
          return pcVar6;
        }
        (**(code **)(plVar1[1] + 0x30))(plVar1);
        return pcVar6;
      }
      uVar9 = 0x24cb;
      *(undefined4 *)(plVar3 + 5) = 0x24cb;
      pcVar6 = (code *)FUN_142cd06a0(tstate,plVar1,classes_const_1982__aliyun_na_tela);
      if (pcVar6 != (code *)0x0) goto LAB_1408db67d;
      goto LAB_1408db6d8;
    }
    lVar8 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
  }
  pcVar6 = (code *)0x0;
  piVar2 = *(int **)(lVar8 + 0x28);
  if (piVar2 == (int *)0x0) {
    pcVar7 = (code *)FUN_142cd9160(plVar3,uVar9);
    bVar10 = pcVar7 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar2 + 6) == plVar3) goto LAB_1408db785;
    pcVar7 = (code *)FUN_142cd9160(plVar3,uVar9);
    *(int **)(pcVar7 + 0x10) = piVar2;
    if (*piVar2 + 1 != 0) {
      *piVar2 = *piVar2 + 1;
    }
    bVar10 = pcVar7 == _Py_NoneStruct_exref;
  }
  plVar5 = *(longlong **)(lVar8 + 0x28);
  if (((!bVar10) && (pcVar6 = pcVar7, pcVar7 != (code *)0x0)) && (*(int *)pcVar7 + 1 != 0)) {
    *(int *)pcVar7 = *(int *)pcVar7 + 1;
  }
  *(code **)(lVar8 + 0x28) = pcVar6;
  if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)
     ) {
    (**(code **)(plVar5[1] + 0x30))();
  }
  if (((pcVar7 != (code *)0x0) && (-1 < *(int *)pcVar7)) &&
     (*(longlong *)pcVar7 = *(longlong *)pcVar7 + -1, *(longlong *)pcVar7 == 0)) {
    (**(code **)(*(longlong *)(pcVar7 + 8) + 0x30))(pcVar7);
  }
LAB_1408db785:
  FUN_142cdb370(plVar3,&UNK_142d0ae4c,plVar1);
  plVar5 = _DAT_142dea7f0;
  if (plVar3 == _DAT_142dea7f0) {
    if ((-1 < (int)*_DAT_142dea7f0) && (*_DAT_142dea7f0 = *_DAT_142dea7f0 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))();
    }
    _DAT_142dea7f0 = (longlong *)0x0;
  }
  plVar3 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar3 + 10) = 0xfffffffe;
  plVar5 = (longlong *)plVar3[2];
  if (((plVar5 != (longlong *)0x0) && (plVar3[2] = 0, -1 < (int)*plVar5)) &&
     (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))();
  }
  if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
    (**(code **)(plVar3[1] + 0x30))(plVar3);
  }
  plVar3[0xc] = 0;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lVar8;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

