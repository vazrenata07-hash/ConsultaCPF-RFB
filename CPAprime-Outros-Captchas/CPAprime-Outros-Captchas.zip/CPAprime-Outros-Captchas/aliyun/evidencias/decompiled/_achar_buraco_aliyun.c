
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _achar_buraco_aliyun(undefined *tstate,undefined *self,undefined **python_pars)

{
  int *piVar1;
  longlong *plVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  code *pcVar11;
  longlong *plVar12;
  longlong *plVar13;
  code *pcVar14;
  longlong lVar15;
  code *pcVar16;
  undefined *puVar17;
  longlong lVar18;
  code *pcVar19;
  undefined8 uVar20;
  code *pcVar21;
  undefined8 *puVar22;
  code *pcVar23;
  code *pcVar24;
  undefined4 uVar25;
  bool bVar26;
  undefined1 auStack_3b8 [32];
  code *pcStack_398;
  longlong *plStack_390;
  longlong *plStack_388;
  code *pcStack_380;
  code *pcStack_378;
  code *pcStack_370;
  code *pcStack_368;
  longlong *plStack_360;
  longlong *plStack_358;
  longlong *plStack_350;
  longlong *plStack_348;
  longlong *plStack_340;
  longlong *plStack_338;
  longlong *plStack_330;
  code *pcStack_328;
  longlong *plStack_320;
  longlong *plStack_318;
  longlong *plStack_310;
  longlong *plStack_308;
  longlong *plStack_300;
  longlong *plStack_2f8;
  longlong *plStack_2f0;
  longlong *plStack_2e8;
  longlong *plStack_2e0;
  longlong *plStack_2d8;
  code *pcStack_2d0;
  code *pcStack_2c8;
  code *pcStack_2c0;
  longlong *plStack_2b8;
  longlong *plStack_2b0;
  longlong *plStack_2a8;
  longlong *plStack_2a0;
  longlong *plStack_298;
  longlong *plStack_290;
  undefined4 uStack_288;
  code *pcStack_278;
  longlong *plStack_270;
  code *pcStack_268;
  code *pcStack_260;
  undefined8 *puStack_258;
  code *pcStack_250;
  longlong *plStack_248;
  undefined *puStack_240;
  longlong *plStack_238;
  longlong *plStack_230;
  code *pcStack_228;
  longlong *plStack_220;
  longlong *plStack_218;
  longlong *plStack_210;
  code *pcStack_208;
  longlong *plStack_200;
  code *pcStack_1f8;
  longlong *plStack_1f0;
  longlong *plStack_1e8;
  code *pcStack_1e0;
  longlong *plStack_1d8;
  longlong *plStack_1d0;
  longlong *plStack_1c8;
  longlong *plStack_1c0;
  longlong *plStack_1b8;
  longlong *plStack_1b0;
  longlong *plStack_1a8;
  code *pcStack_1a0;
  code *pcStack_198;
  longlong *plStack_190;
  longlong *plStack_188;
  longlong *plStack_180;
  longlong *plStack_178;
  longlong *plStack_170;
  longlong *plStack_168;
  longlong *plStack_160;
  longlong *plStack_158;
  longlong *plStack_150;
  longlong *plStack_148;
  longlong *plStack_140;
  longlong *plStack_138;
  longlong *plStack_130;
  longlong *plStack_128;
  code *pcStack_120;
  code *pcStack_118;
  longlong *plStack_110;
  longlong *plStack_108;
  code *pcStack_100;
  longlong *plStack_f8;
  longlong *plStack_f0;
  longlong *plStack_e8;
  longlong *plStack_e0;
  longlong *plStack_d8;
  code *pcStack_d0;
  longlong *plStack_c8;
  longlong *plStack_c0;
  longlong *plStack_b8;
  longlong *plStack_b0;
  longlong *plStack_a8;
  longlong *plStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_88;
  undefined *puStack_80;
  longlong *plStack_78;
  longlong *plStack_70;
  undefined *puStack_68;
  longlong *plStack_60;
  longlong *plStack_58;
  longlong *plStack_50;
  ulonglong uStack_48;
  
  plVar8 = _DAT_142dea7d0;
  uStack_48 = _DAT_142d9a1c0 ^ (ulonglong)auStack_3b8;
  plStack_f8 = (longlong *)*python_pars;
  plStack_108 = (longlong *)python_pars[1];
  pcStack_100 = (code *)python_pars[2];
  pcVar14 = (code *)0x0;
  pcVar24 = (code *)0x0;
  plStack_298 = (longlong *)0x0;
  pcVar21 = (code *)0x0;
  plStack_220 = (longlong *)0x0;
  pcStack_120 = (code *)0x0;
  pcStack_118 = (code *)0x0;
  pcStack_1e0 = (code *)0x0;
  pcStack_1f8 = (code *)0x0;
  plStack_160 = (longlong *)0x0;
  plStack_158 = (longlong *)0x0;
  plStack_150 = (longlong *)0x0;
  plStack_148 = (longlong *)0x0;
  plStack_140 = (longlong *)0x0;
  plStack_138 = (longlong *)0x0;
  plStack_168 = (longlong *)0x0;
  pcStack_228 = (code *)0x0;
  plStack_1d8 = (longlong *)0x0;
  plStack_178 = (longlong *)0x0;
  plStack_170 = (longlong *)0x0;
  plStack_1b0 = (longlong *)0x0;
  plStack_1c8 = (longlong *)0x0;
  plStack_230 = (longlong *)0x0;
  plStack_1a8 = (longlong *)0x0;
  plStack_1b8 = (longlong *)0x0;
  plStack_180 = (longlong *)0x0;
  plStack_188 = (longlong *)0x0;
  pcStack_268 = (code *)0x0;
  pcStack_260 = (code *)0x0;
  pcStack_278 = (code *)0x0;
  plStack_1d0 = (longlong *)0x0;
  plStack_1f0 = (longlong *)0x0;
  plStack_1c0 = (longlong *)0x0;
  plStack_1e8 = (longlong *)0x0;
  plStack_270 = _DAT_142dea7d0;
  puStack_240 = tstate;
  if (_DAT_142dea7d0 == (longlong *)0x0) {
LAB_1408d32c0:
    plStack_270 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9948,_DAT_142f2aaf0,0x110);
  }
  else if ((1 < *_DAT_142dea7d0) || (_DAT_142dea7d0[2] != 0)) {
    if ((_DAT_142dea7d0 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7d0 && (*_DAT_142dea7d0 = *_DAT_142dea7d0 + -1, *plVar8 == 0)))) {
      (**(code **)(plVar8[1] + 0x30))(plVar8);
    }
    goto LAB_1408d32c0;
  }
  plVar8 = plStack_270;
  _DAT_142dea7d0 = plStack_270;
  Nuitka_helper_140008a00(tstate,plStack_270);
  uVar20 = _DAT_142f2aae8;
  puVar17 = classes_const_1774_numpy;
  uVar25 = 0x240b;
  plStack_390 = (longlong *)shared_const_2_0;
  pcStack_398 = _Py_NoneStruct_exref;
  *(undefined4 *)(plVar8 + 5) = 0x240b;
  plVar7 = (longlong *)FUN_142cd5880(tstate,puVar17,uVar20);
  uVar20 = _DAT_142f2aae8;
  puVar17 = classes_const_1775_cv2;
  pcVar19 = pcVar14;
  if (plVar7 == (longlong *)0x0) {
    plVar7 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    plStack_210 = (longlong *)0x0;
    pcVar24 = (code *)0x0;
  }
  else {
    uVar25 = 0x240c;
    plStack_390 = (longlong *)shared_const_2_0;
    pcStack_398 = _Py_NoneStruct_exref;
    *(undefined4 *)(plVar8 + 5) = 0x240c;
    plStack_210 = plVar7;
    plStack_290 = (longlong *)FUN_142cd5880(tstate,puVar17,uVar20);
    if (plStack_290 == (longlong *)0x0) {
      plVar7 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      pcVar24 = pcVar14;
    }
    else {
      plStack_220 = plStack_290;
      plVar8 = (longlong *)FUN_142cd7b20(tstate,plStack_290,classes_const_1781_imdecode);
      if (plVar8 == (longlong *)0x0) {
        plVar7 = *(longlong **)(tstate + 0x70);
        uVar25 = 0x240e;
        *(undefined8 *)(tstate + 0x70) = 0;
        plVar8 = plStack_270;
        pcVar24 = pcVar14;
      }
      else {
        plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar7,classes_const_1782_frombuffer);
        if (plVar7 == (longlong *)0x0) {
          plStack_298 = *(longlong **)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
            (**(code **)(plVar8[1] + 0x30))(plVar8);
          }
          uVar25 = 0x240e;
          plVar8 = plStack_270;
          pcVar14 = pcVar24;
          pcVar19 = pcVar24;
          plVar7 = plStack_298;
        }
        else {
          plVar9 = (longlong *)FUN_142cd7b20(tstate,plStack_210,classes_const_1783_uint8);
          if (plVar9 == (longlong *)0x0) {
            plStack_298 = *(longlong **)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))(plVar8);
            }
            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
              (**(code **)(plVar7[1] + 0x30))(plVar7);
            }
            uVar25 = 0x240e;
            plVar8 = plStack_270;
            pcVar24 = pcVar14;
            plVar7 = plStack_298;
          }
          else {
            uVar25 = 0x240e;
            *(undefined4 *)(plStack_270 + 5) = 0x240e;
            pcStack_d0 = pcStack_100;
            plStack_c8 = plVar9;
            plVar10 = (longlong *)FUN_142cc4ec0(tstate,plVar7,&pcStack_d0);
            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
              (**(code **)(plVar7[1] + 0x30))(plVar7);
            }
            if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
            pcVar24 = pcVar21;
            if (plVar10 == (longlong *)0x0) {
LAB_1408d34e0:
              plStack_298 = *(longlong **)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))(plVar8);
              }
LAB_1408d3501:
              plVar8 = plStack_270;
              pcVar14 = (code *)0x0;
              pcVar19 = (code *)0x0;
              plVar7 = plStack_298;
            }
            else {
              plVar7 = (longlong *)
                       FUN_142cd7b20(tstate,plStack_220,classes_const_1826_IMREAD_UNCHANGED);
              if (plVar7 == (longlong *)0x0) {
                plStack_298 = *(longlong **)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                if (((int)*plVar10 < 0) || (*plVar10 = *plVar10 + -1, *plVar10 != 0))
                goto LAB_1408d3501;
                (**(code **)(plVar10[1] + 0x30))(plVar10);
                plVar8 = plStack_270;
                pcVar14 = (code *)0x0;
                pcVar19 = (code *)0x0;
                plVar7 = plStack_298;
              }
              else {
                *(undefined4 *)(plStack_270 + 5) = 0x240e;
                plStack_c0 = plVar10;
                plStack_b8 = plVar7;
                pcVar21 = (code *)FUN_142cc4ec0(tstate,plVar8,&plStack_c0);
                pcStack_1a0 = pcVar21;
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                  (**(code **)(plVar10[1] + 0x30))(plVar10);
                }
                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                }
                if (pcVar21 == (code *)0x0) {
                  plVar7 = *(longlong **)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  plVar8 = plStack_270;
                  pcVar14 = (code *)0x0;
                  pcVar19 = (code *)0x0;
                }
                else {
                  pcStack_120 = pcVar21;
                  plVar8 = (longlong *)FUN_142cd7b20(tstate,plStack_220,classes_const_1781_imdecode)
                  ;
                  plVar7 = plStack_210;
                  if (plVar8 == (longlong *)0x0) {
                    plStack_298 = *(longlong **)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x70) = 0;
                  }
                  else {
                    plVar9 = (longlong *)
                             FUN_142cd7b20(tstate,plStack_210,classes_const_1782_frombuffer);
                    if (plVar9 == (longlong *)0x0) {
                      plStack_298 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                      }
                    }
                    else {
                      plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar7,classes_const_1783_uint8);
                      if (plVar7 != (longlong *)0x0) {
                        uVar25 = 0x240f;
                        *(undefined4 *)(plStack_270 + 5) = 0x240f;
                        plStack_b0 = plStack_108;
                        plStack_a8 = plVar7;
                        plVar10 = (longlong *)FUN_142cc4ec0(tstate,plVar9,&plStack_b0);
                        if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                          (**(code **)(plVar9[1] + 0x30))(plVar9);
                        }
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (plVar10 == (longlong *)0x0) goto LAB_1408d34e0;
                        plVar9 = (longlong *)
                                 FUN_142cd7b20(tstate,plStack_220,
                                               classes_const_1826_IMREAD_UNCHANGED);
                        plVar7 = plStack_270;
                        if (plVar9 == (longlong *)0x0) {
                          plStack_298 = *(longlong **)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                          }
                          if (((int)*plVar10 < 0) || (*plVar10 = *plVar10 + -1, *plVar10 != 0))
                          goto LAB_1408d3501;
                          (**(code **)(plVar10[1] + 0x30))(plVar10);
                          plVar8 = plStack_270;
                          pcVar14 = (code *)0x0;
                          pcVar19 = (code *)0x0;
                          plVar7 = plStack_298;
                        }
                        else {
                          *(undefined4 *)(plStack_270 + 5) = 0x240f;
                          plStack_a0 = plVar10;
                          plStack_98 = plVar9;
                          pcStack_198 = (code *)FUN_142cc4ec0(tstate,plVar8,&plStack_a0);
                          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                          }
                          if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                            (**(code **)(plVar10[1] + 0x30))(plVar10);
                          }
                          if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                            (**(code **)(plVar9[1] + 0x30))(plVar9);
                          }
                          pcVar19 = pcStack_198;
                          pcVar21 = pcStack_1a0;
                          if (pcStack_198 == (code *)0x0) {
                            plVar7 = *(longlong **)(tstate + 0x70);
                            *(undefined8 *)(tstate + 0x70) = 0;
                            plVar8 = plStack_270;
                            pcVar14 = (code *)0x0;
                            pcVar19 = (code *)0x0;
                          }
                          else {
                            pcStack_118 = pcStack_198;
                            pcVar16 = pcVar14;
                            pcVar23 = pcVar14;
                            pcVar11 = pcVar14;
                            if (pcStack_1a0 == _Py_NoneStruct_exref ||
                                pcStack_198 == _Py_NoneStruct_exref) {
                              if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                              }
                              FUN_140008990(tstate);
                              goto LAB_1408d5dab;
                            }
                            plVar8 = (longlong *)
                                     FUN_142cd7b20(tstate,pcStack_1a0,classes_const_1795_shape);
                            if (plVar8 == (longlong *)0x0) {
LAB_1408d38a4:
                              plStack_298 = *(longlong **)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                            }
                            else {
                              plVar9 = (longlong *)FUN_142cc1f90(tstate,plVar8);
                              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                (**(code **)(plVar8[1] + 0x30))(plVar8);
                              }
                              if (plVar9 == (longlong *)0x0) goto LAB_1408d38a4;
                              cVar3 = Nuitka_helper_142ce2960(plVar9,3);
                              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                              }
                              pcVar21 = pcStack_1a0;
                              uVar4 = (uint)(cVar3 != '\0');
                              if (cVar3 != '\0') {
LAB_1408d39d8:
                                if (uVar4 == 1) {
                                  if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                    *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                                  }
                                  FUN_140008990(tstate);
                                  pcVar19 = pcStack_198;
                                  goto LAB_1408d5dab;
                                }
                                plVar8 = (longlong *)
                                         FUN_142cd7b20(tstate,plStack_210,classes_const_1837_where);
                                if (plVar8 == (longlong *)0x0) {
                                  plVar7 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  goto LAB_1408d6207;
                                }
                                plVar9 = (longlong *)
                                         FUN_140008da0(tstate,pcVar21,
                                                                                                              
                                                  classes_const_1831___type____T____items______type_________items____None__None__None_
                                                  );
                                if (plVar9 == (longlong *)0x0) {
LAB_1408d3a4b:
                                  plStack_298 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  plVar7 = plStack_298;
                                  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                  {
                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                    plVar7 = plStack_298;
                                  }
                                }
                                else {
                                  plVar10 = (longlong *)FUN_142ce1890(plVar9,classes_const_722_40);
                                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0))
                                  {
                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                  }
                                  if (plVar10 == (longlong *)0x0) goto LAB_1408d3a4b;
                                  *(undefined4 *)(plVar7 + 5) = 0x2414;
                                  plVar7 = (longlong *)FUN_142ccfd60(tstate,plVar8,plVar10);
                                  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                  {
                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                  }
                                  if ((-1 < (int)*plVar10) &&
                                     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                                  }
                                  if (plVar7 == (longlong *)0x0) {
                                    plVar7 = *(longlong **)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                  }
                                  else {
                                    plVar8 = (longlong *)FUN_1400099f0(plVar7);
                                    if ((-1 < (int)*plVar7) &&
                                       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                                    }
                                    if (plVar8 == (longlong *)0x0) {
                                      plVar7 = *(longlong **)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                    }
                                    else {
                                      pcVar24 = (code *)0x0;
                                      pcVar21 = (code *)(**(code **)(plVar8[1] + 0xe0))(plVar8);
                                      pcStack_208 = pcVar21;
                                      if (pcVar21 == (code *)0x0) {
                                        if ((*(longlong *)(tstate + 0x70) != 0) &&
                                           (lVar15 = *(longlong *)(*(longlong *)(tstate + 0x70) + 8)
                                           , lVar15 != 0)) {
                                          lVar18 = *(longlong *)(lVar15 + 8);
                                          if ((*(uint *)(*(longlong *)(lVar15 + 8) + 0xa8) &
                                              0x40000000) == 0) {
                                            lVar18 = lVar15;
                                          }
                                          if ((lVar18 != *(longlong *)PyExc_StopIteration_exref) &&
                                             (((pcVar21 = pcVar14,
                                               -1 < *(int *)(*(longlong *)(lVar18 + 8) + 0xa8) ||
                                               (pcVar21 = (code *)0x0,
                                               (*(uint *)(lVar18 + 0xa8) & 0x40000000) == 0)) ||
                                              (cVar3 = Nuitka_helper_142cdd950(), cVar3 != '\x01')))
                                             ) {
LAB_1408d3ba7:
                                            plStack_298 = *(longlong **)(tstate + 0x70);
                                            *(undefined8 *)(tstate + 0x70) = 0;
                                            goto LAB_1408d61b9;
                                          }
                                          plVar7 = *(longlong **)(tstate + 0x70);
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7))
                                             && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                            (**(code **)(plVar7[1] + 0x30))();
                                          }
                                        }
                                        uVar20 = 0;
                                        pcVar21 = pcVar14;
LAB_1408d3bd9:
                                        plVar7 = (longlong *)
                                                 PyUnicode_FromFormat(&UNK_142d0b0b0,2,uVar20);
                                        plStack_298 = (longlong *)
                                                      FUN_142ccfd60(tstate,*(undefined8 *)
                                                                            PyExc_ValueError_exref,
                                                                    plVar7);
                                        pcVar14 = pcVar24;
                                        if ((-1 < (int)*plVar7) &&
                                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                                        }
                                      }
                                      else {
                                        pcVar11 = (code *)(**(code **)(plVar8[1] + 0xe0))(plVar8);
                                        pcStack_250 = pcVar11;
                                        if (pcVar11 == (code *)0x0) {
                                          if ((*(longlong *)(tstate + 0x70) != 0) &&
                                             (lVar15 = *(longlong *)
                                                        (*(longlong *)(tstate + 0x70) + 8),
                                             lVar15 != 0)) {
                                            lVar18 = *(longlong *)(lVar15 + 8);
                                            if ((*(uint *)(*(longlong *)(lVar15 + 8) + 0xa8) &
                                                0x40000000) == 0) {
                                              lVar18 = lVar15;
                                            }
                                            if (lVar18 != *(longlong *)PyExc_StopIteration_exref) {
                                              if ((-1 < *(int *)(*(longlong *)(lVar18 + 8) + 0xa8))
                                                 || ((*(uint *)(lVar18 + 0xa8) & 0x40000000) == 0))
                                              goto LAB_1408d3ba7;
                                              cVar3 = Nuitka_helper_142cdd950();
                                              if (cVar3 != '\x01') {
                                                plStack_298 = *(longlong **)(tstate + 0x70);
                                                *(undefined8 *)(tstate + 0x70) = 0;
                                                pcVar14 = pcVar24;
                                                goto LAB_1408d61b9;
                                              }
                                            }
                                            plVar7 = *(longlong **)(tstate + 0x70);
                                            *(undefined8 *)(tstate + 0x70) = 0;
                                            if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7))
                                               && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                              (**(code **)(plVar7[1] + 0x30))();
                                            }
                                          }
                                          uVar20 = 1;
                                          goto LAB_1408d3bd9;
                                        }
                                        plVar7 = (longlong *)(**(code **)(plVar8[1] + 0xe0))(plVar8)
                                        ;
                                        if (plVar7 == (longlong *)0x0) {
                                          puVar22 = (undefined8 *)(tstate + 0x70);
                                          puStack_258 = puVar22;
                                          if ((*(longlong *)(tstate + 0x70) != 0) &&
                                             (lVar15 = *(longlong *)
                                                        (*(longlong *)(tstate + 0x70) + 8),
                                             lVar15 != 0)) {
                                            lVar18 = *(longlong *)(lVar15 + 8);
                                            if ((*(uint *)(*(longlong *)(lVar15 + 8) + 0xa8) &
                                                0x40000000) == 0) {
                                              lVar18 = lVar15;
                                            }
                                            if (lVar18 != *(longlong *)PyExc_StopIteration_exref) {
                                              if ((*(int *)(*(longlong *)(lVar18 + 8) + 0xa8) < 0)
                                                 && ((*(uint *)(lVar18 + 0xa8) & 0x40000000) != 0))
                                              {
                                                cVar3 = Nuitka_helper_142cdd950
                                                                  (lVar18,*(longlong *)
                                                                           PyExc_StopIteration_exref
                                                                  );
                                                plVar7 = (longlong *)*puVar22;
                                                if (cVar3 == '\x01') {
                                                  *puVar22 = 0;
                                                  if (plVar7 == (longlong *)0x0) goto LAB_1408d3d7f;
                                                  goto LAB_1408d3d6e;
                                                }
                                              }
                                              else {
                                                plVar7 = (longlong *)*puVar22;
                                              }
                                              *puVar22 = 0;
                                              pcVar14 = pcVar11;
                                              plStack_298 = plVar7;
                                              goto LAB_1408d61b9;
                                            }
                                            plVar7 = (longlong *)*puVar22;
                                            *puVar22 = 0;
LAB_1408d3d6e:
                                            if ((-1 < (int)*plVar7) &&
                                               (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                              (**(code **)(plVar7[1] + 0x30))();
                                            }
                                          }
LAB_1408d3d7f:
                                          if ((-1 < (int)*plVar8) &&
                                             (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                                          }
                                          iVar5 = *(int *)pcVar21;
                                          iVar6 = iVar5 + 1;
                                          if (iVar6 != 0) {
                                            *(int *)pcVar21 = iVar6;
                                            iVar5 = iVar6;
                                          }
                                          pcStack_1e0 = pcVar21;
                                          if ((-1 < iVar5) &&
                                             (*(longlong *)pcVar21 = *(longlong *)pcVar21 + -1,
                                             *(longlong *)pcVar21 == 0)) {
                                            (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))
                                                      (pcVar21);
                                          }
                                          iVar5 = *(int *)pcVar11;
                                          iVar6 = iVar5 + 1;
                                          if (iVar6 != 0) {
                                            *(int *)pcVar11 = iVar6;
                                            iVar5 = iVar6;
                                          }
                                          pcStack_1f8 = pcVar11;
                                          if ((-1 < iVar5) &&
                                             (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1,
                                             *(longlong *)pcVar11 == 0)) {
                                            (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))
                                                      (pcVar11);
                                          }
                                          plVar8 = (longlong *)FUN_142cc1f90(tstate,pcVar11);
                                          if (plVar8 == (longlong *)0x0) {
                                            plVar7 = (longlong *)*puVar22;
                                            uVar25 = 0x2415;
                                            *puVar22 = 0;
                                            plVar8 = plStack_270;
                                            pcVar14 = pcVar24;
                                            pcVar19 = pcVar24;
                                            goto LAB_1408d6219;
                                          }
                                          cVar3 = Nuitka_helper_142ce2960(plVar8,0x32);
                                          if ((-1 < (int)*plVar8) &&
                                             (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                                          }
                                          plVar8 = plStack_270;
                                          if (cVar3 != '\0') {
                                            if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                              *(int *)_Py_NoneStruct_exref =
                                                   *(int *)_Py_NoneStruct_exref + 1;
                                            }
                                            FUN_140008990(tstate);
                                            pcVar21 = pcStack_1a0;
                                            pcVar19 = pcStack_198;
                                            pcVar23 = pcStack_1e0;
                                            goto LAB_1408d5dab;
                                          }
                                          uVar25 = 0x2417;
                                          *(undefined4 *)(plStack_270 + 5) = 0x2417;
                                          plVar9 = (longlong *)
                                                   FUN_142cd06a0(tstate,pcVar11,
                                                                 classes_const_228_max);
                                          if (plVar9 != (longlong *)0x0) {
                                            *(undefined4 *)(plVar8 + 5) = 0x2417;
                                            plVar8 = (longlong *)
                                                     FUN_142cd06a0(tstate,pcVar11,
                                                                   classes_const_612_min);
                                            if (plVar8 == (longlong *)0x0) {
LAB_1408d3ecc:
                                              plStack_298 = (longlong *)*puVar22;
                                              *puVar22 = 0;
                                              plVar8 = plStack_270;
                                              pcVar14 = pcStack_268;
                                              pcVar24 = pcStack_268;
                                              pcVar19 = pcStack_268;
                                              plVar7 = plStack_298;
                                              if ((-1 < (int)*plVar9) &&
                                                 (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                plVar8 = plStack_270;
                                                pcVar14 = pcStack_268;
                                                pcVar24 = pcStack_268;
                                                pcVar19 = pcStack_268;
                                                plVar7 = plStack_298;
                                              }
                                              goto LAB_1408d6219;
                                            }
                                            plVar7 = (longlong *)FUN_142cc11d0(plVar9,plVar8);
                                            if ((-1 < (int)*plVar9) &&
                                               (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                              (**(code **)(plVar9[1] + 0x30))(plVar9);
                                            }
                                            if ((-1 < (int)*plVar8) &&
                                               (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                                            }
                                            if (plVar7 != (longlong *)0x0) {
                                              plVar8 = (longlong *)
                                                       FUN_142cbe6d0(plVar7,shared_const_3_1);
                                              if ((-1 < (int)*plVar7) &&
                                                 (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                                              }
                                              if (plVar8 != (longlong *)0x0) {
                                                plVar7 = (longlong *)PyNumber_Long(plVar8);
                                                plStack_f0 = plVar7;
                                                if ((-1 < (int)*plVar8) &&
                                                   (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                }
                                                pcVar14 = pcStack_208;
                                                plVar8 = plStack_270;
                                                if (plVar7 != (longlong *)0x0) {
                                                  uVar25 = 0x2418;
                                                  *(undefined4 *)(plStack_270 + 5) = 0x2418;
                                                  plStack_160 = plVar7;
                                                  plVar9 = (longlong *)
                                                           FUN_142cd06a0(tstate,pcStack_208,
                                                                         classes_const_228_max);
                                                  if (plVar9 != (longlong *)0x0) {
                                                    *(undefined4 *)(plVar8 + 5) = 0x2418;
                                                    plVar8 = (longlong *)
                                                             FUN_142cd06a0(tstate,pcVar14,
                                                                           classes_const_612_min);
                                                    if (plVar8 == (longlong *)0x0)
                                                    goto LAB_1408d3ecc;
                                                    plVar10 = (longlong *)
                                                              FUN_142cc11d0(plVar9,plVar8);
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if (plVar10 != (longlong *)0x0) {
                                                      plVar8 = (longlong *)
                                                               FUN_142cbe6d0(plVar10,
                                                  shared_const_3_1);
                                                  if ((-1 < (int)*plVar10) &&
                                                     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                  }
                                                  if (plVar8 != (longlong *)0x0) {
                                                    plStack_128 = (longlong *)PyNumber_Long(plVar8);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    plVar8 = plStack_270;
                                                    if (plStack_128 == (longlong *)0x0) {
                                                      plVar7 = (longlong *)*puVar22;
                                                      *puVar22 = 0;
                                                      pcVar14 = pcStack_268;
                                                      pcVar24 = pcStack_268;
                                                      pcVar19 = pcStack_268;
                                                    }
                                                    else {
                                                      uVar25 = 0x2419;
                                                      *(undefined4 *)(plStack_270 + 5) = 0x2419;
                                                      plStack_158 = plStack_128;
                                                      plStack_e0 = (longlong *)
                                                                   FUN_142cd06a0(tstate,pcStack_250,
                                                                                                                                                                  
                                                  classes_const_1964_mean);
                                                  if (plStack_e0 == (longlong *)0x0) {
                                                    plVar7 = (longlong *)*puVar22;
                                                    *puVar22 = 0;
                                                    pcVar14 = pcStack_268;
                                                    pcVar24 = pcStack_268;
                                                    pcVar19 = pcStack_268;
                                                  }
                                                  else {
                                                    uVar25 = 0x241a;
                                                    *(undefined4 *)(plVar8 + 5) = 0x241a;
                                                    plStack_150 = plStack_e0;
                                                    plStack_d8 = (longlong *)
                                                                 FUN_142cd06a0(tstate,pcStack_208,
                                                                                                                                                              
                                                  classes_const_1964_mean);
                                                  plVar9 = plStack_220;
                                                  if (plStack_d8 == (longlong *)0x0) {
                                                    plVar7 = (longlong *)*puVar22;
                                                    *puVar22 = 0;
                                                    pcVar14 = pcStack_268;
                                                    pcVar24 = pcStack_268;
                                                    pcVar19 = pcStack_268;
                                                  }
                                                  else {
                                                    plStack_148 = plStack_d8;
                                                    plVar8 = (longlong *)
                                                             FUN_142cd7b20(tstate,plStack_220,
                                                                                                                                                      
                                                  classes_const_1827_cvtColor);
                                                  if (plVar8 == (longlong *)0x0) {
                                                    plVar7 = (longlong *)*puVar22;
                                                    uVar25 = 0x241c;
                                                    *puVar22 = 0;
                                                    plVar8 = plStack_270;
                                                    pcVar14 = pcStack_268;
                                                    pcVar24 = pcStack_268;
                                                    pcVar19 = pcStack_268;
                                                  }
                                                  else {
                                                    plVar10 = (longlong *)
                                                              FUN_140008da0(tstate,pcStack_198,
                                                                                                                                                        
                                                  classes_const_1829___type____T____items______type_________items____None__None__None_
                                                  );
                                                  if (plVar10 == (longlong *)0x0) {
                                                    plStack_298 = (longlong *)*puVar22;
                                                    *puVar22 = 0;
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                  }
                                                  else {
                                                    plVar9 = (longlong *)
                                                             FUN_142cd7b20(tstate,plVar9,
                                                                                                                                                      
                                                  classes_const_1965_COLOR_BGR2HSV);
                                                  if (plVar9 != (longlong *)0x0) {
                                                    uVar25 = 0x241c;
                                                    *(undefined4 *)(plStack_270 + 5) = 0x241c;
                                                    plStack_90 = plVar10;
                                                    plStack_88 = plVar9;
                                                    plStack_238 = (longlong *)
                                                                  FUN_142cc4ec0(tstate,plVar8,
                                                                                &plStack_90);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if ((-1 < (int)*plVar10) &&
                                                       (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                                      (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                    }
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    plVar8 = plStack_238;
                                                    if (plStack_238 != (longlong *)0x0) {
                                                      plStack_140 = plStack_238;
                                                      plVar9 = (longlong *)
                                                               FUN_140008da0(tstate,plStack_238,
                                                                                                                                                          
                                                  classes_const_1966___type____T____items______type_________items____None__None__None_
                                                  );
                                                  uVar25 = 0x241d;
                                                  if (plVar9 != (longlong *)0x0) {
                                                    *(undefined4 *)(plStack_270 + 5) = 0x241d;
                                                    plVar10 = (longlong *)
                                                              FUN_142cd12f0(tstate,plVar9,
                                                                                                                                                        
                                                  classes_const_1967_astype,
                                                  *(undefined8 *)
                                                   (
                                                  classes_const_1968___type____T____items______type____O____name____int____
                                                  + 0x18));
                                                  plStack_110 = plVar10;
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  if (plVar10 != (longlong *)0x0) {
                                                    plStack_138 = plVar10;
                                                    plVar8 = (longlong *)
                                                             FUN_140008da0(tstate,plVar8,
                                                                                                                                                      
                                                  classes_const_1969___type____T____items______type_________items____None__None__None_
                                                  );
                                                  uVar25 = 0x241e;
                                                  if (plVar8 != (longlong *)0x0) {
                                                    *(undefined4 *)(plStack_270 + 5) = 0x241e;
                                                    plVar9 = (longlong *)
                                                             FUN_142cd12f0(tstate,plVar8,
                                                                           classes_const_1967_astype
                                                                           ,*(undefined8 *)
                                                                             (
                                                  classes_const_1968___type____T____items______type____O____name____int____
                                                  + 0x18));
                                                  plStack_e8 = plVar9;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if (plVar9 != (longlong *)0x0) {
                                                    plStack_130 = (longlong *)0x0;
                                                    pcStack_228 = _Py_NoneStruct_exref;
                                                    if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                                      *(int *)_Py_NoneStruct_exref =
                                                           *(int *)_Py_NoneStruct_exref + 1;
                                                    }
                                                    plStack_168 = plVar9;
                                                    plStack_190 = (longlong *)
                                                                  FUN_140009960(
                                                  classes_const_1970___type____T____items______type____T____items____30__190______type
                                                  );
                                                  plVar12 = (longlong *)
                                                            (**(code **)(plStack_190[1] + 0xe0))
                                                                      (plStack_190);
                                                  plVar8 = (longlong *)0x0;
                                                  if (plVar12 != (longlong *)0x0) {
                                                    uStack_288 = 0x2435;
                                                    plStack_130 = (longlong *)0x0;
LAB_1408d4400:
                                                    plVar8 = plVar12;
                                                    if (((plStack_130 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_130)) &&
                                                       (*plStack_130 = *plStack_130 + -1,
                                                       *plStack_130 == 0)) {
                                                      plVar8 = plStack_130 + 1;
                                                      plVar7 = plStack_130;
                                                      plStack_130 = plVar12;
                                                      (**(code **)(*plVar8 + 0x30))(plVar7);
                                                      plVar8 = plStack_130;
                                                    }
                                                    plStack_130 = plVar8;
                                                    plVar8 = (longlong *)FUN_1400099f0(plVar12);
                                                    if (plVar8 == (longlong *)0x0) {
                                                      plVar7 = (longlong *)*puVar22;
                                                      *puVar22 = 0;
                                                    }
                                                    else {
                                                      pcStack_398 = (code *)CONCAT44(pcStack_398.
                                                                                     _4_4_,2);
                                                      plVar9 = (longlong *)
                                                               FUN_140009d90(tstate,&plStack_298,
                                                                             plVar8,0);
                                                      if (plVar9 == (longlong *)0x0) {
                                                        plVar9 = (longlong *)0x0;
LAB_1408d5be6:
                                                        plVar10 = (longlong *)0x0;
                                                      }
                                                      else {
                                                        pcStack_398 = (code *)CONCAT44(pcStack_398.
                                                                                       _4_4_,2);
                                                        plVar10 = (longlong *)
                                                                  FUN_140009d90(tstate,&plStack_298,
                                                                                plVar8,1);
                                                        if (plVar10 == (longlong *)0x0)
                                                        goto LAB_1408d5be6;
                                                        cVar3 = FUN_140009c30(tstate,&plStack_298,
                                                                              plVar8,2);
                                                        plVar12 = plStack_178;
                                                        plVar7 = plStack_1d8;
                                                        if (cVar3 != '\0') {
                                                          if ((-1 < (int)*plVar8) &&
                                                             (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                                          {
                                                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                          }
                                                          iVar6 = (int)*plVar9 + 1;
                                                          if (iVar6 != 0) {
                                                            *(int *)plVar9 = iVar6;
                                                          }
                                                          plStack_1d8 = plVar9;
                                                          if (((plVar7 != (longlong *)0x0) &&
                                                              (-1 < (int)*plVar7)) &&
                                                             (*plVar7 = *plVar7 + -1, *plVar7 == 0))
                                                          {
                                                            (**(code **)(plVar7[1] + 0x30))();
                                                          }
                                                          if ((-1 < (int)*plVar9) &&
                                                             (*plVar9 = *plVar9 + -1, *plVar9 == 0))
                                                          {
                                                            (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                          }
                                                          iVar6 = (int)*plVar10 + 1;
                                                          if (iVar6 != 0) {
                                                            *(int *)plVar10 = iVar6;
                                                          }
                                                          plStack_178 = plVar10;
                                                          if (((plVar12 != (longlong *)0x0) &&
                                                              (-1 < (int)*plVar12)) &&
                                                             (*plVar12 = *plVar12 + -1,
                                                             *plVar12 == 0)) {
                                                            (**(code **)(plVar12[1] + 0x30))();
                                                          }
                                                          if ((-1 < (int)*plVar10) &&
                                                             (*plVar10 = *plVar10 + -1,
                                                             *plVar10 == 0)) {
                                                            (**(code **)(plVar10[1] + 0x30))
                                                                      (plVar10);
                                                          }
                                                          plVar8 = (longlong *)
                                                                   FUN_142ce3540(plStack_110,plVar9)
                                                          ;
                                                          if (plVar8 == (longlong *)0x0)
                                                          goto LAB_1408d5bdc;
                                                          plVar7 = (longlong *)
                                                                   FUN_142ce1980(plStack_e8,plVar10)
                                                          ;
                                                          if (plVar7 == (longlong *)0x0) {
LAB_1408d5bac:
                                                            plStack_298 = (longlong *)*puVar22;
                                                            *puVar22 = 0;
                                                            if ((-1 < (int)*plVar8) &&
                                                               (*plVar8 = *plVar8 + -1, *plVar8 == 0
                                                               )) {
                                                              (**(code **)(plVar8[1] + 0x30))
                                                                        (plVar8);
                                                            }
                                                            pcVar24 = pcStack_278;
                                                            uVar25 = 0x2423;
                                                            plVar7 = plStack_298;
                                                            goto LAB_1408d5c75;
                                                          }
                                                          plVar9 = (longlong *)
                                                                   FUN_142cbecf0(plVar8,plVar7);
                                                          if ((-1 < (int)*plVar8) &&
                                                             (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                                          {
                                                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                          }
                                                          if ((-1 < (int)*plVar7) &&
                                                             (*plVar7 = *plVar7 + -1, *plVar7 == 0))
                                                          {
                                                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                          }
                                                          if (plVar9 != (longlong *)0x0) {
                                                            plVar8 = (longlong *)
                                                                     FUN_142cd7b20(tstate,plVar9,
                                                                                                                                                                      
                                                  classes_const_1967_astype);
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  plVar7 = plStack_210;
                                                  if (plVar8 != (longlong *)0x0) {
                                                    plVar9 = (longlong *)
                                                             FUN_142cd7b20(tstate,plStack_210,
                                                                           classes_const_1783_uint8)
                                                    ;
                                                    if (plVar9 == (longlong *)0x0)
                                                    goto LAB_1408d5bac;
                                                    *(undefined4 *)(plStack_270 + 5) = 0x2423;
                                                    plVar10 = (longlong *)
                                                              FUN_142ccfd60(tstate,plVar8,plVar9);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    if (plVar10 == (longlong *)0x0) {
                                                      plVar7 = *(longlong **)(tstate + 0x70);
                                                      *(undefined8 *)(tstate + 0x70) = 0;
                                                      pcVar24 = pcStack_278;
                                                      uVar25 = 0x2423;
                                                      goto LAB_1408d5c75;
                                                    }
                                                    plVar8 = plVar10;
                                                    if (((plStack_170 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_170)) &&
                                                       (*plStack_170 = *plStack_170 + -1,
                                                       *plStack_170 == 0)) {
                                                      plVar8 = plStack_170 + 1;
                                                      plStack_170 = plVar10;
                                                      (**(code **)(*plVar8 + 0x30))();
                                                      plVar8 = plStack_170;
                                                    }
                                                    plStack_170 = plVar8;
                                                    plVar8 = plStack_220;
                                                    plVar9 = (longlong *)
                                                             FUN_142cd7b20(tstate,plStack_220,
                                                                                                                                                      
                                                  classes_const_1971_morphologyEx);
                                                  if (plVar9 == (longlong *)0x0) {
LAB_1408d5a97:
                                                    plStack_298 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                  }
                                                  else {
                                                    plVar8 = (longlong *)
                                                             FUN_142cd7b20(tstate,plVar8,
                                                                                                                                                      
                                                  classes_const_1972_MORPH_CLOSE);
                                                  if (plVar8 == (longlong *)0x0) {
                                                    plStack_298 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                      pcVar24 = pcStack_278;
                                                      uVar25 = 0x2424;
                                                      plVar7 = plStack_298;
                                                      goto LAB_1408d5c75;
                                                    }
                                                  }
                                                  else {
                                                    plVar12 = (longlong *)
                                                              FUN_142cd7b20(tstate,plVar7,
                                                                            classes_const_1973_ones)
                                                    ;
                                                    puVar17 = 
                                                  classes_const_1820___type____T____items____3__3__;
                                                  if (plVar12 == (longlong *)0x0) {
LAB_1408d5ab2:
                                                    plStack_298 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                      pcVar24 = pcStack_278;
                                                      uVar25 = 0x2424;
                                                      plVar7 = plStack_298;
                                                      goto LAB_1408d5c75;
                                                    }
                                                  }
                                                  else {
                                                    plVar7 = (longlong *)
                                                             FUN_142cd7b20(tstate,plVar7,
                                                                           classes_const_1783_uint8)
                                                    ;
                                                    if (plVar7 != (longlong *)0x0) {
                                                      *(undefined4 *)(plStack_270 + 5) = 0x2424;
                                                      puStack_80 = puVar17;
                                                      plStack_78 = plVar7;
                                                      plVar13 = (longlong *)
                                                                FUN_142cc4ec0(tstate,plVar12,
                                                                              &puStack_80);
                                                      if ((-1 < (int)*plVar12) &&
                                                         (*plVar12 = *plVar12 + -1, *plVar12 == 0))
                                                      {
                                                        (**(code **)(plVar12[1] + 0x30))(plVar12);
                                                      }
                                                      if ((-1 < (int)*plVar7) &&
                                                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                        (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                      }
                                                      plVar7 = plStack_270;
                                                      if (plVar13 == (longlong *)0x0)
                                                      goto LAB_1408d5ab2;
                                                      *(undefined4 *)(plStack_270 + 5) = 0x2424;
                                                      plStack_60 = plVar10;
                                                      plStack_58 = plVar8;
                                                      plStack_50 = plVar13;
                                                      plVar12 = (longlong *)
                                                                FUN_142cc5e90(tstate,plVar9,
                                                                              &plStack_60);
                                                      if ((-1 < (int)*plVar9) &&
                                                         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                      }
                                                      if ((-1 < (int)*plVar8) &&
                                                         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                      }
                                                      if ((-1 < (int)*plVar13) &&
                                                         (*plVar13 = *plVar13 + -1, *plVar13 == 0))
                                                      {
                                                        (**(code **)(plVar13[1] + 0x30))(plVar13);
                                                      }
                                                      if (plVar12 == (longlong *)0x0)
                                                      goto LAB_1408d5a97;
                                                      plStack_170 = plVar12;
                                                      if ((-1 < (int)*plVar10) &&
                                                         (*plVar10 = *plVar10 + -1, *plVar10 == 0))
                                                      {
                                                        (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                      }
                                                      puStack_68 = classes_const_116_8;
                                                      *(undefined4 *)(plVar7 + 5) = 0x2425;
                                                      plStack_70 = plVar12;
                                                      plVar8 = (longlong *)
                                                               FUN_142cd07f0(tstate,plStack_220,
                                                                                                                                                          
                                                  classes_const_1974_connectedComponentsWithStats,
                                                  &plStack_70);
                                                  if (plVar8 != (longlong *)0x0) {
                                                    plVar9 = (longlong *)FUN_1400099f0(plVar8);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if (plVar9 != (longlong *)0x0) {
                                                      pcStack_398 = (code *)CONCAT44(pcStack_398.
                                                                                     _4_4_,4);
                                                      plVar8 = (longlong *)
                                                               FUN_140009d90(tstate,&plStack_298,
                                                                             plVar9,0);
                                                      if (plVar8 == (longlong *)0x0) {
                                                        plVar8 = (longlong *)0x0;
LAB_1408d59d4:
                                                        plVar10 = (longlong *)0x0;
LAB_1408d59d7:
                                                        plVar12 = (longlong *)0x0;
LAB_1408d59da:
                                                        plVar13 = (longlong *)0x0;
                                                      }
                                                      else {
                                                        pcStack_398 = (code *)CONCAT44(pcStack_398.
                                                                                       _4_4_,4);
                                                        plVar10 = (longlong *)
                                                                  FUN_140009d90(tstate,&plStack_298,
                                                                                plVar9,1);
                                                        if (plVar10 == (longlong *)0x0)
                                                        goto LAB_1408d59d4;
                                                        pcStack_398 = (code *)CONCAT44(pcStack_398.
                                                                                       _4_4_,4);
                                                        plVar12 = (longlong *)
                                                                  FUN_140009d90(tstate,&plStack_298,
                                                                                plVar9,2);
                                                        if (plVar12 == (longlong *)0x0)
                                                        goto LAB_1408d59d7;
                                                        pcStack_398 = (code *)CONCAT44(pcStack_398.
                                                                                       _4_4_,4);
                                                        plVar13 = (longlong *)
                                                                  FUN_140009d90(tstate,&plStack_298,
                                                                                plVar9,3);
                                                        if (plVar13 == (longlong *)0x0)
                                                        goto LAB_1408d59da;
                                                        cVar3 = FUN_140009c30(puStack_240,
                                                                              &plStack_298,plVar9);
                                                        plVar2 = plStack_1b0;
                                                        plVar7 = plStack_1c8;
                                                        if (cVar3 != '\0') {
                                                          if ((-1 < (int)*plVar9) &&
                                                             (*plVar9 = *plVar9 + -1, *plVar9 == 0))
                                                          {
                                                            (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                          }
                                                          iVar6 = (int)*plVar8 + 1;
                                                          if (iVar6 != 0) {
                                                            *(int *)plVar8 = iVar6;
                                                          }
                                                          plStack_1b0 = plVar8;
                                                          if (((plVar2 != (longlong *)0x0) &&
                                                              (-1 < (int)*plVar2)) &&
                                                             (*plVar2 = *plVar2 + -1, *plVar2 == 0))
                                                          {
                                                            (**(code **)(plVar2[1] + 0x30))();
                                                          }
                                                          if ((-1 < (int)*plVar8) &&
                                                             (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                                          {
                                                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                          }
                                                          iVar6 = (int)*plVar10 + 1;
                                                          if (iVar6 != 0) {
                                                            *(int *)plVar10 = iVar6;
                                                          }
                                                          plStack_1c8 = plVar10;
                                                          if (((plVar7 != (longlong *)0x0) &&
                                                              (-1 < (int)*plVar7)) &&
                                                             (*plVar7 = *plVar7 + -1, *plVar7 == 0))
                                                          {
                                                            (**(code **)(plVar7[1] + 0x30))();
                                                          }
                                                          if ((-1 < (int)*plVar10) &&
                                                             (*plVar10 = *plVar10 + -1,
                                                             *plVar10 == 0)) {
                                                            (**(code **)(plVar10[1] + 0x30))
                                                                      (plVar10);
                                                          }
                                                          iVar6 = (int)*plVar12 + 1;
                                                          if (iVar6 != 0) {
                                                            *(int *)plVar12 = iVar6;
                                                          }
                                                          plVar7 = plVar12;
                                                          if (((plStack_230 != (longlong *)0x0) &&
                                                              (-1 < (int)*plStack_230)) &&
                                                             (*plStack_230 = *plStack_230 + -1,
                                                             *plStack_230 == 0)) {
                                                            plVar7 = plStack_230 + 1;
                                                            plStack_230 = plVar12;
                                                            (**(code **)(*plVar7 + 0x30))();
                                                            plVar7 = plStack_230;
                                                          }
                                                          plStack_230 = plVar7;
                                                          if ((-1 < (int)*plVar12) &&
                                                             (*plVar12 = *plVar12 + -1,
                                                             *plVar12 == 0)) {
                                                            (**(code **)(plVar12[1] + 0x30))
                                                                      (plVar12);
                                                          }
                                                          iVar6 = (int)*plVar13 + 1;
                                                          if (iVar6 != 0) {
                                                            *(int *)plVar13 = iVar6;
                                                          }
                                                          plVar7 = plVar13;
                                                          if (((plStack_1a8 != (longlong *)0x0) &&
                                                              (-1 < (int)*plStack_1a8)) &&
                                                             (*plStack_1a8 = *plStack_1a8 + -1,
                                                             *plStack_1a8 == 0)) {
                                                            plVar7 = plStack_1a8 + 1;
                                                            plStack_1a8 = plVar13;
                                                            (**(code **)(*plVar7 + 0x30))();
                                                            plVar7 = plStack_1a8;
                                                          }
                                                          plStack_1a8 = plVar7;
                                                          if ((-1 < (int)*plVar13) &&
                                                             (*plVar13 = *plVar13 + -1,
                                                             *plVar13 == 0)) {
                                                            (**(code **)(plVar13[1] + 0x30))
                                                                      (plVar13);
                                                          }
                                                          tstate = puStack_240;
                                                          plVar8 = (longlong *)
                                                                   Nuitka_helper_142cc2f20
                                                                             (puStack_240,
                                                                              shared_const_3_1,
                                                                              plVar8);
                                                          if (plVar8 != (longlong *)0x0) {
                                                            plVar9 = (longlong *)
                                                                     FUN_140009850(tstate,plVar8);
                                                            plStack_218 = plVar9;
                                                            if ((-1 < (int)*plVar8) &&
                                                               (*plVar8 = *plVar8 + -1, *plVar8 == 0
                                                               )) {
                                                              (**(code **)(plVar8[1] + 0x30))
                                                                        (plVar8);
                                                            }
                                                            if (plVar9 != (longlong *)0x0) {
                                                              plVar8 = (longlong *)0x0;
                                                              pcVar14 = pcStack_268;
LAB_1408d4ad0:
                                                              do {
                                                                plStack_248 = (longlong *)
                                                                              (**(code **)(plVar9[1]
                                                                                          + 0xe0))
                                                                                        (plVar9);
                                                                if (plStack_248 == (longlong *)0x0)
                                                                goto LAB_1408d5403;
                                                                plStack_200 = plStack_248;
                                                                if (((plVar8 != (longlong *)0x0) &&
                                                                    (-1 < (int)*plVar8)) &&
                                                                   (*plVar8 = *plVar8 + -1,
                                                                   *plVar8 == 0)) {
                                                                  (**(code **)(plVar8[1] + 0x30))
                                                                            (plVar8);
                                                                }
                                                                iVar6 = (int)*plStack_248 + 1;
                                                                if (iVar6 != 0) {
                                                                  *(int *)plStack_248 = iVar6;
                                                                }
                                                                plVar8 = plStack_248;
                                                                if (((plStack_1b8 != (longlong *)0x0
                                                                     ) && (plVar8 = plStack_248,
                                                                          -1 < (int)*plStack_1b8))
                                                                   && (*plStack_1b8 = *plStack_1b8 +
                                                                                      -1,
                                                                      plVar8 = plStack_248,
                                                                      *plStack_1b8 == 0)) {
                                                                  plVar8 = plStack_1b8 + 1;
                                                                  plStack_1b8 = plStack_248;
                                                                  (**(code **)(*plVar8 + 0x30))();
                                                                  plVar8 = plStack_1b8;
                                                                }
                                                                plStack_1b8 = plVar8;
                                                                plVar8 = (longlong *)
                                                                         FUN_140008da0(tstate,
                                                  plVar12,plStack_248);
                                                  if (plVar8 == (longlong *)0x0) {
LAB_1408d58cd:
                                                    uStack_288 = 0x2427;
                                                    plVar7 = (longlong *)*puStack_258;
                                                    *puStack_258 = 0;
                                                    pcVar24 = pcStack_278;
                                                    plVar8 = plStack_200;
                                                    goto LAB_1408d5977;
                                                  }
                                                  plVar9 = (longlong *)FUN_1400099f0(plVar8);
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if (plVar9 == (longlong *)0x0) goto LAB_1408d58cd;
                                                  pcStack_398 = (code *)CONCAT44(pcStack_398._4_4_,5
                                                                                );
                                                  plVar8 = (longlong *)
                                                           FUN_140009d90(tstate,&plStack_298,plVar9,
                                                                         0);
                                                  if (plVar8 == (longlong *)0x0) {
                                                    plVar8 = (longlong *)0x0;
LAB_1408d5804:
                                                    plVar10 = (longlong *)0x0;
LAB_1408d5807:
                                                    pcVar14 = (code *)0x0;
LAB_1408d580a:
                                                    pcVar24 = (code *)0x0;
LAB_1408d580d:
                                                    pcVar21 = (code *)0x0;
LAB_1408d5810:
                                                    plVar7 = plStack_298;
                                                    uStack_288 = 0x2427;
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    if (((plVar8 != (longlong *)0x0) &&
                                                        (-1 < (int)*plVar8)) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if (((plVar10 != (longlong *)0x0) &&
                                                        (-1 < (int)*plVar10)) &&
                                                       (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                                      (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                    }
                                                    if (((pcVar14 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar14)) &&
                                                       (*(longlong *)pcVar14 =
                                                             *(longlong *)pcVar14 + -1,
                                                       *(longlong *)pcVar14 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30
                                                                  ))(pcVar14);
                                                    }
                                                    if (((pcVar24 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar24)) &&
                                                       (*(longlong *)pcVar24 =
                                                             *(longlong *)pcVar24 + -1,
                                                       *(longlong *)pcVar24 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar24 + 8) + 0x30
                                                                  ))(pcVar24);
                                                    }
                                                    pcVar24 = pcStack_278;
                                                    plVar8 = plStack_200;
                                                    if (((pcVar21 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar21)) &&
                                                       (*(longlong *)pcVar21 =
                                                             *(longlong *)pcVar21 + -1,
                                                       *(longlong *)pcVar21 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30
                                                                  ))(pcVar21);
                                                      pcVar24 = pcStack_278;
                                                      plVar8 = plStack_200;
                                                    }
                                                    goto LAB_1408d5977;
                                                  }
                                                  pcStack_398 = (code *)CONCAT44(pcStack_398._4_4_,5
                                                                                );
                                                  plVar10 = (longlong *)
                                                            FUN_140009d90(tstate,&plStack_298,plVar9
                                                                          ,1);
                                                  if (plVar10 == (longlong *)0x0)
                                                  goto LAB_1408d5804;
                                                  pcStack_398 = (code *)CONCAT44(pcStack_398._4_4_,5
                                                                                );
                                                  pcVar14 = (code *)FUN_140009d90(tstate,&
                                                  plStack_298,plVar9,2);
                                                  if (pcVar14 == (code *)0x0) goto LAB_1408d5807;
                                                  pcStack_398 = (code *)CONCAT44(pcStack_398._4_4_,5
                                                                                );
                                                  pcVar24 = (code *)FUN_140009d90(tstate,&
                                                  plStack_298,plVar9,3);
                                                  if (pcVar24 == (code *)0x0) goto LAB_1408d580a;
                                                  pcStack_398 = (code *)CONCAT44(pcStack_398._4_4_,5
                                                                                );
                                                  pcVar21 = (code *)FUN_140009d90(tstate,&
                                                  plStack_298,plVar9,4);
                                                  if (pcVar21 == (code *)0x0) goto LAB_1408d580d;
                                                  cVar3 = FUN_140009c30(puStack_240,&plStack_298);
                                                  if (cVar3 == '\0') goto LAB_1408d5810;
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  iVar6 = (int)*plVar8 + 1;
                                                  if (iVar6 != 0) {
                                                    *(int *)plVar8 = iVar6;
                                                  }
                                                  plVar7 = plVar8;
                                                  if (((plStack_180 != (longlong *)0x0) &&
                                                      (-1 < (int)*plStack_180)) &&
                                                     (*plStack_180 = *plStack_180 + -1,
                                                     *plStack_180 == 0)) {
                                                    plVar7 = plStack_180 + 1;
                                                    plStack_180 = plVar8;
                                                    (**(code **)(*plVar7 + 0x30))();
                                                    plVar7 = plStack_180;
                                                  }
                                                  plStack_180 = plVar7;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  iVar6 = (int)*plVar10 + 1;
                                                  if (iVar6 != 0) {
                                                    *(int *)plVar10 = iVar6;
                                                  }
                                                  plVar8 = plVar10;
                                                  if (((plStack_188 != (longlong *)0x0) &&
                                                      (-1 < (int)*plStack_188)) &&
                                                     (*plStack_188 = *plStack_188 + -1,
                                                     *plStack_188 == 0)) {
                                                    plVar8 = plStack_188 + 1;
                                                    plStack_188 = plVar10;
                                                    (**(code **)(*plVar8 + 0x30))();
                                                    plVar8 = plStack_188;
                                                  }
                                                  plStack_188 = plVar8;
                                                  if ((-1 < (int)*plVar10) &&
                                                     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                  }
                                                  if (*(int *)pcVar14 + 1 != 0) {
                                                    *(int *)pcVar14 = *(int *)pcVar14 + 1;
                                                  }
                                                  pcVar19 = pcVar14;
                                                  if (((pcStack_268 != (code *)0x0) &&
                                                      (-1 < *(int *)pcStack_268)) &&
                                                     (*(longlong *)pcStack_268 =
                                                           *(longlong *)pcStack_268 + -1,
                                                     *(longlong *)pcStack_268 == 0)) {
                                                    pcVar19 = pcStack_268 + 8;
                                                    pcStack_268 = pcVar14;
                                                    (**(code **)(*(longlong *)pcVar19 + 0x30))();
                                                    pcVar19 = pcStack_268;
                                                  }
                                                  pcStack_268 = pcVar19;
                                                  if ((-1 < *(int *)pcVar14) &&
                                                     (*(longlong *)pcVar14 =
                                                           *(longlong *)pcVar14 + -1,
                                                     *(longlong *)pcVar14 == 0)) {
                                                    (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))
                                                              (pcVar14);
                                                  }
                                                  if (*(int *)pcVar24 + 1 != 0) {
                                                    *(int *)pcVar24 = *(int *)pcVar24 + 1;
                                                  }
                                                  pcVar19 = pcVar24;
                                                  if (((pcStack_260 != (code *)0x0) &&
                                                      (-1 < *(int *)pcStack_260)) &&
                                                     (*(longlong *)pcStack_260 =
                                                           *(longlong *)pcStack_260 + -1,
                                                     *(longlong *)pcStack_260 == 0)) {
                                                    pcVar19 = pcStack_260 + 8;
                                                    pcStack_260 = pcVar24;
                                                    (**(code **)(*(longlong *)pcVar19 + 0x30))();
                                                    pcVar19 = pcStack_260;
                                                  }
                                                  pcStack_260 = pcVar19;
                                                  if ((-1 < *(int *)pcVar24) &&
                                                     (*(longlong *)pcVar24 =
                                                           *(longlong *)pcVar24 + -1,
                                                     *(longlong *)pcVar24 == 0)) {
                                                    (**(code **)(*(longlong *)(pcVar24 + 8) + 0x30))
                                                              (pcVar24);
                                                  }
                                                  if (*(int *)pcVar21 + 1 != 0) {
                                                    *(int *)pcVar21 = *(int *)pcVar21 + 1;
                                                  }
                                                  pcVar24 = pcVar21;
                                                  if (((pcStack_278 != (code *)0x0) &&
                                                      (-1 < *(int *)pcStack_278)) &&
                                                     (*(longlong *)pcStack_278 =
                                                           *(longlong *)pcStack_278 + -1,
                                                     *(longlong *)pcStack_278 == 0)) {
                                                    pcVar24 = pcStack_278 + 8;
                                                    pcStack_278 = pcVar21;
                                                    (**(code **)(*(longlong *)pcVar24 + 0x30))();
                                                    pcVar24 = pcStack_278;
                                                  }
                                                  pcStack_278 = pcVar24;
                                                  if ((-1 < *(int *)pcVar21) &&
                                                     (*(longlong *)pcVar21 =
                                                           *(longlong *)pcVar21 + -1,
                                                     *(longlong *)pcVar21 == 0)) {
                                                    (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))
                                                              (pcVar21);
                                                  }
                                                  plVar7 = plStack_f0;
                                                  plVar8 = (longlong *)
                                                           func_0x000142cc0180(
                                                  classes_const_1975_0_6,plStack_f0);
                                                  if (plVar8 == (longlong *)0x0) {
LAB_1408d57d9:
                                                    plVar7 = (longlong *)*puStack_258;
                                                    *puStack_258 = 0;
                                                    uStack_288 = 0x2428;
                                                    pcVar24 = pcVar21;
                                                    plVar8 = plStack_200;
                                                    goto LAB_1408d5977;
                                                  }
                                                  iVar6 = FUN_142ce2e00(pcVar14,plVar8);
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  plVar9 = plStack_218;
                                                  plVar12 = plStack_230;
                                                  tstate = puStack_240;
                                                  if (iVar6 == -1) goto LAB_1408d57d9;
                                                  plVar8 = plStack_200;
                                                  if (iVar6 != 1) {
                                                    plVar8 = (longlong *)
                                                             func_0x000142cc0180(
                                                  classes_const_1977_1_4,plVar7);
                                                  if (plVar8 != (longlong *)0x0) {
                                                    iVar6 = FUN_142ce13d0(pcVar14,plVar8);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if (iVar6 != -1) {
                                                      plVar8 = plStack_200;
                                                      if (iVar6 != 1) {
                                                        plVar8 = (longlong *)
                                                                 func_0x000142cc0180(
                                                  classes_const_1975_0_6,plStack_128);
                                                  pcVar24 = pcStack_260;
                                                  if (plVar8 != (longlong *)0x0) {
                                                    iVar6 = FUN_142ce2e00(pcStack_260,plVar8);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if (iVar6 != -1) {
                                                      plVar8 = plStack_200;
                                                      plVar12 = plStack_230;
                                                      if (iVar6 == 1) goto LAB_1408d4ad0;
                                                      plVar8 = (longlong *)
                                                               func_0x000142cc0180(
                                                  classes_const_1977_1_4,plStack_128);
                                                  if (plVar8 != (longlong *)0x0) {
                                                    iVar6 = FUN_142ce13d0(pcVar24,plVar8);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    plVar8 = plStack_200;
                                                    if (iVar6 != -1) {
                                                      plVar12 = plStack_230;
                                                      if (iVar6 != 1) {
                                                        plVar9 = (longlong *)
                                                                 FUN_142cd7b20(tstate,plStack_210,
                                                                                                                                                              
                                                  classes_const_1837_where);
                                                  if (plVar9 == (longlong *)0x0) goto LAB_1408d5760;
                                                  plVar8 = (longlong *)
                                                           FUN_142ce0130(plStack_1c8,plVar8);
                                                  plVar10 = plStack_270;
                                                  if (plVar8 == (longlong *)0x0) {
                                                    plStack_298 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    plVar7 = plStack_298;
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                      plVar7 = plStack_298;
                                                    }
                                                  }
                                                  else {
                                                    *(undefined4 *)(plStack_270 + 5) = 0x242c;
                                                    plVar12 = (longlong *)
                                                              FUN_142ccfd60(tstate,plVar9,plVar8);
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if (plVar12 != (longlong *)0x0) {
                                                      plVar8 = (longlong *)FUN_1400099f0(plVar12);
                                                      if ((-1 < (int)*plVar12) &&
                                                         (*plVar12 = *plVar12 + -1, *plVar12 == 0))
                                                      {
                                                        (**(code **)(plVar12[1] + 0x30))(plVar12);
                                                      }
                                                      if (plVar8 != (longlong *)0x0) {
                                                        pcStack_398 = (code *)CONCAT44(pcStack_398.
                                                                                       _4_4_,2);
                                                        plVar9 = (longlong *)
                                                                 FUN_140009d90(tstate,&plStack_298,
                                                                               plVar8,0);
                                                        if (plVar9 == (longlong *)0x0) {
                                                          plVar9 = (longlong *)0x0;
LAB_1408d56cb:
                                                          plVar12 = (longlong *)0x0;
                                                        }
                                                        else {
                                                          pcStack_398 = (code *)CONCAT44(pcStack_398
                                                                                         ._4_4_,2);
                                                          plVar12 = (longlong *)
                                                                    FUN_140009d90(tstate,&
                                                  plStack_298,plVar8,1);
                                                  if (plVar12 == (longlong *)0x0)
                                                  goto LAB_1408d56cb;
                                                  cVar3 = FUN_140009c30(tstate,&plStack_298,plVar8);
                                                  if (cVar3 != '\0') {
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    iVar6 = (int)*plVar9 + 1;
                                                    if (iVar6 != 0) {
                                                      *(int *)plVar9 = iVar6;
                                                    }
                                                    plVar8 = plVar9;
                                                    if (((plStack_1d0 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1d0)) &&
                                                       (*plStack_1d0 = *plStack_1d0 + -1,
                                                       *plStack_1d0 == 0)) {
                                                      plVar8 = plStack_1d0 + 1;
                                                      plStack_1d0 = plVar9;
                                                      (**(code **)(*plVar8 + 0x30))();
                                                      plVar8 = plStack_1d0;
                                                    }
                                                    plStack_1d0 = plVar8;
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    iVar6 = (int)*plVar12 + 1;
                                                    if (iVar6 != 0) {
                                                      *(int *)plVar12 = iVar6;
                                                    }
                                                    plVar8 = plVar12;
                                                    if (((plStack_1f0 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1f0)) &&
                                                       (*plStack_1f0 = *plStack_1f0 + -1,
                                                       *plStack_1f0 == 0)) {
                                                      plVar8 = plStack_1f0 + 1;
                                                      plStack_1f0 = plVar12;
                                                      (**(code **)(*plVar8 + 0x30))();
                                                      plVar8 = plStack_1f0;
                                                    }
                                                    plStack_1f0 = plVar8;
                                                    if ((-1 < (int)*plVar12) &&
                                                       (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                                      (**(code **)(plVar12[1] + 0x30))(plVar12);
                                                    }
                                                    *(undefined4 *)(plVar10 + 5) = 0x242d;
                                                    plVar8 = (longlong *)
                                                             FUN_142cd06a0(tstate,plVar9);
                                                    if (plVar8 != (longlong *)0x0) {
                                                      plVar9 = (longlong *)
                                                               FUN_142cc11d0(plVar8,plStack_d8);
                                                      if ((-1 < (int)*plVar8) &&
                                                         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                      }
                                                      if (plVar9 != (longlong *)0x0) {
                                                        plVar13 = (longlong *)
                                                                  Nuitka_helper_142cc1650(plVar9);
                                                        if ((-1 < (int)*plVar9) &&
                                                           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                          (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                        }
                                                        plVar8 = plStack_1c0;
                                                        if (plVar13 != (longlong *)0x0) {
                                                          plVar9 = plVar13;
                                                          if (((plStack_1c0 != (longlong *)0x0) &&
                                                              (-1 < (int)*plStack_1c0)) &&
                                                             (*plStack_1c0 = *plStack_1c0 + -1,
                                                             *plStack_1c0 == 0)) {
                                                            plVar9 = plStack_1c0 + 1;
                                                            plStack_1c0 = plVar13;
                                                            (**(code **)(*plVar9 + 0x30))(plVar8);
                                                            plVar9 = plStack_1c0;
                                                          }
                                                          plStack_1c0 = plVar9;
                                                          iVar6 = FUN_142ce1250(plVar13,
                                                  classes_const_721_6);
                                                  plVar8 = plStack_200;
                                                  if (iVar6 == -1) {
                                                    plVar7 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    uStack_288 = 0x2431;
                                                    pcVar24 = pcStack_278;
                                                    goto LAB_1408d5977;
                                                  }
                                                  plVar9 = plStack_218;
                                                  plVar12 = plStack_230;
                                                  pcVar14 = pcStack_268;
                                                  if (iVar6 != 1) {
                                                    plVar8 = (longlong *)
                                                             FUN_142cc11d0(pcStack_268,plVar7);
                                                    if (plVar8 != (longlong *)0x0) {
                                                      plVar9 = (longlong *)
                                                               Nuitka_helper_142cc1650(plVar8);
                                                      if ((-1 < (int)*plVar8) &&
                                                         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                      }
                                                      if (plVar9 != (longlong *)0x0) {
                                                        plVar8 = (longlong *)
                                                                 Nuitka_helper_142ce5200(plVar7);
                                                        if (plVar8 == (longlong *)0x0) {
                                                          plStack_298 = *(longlong **)
                                                                         (tstate + 0x70);
                                                          *(undefined8 *)(tstate + 0x70) = 0;
                                                          if ((-1 < (int)*plVar9) &&
                                                             (*plVar9 = *plVar9 + -1, *plVar9 == 0))
                                                          {
                                                            (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                          }
                                                          uStack_288 = 0x2433;
                                                          plVar7 = plStack_298;
                                                          pcVar24 = pcStack_278;
                                                          plVar8 = plStack_200;
                                                          goto LAB_1408d5977;
                                                        }
                                                        plVar7 = (longlong *)
                                                                 FUN_142cc1540(plVar9,plVar8);
                                                        if ((-1 < (int)*plVar9) &&
                                                           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                          (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                        }
                                                        if ((-1 < (int)*plVar8) &&
                                                           (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                          (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                        }
                                                        if (plVar7 != (longlong *)0x0) {
                                                          plVar8 = (longlong *)
                                                                   FUN_142cc04f0(plVar7,
                                                  classes_const_272_10);
                                                  if ((-1 < (int)*plVar7) &&
                                                     (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                  }
                                                  if (plVar8 != (longlong *)0x0) {
                                                    plVar7 = (longlong *)
                                                             FUN_142cbe7f0(plVar13,plVar8);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    plVar8 = plStack_1e8;
                                                    if (plVar7 != (longlong *)0x0) {
                                                      plVar9 = plVar7;
                                                      if (((plStack_1e8 != (longlong *)0x0) &&
                                                          (-1 < (int)*plStack_1e8)) &&
                                                         (*plStack_1e8 = *plStack_1e8 + -1,
                                                         *plStack_1e8 == 0)) {
                                                        plVar9 = plStack_1e8 + 1;
                                                        plStack_1e8 = plVar7;
                                                        (**(code **)(*plVar9 + 0x30))(plVar8);
                                                        plVar9 = plStack_1e8;
                                                      }
                                                      plStack_1e8 = plVar9;
                                                      pcVar14 = pcStack_228;
                                                      if (pcStack_228 == (code *)0x0) {
                                                        FUN_142cd4900(tstate,&plStack_298,
                                                                      classes_const_1255_melhor);
                                                        FUN_1400048d0(tstate,plStack_298);
                                                        uStack_288 = 0x2434;
                                                        plVar7 = plStack_298;
                                                        pcVar24 = pcStack_278;
                                                        plVar8 = plStack_200;
                                                        goto LAB_1408d5977;
                                                      }
                                                      uVar4 = (uint)(pcStack_228 ==
                                                                    _Py_NoneStruct_exref);
                                                      if (pcStack_228 != _Py_NoneStruct_exref) {
                                                        plVar8 = (longlong *)
                                                                 FUN_140008f40(tstate,pcStack_228,
                                                                               shared_const_2_0);
                                                        if (plVar8 != (longlong *)0x0) {
                                                          uVar4 = FUN_142ce2e00(plVar7,plVar8);
                                                          if ((-1 < (int)*plVar8) &&
                                                             (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                                          {
                                                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                          }
                                                          if (uVar4 != 0xffffffff)
                                                          goto LAB_1408d534b;
                                                        }
                                                        plVar7 = (longlong *)*puStack_258;
                                                        uStack_288 = 0x2434;
                                                        *puStack_258 = 0;
                                                        pcVar24 = pcStack_278;
                                                        plVar8 = plStack_200;
                                                        goto LAB_1408d5977;
                                                      }
LAB_1408d534b:
                                                      if (uVar4 == 1) {
                                                        pcVar21 = (code *)FUN_142cd9440(tstate,2);
                                                        uVar25 = uStack_288;
                                                        iVar6 = (int)*plVar7 + 1;
                                                        if (iVar6 != 0) {
                                                          *(int *)plVar7 = iVar6;
                                                        }
                                                        *(longlong **)(pcVar21 + 0x18) = plVar7;
                                                        *(undefined4 *)(plVar10 + 5) = uStack_288;
                                                        plVar8 = (longlong *)
                                                                 FUN_142cd06a0(tstate,plStack_1f0,
                                                                                                                                                              
                                                  classes_const_1964_mean);
                                                  if (plVar8 != (longlong *)0x0) {
                                                    lVar15 = FUN_142cc11d0(plVar8,plStack_e0);
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))();
                                                    }
                                                    uVar25 = uStack_288;
                                                    if (lVar15 != 0) {
                                                      *(longlong *)(pcVar21 + 0x20) = lVar15;
                                                      pcStack_228 = pcVar21;
                                                      if ((-1 < *(int *)pcVar14) &&
                                                         (*(longlong *)pcVar14 =
                                                               *(longlong *)pcVar14 + -1,
                                                         *(longlong *)pcVar14 == 0)) {
                                                        (**(code **)(*(longlong *)(pcVar14 + 8) +
                                                                    0x30))(pcVar14);
                                                      }
                                                      goto LAB_1408d53e6;
                                                    }
                                                  }
                                                  uStack_288 = uVar25;
                                                  plStack_298 = (longlong *)*puStack_258;
                                                  *puStack_258 = 0;
                                                  plVar7 = plStack_298;
                                                  pcVar24 = pcStack_278;
                                                  plVar8 = plStack_200;
                                                  if ((-1 < *(int *)pcVar21) &&
                                                     (*(longlong *)pcVar21 =
                                                           *(longlong *)pcVar21 + -1,
                                                     *(longlong *)pcVar21 == 0)) {
                                                    (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))
                                                              (pcVar21);
                                                    plVar7 = plStack_298;
                                                    pcVar24 = pcStack_278;
                                                    plVar8 = plStack_200;
                                                  }
                                                  goto LAB_1408d5977;
                                                  }
LAB_1408d53e6:
                                                  cVar3 = FUN_140008af0(tstate);
                                                  plVar9 = plStack_218;
                                                  plVar8 = plStack_200;
                                                  plVar12 = plStack_230;
                                                  pcVar14 = pcStack_268;
                                                  if (cVar3 == '\0') {
                                                    plVar7 = (longlong *)*puStack_258;
                                                    uStack_288 = 0x2426;
                                                    *puStack_258 = 0;
                                                    pcVar24 = pcStack_278;
                                                    goto LAB_1408d5977;
                                                  }
                                                  goto LAB_1408d4ad0;
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  plVar7 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  uStack_288 = 0x2433;
                                                  pcVar24 = pcStack_278;
                                                  plVar8 = plStack_200;
                                                  goto LAB_1408d5977;
                                                  }
                                                  goto LAB_1408d4ad0;
                                                  }
                                                  }
                                                  }
                                                  plVar7 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  uStack_288 = 0x242d;
                                                  pcVar24 = pcStack_278;
                                                  plVar8 = plStack_200;
                                                  goto LAB_1408d5977;
                                                  }
                                                  }
                                                  plVar7 = plStack_298;
                                                  uStack_288 = 0x242c;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if (((plVar9 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar9)) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  pcVar24 = pcStack_278;
                                                  plVar8 = plStack_200;
                                                  if (((plVar12 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar12)) &&
                                                     (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                                    (**(code **)(plVar12[1] + 0x30))(plVar12);
                                                    pcVar24 = pcStack_278;
                                                    plVar8 = plStack_200;
                                                  }
                                                  goto LAB_1408d5977;
                                                  }
                                                  }
LAB_1408d5760:
                                                  plVar7 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  }
                                                  uStack_288 = 0x242c;
                                                  pcVar24 = pcStack_278;
                                                  plVar8 = plStack_200;
                                                  goto LAB_1408d5977;
                                                  }
                                                  goto LAB_1408d4ad0;
                                                  }
                                                  }
                                                  }
                                                  }
                                                  plVar7 = (longlong *)*puStack_258;
                                                  *puStack_258 = 0;
                                                  uStack_288 = 0x242a;
                                                  pcVar24 = pcStack_278;
                                                  plVar8 = plStack_200;
                                                  goto LAB_1408d5977;
                                                  }
                                                  goto LAB_1408d4ad0;
                                                  }
                                                  }
                                                  plVar7 = (longlong *)*puStack_258;
                                                  *puStack_258 = 0;
                                                  uStack_288 = 0x2428;
                                                  pcVar24 = pcStack_278;
                                                  plVar8 = plStack_200;
                                                  goto LAB_1408d5977;
                                                  }
                                                  } while( true );
                                                  }
                                                  }
                                                  plVar7 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  pcVar24 = pcStack_278;
                                                  uVar25 = 0x2426;
                                                  goto LAB_1408d5c75;
                                                  }
                                                  }
                                                  plVar7 = plStack_298;
                                                  uStack_288 = 0x2425;
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  if (((plVar8 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar8)) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if (((plVar10 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar10)) &&
                                                     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                  }
                                                  if (((plVar12 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar12)) &&
                                                     (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                                    (**(code **)(plVar12[1] + 0x30))(plVar12);
                                                  }
                                                  pcVar24 = pcStack_278;
                                                  tstate = puStack_240;
                                                  uVar25 = uStack_288;
                                                  if (((plVar13 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar13)) &&
                                                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                                                    pcVar24 = pcStack_278;
                                                    tstate = puStack_240;
                                                    uVar25 = uStack_288;
                                                  }
                                                  goto LAB_1408d5c75;
                                                  }
                                                  }
                                                  plVar7 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  pcVar24 = pcStack_278;
                                                  uVar25 = 0x2425;
                                                  goto LAB_1408d5c75;
                                                  }
                                                  plStack_298 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if ((-1 < (int)*plVar12) &&
                                                     (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                                    (**(code **)(plVar12[1] + 0x30))(plVar12);
                                                    pcVar24 = pcStack_278;
                                                    uVar25 = 0x2424;
                                                    plVar7 = plStack_298;
                                                    goto LAB_1408d5c75;
                                                  }
                                                  }
                                                  }
                                                  }
                                                  pcVar24 = pcStack_278;
                                                  uVar25 = 0x2424;
                                                  plVar7 = plStack_298;
                                                  goto LAB_1408d5c75;
                                                  }
                                                  }
LAB_1408d5bdc:
                                                  uVar25 = 0x2423;
                                                  goto LAB_1408d5c61;
                                                  }
                                                  }
                                                  plVar7 = plStack_298;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if (((plVar9 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar9)) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  if (((plVar10 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar10)) &&
                                                     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                    pcVar24 = pcStack_278;
                                                    uVar25 = 0x2422;
                                                    goto LAB_1408d5c75;
                                                  }
                                                  }
                                                  pcVar24 = pcStack_278;
                                                  uVar25 = 0x2422;
                                                  goto LAB_1408d5c75;
                                                  }
LAB_1408d54c2:
                                                  plVar12 = (longlong *)*puVar22;
                                                  if (plVar12 != (longlong *)0x0) {
                                                    cVar3 = FUN_140008d40(tstate,plVar12,
                                                                          *(undefined8 *)
                                                                           PyExc_StopIteration_exref
                                                                         );
                                                    if (cVar3 == '\0') {
LAB_1408d5c5b:
                                                      uVar25 = 0x2422;
LAB_1408d5c61:
                                                      plVar7 = (longlong *)*puVar22;
                                                      *puVar22 = 0;
                                                      pcVar24 = pcStack_278;
LAB_1408d5c75:
                                                      plStack_298 = plVar7;
                                                      plVar7 = plStack_298;
                                                      plStack_298 = (longlong *)0x0;
                                                      if (((plStack_130 != (longlong *)0x0) &&
                                                          (-1 < (int)*plStack_130)) &&
                                                         (*plStack_130 = *plStack_130 + -1,
                                                         *plStack_130 == 0)) {
                                                        (**(code **)(plStack_130[1] + 0x30))();
                                                      }
                                                      plVar8 = plStack_270;
                                                      pcVar14 = pcStack_268;
                                                      pcVar19 = pcStack_260;
                                                      if ((-1 < (int)*plStack_190) &&
                                                         (*plStack_190 = *plStack_190 + -1,
                                                         *plStack_190 == 0)) {
                                                        (**(code **)(plStack_190[1] + 0x30))();
                                                        plVar8 = plStack_270;
                                                        pcVar14 = pcStack_268;
                                                        pcVar19 = pcStack_260;
                                                      }
                                                      goto LAB_1408d6219;
                                                    }
                                                    *puVar22 = 0;
                                                    if ((-1 < (int)*plVar12) &&
                                                       (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                                      (**(code **)(plVar12[1] + 0x30))(plVar12);
                                                    }
                                                  }
                                                  if (((plVar8 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar8)) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if ((-1 < (int)*plStack_190) &&
                                                     (*plStack_190 = *plStack_190 + -1,
                                                     *plStack_190 == 0)) {
                                                    (**(code **)(plStack_190[1] + 0x30))();
                                                  }
                                                  pcVar14 = pcStack_228;
                                                  if (pcStack_228 != (code *)0x0) {
                                                    if (pcStack_228 == _Py_NoneStruct_exref) {
                                                      if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                                        *(int *)_Py_NoneStruct_exref =
                                                             *(int *)_Py_NoneStruct_exref + 1;
                                                      }
                                                      FUN_140008990(tstate);
                                                      pcVar21 = pcStack_1a0;
                                                      pcVar19 = pcStack_198;
                                                      pcVar16 = pcStack_278;
                                                      pcVar23 = pcStack_1e0;
                                                      pcVar11 = pcStack_1f8;
                                                    }
                                                    else {
                                                      lVar15 = FUN_140008f40(tstate,pcStack_228,
                                                                             shared_const_3_1,1);
                                                      if (lVar15 == 0) {
                                                        plVar7 = (longlong *)*puVar22;
                                                        uVar25 = 0x2438;
                                                        *puVar22 = 0;
                                                        plVar8 = plStack_270;
                                                        pcVar14 = pcStack_268;
                                                        pcVar24 = pcStack_278;
                                                        pcVar19 = pcStack_260;
                                                        goto LAB_1408d6219;
                                                      }
                                                      FUN_140008990(tstate);
                                                      pcStack_1f8 = pcStack_250;
                                                      plStack_158 = plStack_128;
                                                      plStack_150 = plStack_e0;
                                                      plStack_148 = plStack_d8;
                                                      plStack_140 = plStack_238;
                                                      pcVar21 = pcStack_1a0;
                                                      pcVar19 = pcStack_198;
                                                      pcVar16 = pcStack_278;
                                                      pcVar23 = pcStack_208;
                                                      pcVar11 = pcStack_250;
                                                      plStack_168 = plVar9;
                                                      plStack_160 = plVar7;
                                                      plStack_138 = plVar10;
                                                    }
LAB_1408d5dab:
                                                    if ((-1 < (int)*plStack_210) &&
                                                       (*plStack_210 = *plStack_210 + -1,
                                                       *plStack_210 == 0)) {
                                                      (**(code **)(plStack_210[1] + 0x30))();
                                                    }
                                                    if ((-1 < (int)*plStack_290) &&
                                                       (*plStack_290 = *plStack_290 + -1,
                                                       *plStack_290 == 0)) {
                                                      (**(code **)(plStack_220[1] + 0x30))();
                                                    }
                                                    if ((-1 < *(int *)pcVar21) &&
                                                       (*(longlong *)pcVar21 =
                                                             *(longlong *)pcVar21 + -1,
                                                       *(longlong *)pcVar21 == 0)) {
                                                      (**(code **)(*(longlong *)(pcStack_120 + 8) +
                                                                  0x30))();
                                                    }
                                                    if ((-1 < *(int *)pcVar19) &&
                                                       (*(longlong *)pcVar19 =
                                                             *(longlong *)pcVar19 + -1,
                                                       *(longlong *)pcVar19 == 0)) {
                                                      (**(code **)(*(longlong *)(pcStack_118 + 8) +
                                                                  0x30))();
                                                    }
                                                    if (((pcVar23 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar23)) &&
                                                       (*(longlong *)pcVar23 =
                                                             *(longlong *)pcVar23 + -1,
                                                       *(longlong *)pcVar23 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar23 + 8) + 0x30
                                                                  ))(pcVar23);
                                                    }
                                                    if (((pcVar11 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar11)) &&
                                                       (*(longlong *)pcVar11 =
                                                             *(longlong *)pcVar11 + -1,
                                                       *(longlong *)pcVar11 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30
                                                                  ))(pcVar11);
                                                    }
                                                    if (((plStack_160 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_160)) &&
                                                       (*plStack_160 = *plStack_160 + -1,
                                                       *plStack_160 == 0)) {
                                                      (**(code **)(plStack_160[1] + 0x30))();
                                                    }
                                                    if (((plStack_158 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_158)) &&
                                                       (*plStack_158 = *plStack_158 + -1,
                                                       *plStack_158 == 0)) {
                                                      (**(code **)(plStack_158[1] + 0x30))();
                                                    }
                                                    if (((plStack_150 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_150)) &&
                                                       (*plStack_150 = *plStack_150 + -1,
                                                       *plStack_150 == 0)) {
                                                      (**(code **)(plStack_150[1] + 0x30))();
                                                    }
                                                    if (((plStack_148 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_148)) &&
                                                       (*plStack_148 = *plStack_148 + -1,
                                                       *plStack_148 == 0)) {
                                                      (**(code **)(plStack_148[1] + 0x30))();
                                                    }
                                                    if (((plStack_140 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_140)) &&
                                                       (*plStack_140 = *plStack_140 + -1,
                                                       *plStack_140 == 0)) {
                                                      (**(code **)(plStack_140[1] + 0x30))();
                                                    }
                                                    if (((plStack_138 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_138)) &&
                                                       (*plStack_138 = *plStack_138 + -1,
                                                       *plStack_138 == 0)) {
                                                      (**(code **)(plStack_138[1] + 0x30))();
                                                    }
                                                    if (((plStack_168 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_168)) &&
                                                       (*plStack_168 = *plStack_168 + -1,
                                                       *plStack_168 == 0)) {
                                                      (**(code **)(plStack_168[1] + 0x30))();
                                                    }
                                                    if (((pcVar14 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar14)) &&
                                                       (*(longlong *)pcVar14 =
                                                             *(longlong *)pcVar14 + -1,
                                                       *(longlong *)pcVar14 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30
                                                                  ))(pcVar14);
                                                    }
                                                    if (((plStack_1d8 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1d8)) &&
                                                       (*plStack_1d8 = *plStack_1d8 + -1,
                                                       *plStack_1d8 == 0)) {
                                                      (**(code **)(plStack_1d8[1] + 0x30))();
                                                    }
                                                    if (((plStack_178 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_178)) &&
                                                       (*plStack_178 = *plStack_178 + -1,
                                                       *plStack_178 == 0)) {
                                                      (**(code **)(plStack_178[1] + 0x30))();
                                                    }
                                                    if (((plStack_170 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_170)) &&
                                                       (*plStack_170 = *plStack_170 + -1,
                                                       *plStack_170 == 0)) {
                                                      (**(code **)(plStack_170[1] + 0x30))();
                                                    }
                                                    if (((plStack_1b0 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1b0)) &&
                                                       (*plStack_1b0 = *plStack_1b0 + -1,
                                                       *plStack_1b0 == 0)) {
                                                      (**(code **)(plStack_1b0[1] + 0x30))();
                                                    }
                                                    if (((plStack_1c8 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1c8)) &&
                                                       (*plStack_1c8 = *plStack_1c8 + -1,
                                                       *plStack_1c8 == 0)) {
                                                      (**(code **)(plStack_1c8[1] + 0x30))();
                                                    }
                                                    if (((plStack_230 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_230)) &&
                                                       (*plStack_230 = *plStack_230 + -1,
                                                       *plStack_230 == 0)) {
                                                      (**(code **)(plStack_230[1] + 0x30))();
                                                    }
                                                    if (((plStack_1a8 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1a8)) &&
                                                       (*plStack_1a8 = *plStack_1a8 + -1,
                                                       *plStack_1a8 == 0)) {
                                                      (**(code **)(plStack_1a8[1] + 0x30))();
                                                    }
                                                    if (((plStack_1b8 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1b8)) &&
                                                       (*plStack_1b8 = *plStack_1b8 + -1,
                                                       *plStack_1b8 == 0)) {
                                                      (**(code **)(plStack_1b8[1] + 0x30))();
                                                    }
                                                    if (((plStack_180 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_180)) &&
                                                       (*plStack_180 = *plStack_180 + -1,
                                                       *plStack_180 == 0)) {
                                                      (**(code **)(plStack_180[1] + 0x30))();
                                                    }
                                                    if (((plStack_188 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_188)) &&
                                                       (*plStack_188 = *plStack_188 + -1,
                                                       *plStack_188 == 0)) {
                                                      (**(code **)(plStack_188[1] + 0x30))();
                                                    }
                                                    if (((pcStack_268 != (code *)0x0) &&
                                                        (-1 < *(int *)pcStack_268)) &&
                                                       (*(longlong *)pcStack_268 =
                                                             *(longlong *)pcStack_268 + -1,
                                                       *(longlong *)pcStack_268 == 0)) {
                                                      (**(code **)(*(longlong *)(pcStack_268 + 8) +
                                                                  0x30))();
                                                    }
                                                    if (((pcStack_260 != (code *)0x0) &&
                                                        (-1 < *(int *)pcStack_260)) &&
                                                       (*(longlong *)pcStack_260 =
                                                             *(longlong *)pcStack_260 + -1,
                                                       *(longlong *)pcStack_260 == 0)) {
                                                      (**(code **)(*(longlong *)(pcStack_260 + 8) +
                                                                  0x30))();
                                                    }
                                                    if (((pcVar16 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar16)) &&
                                                       (*(longlong *)pcVar16 =
                                                             *(longlong *)pcVar16 + -1,
                                                       *(longlong *)pcVar16 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar16 + 8) + 0x30
                                                                  ))(pcVar16);
                                                    }
                                                    if (((plStack_1d0 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1d0)) &&
                                                       (*plStack_1d0 = *plStack_1d0 + -1,
                                                       *plStack_1d0 == 0)) {
                                                      (**(code **)(plStack_1d0[1] + 0x30))();
                                                    }
                                                    if (((plStack_1f0 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1f0)) &&
                                                       (*plStack_1f0 = *plStack_1f0 + -1,
                                                       *plStack_1f0 == 0)) {
                                                      (**(code **)(plStack_1f0[1] + 0x30))();
                                                    }
                                                    if (((plStack_1c0 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1c0)) &&
                                                       (*plStack_1c0 = *plStack_1c0 + -1,
                                                       *plStack_1c0 == 0)) {
                                                      (**(code **)(plStack_1c0[1] + 0x30))();
                                                    }
                                                    if (((plStack_1e8 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_1e8)) &&
                                                       (*plStack_1e8 = *plStack_1e8 + -1,
                                                       *plStack_1e8 == 0)) {
                                                      (**(code **)(plStack_1e8[1] + 0x30))();
                                                    }
                                                    if ((-1 < (int)*plStack_f8) &&
                                                       (*plStack_f8 = *plStack_f8 + -1,
                                                       *plStack_f8 == 0)) {
                                                      (**(code **)(plStack_f8[1] + 0x30))();
                                                    }
                                                    if ((-1 < (int)*plStack_108) &&
                                                       (*plStack_108 = *plStack_108 + -1,
                                                       *plStack_108 == 0)) {
                                                      (**(code **)(plStack_108[1] + 0x30))();
                                                    }
                                                    if ((-1 < *(int *)pcStack_100) &&
                                                       (*(longlong *)pcStack_100 =
                                                             *(longlong *)pcStack_100 + -1,
                                                       *(longlong *)pcStack_100 == 0)) {
                                                      (**(code **)(*(longlong *)(pcStack_100 + 8) +
                                                                  0x30))();
                                                    }
                                                    goto LAB_1408d686c;
                                                  }
                                                  FUN_142cd4900(tstate,&plStack_298,
                                                                classes_const_1255_melhor);
                                                  FUN_1400048d0(tstate,plStack_298);
                                                  uVar25 = 0x2436;
                                                  plVar8 = plStack_270;
                                                  pcVar14 = pcStack_268;
                                                  pcVar24 = pcStack_278;
                                                  pcVar19 = pcStack_260;
                                                  plVar7 = plStack_298;
                                                  goto LAB_1408d6219;
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  goto LAB_1408d3e99;
                                                  }
                                                  plStack_298 = (longlong *)*puVar22;
                                                  *puVar22 = 0;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if ((-1 < (int)*plVar10) &&
                                                     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                                                    uVar25 = 0x241c;
                                                    plVar8 = plStack_270;
                                                    pcVar14 = pcStack_268;
                                                    pcVar24 = pcStack_268;
                                                    pcVar19 = pcStack_268;
                                                    plVar7 = plStack_298;
                                                    goto LAB_1408d6219;
                                                  }
                                                  }
                                                  uVar25 = 0x241c;
                                                  plVar8 = plStack_270;
                                                  pcVar14 = pcStack_268;
                                                  pcVar24 = pcStack_268;
                                                  pcVar19 = pcStack_268;
                                                  plVar7 = plStack_298;
                                                  }
                                                  }
                                                  }
                                                  }
                                                  goto LAB_1408d6219;
                                                  }
                                                  }
                                                  }
                                                }
                                              }
                                            }
                                          }
LAB_1408d3e99:
                                          plVar7 = (longlong *)*puVar22;
                                          *puVar22 = 0;
                                          plVar8 = plStack_270;
                                          pcVar14 = pcStack_268;
                                          pcVar24 = pcStack_268;
                                          pcVar19 = pcStack_268;
                                          goto LAB_1408d6219;
                                        }
                                        if ((-1 < (int)*plVar7) &&
                                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                                        }
                                        plVar7 = (longlong *)PyUnicode_FromFormat(&UNK_142d0b0e8,2);
                                        plStack_298 = (longlong *)
                                                      FUN_142ccfd60(tstate,*(undefined8 *)
                                                                            PyExc_ValueError_exref,
                                                                    plVar7);
                                        pcVar14 = pcStack_250;
                                        if ((-1 < (int)*plVar7) &&
                                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                                          pcVar14 = pcStack_250;
                                        }
                                      }
LAB_1408d61b9:
                                      plVar7 = plStack_298;
                                      if ((-1 < (int)*plVar8) &&
                                         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                                      }
                                      if (((pcVar21 != (code *)0x0) && (-1 < *(int *)pcVar21)) &&
                                         (*(longlong *)pcVar21 = *(longlong *)pcVar21 + -1,
                                         *(longlong *)pcVar21 == 0)) {
                                        (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))(pcVar21);
                                      }
                                      if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                                         (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                                         *(longlong *)pcVar14 == 0)) {
                                        (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                                      }
                                    }
                                  }
                                }
LAB_1408d6207:
                                uVar25 = 0x2414;
                                plVar8 = plStack_270;
                                pcVar14 = pcStack_268;
                                pcVar24 = pcStack_268;
                                pcVar19 = pcStack_268;
                                goto LAB_1408d6219;
                              }
                              plVar8 = (longlong *)
                                       FUN_142cd7b20(tstate,pcStack_1a0,classes_const_1795_shape);
                              if (plVar8 == (longlong *)0x0) {
                                plStack_298 = *(longlong **)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                              }
                              else {
                                plVar9 = (longlong *)
                                         FUN_140008f40(tstate,plVar8,classes_const_605_2,2);
                                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                                }
                                if (plVar9 == (longlong *)0x0) {
                                  plStack_298 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                }
                                else {
                                  uVar4 = FUN_142ce2c80(plVar9,classes_const_1029_4);
                                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0))
                                  {
                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                  }
                                  if (uVar4 != 0xffffffff) goto LAB_1408d39d8;
                                  plStack_298 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                }
                              }
                            }
                            uVar25 = 0x2412;
                            plVar8 = plStack_270;
                            pcVar14 = (code *)0x0;
                            pcVar19 = (code *)0x0;
                            plVar7 = plStack_298;
                          }
                        }
                        goto LAB_1408d6219;
                      }
                      plStack_298 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                      }
                      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                      }
                    }
                  }
                  uVar25 = 0x240f;
                  plVar8 = plStack_270;
                  pcVar14 = (code *)0x0;
                  pcVar19 = (code *)0x0;
                  plVar7 = plStack_298;
                }
              }
            }
          }
        }
      }
    }
  }
LAB_1408d6219:
  plStack_298 = plVar7;
  piVar1 = (int *)plStack_298[5];
  if (piVar1 == (int *)0x0) {
    pcVar21 = (code *)FUN_142cd9160(plVar8,uVar25);
    bVar26 = pcVar21 == _Py_NoneStruct_exref;
LAB_1408d6265:
    plVar8 = (longlong *)plStack_298[5];
    if (bVar26) {
      pcVar16 = (code *)0x0;
    }
    else {
      pcVar16 = pcVar21;
      if ((pcVar21 != (code *)0x0) && (*(int *)pcVar21 + 1 != 0)) {
        *(int *)pcVar21 = *(int *)pcVar21 + 1;
      }
    }
    plStack_298[5] = (longlong)pcVar16;
    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    plVar8 = plStack_270;
    if (((pcVar21 != (code *)0x0) && (-1 < *(int *)pcVar21)) &&
       (*(longlong *)pcVar21 = *(longlong *)pcVar21 + -1, *(longlong *)pcVar21 == 0)) {
      (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))(pcVar21);
      plVar8 = plStack_270;
    }
  }
  else if (*(longlong **)(piVar1 + 6) != plVar8) {
    pcVar21 = (code *)FUN_142cd9160(plVar8,uVar25);
    *(int **)(pcVar21 + 0x10) = piVar1;
    if (*piVar1 + 1 != 0) {
      *piVar1 = *piVar1 + 1;
    }
    bVar26 = pcVar21 == _Py_NoneStruct_exref;
    goto LAB_1408d6265;
  }
  plVar10 = plStack_180;
  plVar9 = plStack_188;
  plStack_2a0 = plStack_1e8;
  plStack_2a8 = plStack_1c0;
  plStack_2b0 = plStack_1f0;
  plStack_2b8 = plStack_1d0;
  plStack_2d8 = plStack_188;
  plStack_2e0 = plStack_180;
  plStack_2e8 = plStack_1b8;
  plStack_2f0 = plStack_1a8;
  plStack_2f8 = plStack_230;
  plStack_300 = plStack_1c8;
  plStack_308 = plStack_1b0;
  plStack_310 = plStack_170;
  plStack_318 = plStack_178;
  plStack_320 = plStack_1d8;
  pcStack_328 = pcStack_228;
  plStack_330 = plStack_168;
  plStack_338 = plStack_138;
  plStack_340 = plStack_140;
  plStack_348 = plStack_148;
  plStack_350 = plStack_150;
  plStack_358 = plStack_158;
  plStack_360 = plStack_160;
  pcStack_368 = pcStack_1f8;
  pcStack_370 = pcStack_1e0;
  pcStack_378 = pcStack_118;
  pcStack_380 = pcStack_120;
  plStack_388 = plStack_220;
  plStack_390 = plStack_210;
  pcStack_398 = pcStack_100;
  pcStack_2d0 = pcVar14;
  pcStack_2c8 = pcVar19;
  pcStack_2c0 = pcVar24;
  FUN_142cdb370(plVar8,&UNK_142d0d378,plStack_f8,plStack_108);
  plVar7 = _DAT_142dea7d0;
  if (plVar8 == _DAT_142dea7d0) {
    if ((-1 < (int)*_DAT_142dea7d0) && (*_DAT_142dea7d0 = *_DAT_142dea7d0 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))();
    }
    _DAT_142dea7d0 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  plVar8 = plStack_298;
  plStack_298 = (longlong *)0x0;
  if (((plStack_210 != (longlong *)0x0) && (-1 < (int)*plStack_210)) &&
     (*plStack_210 = *plStack_210 + -1, *plStack_210 == 0)) {
    (**(code **)(plStack_210[1] + 0x30))();
  }
  if (((plStack_220 != (longlong *)0x0) && (-1 < (int)*plStack_220)) &&
     (*plStack_220 = *plStack_220 + -1, *plStack_220 == 0)) {
    (**(code **)(plStack_220[1] + 0x30))();
  }
  if (((pcStack_120 != (code *)0x0) && (-1 < *(int *)pcStack_120)) &&
     (*(longlong *)pcStack_120 = *(longlong *)pcStack_120 + -1, *(longlong *)pcStack_120 == 0)) {
    (**(code **)(*(longlong *)(pcStack_120 + 8) + 0x30))();
  }
  if (((pcStack_118 != (code *)0x0) && (-1 < *(int *)pcStack_118)) &&
     (*(longlong *)pcStack_118 = *(longlong *)pcStack_118 + -1, *(longlong *)pcStack_118 == 0)) {
    (**(code **)(*(longlong *)(pcStack_118 + 8) + 0x30))();
  }
  if (((pcStack_1e0 != (code *)0x0) && (-1 < *(int *)pcStack_1e0)) &&
     (*(longlong *)pcStack_1e0 = *(longlong *)pcStack_1e0 + -1, *(longlong *)pcStack_1e0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_1e0 + 8) + 0x30))();
  }
  if (((pcStack_1f8 != (code *)0x0) && (-1 < *(int *)pcStack_1f8)) &&
     (*(longlong *)pcStack_1f8 = *(longlong *)pcStack_1f8 + -1, *(longlong *)pcStack_1f8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_1f8 + 8) + 0x30))();
  }
  if (((plStack_160 != (longlong *)0x0) && (-1 < (int)*plStack_160)) &&
     (*plStack_160 = *plStack_160 + -1, *plStack_160 == 0)) {
    (**(code **)(plStack_160[1] + 0x30))();
  }
  if (((plStack_158 != (longlong *)0x0) && (-1 < (int)*plStack_158)) &&
     (*plStack_158 = *plStack_158 + -1, *plStack_158 == 0)) {
    (**(code **)(plStack_158[1] + 0x30))();
  }
  if (((plStack_150 != (longlong *)0x0) && (-1 < (int)*plStack_150)) &&
     (*plStack_150 = *plStack_150 + -1, *plStack_150 == 0)) {
    (**(code **)(plStack_150[1] + 0x30))();
  }
  if (((plStack_148 != (longlong *)0x0) && (-1 < (int)*plStack_148)) &&
     (*plStack_148 = *plStack_148 + -1, *plStack_148 == 0)) {
    (**(code **)(plStack_148[1] + 0x30))();
  }
  if (((plStack_140 != (longlong *)0x0) && (-1 < (int)*plStack_140)) &&
     (*plStack_140 = *plStack_140 + -1, *plStack_140 == 0)) {
    (**(code **)(plStack_140[1] + 0x30))();
  }
  if (((plStack_138 != (longlong *)0x0) && (-1 < (int)*plStack_138)) &&
     (*plStack_138 = *plStack_138 + -1, *plStack_138 == 0)) {
    (**(code **)(plStack_138[1] + 0x30))();
  }
  if (((plStack_168 != (longlong *)0x0) && (-1 < (int)*plStack_168)) &&
     (*plStack_168 = *plStack_168 + -1, *plStack_168 == 0)) {
    (**(code **)(plStack_168[1] + 0x30))();
  }
  if (((pcStack_228 != (code *)0x0) && (-1 < *(int *)pcStack_228)) &&
     (*(longlong *)pcStack_228 = *(longlong *)pcStack_228 + -1, *(longlong *)pcStack_228 == 0)) {
    (**(code **)(*(longlong *)(pcStack_228 + 8) + 0x30))();
  }
  if (((plStack_1d8 != (longlong *)0x0) && (-1 < (int)*plStack_1d8)) &&
     (*plStack_1d8 = *plStack_1d8 + -1, *plStack_1d8 == 0)) {
    (**(code **)(plStack_1d8[1] + 0x30))();
  }
  if (((plStack_178 != (longlong *)0x0) && (-1 < (int)*plStack_178)) &&
     (*plStack_178 = *plStack_178 + -1, *plStack_178 == 0)) {
    (**(code **)(plStack_178[1] + 0x30))();
  }
  if (((plStack_170 != (longlong *)0x0) && (-1 < (int)*plStack_170)) &&
     (*plStack_170 = *plStack_170 + -1, *plStack_170 == 0)) {
    (**(code **)(plStack_170[1] + 0x30))();
  }
  if (((plStack_1b0 != (longlong *)0x0) && (-1 < (int)*plStack_1b0)) &&
     (*plStack_1b0 = *plStack_1b0 + -1, *plStack_1b0 == 0)) {
    (**(code **)(plStack_1b0[1] + 0x30))();
  }
  if (((plStack_1c8 != (longlong *)0x0) && (-1 < (int)*plStack_1c8)) &&
     (*plStack_1c8 = *plStack_1c8 + -1, *plStack_1c8 == 0)) {
    (**(code **)(plStack_1c8[1] + 0x30))();
  }
  if (((plStack_230 != (longlong *)0x0) && (-1 < (int)*plStack_230)) &&
     (*plStack_230 = *plStack_230 + -1, *plStack_230 == 0)) {
    (**(code **)(plStack_230[1] + 0x30))();
  }
  if (((plStack_1a8 != (longlong *)0x0) && (-1 < (int)*plStack_1a8)) &&
     (*plStack_1a8 = *plStack_1a8 + -1, *plStack_1a8 == 0)) {
    (**(code **)(plStack_1a8[1] + 0x30))();
  }
  if (((plStack_1b8 != (longlong *)0x0) && (-1 < (int)*plStack_1b8)) &&
     (*plStack_1b8 = *plStack_1b8 + -1, *plStack_1b8 == 0)) {
    (**(code **)(plStack_1b8[1] + 0x30))();
  }
  if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))(plVar10);
  }
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
     (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
    (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
  }
  if (((pcVar19 != (code *)0x0) && (-1 < *(int *)pcVar19)) &&
     (*(longlong *)pcVar19 = *(longlong *)pcVar19 + -1, *(longlong *)pcVar19 == 0)) {
    (**(code **)(*(longlong *)(pcVar19 + 8) + 0x30))(pcVar19);
  }
  if (((pcVar24 != (code *)0x0) && (-1 < *(int *)pcVar24)) &&
     (*(longlong *)pcVar24 = *(longlong *)pcVar24 + -1, *(longlong *)pcVar24 == 0)) {
    (**(code **)(*(longlong *)(pcVar24 + 8) + 0x30))(pcVar24);
  }
  if (((plStack_1d0 != (longlong *)0x0) && (-1 < (int)*plStack_1d0)) &&
     (*plStack_1d0 = *plStack_1d0 + -1, *plStack_1d0 == 0)) {
    (**(code **)(plStack_1d0[1] + 0x30))();
  }
  if (((plStack_1f0 != (longlong *)0x0) && (-1 < (int)*plStack_1f0)) &&
     (*plStack_1f0 = *plStack_1f0 + -1, *plStack_1f0 == 0)) {
    (**(code **)(plStack_1f0[1] + 0x30))();
  }
  if (((plStack_1c0 != (longlong *)0x0) && (-1 < (int)*plStack_1c0)) &&
     (*plStack_1c0 = *plStack_1c0 + -1, *plStack_1c0 == 0)) {
    (**(code **)(plStack_1c0[1] + 0x30))();
  }
  if (((plStack_1e8 != (longlong *)0x0) && (-1 < (int)*plStack_1e8)) &&
     (*plStack_1e8 = *plStack_1e8 + -1, *plStack_1e8 == 0)) {
    (**(code **)(plStack_1e8[1] + 0x30))();
  }
  plStack_298 = plVar8;
  if ((-1 < (int)*plStack_f8) && (*plStack_f8 = *plStack_f8 + -1, *plStack_f8 == 0)) {
    (**(code **)(plStack_f8[1] + 0x30))();
  }
  if ((-1 < (int)*plStack_108) && (*plStack_108 = *plStack_108 + -1, *plStack_108 == 0)) {
    (**(code **)(plStack_108[1] + 0x30))();
  }
  if ((-1 < *(int *)pcStack_100) &&
     (*(longlong *)pcStack_100 = *(longlong *)pcStack_100 + -1, *(longlong *)pcStack_100 == 0)) {
    (**(code **)(*(longlong *)(pcStack_100 + 8) + 0x30))();
  }
  plVar8 = *(longlong **)(tstate + 0x70);
  *(longlong **)(tstate + 0x70) = plStack_298;
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))();
  }
LAB_1408d686c:
  puVar17 = (undefined *)FUN_142cfc380(uStack_48 ^ (ulonglong)auStack_3b8);
  return puVar17;
LAB_1408d5403:
  plVar7 = *(longlong **)(tstate + 0x70);
  puVar22 = (undefined8 *)(tstate + 0x70);
  if (plVar7 != (longlong *)0x0) {
    cVar3 = FUN_140008d40(tstate,plVar7,*(undefined8 *)PyExc_StopIteration_exref);
    if (cVar3 == '\0') {
      plVar7 = (longlong *)*puVar22;
      *puVar22 = 0;
      plStack_298 = (longlong *)0x0;
      uStack_288 = 0x2426;
      pcVar24 = pcStack_278;
      pcStack_268 = pcVar14;
      if (plVar8 != (longlong *)0x0) {
LAB_1408d5977:
        plStack_200 = plVar8;
        plStack_298 = (longlong *)0x0;
        plVar9 = plStack_218;
        tstate = puStack_240;
        if ((-1 < (int)*plStack_200) && (*plStack_200 = *plStack_200 + -1, *plStack_200 == 0)) {
          (**(code **)(plStack_200[1] + 0x30))();
          plVar9 = plStack_218;
          tstate = puStack_240;
        }
      }
      uVar25 = uStack_288;
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
        uVar25 = uStack_288;
      }
      goto LAB_1408d5c75;
    }
    *puVar22 = 0;
    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))(plVar7);
    }
  }
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))(plVar8);
  }
  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  cVar3 = FUN_140008af0(tstate);
  if (cVar3 == '\0') goto LAB_1408d5c5b;
  plVar12 = (longlong *)(**(code **)(plStack_190[1] + 0xe0))();
  plVar10 = plStack_110;
  plVar9 = plStack_e8;
  plVar7 = plStack_f0;
  plVar8 = plStack_130;
  if (plVar12 == (longlong *)0x0) goto LAB_1408d54c2;
  goto LAB_1408d4400;
}

