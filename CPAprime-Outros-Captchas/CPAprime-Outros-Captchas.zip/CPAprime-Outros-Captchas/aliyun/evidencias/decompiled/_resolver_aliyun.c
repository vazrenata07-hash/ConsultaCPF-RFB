
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _resolver_aliyun(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  code *pcVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong lVar13;
  undefined8 uVar14;
  code *pcVar15;
  undefined *puVar16;
  code *pcVar17;
  code *pcVar18;
  undefined4 uVar19;
  bool bVar20;
  longlong lStack_100;
  longlong *plStack_f8;
  longlong *plStack_f0;
  code *pcStack_e8;
  code *pcStack_e0;
  longlong *plStack_d8;
  longlong *plStack_d0;
  longlong *plStack_c8;
  longlong *plStack_c0;
  longlong *plStack_b8;
  code *pcStack_b0;
  code *pcStack_a8;
  code *pcStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_88;
  longlong *plStack_80;
  longlong *plStack_78;
  longlong *plStack_70;
  code *pcStack_68;
  code *pcStack_60;
  undefined *puStack_58;
  longlong *plStack_50;
  longlong *plStack_48;
  longlong *plStack_40;
  
  plVar6 = _DAT_142dea7e0;
  plVar1 = (longlong *)*python_pars;
  plVar8 = (longlong *)python_pars[1];
  pcVar18 = (code *)0x0;
  plStack_c8 = (longlong *)0x0;
  plStack_c0 = (longlong *)0x0;
  plStack_b8 = (longlong *)0x0;
  pcStack_b0 = (code *)0x0;
  pcStack_a8 = (code *)0x0;
  pcStack_a0 = (code *)0x0;
  plStack_98 = (longlong *)0x0;
  plStack_d8 = (longlong *)0x0;
  plStack_90 = (longlong *)0x0;
  plStack_88 = (longlong *)0x0;
  pcStack_e8 = (code *)0x0;
  lStack_100 = 0;
  plStack_f0 = _DAT_142dea7e0;
  plStack_d0 = plVar8;
  if (_DAT_142dea7e0 == (longlong *)0x0) {
LAB_1408d7021:
    plStack_f0 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9d30,_DAT_142f2aaf0,0x70);
  }
  else if ((1 < *_DAT_142dea7e0) || (_DAT_142dea7e0[2] != 0)) {
    if ((_DAT_142dea7e0 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7e0 && (*_DAT_142dea7e0 = *_DAT_142dea7e0 + -1, *plVar6 == 0)))) {
      (**(code **)(plVar6[1] + 0x30))();
    }
    goto LAB_1408d7021;
  }
  _DAT_142dea7e0 = plStack_f0;
  Nuitka_helper_140008a00(tstate,plStack_f0);
  puVar16 = shared_const_3_1;
  plVar6 = (longlong *)FUN_142cbe6d0(plVar8,shared_const_3_1);
  if (plVar6 == (longlong *)0x0) {
    lVar12 = *(longlong *)(tstate + 0x70);
    uVar19 = 0x244b;
    *(undefined8 *)(tstate + 0x70) = 0;
    pcVar10 = pcVar18;
  }
  else {
    plVar7 = (longlong *)Nuitka_helper_142cc2f20(tstate,puVar16,plVar6);
    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
    pcVar10 = (code *)0x0;
    if (plVar7 == (longlong *)0x0) {
      lVar12 = *(longlong *)(tstate + 0x70);
      uVar19 = 0x244b;
      *(undefined8 *)(tstate + 0x70) = 0;
      pcVar18 = (code *)0x0;
    }
    else {
      plVar6 = (longlong *)FUN_140009850(tstate,plVar7);
      plStack_78 = plVar6;
      if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
        (**(code **)(plVar7[1] + 0x30))(plVar7);
      }
      if (plVar6 == (longlong *)0x0) {
        lVar12 = *(longlong *)(tstate + 0x70);
        uVar19 = 0x244b;
        *(undefined8 *)(tstate + 0x70) = 0;
        pcVar18 = (code *)0x0;
      }
      else {
        pcStack_e0 = (code *)(**(code **)(plVar6[1] + 0xe0))(plVar6);
        pcVar10 = pcVar18;
        if (pcStack_e0 != (code *)0x0) {
          pcVar15 = (code *)0x0;
          pcVar17 = pcVar18;
          do {
            uVar19 = 0x2455;
            if (((pcVar15 != (code *)0x0) && (-1 < *(int *)pcVar15)) &&
               (*(longlong *)pcVar15 = *(longlong *)pcVar15 + -1, *(longlong *)pcVar15 == 0)) {
              (**(code **)(*(longlong *)(pcVar15 + 8) + 0x30))(pcVar15);
            }
            pcVar18 = pcStack_e0;
            if (*(int *)pcStack_e0 + 1 != 0) {
              *(int *)pcStack_e0 = *(int *)pcStack_e0 + 1;
            }
            if (((pcVar17 != (code *)0x0) && (-1 < *(int *)pcVar17)) &&
               (*(longlong *)pcVar17 = *(longlong *)pcVar17 + -1, *(longlong *)pcVar17 == 0)) {
              (**(code **)(*(longlong *)(pcVar17 + 8) + 0x30))();
            }
            if (plVar1 == (longlong *)0x0) {
              FUN_142cd4900(tstate,&lStack_100,classes_const_403_self);
              FUN_1400048d0(tstate,lStack_100);
              lVar12 = lStack_100;
LAB_1408d8d81:
              plVar8 = plStack_f0;
              piVar2 = *(int **)(tstate + 0xf8);
              lStack_100 = 0;
              if ((piVar2 != (int *)0x0) && (*piVar2 + 1 != 0)) {
                *piVar2 = *piVar2 + 1;
              }
              piVar3 = *(int **)(lVar12 + 0x28);
              if (piVar3 == (int *)0x0) {
                pcVar10 = (code *)FUN_142cd9160(plStack_f0,0x244d);
                plVar6 = *(longlong **)(lVar12 + 0x28);
                if (pcVar10 == _Py_NoneStruct_exref) {
                  pcVar15 = (code *)0x0;
                }
                else {
                  pcVar15 = pcVar10;
                  if ((pcVar10 != (code *)0x0) && (*(int *)pcVar10 + 1 != 0)) {
                    *(int *)pcVar10 = *(int *)pcVar10 + 1;
                  }
                }
                *(code **)(lVar12 + 0x28) = pcVar15;
                if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) &&
                   (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))();
                }
                if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
                   (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
                  (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
                }
              }
              else {
                pcVar10 = (code *)FUN_142cd9160(plStack_f0,0x244d);
                *(int **)(pcVar10 + 0x10) = piVar3;
                if (*piVar3 + 1 != 0) {
                  *piVar3 = *piVar3 + 1;
                }
                plVar8 = *(longlong **)(lVar12 + 0x28);
                if (pcVar10 == _Py_NoneStruct_exref) {
                  pcVar15 = (code *)0x0;
                }
                else {
                  pcVar15 = pcVar10;
                  if ((pcVar10 != (code *)0x0) && (*(int *)pcVar10 + 1 != 0)) {
                    *(int *)pcVar10 = *(int *)pcVar10 + 1;
                  }
                }
                *(code **)(lVar12 + 0x28) = pcVar15;
                if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                   (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))();
                }
                plVar8 = plStack_f0;
                if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
                   (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
                  (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
                  plVar8 = plStack_f0;
                }
              }
              plVar6 = *(longlong **)(tstate + 0xf8);
              *(longlong *)(tstate + 0xf8) = lVar12;
              if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) &&
                 (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                (**(code **)(plVar6[1] + 0x30))();
              }
              iVar5 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                                    *(undefined8 *)PyExc_Exception_exref);
              pcVar15 = _Py_FalseStruct_exref;
              if (iVar5 == 0) {
                cVar4 = FUN_142cded30(tstate,&lStack_100);
                lVar12 = lStack_100;
                uVar19 = 0x244c;
                if (cVar4 != '\0') {
                  uVar19 = 0;
                }
                lVar13 = *(longlong *)(lStack_100 + 0x28);
                if ((lVar13 != 0) && (*(longlong **)(lVar13 + 0x18) == plVar8)) {
                  *(undefined4 *)(plVar8 + 5) = *(undefined4 *)(lVar13 + 0x24);
                }
                lStack_100 = 0;
                plVar8 = *(longlong **)(tstate + 0xf8);
                *(int **)(tstate + 0xf8) = piVar2;
                if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                   (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))();
                }
                goto LAB_1408d84f0;
              }
              if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
                *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
              }
              plVar8 = *(longlong **)(tstate + 0xf8);
              *(int **)(tstate + 0xf8) = piVar2;
              if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                 (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))();
              }
LAB_1408d8f1c:
              if ((-1 < *(int *)pcStack_e0) &&
                 (*(longlong *)pcStack_e0 = *(longlong *)pcStack_e0 + -1,
                 *(longlong *)pcStack_e0 == 0)) {
                (**(code **)(*(longlong *)(pcStack_e0 + 8) + 0x30))();
              }
              if ((-1 < (int)*plStack_78) && (*plStack_78 = *plStack_78 + -1, *plStack_78 == 0)) {
                (**(code **)(plStack_78[1] + 0x30))();
              }
              FUN_140008990(tstate);
              pcVar10 = pcStack_e8;
              plVar8 = plStack_d0;
              goto LAB_1408d9360;
            }
            plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
            if (plVar8 == (longlong *)0x0) {
LAB_1408d8d53:
              lVar12 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              goto LAB_1408d8d81;
            }
            plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_338_execute_script);
            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))(plVar8);
            }
            if (plVar6 == (longlong *)0x0) goto LAB_1408d8d53;
            plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1986__JS_ALIYUN_ESTADO);
            plVar8 = plStack_f0;
            if (plVar7 == (longlong *)0x0) {
              lStack_100 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              lVar12 = lStack_100;
              if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                (**(code **)(plVar6[1] + 0x30))(plVar6);
                lVar12 = lStack_100;
              }
              goto LAB_1408d8d81;
            }
            *(undefined4 *)(plStack_f0 + 5) = 0x244d;
            plVar9 = (longlong *)FUN_142ccfd60(tstate,plVar6,plVar7);
            plStack_80 = plVar9;
            if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
              (**(code **)(plVar6[1] + 0x30))(plVar6);
            }
            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
              (**(code **)(plVar7[1] + 0x30))(plVar7);
            }
            if (plVar9 == (longlong *)0x0) goto LAB_1408d8d53;
            plVar6 = plVar9;
            if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
               (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
              plVar6 = plStack_c8 + 1;
              plStack_c8 = plVar9;
              (**(code **)(*plVar6 + 0x30))();
              plVar6 = plStack_c8;
            }
            plStack_c8 = plVar6;
            iVar5 = PyObject_IsInstance(plVar9,PyDict_Type_exref);
            if (iVar5 == -1) {
LAB_1408d8d15:
              lVar12 = *(longlong *)(tstate + 0x70);
              uVar19 = 0x2450;
              *(undefined8 *)(tstate + 0x70) = 0;
              goto LAB_1408d84f0;
            }
            pcVar10 = _Py_FalseStruct_exref;
            if (iVar5 != 0) {
              pcVar10 = _Py_TrueStruct_exref;
            }
            iVar5 = FUN_140004970(pcVar10);
            if (iVar5 == -1) goto LAB_1408d8d15;
            bVar20 = iVar5 == 0;
            if (iVar5 == 0) goto LAB_1408d74aa;
            plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar9,classes_const_211_get);
            if (plVar6 == (longlong *)0x0) goto LAB_1408d8d15;
            *(undefined4 *)(plVar8 + 5) = 0x2450;
            pcVar10 = (code *)FUN_142cccf70(tstate,plVar6,
                                            classes_const_1987___type____T____items_____fundo___);
            if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
              (**(code **)(plVar6[1] + 0x30))(plVar6);
            }
            if (pcVar10 == (code *)0x0) goto LAB_1408d8d15;
            if (pcVar10 == _Py_TrueStruct_exref) {
LAB_1408d7303:
              iVar5 = 1;
            }
            else if ((pcVar10 == _Py_FalseStruct_exref) || (pcVar10 == _Py_NoneStruct_exref)) {
              iVar5 = 0;
            }
            else {
              lVar12 = *(longlong *)(pcVar10 + 8);
              if ((*(longlong *)(lVar12 + 0x60) == 0) ||
                 (pcVar15 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48), pcVar15 == (code *)0x0)
                 ) {
                if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
                   (pcVar15 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar15 == (code *)0x0)) {
                  if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
                     (pcVar15 = (code *)**(undefined8 **)(lVar12 + 0x68), pcVar15 == (code *)0x0))
                  goto LAB_1408d7303;
                  lVar12 = (*pcVar15)(pcVar10);
                }
                else {
                  lVar12 = (*pcVar15)(pcVar10);
                }
              }
              else {
                iVar5 = (*pcVar15)(pcVar10);
                lVar12 = (longlong)iVar5;
              }
              if (lVar12 < 1) {
                iVar5 = -(uint)(lVar12 != 0);
              }
              else {
                iVar5 = 1;
              }
            }
            if ((-1 < *(int *)pcVar10) &&
               (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
              (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
            }
            if (iVar5 == -1) goto LAB_1408d8d15;
            bVar20 = iVar5 == 0;
            if (iVar5 != 0) {
              plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar9,classes_const_211_get);
              if (plVar6 != (longlong *)0x0) {
                *(undefined4 *)(plVar8 + 5) = 0x2450;
                pcVar10 = (code *)FUN_142cccf70(tstate,plVar6,
                                                classes_const_1988___type____T____items_____peca___)
                ;
                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                }
                if (pcVar10 != (code *)0x0) {
                  if (pcVar10 == _Py_TrueStruct_exref) {
LAB_1408d740c:
                    iVar5 = 1;
                  }
                  else if ((pcVar10 == _Py_FalseStruct_exref) || (pcVar10 == _Py_NoneStruct_exref))
                  {
                    iVar5 = 0;
                  }
                  else {
                    lVar12 = *(longlong *)(pcVar10 + 8);
                    if ((*(longlong *)(lVar12 + 0x60) == 0) ||
                       (pcVar15 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48),
                       pcVar15 == (code *)0x0)) {
                      if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
                         (pcVar15 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar15 == (code *)0x0
                         )) {
                        if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
                           (pcVar15 = (code *)**(undefined8 **)(lVar12 + 0x68),
                           pcVar15 == (code *)0x0)) goto LAB_1408d740c;
                        lVar12 = (*pcVar15)(pcVar10);
                      }
                      else {
                        lVar12 = (*pcVar15)(pcVar10);
                      }
                    }
                    else {
                      iVar5 = (*pcVar15)(pcVar10);
                      lVar12 = (longlong)iVar5;
                    }
                    if (lVar12 < 1) {
                      iVar5 = -(uint)(lVar12 != 0);
                    }
                    else {
                      iVar5 = 1;
                    }
                  }
                  if ((-1 < *(int *)pcVar10) &&
                     (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0))
                  {
                    (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
                  }
                  if (iVar5 != -1) {
                    bVar20 = iVar5 == 0;
                    goto LAB_1408d74aa;
                  }
                }
              }
              goto LAB_1408d8d15;
            }
LAB_1408d74aa:
            pcVar15 = _Py_FalseStruct_exref;
            if (bVar20) {
LAB_1408d863e:
              if (*(int *)pcVar15 + 1 != 0) {
                *(int *)pcVar15 = *(int *)pcVar15 + 1;
              }
              goto LAB_1408d8f1c;
            }
            plVar7 = (longlong *)FUN_140008da0(tstate,plVar9,classes_const_1989_fundo);
            plVar6 = plStack_c0;
            plStack_70 = plVar7;
            if (plVar7 == (longlong *)0x0) {
              lVar12 = *(longlong *)(tstate + 0x70);
              uVar19 = 0x2452;
              *(undefined8 *)(tstate + 0x70) = 0;
              goto LAB_1408d84f0;
            }
            plVar11 = plVar7;
            if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
               (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
              plVar11 = plStack_c0 + 1;
              plStack_c0 = plVar7;
              (**(code **)(*plVar11 + 0x30))(plVar6);
              plVar11 = plStack_c0;
            }
            plStack_c0 = plVar11;
            plVar9 = (longlong *)FUN_140008da0(tstate,plVar9,classes_const_1990_peca);
            plVar6 = plStack_b8;
            plStack_f8 = plVar9;
            if (plVar9 == (longlong *)0x0) {
              lVar12 = *(longlong *)(tstate + 0x70);
              uVar19 = 0x2453;
              *(undefined8 *)(tstate + 0x70) = 0;
              goto LAB_1408d84f0;
            }
            plVar11 = plVar9;
            if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
               (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
              plVar11 = plStack_b8 + 1;
              plStack_b8 = plVar9;
              (**(code **)(*plVar11 + 0x30))(plVar6);
              plVar11 = plStack_b8;
            }
            plStack_b8 = plVar11;
            plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar7,classes_const_211_get);
            if (plVar6 == (longlong *)0x0) {
LAB_1408d8cd0:
              lVar12 = *(longlong *)(tstate + 0x70);
              uVar19 = 0x2454;
              *(undefined8 *)(tstate + 0x70) = 0;
              goto LAB_1408d84f0;
            }
            *(undefined4 *)(plVar8 + 5) = 0x2454;
            plVar11 = (longlong *)
                      FUN_142cccf70(tstate,plVar6,classes_const_1991___type____T____items_____nw___)
            ;
            if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
              (**(code **)(plVar6[1] + 0x30))(plVar6);
            }
            if (plVar11 == (longlong *)0x0) goto LAB_1408d8cd0;
            iVar5 = FUN_140004970(plVar11);
            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
              (**(code **)(plVar11[1] + 0x30))(plVar11);
            }
            if (iVar5 == -1) goto LAB_1408d8cd0;
            if (iVar5 != 0) {
              plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1992__imagem_aliyun);
              if (plVar6 == (longlong *)0x0) {
LAB_1408d8c85:
                lVar12 = *(longlong *)(tstate + 0x70);
                uVar19 = 0x2458;
                *(undefined8 *)(tstate + 0x70) = 0;
                goto LAB_1408d84f0;
              }
              plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar7,classes_const_211_get);
              if (plVar7 != (longlong *)0x0) {
                *(undefined4 *)(plVar8 + 5) = 0x2458;
                plVar11 = (longlong *)
                          FUN_142ccd7d0(tstate,plVar7,
                                        classes_const_1993___type____T____items_____src_______);
                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                }
                if (plVar11 != (longlong *)0x0) {
                  *(undefined4 *)(plVar8 + 5) = 0x2458;
                  pcVar10 = (code *)FUN_142ccfd60(tstate,plVar6,plVar11);
                  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                  }
                  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                    (**(code **)(plVar11[1] + 0x30))(plVar11);
                  }
                  if (pcVar10 == (code *)0x0) goto LAB_1408d8c85;
                  pcVar15 = pcVar10;
                  if (((pcStack_b0 != (code *)0x0) && (-1 < *(int *)pcStack_b0)) &&
                     (*(longlong *)pcStack_b0 = *(longlong *)pcStack_b0 + -1,
                     *(longlong *)pcStack_b0 == 0)) {
                    pcVar15 = pcStack_b0 + 8;
                    pcStack_b0 = pcVar10;
                    (**(code **)(*(longlong *)pcVar15 + 0x30))();
                    pcVar15 = pcStack_b0;
                  }
                  pcStack_b0 = pcVar15;
                  plVar6 = (longlong *)
                           FUN_142cd7b20(tstate,plVar1,classes_const_1992__imagem_aliyun);
                  if (plVar6 == (longlong *)0x0) {
LAB_1408d8c3a:
                    lVar12 = *(longlong *)(tstate + 0x70);
                    uVar19 = 0x2459;
                    *(undefined8 *)(tstate + 0x70) = 0;
                    goto LAB_1408d84f0;
                  }
                  plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar9,classes_const_211_get);
                  if (plVar7 != (longlong *)0x0) {
                    *(undefined4 *)(plVar8 + 5) = 0x2459;
                    plVar9 = (longlong *)
                             FUN_142ccd7d0(tstate,plVar7,
                                           classes_const_1993___type____T____items_____src_______);
                    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    if (plVar9 != (longlong *)0x0) {
                      *(undefined4 *)(plVar8 + 5) = 0x2459;
                      pcVar15 = (code *)FUN_142ccfd60(tstate,plVar6,plVar9);
                      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                      }
                      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                      }
                      if (pcVar15 == (code *)0x0) goto LAB_1408d8c3a;
                      pcVar17 = pcVar15;
                      if (((pcStack_a8 != (code *)0x0) && (-1 < *(int *)pcStack_a8)) &&
                         (*(longlong *)pcStack_a8 = *(longlong *)pcStack_a8 + -1,
                         *(longlong *)pcStack_a8 == 0)) {
                        pcVar17 = pcStack_a8 + 8;
                        pcStack_a8 = pcVar15;
                        (**(code **)(*(longlong *)pcVar17 + 0x30))();
                        pcVar17 = pcStack_a8;
                      }
                      pcStack_a8 = pcVar17;
                      if (pcVar10 == _Py_TrueStruct_exref) {
LAB_1408d7866:
                        if (pcVar15 == _Py_TrueStruct_exref) {
LAB_1408d786b:
                          bVar20 = false;
                        }
                        else {
                          if ((pcVar15 != _Py_FalseStruct_exref) &&
                             (pcVar15 != _Py_NoneStruct_exref)) {
                            lVar12 = *(longlong *)(pcVar15 + 8);
                            if ((*(longlong *)(lVar12 + 0x60) == 0) ||
                               (pcVar17 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48),
                               pcVar17 == (code *)0x0)) {
                              if (((*(longlong **)(lVar12 + 0x70) == (longlong *)0x0) ||
                                  (pcVar17 = (code *)**(longlong **)(lVar12 + 0x70),
                                  pcVar17 == (code *)0x0)) &&
                                 ((*(longlong **)(lVar12 + 0x68) == (longlong *)0x0 ||
                                  (pcVar17 = (code *)**(longlong **)(lVar12 + 0x68),
                                  pcVar17 == (code *)0x0)))) goto LAB_1408d786b;
                              lVar12 = (*pcVar17)(pcVar15);
                            }
                            else {
                              iVar5 = (*pcVar17)(pcVar15);
                              lVar12 = (longlong)iVar5;
                            }
                            if (0 < lVar12) {
                              bVar20 = false;
                              goto LAB_1408d78db;
                            }
                            if (lVar12 != 0) goto LAB_1408d855e;
                          }
                          bVar20 = true;
                        }
LAB_1408d78db:
                        if (bVar20) goto LAB_1408d857a;
                        *(undefined4 *)(plVar8 + 5) = 0x245e;
                        pcStack_68 = pcVar10;
                        pcStack_60 = pcVar15;
                        pcVar15 = (code *)FUN_142cd07f0(tstate,plVar1,
                                                        classes_const_1995__achar_buraco_aliyun,
                                                        &pcStack_68);
                        pcVar10 = pcStack_a0;
                        if (pcVar15 == (code *)0x0) {
                          lVar12 = *(longlong *)(tstate + 0x70);
                          uVar19 = 0x245e;
                          *(undefined8 *)(tstate + 0x70) = 0;
                          goto LAB_1408d84f0;
                        }
                        pcVar17 = pcVar15;
                        if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
                           (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1,
                           *(longlong *)pcStack_a0 == 0)) {
                          pcVar17 = pcStack_a0 + 8;
                          pcStack_a0 = pcVar15;
                          (**(code **)(*(longlong *)pcVar17 + 0x30))(pcVar10);
                          pcVar17 = pcStack_a0;
                        }
                        pcStack_a0 = pcVar17;
                        plVar8 = plStack_70;
                        if (pcVar15 != _Py_NoneStruct_exref) {
                          plVar6 = (longlong *)FUN_140008da0(tstate,plStack_70,classes_const_1873_w)
                          ;
                          if (plVar6 == (longlong *)0x0) {
                            lVar12 = *(longlong *)(tstate + 0x70);
                            uVar19 = 0x2463;
                            *(undefined8 *)(tstate + 0x70) = 0;
                            goto LAB_1408d84f0;
                          }
                          plVar7 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_228_max);
                          puVar16 = classes_const_1793_1_0;
                          if ((plVar7 == (longlong *)0x0) || (lVar12 = *plVar7, lVar12 == 0))
                          goto LAB_1408d8bd6;
                          plVar8 = (longlong *)FUN_140008da0(tstate,plVar8,classes_const_1997_nw);
                          if (plVar8 != (longlong *)0x0) {
                            plVar7 = (longlong *)Nuitka_helper_142ce5200(plVar8);
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                            if (plVar7 != (longlong *)0x0) {
                              puStack_58 = puVar16;
                              *(undefined4 *)(plStack_f0 + 5) = 0x2463;
                              plStack_50 = plVar7;
                              plVar8 = (longlong *)FUN_142cc4ec0(tstate,lVar12,&puStack_58);
                              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                              }
                              if (plVar8 != (longlong *)0x0) {
                                plVar7 = (longlong *)FUN_142cc1540(plVar6,plVar8);
                                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                                }
                                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                                }
                                if (plVar7 == (longlong *)0x0) {
                                  lVar12 = *(longlong *)(tstate + 0x70);
                                  uVar19 = 0x2463;
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  goto LAB_1408d84f0;
                                }
                                plVar8 = plVar7;
                                if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
                                   (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
                                  plVar8 = plStack_98 + 1;
                                  plStack_98 = plVar7;
                                  (**(code **)(*plVar8 + 0x30))();
                                  plVar8 = plStack_98;
                                }
                                plStack_98 = plVar8;
                                plVar8 = plStack_70;
                                plVar6 = (longlong *)
                                         FUN_140008da0(tstate,plStack_70,classes_const_309_x);
                                if (plVar6 != (longlong *)0x0) {
                                  plVar9 = (longlong *)Nuitka_helper_142cc0520(pcVar15,plVar7);
                                  if (plVar9 == (longlong *)0x0) {
                                    lStack_100 = *(longlong *)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                    if ((-1 < (int)*plVar6) &&
                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                    }
                                    uVar19 = 0x2464;
                                    lVar12 = lStack_100;
                                    goto LAB_1408d84f0;
                                  }
                                  plVar11 = (longlong *)FUN_142cbe7f0(plVar6,plVar9);
                                  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0))
                                  {
                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                  }
                                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0))
                                  {
                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                  }
                                  if (plVar11 != (longlong *)0x0) {
                                    plVar6 = plVar11;
                                    if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8))
                                       && (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
                                      plVar6 = plStack_d8 + 1;
                                      plStack_d8 = plVar11;
                                      (**(code **)(*plVar6 + 0x30))();
                                      plVar6 = plStack_d8;
                                    }
                                    plStack_d8 = plVar6;
                                    plVar6 = (longlong *)
                                             FUN_140008da0(tstate,plVar8,classes_const_309_x);
                                    if (plVar6 != (longlong *)0x0) {
                                      plVar8 = (longlong *)
                                               FUN_140008da0(tstate,plVar8,classes_const_1873_w);
                                      if (plVar8 == (longlong *)0x0) {
                                        lStack_100 = *(longlong *)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        if (((int)*plVar6 < 0) ||
                                           (*plVar6 = *plVar6 + -1, *plVar6 != 0)) {
LAB_1408d8b05:
                                          uVar19 = 0x2468;
                                          lVar12 = lStack_100;
                                        }
                                        else {
                                          (**(code **)(plVar6[1] + 0x30))(plVar6);
                                          uVar19 = 0x2468;
                                          lVar12 = lStack_100;
                                        }
                                        goto LAB_1408d84f0;
                                      }
                                      plVar9 = (longlong *)FUN_142cbe7f0(plVar6,plVar8);
                                      if ((-1 < (int)*plVar6) &&
                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                      }
                                      if ((-1 < (int)*plVar8) &&
                                         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                                      }
                                      if (plVar9 != (longlong *)0x0) {
                                        plVar8 = (longlong *)
                                                 FUN_140008da0(tstate,plStack_f8,
                                                               classes_const_1873_w);
                                        if (plVar8 == (longlong *)0x0) {
                                          lStack_100 = *(longlong *)(tstate + 0x70);
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          if ((-1 < (int)*plVar9) &&
                                             (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                            (**(code **)(plVar9[1] + 0x30))(plVar9);
                                          }
                                          goto LAB_1408d8b05;
                                        }
                                        plVar6 = (longlong *)FUN_142cc11d0(plVar9,plVar8);
                                        if ((-1 < (int)*plVar9) &&
                                           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                          (**(code **)(plVar9[1] + 0x30))(plVar9);
                                        }
                                        if ((-1 < (int)*plVar8) &&
                                           (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                          (**(code **)(plVar8[1] + 0x30))(plVar8);
                                        }
                                        if (plVar6 != (longlong *)0x0) {
                                          plVar8 = plVar6;
                                          if (((plStack_90 != (longlong *)0x0) &&
                                              (-1 < (int)*plStack_90)) &&
                                             (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
                                            plVar8 = plStack_90 + 1;
                                            plStack_90 = plVar6;
                                            (**(code **)(*plVar8 + 0x30))();
                                            plVar8 = plStack_90;
                                          }
                                          plStack_90 = plVar8;
                                          iVar5 = FUN_142ce13d0(plVar11,plVar6);
                                          if (iVar5 == -1) {
                                            lVar12 = *(longlong *)(tstate + 0x70);
                                            uVar19 = 0x2469;
                                            *(undefined8 *)(tstate + 0x70) = 0;
                                            goto LAB_1408d84f0;
                                          }
                                          if (iVar5 == 1) {
                                            iVar5 = (int)*plVar6 + 1;
                                            if (iVar5 != 0) {
                                              *(int *)plVar6 = iVar5;
                                            }
                                            plStack_d8 = plVar6;
                                            if ((-1 < (int)*plVar11) &&
                                               (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                                            }
                                          }
                                          plVar6 = (longlong *)
                                                   FUN_142cd7b20(tstate,plStack_80,
                                                                 classes_const_211_get);
                                          plVar8 = plStack_f0;
                                          if (plVar6 != (longlong *)0x0) {
                                            *(undefined4 *)(plStack_f0 + 5) = 0x246b;
                                            plVar9 = (longlong *)
                                                     FUN_142cccf70(tstate,plVar6,
                                                                                                                                      
                                                  classes_const_1998___type____T____items_____alca___
                                                  );
                                            if ((-1 < (int)*plVar6) &&
                                               (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                              (**(code **)(plVar6[1] + 0x30))(plVar6);
                                            }
                                            if (plVar9 != (longlong *)0x0) {
                                              iVar5 = FUN_140004970(plVar9);
                                              if ((-1 < (int)*plVar9) &&
                                                 (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                                              }
                                              if (iVar5 != -1) {
                                                if (iVar5 == 0) {
                                                  uVar14 = FUN_1400776a0(classes_const_257_print);
                                                  uVar19 = 0x246c;
                                                  puVar16 = 
                                                  classes_const_1999__s__aliyun__sem_alca_na_tela;
                                                  goto LAB_1408d8a1c;
                                                }
                                                plVar8 = (longlong *)
                                                         FUN_140004a00(_DAT_142f24450,
                                                                       classes_const_257_print);
                                                puVar16 = 
                                                classes_const_2000__s__aliyun__buraco_a___0fpx___arrastando__tentativa__d_de__d_
                                                ;
                                                if ((plVar8 == (longlong *)0x0) ||
                                                   (lVar12 = *plVar8, lVar12 == 0)) {
LAB_1408d8bd6:
                                                  PyErr_PrintEx(0);
                                                  Py_Exit(1);
                                                  pcVar18 = (code *)swi(3);
                                                  puVar16 = (undefined *)(*pcVar18)();
                                                  return puVar16;
                                                }
                                                *(undefined4 *)(plStack_f0 + 5) = 0x2470;
                                                lVar13 = FUN_142cd06a0(tstate,plVar1,
                                                                       classes_const_1346__tag);
                                                if (lVar13 != 0) {
                                                  plVar8 = (longlong *)FUN_142cd9440(tstate,4);
                                                  plVar8[3] = lVar13;
                                                  lVar13 = Nuitka_helper_142cc0520(pcVar15,plVar7);
                                                  if (lVar13 == 0) {
                                                    lStack_100 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x2470;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    lVar12 = lStack_100;
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                      lVar12 = lStack_100;
                                                    }
                                                    goto LAB_1408d84f0;
                                                  }
                                                  plVar8[4] = lVar13;
                                                  if (*(int *)pcStack_e0 + 1 != 0) {
                                                    *(int *)pcStack_e0 = *(int *)pcStack_e0 + 1;
                                                  }
                                                  plVar8[5] = (longlong)pcStack_e0;
                                                  iVar5 = (int)*plStack_d0 + 1;
                                                  if (iVar5 != 0) {
                                                    *(int *)plStack_d0 = iVar5;
                                                  }
                                                  plVar8[6] = (longlong)plStack_d0;
                                                  plVar6 = (longlong *)FUN_142cbffc0(puVar16,plVar8)
                                                  ;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  plVar8 = plStack_f0;
                                                  if (plVar6 != (longlong *)0x0) {
                                                    *(undefined4 *)(plStack_f0 + 5) = 0x246f;
                                                    plVar7 = (longlong *)
                                                             FUN_142ccfd60(tstate,lVar12,plVar6);
                                                    if ((-1 < (int)*plVar6) &&
                                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                    }
                                                    if (plVar7 == (longlong *)0x0) {
                                                      lVar12 = *(longlong *)(tstate + 0x70);
                                                      uVar19 = 0x246f;
                                                      *(undefined8 *)(tstate + 0x70) = 0;
                                                      goto LAB_1408d84f0;
                                                    }
                                                    if ((-1 < (int)*plVar7) &&
                                                       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                    }
                                                    plVar6 = (longlong *)
                                                             FUN_142cd7b20(tstate,plVar1,
                                                                                                                                                      
                                                  classes_const_2001__arrastar_aliyun);
                                                  if (plVar6 != (longlong *)0x0) {
                                                    plVar7 = (longlong *)
                                                             FUN_140008da0(tstate,plStack_80,
                                                                           classes_const_2002_alca);
                                                    if (plVar7 == (longlong *)0x0) {
                                                      lStack_100 = *(longlong *)(tstate + 0x70);
                                                      *(undefined8 *)(tstate + 0x70) = 0;
                                                      if ((-1 < (int)*plVar6) &&
                                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                      }
                                                      uVar19 = 0x2471;
                                                      lVar12 = lStack_100;
                                                      goto LAB_1408d84f0;
                                                    }
                                                    plStack_40 = plStack_d8;
                                                    *(undefined4 *)(plVar8 + 5) = 0x2471;
                                                    plStack_48 = plVar7;
                                                    plVar9 = (longlong *)
                                                             FUN_142cc4ec0(tstate,plVar6,&plStack_48
                                                                          );
                                                    if ((-1 < (int)*plVar6) &&
                                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                    }
                                                    if ((-1 < (int)*plVar7) &&
                                                       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                    }
                                                    if (plVar9 != (longlong *)0x0) {
                                                      if ((-1 < (int)*plVar9) &&
                                                         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                      }
                                                      lVar12 = FUN_140a3b210(tstate);
                                                      if (lVar12 == 0) {
                                                        FUN_142cde870(tstate,&lStack_100,
                                                                      classes_const_76_time);
                                                        uVar19 = 0x2474;
                                                        lVar12 = lStack_100;
                                                      }
                                                      else {
                                                        *(undefined4 *)(plVar8 + 5) = 0x2474;
                                                        plVar6 = (longlong *)
                                                                 FUN_142cd06a0(tstate,lVar12,
                                                                               classes_const_76_time
                                                                              );
                                                        if (plVar6 == (longlong *)0x0) {
                                                          lVar12 = *(longlong *)(tstate + 0x70);
                                                          uVar19 = 0x2474;
                                                          *(undefined8 *)(tstate + 0x70) = 0;
                                                        }
                                                        else {
                                                          plVar7 = (longlong *)
                                                                   FUN_142cbe6d0(plVar6,
                                                  classes_const_721_6);
                                                  if ((-1 < (int)*plVar6) &&
                                                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                  }
                                                  pcVar10 = pcStack_e8;
                                                  if (plVar7 == (longlong *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x2474;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                  }
                                                  else {
                                                    plVar6 = plVar7;
                                                    if (((plStack_88 != (longlong *)0x0) &&
                                                        (-1 < (int)*plStack_88)) &&
                                                       (*plStack_88 = *plStack_88 + -1,
                                                       *plStack_88 == 0)) {
                                                      plVar6 = plStack_88 + 1;
                                                      plStack_88 = plVar7;
                                                      (**(code **)(*plVar6 + 0x30))();
                                                      plVar6 = plStack_88;
                                                    }
                                                    plStack_88 = plVar6;
                                                    pcVar15 = _Py_NoneStruct_exref;
                                                    pcStack_e8 = _Py_NoneStruct_exref;
                                                    if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                                      *(int *)_Py_NoneStruct_exref =
                                                           *(int *)_Py_NoneStruct_exref + 1;
                                                    }
                                                    if (((pcVar10 != (code *)0x0) &&
                                                        (-1 < *(int *)pcVar10)) &&
                                                       (*(longlong *)pcVar10 =
                                                             *(longlong *)pcVar10 + -1,
                                                       *(longlong *)pcVar10 == 0)) {
                                                      (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30
                                                                  ))();
                                                    }
                                                    while( true ) {
                                                      lVar12 = FUN_140a3b210(tstate);
                                                      if (lVar12 == 0) {
                                                        FUN_142cde870(tstate,&lStack_100,
                                                                      classes_const_76_time);
                                                        uVar19 = 0x2476;
                                                        lVar12 = lStack_100;
                                                        goto LAB_1408d84f0;
                                                      }
                                                      *(undefined4 *)(plVar8 + 5) = 0x2476;
                                                      plVar6 = (longlong *)
                                                               FUN_142cd06a0(tstate,lVar12,
                                                                             classes_const_76_time);
                                                      if (plVar6 == (longlong *)0x0)
                                                      goto LAB_1408d8267;
                                                      plVar9 = (longlong *)
                                                               FUN_142ce3540(plVar6,plVar7);
                                                      if ((-1 < (int)*plVar6) &&
                                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                      }
                                                      if (plVar9 == (longlong *)0x0)
                                                      goto LAB_1408d8267;
                                                      iVar5 = FUN_140004970(plVar9);
                                                      if ((-1 < (int)*plVar9) &&
                                                         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                      }
                                                      if (iVar5 == -1) goto LAB_1408d8267;
                                                      if (iVar5 == 0) break;
                                                      *(undefined4 *)(plVar8 + 5) = 0x2477;
                                                      plVar6 = (longlong *)
                                                               FUN_142cd06a0(tstate,plVar1,
                                                                                                                                                          
                                                  classes_const_1982__aliyun_na_tela);
                                                  if (plVar6 == (longlong *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x2477;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  iVar5 = FUN_140004970(plVar6);
                                                  if (iVar5 == -1) {
                                                    lStack_100 = *(longlong *)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    if ((-1 < (int)*plVar6) &&
                                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                    }
                                                    uVar19 = 0x2477;
                                                    lVar12 = lStack_100;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  if ((-1 < (int)*plVar6) &&
                                                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                  }
                                                  pcVar10 = _Py_NoneStruct_exref;
                                                  if (iVar5 == 0) {
                                                    if (pcVar15 == (code *)0x0) {
                                                      FUN_142cd4900(tstate,&lStack_100,
                                                                    classes_const_2003_fechado);
                                                      FUN_1400048d0(tstate,lStack_100);
                                                      uVar19 = 0x247a;
                                                      lVar12 = lStack_100;
                                                      goto LAB_1408d84f0;
                                                    }
                                                    if (pcVar15 != _Py_NoneStruct_exref) {
                                                      lVar12 = FUN_140a3b210();
                                                      if (lVar12 == 0) {
                                                        FUN_142cde870(tstate,&lStack_100,
                                                                      classes_const_76_time);
                                                        uVar19 = 0x247c;
                                                        lVar12 = lStack_100;
                                                        goto LAB_1408d84f0;
                                                      }
                                                      *(undefined4 *)(plVar8 + 5) = 0x247c;
                                                      plVar6 = (longlong *)
                                                               FUN_142cd06a0(tstate,lVar12,
                                                                             classes_const_76_time);
                                                      if (plVar6 != (longlong *)0x0) {
                                                        plVar9 = (longlong *)
                                                                 FUN_142cc11d0(plVar6,pcVar15);
                                                        if ((-1 < (int)*plVar6) &&
                                                           (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                          (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                        }
                                                        if (plVar9 != (longlong *)0x0) {
                                                          iVar5 = FUN_142ce05d0(plVar9,
                                                  classes_const_2004_1_5);
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  if (iVar5 != -1) {
                                                    pcVar10 = pcVar15;
                                                    if (iVar5 != 1) goto LAB_1408d819d;
                                                    uVar14 = FUN_1400776a0(classes_const_257_print);
                                                    puVar16 = 
                                                  classes_const_2005__s__aliyun__resolvido;
                                                  uVar19 = 0x247d;
                                                  *(undefined4 *)(plVar8 + 5) = 0x247d;
                                                  plVar6 = (longlong *)
                                                           FUN_142cd06a0(tstate,plVar1,
                                                                         classes_const_1346__tag);
                                                  if (plVar6 == (longlong *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  plVar7 = (longlong *)FUN_142cbff90(puVar16,plVar6)
                                                  ;
                                                  if ((-1 < (int)*plVar6) &&
                                                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                  }
                                                  if (plVar7 == (longlong *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  *(undefined4 *)(plVar8 + 5) = 0x247d;
                                                  plVar8 = (longlong *)
                                                           FUN_142ccfd60(tstate,uVar14,plVar7);
                                                  if ((-1 < (int)*plVar7) &&
                                                     (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                  }
                                                  if (plVar8 == (longlong *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  pcVar15 = _Py_TrueStruct_exref;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1,
                                                     pcVar15 = _Py_TrueStruct_exref, *plVar8 == 0))
                                                  {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    pcVar15 = _Py_TrueStruct_exref;
                                                  }
                                                  goto LAB_1408d863e;
                                                  }
                                                  }
                                                  }
                                                  lVar12 = *(longlong *)(tstate + 0x70);
                                                  uVar19 = 0x247c;
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  goto LAB_1408d84f0;
                                                  }
                                                  lVar12 = FUN_140a3b210();
                                                  if (lVar12 == 0) {
                                                    FUN_142cde870(tstate,&lStack_100,
                                                                  classes_const_76_time);
                                                    uVar19 = 0x247b;
                                                    lVar12 = lStack_100;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  *(undefined4 *)(plVar8 + 5) = 0x247b;
                                                  pcVar10 = (code *)FUN_142cd06a0(tstate,lVar12,
                                                                                                                                                                    
                                                  classes_const_76_time);
                                                  if (pcVar10 == (code *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x247b;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408d84f0;
                                                  }
LAB_1408d80e5:
                                                  pcStack_e8 = pcVar10;
                                                  if ((-1 < *(int *)pcVar15) &&
                                                     (*(longlong *)pcVar15 =
                                                           *(longlong *)pcVar15 + -1,
                                                     *(longlong *)pcVar15 == 0)) {
                                                    (**(code **)(*(longlong *)(pcVar15 + 8) + 0x30))
                                                              ();
                                                  }
                                                  }
                                                  else {
                                                    pcStack_e8 = _Py_NoneStruct_exref;
                                                    if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                                      *(int *)_Py_NoneStruct_exref =
                                                           *(int *)_Py_NoneStruct_exref + 1;
                                                    }
                                                    if (pcVar15 != (code *)0x0) goto LAB_1408d80e5;
                                                  }
LAB_1408d819d:
                                                  lVar12 = FUN_140a3b210(tstate);
                                                  if (lVar12 == 0) {
                                                    FUN_142cde870(tstate,&lStack_100,
                                                                  classes_const_76_time);
                                                    uVar19 = 0x247f;
                                                    lVar12 = lStack_100;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  *(undefined4 *)(plVar8 + 5) = 0x247f;
                                                  plVar6 = (longlong *)
                                                           FUN_142cd12f0(tstate,lVar12,
                                                                         classes_const_77_sleep,
                                                                         *(undefined8 *)
                                                                          (
                                                  classes_const_1551___type____T____items____0_3__ +
                                                  0x18));
                                                  if (plVar6 == (longlong *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x247f;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  if ((-1 < (int)*plVar6) &&
                                                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                  }
                                                  if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                                                      (iVar5 = Py_MakePendingCalls(), iVar5 < 0)) &&
                                                     (*(longlong *)(tstate + 0x70) != 0))
                                                  goto LAB_1408d8267;
                                                  if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                                                    PyEval_SaveThread();
                                                    PyEval_AcquireThread(tstate);
                                                  }
                                                  pcVar15 = pcVar10;
                                                  if (*(longlong *)(tstate + 0x90) != 0) {
                                                    plVar8 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x90) = 0;
                                                    uVar14 = FUN_142cd9e70(tstate);
                                                    *(undefined8 *)(tstate + 0x70) = uVar14;
                                                    if (((plVar8 != (longlong *)0x0) &&
                                                        (-1 < (int)*plVar8)) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
LAB_1408d8267:
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x2476;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408d84f0;
                                                  }
                                                  }
                                                  plVar6 = (longlong *)
                                                           FUN_140004a00(_DAT_142f24450,
                                                                         classes_const_257_print);
                                                  puVar16 = 
                                                  classes_const_2006__s__aliyun__arrastei_e_o_captcha_ficou__tentativa__d_de__d_
                                                  ;
                                                  if ((plVar6 == (longlong *)0x0) ||
                                                     (lVar12 = *plVar6, lVar12 == 0))
                                                  goto LAB_1408d8bd6;
                                                  *(undefined4 *)(plVar8 + 5) = 0x2481;
                                                  lVar13 = FUN_142cd06a0(tstate,plVar1,
                                                                         classes_const_1346__tag);
                                                  if (lVar13 != 0) {
                                                    plVar6 = (longlong *)FUN_142cd9440(tstate,3);
                                                    plVar6[3] = lVar13;
                                                    if (*(int *)pcStack_e0 + 1 != 0) {
                                                      *(int *)pcStack_e0 = *(int *)pcStack_e0 + 1;
                                                    }
                                                    plVar6[4] = (longlong)pcStack_e0;
                                                    iVar5 = (int)*plStack_d0 + 1;
                                                    if (iVar5 != 0) {
                                                      *(int *)plStack_d0 = iVar5;
                                                    }
                                                    plVar6[5] = (longlong)plStack_d0;
                                                    plVar7 = (longlong *)
                                                             FUN_142cbffc0(puVar16,plVar6);
                                                    if ((-1 < (int)*plVar6) &&
                                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                    }
                                                    if (plVar7 != (longlong *)0x0) {
                                                      *(undefined4 *)(plVar8 + 5) = 0x2480;
                                                      plVar6 = (longlong *)
                                                               FUN_142ccfd60(tstate,lVar12,plVar7);
                                                      if ((-1 < (int)*plVar7) &&
                                                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                        (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                      }
                                                      if (plVar6 == (longlong *)0x0) {
                                                        lVar12 = *(longlong *)(tstate + 0x70);
                                                        uVar19 = 0x2480;
                                                        *(undefined8 *)(tstate + 0x70) = 0;
                                                      }
                                                      else {
                                                        if ((-1 < (int)*plVar6) &&
                                                           (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                          (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                        }
                                                        lVar12 = FUN_140a3b210(tstate);
                                                        if (lVar12 == 0) {
                                                          FUN_142cde870(tstate,&lStack_100,
                                                                        classes_const_76_time);
                                                          uVar19 = 0x2482;
                                                          lVar12 = lStack_100;
                                                        }
                                                        else {
                                                          *(undefined4 *)(plVar8 + 5) = 0x2482;
                                                          plVar8 = (longlong *)
                                                                   FUN_142cd12f0(tstate,lVar12,
                                                                                                                                                                  
                                                  classes_const_77_sleep,
                                                  *(undefined8 *)
                                                   (classes_const_1890___type____T____items____1_5__
                                                   + 0x18));
                                                  if (plVar8 == (longlong *)0x0) {
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x2482;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                  }
                                                  else {
                                                    if ((-1 < (int)*plVar8) &&
                                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    }
                                                    if ((((*(ulonglong *)(tstate + 0x18) & 6) == 0)
                                                        || (iVar5 = Py_MakePendingCalls(),
                                                           -1 < iVar5)) ||
                                                       (*(longlong *)(tstate + 0x70) == 0)) {
                                                      if ((*(ulonglong *)(tstate + 0x18) & 1) != 0)
                                                      {
                                                        PyEval_SaveThread();
                                                        PyEval_AcquireThread(tstate);
                                                      }
                                                      if (*(longlong *)(tstate + 0x90) == 0)
                                                      goto LAB_1408d8427;
                                                      plVar8 = *(longlong **)(tstate + 0x70);
                                                      *(undefined8 *)(tstate + 0x90) = 0;
                                                      uVar14 = FUN_142cd9e70(tstate);
                                                      *(undefined8 *)(tstate + 0x70) = uVar14;
                                                      if (((plVar8 != (longlong *)0x0) &&
                                                          (-1 < (int)*plVar8)) &&
                                                         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                      }
                                                    }
                                                    lVar12 = *(longlong *)(tstate + 0x70);
                                                    uVar19 = 0x244b;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                  }
                                                  }
                                                  }
                                                  goto LAB_1408d84f0;
                                                  }
                                                  }
                                                  lVar12 = *(longlong *)(tstate + 0x70);
                                                  uVar19 = 0x2481;
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  }
                                                  }
                                                  }
                                                  goto LAB_1408d84f0;
                                                  }
                                                  }
                                                  lVar12 = *(longlong *)(tstate + 0x70);
                                                  uVar19 = 0x2471;
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  goto LAB_1408d84f0;
                                                  }
                                                }
                                                lVar12 = *(longlong *)(tstate + 0x70);
                                                uVar19 = 0x2470;
                                                *(undefined8 *)(tstate + 0x70) = 0;
                                                goto LAB_1408d84f0;
                                              }
                                            }
                                          }
                                          lVar12 = *(longlong *)(tstate + 0x70);
                                          uVar19 = 0x246b;
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          goto LAB_1408d84f0;
                                        }
                                      }
                                    }
                                    lVar12 = *(longlong *)(tstate + 0x70);
                                    uVar19 = 0x2468;
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                    goto LAB_1408d84f0;
                                  }
                                }
                                lVar12 = *(longlong *)(tstate + 0x70);
                                uVar19 = 0x2464;
                                *(undefined8 *)(tstate + 0x70) = 0;
                                goto LAB_1408d84f0;
                              }
                            }
                          }
                          lStack_100 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                            (**(code **)(plVar6[1] + 0x30))(plVar6);
                          }
                          uVar19 = 0x2463;
                          lVar12 = lStack_100;
                          goto LAB_1408d84f0;
                        }
                        uVar14 = FUN_1400776a0(classes_const_257_print);
                        uVar19 = 0x2460;
                        puVar16 = classes_const_1996__s__aliyun__nao_localizei_o_buraco;
                        plVar8 = plStack_f0;
LAB_1408d8a1c:
                        *(undefined4 *)(plVar8 + 5) = uVar19;
                        plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
                        if (plVar6 == (longlong *)0x0) goto LAB_1408d8a41;
                        plVar7 = (longlong *)FUN_142cbff90(puVar16,plVar6);
                        if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                          (**(code **)(plVar6[1] + 0x30))(plVar6);
                        }
                        if (plVar7 == (longlong *)0x0) {
                          lVar12 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          goto LAB_1408d84f0;
                        }
                        *(undefined4 *)(plVar8 + 5) = uVar19;
LAB_1408d85ef:
                        plVar8 = (longlong *)FUN_142ccfd60(tstate,uVar14,plVar7);
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (plVar8 != (longlong *)0x0) {
                          pcVar15 = _Py_FalseStruct_exref;
                          if ((-1 < (int)*plVar8) &&
                             (*plVar8 = *plVar8 + -1, pcVar15 = _Py_FalseStruct_exref, *plVar8 == 0)
                             ) {
                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                            pcVar15 = _Py_FalseStruct_exref;
                          }
                          goto LAB_1408d863e;
                        }
                      }
                      else {
                        if ((pcVar10 != _Py_FalseStruct_exref) && (pcVar10 != _Py_NoneStruct_exref))
                        {
                          lVar12 = *(longlong *)(pcVar10 + 8);
                          if ((*(longlong *)(lVar12 + 0x60) == 0) ||
                             (pcVar17 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48),
                             pcVar17 == (code *)0x0)) {
                            if (((*(longlong **)(lVar12 + 0x70) == (longlong *)0x0) ||
                                (pcVar17 = (code *)**(longlong **)(lVar12 + 0x70),
                                pcVar17 == (code *)0x0)) &&
                               ((*(longlong **)(lVar12 + 0x68) == (longlong *)0x0 ||
                                (pcVar17 = (code *)**(longlong **)(lVar12 + 0x68),
                                pcVar17 == (code *)0x0)))) goto LAB_1408d7866;
                            lVar12 = (*pcVar17)(pcVar10);
                          }
                          else {
                            iVar5 = (*pcVar17)(pcVar10);
                            lVar12 = (longlong)iVar5;
                          }
                          if (0 < lVar12) goto LAB_1408d7866;
                          if (lVar12 == 0) goto LAB_1408d857a;
LAB_1408d855e:
                          lVar12 = *(longlong *)(tstate + 0x70);
                          uVar19 = 0x245a;
                          *(undefined8 *)(tstate + 0x70) = 0;
                          goto LAB_1408d84f0;
                        }
LAB_1408d857a:
                        uVar14 = FUN_1400776a0(classes_const_257_print);
                        puVar16 = classes_const_1994__s__aliyun__nao_consegui_baixar_as_imagens;
                        uVar19 = 0x245b;
                        *(undefined4 *)(plVar8 + 5) = 0x245b;
                        plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
                        if (plVar6 != (longlong *)0x0) {
                          plVar7 = (longlong *)FUN_142cbff90(puVar16,plVar6);
                          if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                            (**(code **)(plVar6[1] + 0x30))(plVar6);
                          }
                          if (plVar7 != (longlong *)0x0) {
                            *(undefined4 *)(plVar8 + 5) = 0x245b;
                            goto LAB_1408d85ef;
                          }
                        }
                      }
LAB_1408d8a41:
                      lVar12 = *(longlong *)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      goto LAB_1408d84f0;
                    }
                  }
                  lStack_100 = *(longlong *)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                  }
                  uVar19 = 0x2459;
                  lVar12 = lStack_100;
                  goto LAB_1408d84f0;
                }
              }
              lStack_100 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                (**(code **)(plVar6[1] + 0x30))(plVar6);
              }
              uVar19 = 0x2458;
              lVar12 = lStack_100;
              goto LAB_1408d84f0;
            }
            lVar12 = FUN_140a3b210();
            if (lVar12 == 0) {
              FUN_142cde870(tstate,&lStack_100,classes_const_76_time);
              lVar12 = lStack_100;
              goto LAB_1408d84f0;
            }
            *(undefined4 *)(plVar8 + 5) = 0x2455;
            plVar8 = (longlong *)
                     FUN_142cd12f0(tstate,lVar12,classes_const_77_sleep,
                                   *(undefined8 *)
                                    (classes_const_1854___type____T____items____1_0__ + 0x18));
            if (plVar8 == (longlong *)0x0) goto LAB_1408d8a41;
            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))(plVar8);
            }
LAB_1408d8427:
            plVar6 = plStack_78;
            pcVar15 = pcStack_e0;
            pcStack_e0 = (code *)(**(code **)(plStack_78[1] + 0xe0))(plStack_78);
            pcVar10 = pcStack_e8;
            pcVar17 = pcVar18;
            plVar8 = plStack_d0;
          } while (pcStack_e0 != (code *)0x0);
        }
        plVar7 = *(longlong **)(tstate + 0x70);
        if (plVar7 == (longlong *)0x0) {
LAB_1408d9315:
          FUN_140008990(tstate);
          if (((pcVar18 != (code *)0x0) && (-1 < *(int *)pcVar18)) &&
             (*(longlong *)pcVar18 = *(longlong *)pcVar18 + -1, *(longlong *)pcVar18 == 0)) {
            (**(code **)(*(longlong *)(pcVar18 + 8) + 0x30))(pcVar18);
          }
          if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
            (**(code **)(plVar6[1] + 0x30))(plVar6);
          }
          pcVar15 = _Py_FalseStruct_exref;
          if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
            *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
          }
LAB_1408d9360:
          if (((pcVar18 != (code *)0x0) && (-1 < *(int *)pcVar18)) &&
             (*(longlong *)pcVar18 = *(longlong *)pcVar18 + -1, *(longlong *)pcVar18 == 0)) {
            (**(code **)(*(longlong *)(pcVar18 + 8) + 0x30))(pcVar18);
          }
          if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
             (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
            (**(code **)(plStack_c8[1] + 0x30))();
          }
          if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
             (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
            (**(code **)(plStack_c0[1] + 0x30))();
          }
          if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
             (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
            (**(code **)(plStack_b8[1] + 0x30))();
          }
          if (((pcStack_b0 != (code *)0x0) && (-1 < *(int *)pcStack_b0)) &&
             (*(longlong *)pcStack_b0 = *(longlong *)pcStack_b0 + -1, *(longlong *)pcStack_b0 == 0))
          {
            (**(code **)(*(longlong *)(pcStack_b0 + 8) + 0x30))();
          }
          if (((pcStack_a8 != (code *)0x0) && (-1 < *(int *)pcStack_a8)) &&
             (*(longlong *)pcStack_a8 = *(longlong *)pcStack_a8 + -1, *(longlong *)pcStack_a8 == 0))
          {
            (**(code **)(*(longlong *)(pcStack_a8 + 8) + 0x30))();
          }
          if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
             (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0))
          {
            (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))();
          }
          if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
             (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
            (**(code **)(plStack_98[1] + 0x30))();
          }
          if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8)) &&
             (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
            (**(code **)(plStack_d8[1] + 0x30))();
          }
          if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
             (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
            (**(code **)(plStack_90[1] + 0x30))();
          }
          if (((plStack_88 != (longlong *)0x0) && (-1 < (int)*plStack_88)) &&
             (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
            (**(code **)(plStack_88[1] + 0x30))();
          }
          if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
             (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
            (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
          }
          if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
            (**(code **)(plVar1[1] + 0x30))(plVar1);
          }
          if ((int)*plVar8 < 0) {
            return pcVar15;
          }
          *plVar8 = *plVar8 + -1;
          if (*plVar8 != 0) {
            return pcVar15;
          }
          (**(code **)(plVar8[1] + 0x30))(plVar8);
          return pcVar15;
        }
        plVar9 = (longlong *)plVar7[1];
        if ((*(uint *)((longlong *)plVar7[1] + 0x15) & 0x40000000) == 0) {
          plVar9 = plVar7;
        }
        if ((plVar9 == *(longlong **)PyExc_StopIteration_exref) ||
           (((*(int *)(plVar9[1] + 0xa8) < 0 && ((*(uint *)(plVar9 + 0x15) & 0x40000000) != 0)) &&
            (cVar4 = Nuitka_helper_142cdd950(), cVar4 == '\x01')))) {
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
            (**(code **)(plVar7[1] + 0x30))(plVar7);
          }
          goto LAB_1408d9315;
        }
        lVar12 = *(longlong *)(tstate + 0x70);
        uVar19 = 0x244b;
        *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408d84f0:
        lStack_100 = 0;
        if (((pcVar18 != (code *)0x0) && (-1 < *(int *)pcVar18)) &&
           (*(longlong *)pcVar18 = *(longlong *)pcVar18 + -1, *(longlong *)pcVar18 == 0)) {
          (**(code **)(*(longlong *)(pcVar18 + 8) + 0x30))(pcVar18);
        }
        pcVar10 = pcStack_e8;
        if ((-1 < (int)*plStack_78) && (*plStack_78 = *plStack_78 + -1, *plStack_78 == 0)) {
          (**(code **)(plStack_78[1] + 0x30))();
          pcVar10 = pcStack_e8;
        }
      }
    }
  }
  piVar2 = *(int **)(lVar12 + 0x28);
  lStack_100 = lVar12;
  if (piVar2 == (int *)0x0) {
    pcVar15 = (code *)FUN_142cd9160(plStack_f0,uVar19);
    bVar20 = pcVar15 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar2 + 6) == plStack_f0) goto LAB_1408d9055;
    pcVar15 = (code *)FUN_142cd9160(plStack_f0,uVar19);
    *(int **)(pcVar15 + 0x10) = piVar2;
    if (*piVar2 + 1 != 0) {
      *piVar2 = *piVar2 + 1;
    }
    bVar20 = pcVar15 == _Py_NoneStruct_exref;
  }
  plVar8 = *(longlong **)(lStack_100 + 0x28);
  if (bVar20) {
    pcVar17 = (code *)0x0;
  }
  else {
    pcVar17 = pcVar15;
    if ((pcVar15 != (code *)0x0) && (*(int *)pcVar15 + 1 != 0)) {
      *(int *)pcVar15 = *(int *)pcVar15 + 1;
    }
  }
  *(code **)(lStack_100 + 0x28) = pcVar17;
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))();
  }
  if (((pcVar15 != (code *)0x0) && (-1 < *(int *)pcVar15)) &&
     (*(longlong *)pcVar15 = *(longlong *)pcVar15 + -1, *(longlong *)pcVar15 == 0)) {
    (**(code **)(*(longlong *)(pcVar15 + 8) + 0x30))(pcVar15);
  }
LAB_1408d9055:
  plVar7 = plStack_d0;
  plVar6 = plStack_d8;
  FUN_142cdb370(plStack_f0,&UNK_142d0b320,plVar1,plStack_d0,pcVar18,plStack_c8,plStack_c0,plStack_b8
                ,pcStack_b0,pcStack_a8,pcStack_a0,plStack_98,plStack_d8,plStack_90,plStack_88,
                pcVar10);
  plVar8 = _DAT_142dea7e0;
  if (plStack_f0 == _DAT_142dea7e0) {
    if ((-1 < (int)*_DAT_142dea7e0) && (*_DAT_142dea7e0 = *_DAT_142dea7e0 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    _DAT_142dea7e0 = (longlong *)0x0;
  }
  plVar8 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar8 + 10) = 0xfffffffe;
  plVar9 = (longlong *)plVar8[2];
  if (((plVar9 != (longlong *)0x0) && (plVar8[2] = 0, -1 < (int)*plVar9)) &&
     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
    (**(code **)(plVar8[1] + 0x30))(plVar8);
  }
  lVar12 = lStack_100;
  plVar8[0xc] = 0;
  lStack_100 = 0;
  if (((pcVar18 != (code *)0x0) && (-1 < *(int *)pcVar18)) &&
     (*(longlong *)pcVar18 = *(longlong *)pcVar18 + -1, *(longlong *)pcVar18 == 0)) {
    (**(code **)(*(longlong *)(pcVar18 + 8) + 0x30))(pcVar18);
  }
  if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
     (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
    (**(code **)(plStack_c8[1] + 0x30))();
  }
  if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
     (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
    (**(code **)(plStack_c0[1] + 0x30))();
  }
  if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
     (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
    (**(code **)(plStack_b8[1] + 0x30))();
  }
  if (((pcStack_b0 != (code *)0x0) && (-1 < *(int *)pcStack_b0)) &&
     (*(longlong *)pcStack_b0 = *(longlong *)pcStack_b0 + -1, *(longlong *)pcStack_b0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_b0 + 8) + 0x30))();
  }
  if (((pcStack_a8 != (code *)0x0) && (-1 < *(int *)pcStack_a8)) &&
     (*(longlong *)pcStack_a8 = *(longlong *)pcStack_a8 + -1, *(longlong *)pcStack_a8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_a8 + 8) + 0x30))();
  }
  if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
     (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))();
  }
  if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
     (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
    (**(code **)(plStack_98[1] + 0x30))();
  }
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
     (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
    (**(code **)(plStack_90[1] + 0x30))();
  }
  if (((plStack_88 != (longlong *)0x0) && (-1 < (int)*plStack_88)) &&
     (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
    (**(code **)(plStack_88[1] + 0x30))();
  }
  if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
     (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
    (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
  }
  lStack_100 = lVar12;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
    (**(code **)(plVar7[1] + 0x30))(plVar7);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStack_100;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

