
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _imagem_aliyun(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  longlong lVar3;
  int *piVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined *puVar12;
  code *pcVar13;
  code *pcVar14;
  code *pcVar15;
  bool bVar16;
  longlong lStackX_18;
  longlong *plStackX_20;
  
  plVar5 = _DAT_142dea7c8;
  plVar8 = (longlong *)*python_pars;
  plVar1 = (longlong *)python_pars[1];
  lStackX_18 = 0;
  plStackX_20 = plVar8;
  if (_DAT_142dea7c8 == (longlong *)0x0) {
LAB_1408d2b11:
    _DAT_142dea7c8 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9bc0,_DAT_142f2aaf0,0x10);
  }
  else if ((1 < *_DAT_142dea7c8) || (_DAT_142dea7c8[2] != 0)) {
    if ((_DAT_142dea7c8 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7c8 && (*_DAT_142dea7c8 = *_DAT_142dea7c8 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408d2b11;
  }
  plVar5 = _DAT_142dea7c8;
  Nuitka_helper_140008a00(tstate,_DAT_142dea7c8);
  iVar7 = FUN_140004970(plVar1);
  puVar12 = classes_const_830___bytes_hex______;
  pcVar14 = (code *)0x0;
  if (iVar7 == -1) {
    pcVar15 = (code *)0x23f7;
    goto LAB_1408d2fe9;
  }
  if (iVar7 == 0) {
    if (*(int *)classes_const_830___bytes_hex______ + 1 != 0) {
      *(int *)classes_const_830___bytes_hex______ = *(int *)classes_const_830___bytes_hex______ + 1;
    }
    goto LAB_1408d2ec1;
  }
  plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1434_startswith);
  pcVar15 = (code *)0x23f9;
  if (plVar8 == (longlong *)0x0) {
LAB_1408d2fe9:
    lVar10 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
  }
  else {
    *(undefined4 *)(plVar5 + 5) = 0x23f9;
    plVar9 = (longlong *)
             FUN_142cccf70(tstate,plVar8,classes_const_1724___type____T____items_____data____);
    if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))(plVar8);
    }
    if (plVar9 == (longlong *)0x0) goto LAB_1408d2fe9;
    iVar7 = FUN_140004970(plVar9);
    if (iVar7 == -1) {
      lStackX_18 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      lVar10 = lStackX_18;
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
        lVar10 = lStackX_18;
      }
    }
    else {
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      if (iVar7 == 0) {
        pcVar15 = (code *)0x23fe;
        *(undefined4 *)(plVar5 + 5) = 0x23fe;
        puVar12 = (undefined *)
                  FUN_142cd12f0(tstate,plStackX_20,classes_const_1864__baixar_bytes,plVar1);
        plVar8 = plStackX_20;
        if (puVar12 != (undefined *)0x0) goto LAB_1408d2ec1;
        goto LAB_1408d2fe9;
      }
      lVar10 = FUN_140a39450();
      if (lVar10 == 0) {
        FUN_142cde870(tstate,&lStackX_18,classes_const_827_base64);
      }
      else {
        plVar8 = (longlong *)FUN_142cd7b20(tstate,lVar10,classes_const_828_b64decode);
        if (plVar8 == (longlong *)0x0) {
LAB_1408d2d84:
          lStackX_18 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
        }
        else {
          plVar9 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_529_split);
          if (plVar9 != (longlong *)0x0) {
            *(undefined4 *)(plVar5 + 5) = 0x23fb;
            plVar11 = (longlong *)
                      FUN_142ccd7d0(tstate,plVar9,
                                    classes_const_1845___type____T____items_________1__);
            if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
            if (plVar11 != (longlong *)0x0) {
              plVar9 = (longlong *)FUN_140008f40(tstate,plVar11,shared_const_3_1,1);
              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                (**(code **)(plVar11[1] + 0x30))(plVar11);
              }
              if (plVar9 != (longlong *)0x0) {
                *(undefined4 *)(plVar5 + 5) = 0x23fb;
                puVar12 = (undefined *)FUN_142ccfd60(tstate,plVar8,plVar9);
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                }
                plVar8 = plStackX_20;
                if (puVar12 != (undefined *)0x0) goto LAB_1408d2ec1;
                goto LAB_1408d2d84;
              }
            }
          }
          lStackX_18 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
            (**(code **)(plVar8[1] + 0x30))(plVar8);
          }
        }
      }
      lVar10 = lStackX_18;
      piVar4 = *(int **)(tstate + 0xf8);
      lStackX_18 = 0;
      if ((piVar4 != (int *)0x0) && (*piVar4 + 1 != 0)) {
        *piVar4 = *piVar4 + 1;
      }
      piVar2 = *(int **)(lVar10 + 0x28);
      pcVar15 = (code *)FUN_142cd9160(plVar5,0x23fb);
      if (piVar2 != (int *)0x0) {
        *(int **)(pcVar15 + 0x10) = piVar2;
        if (*piVar2 + 1 != 0) {
          *piVar2 = *piVar2 + 1;
        }
      }
      plVar8 = *(longlong **)(lVar10 + 0x28);
      pcVar13 = pcVar14;
      if (((pcVar15 != _Py_NoneStruct_exref) && (pcVar13 = pcVar15, pcVar15 != (code *)0x0)) &&
         (*(int *)pcVar15 + 1 != 0)) {
        *(int *)pcVar15 = *(int *)pcVar15 + 1;
      }
      *(code **)(lVar10 + 0x28) = pcVar13;
      if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))();
      }
      if (((pcVar15 != (code *)0x0) && (-1 < *(int *)pcVar15)) &&
         (*(longlong *)pcVar15 = *(longlong *)pcVar15 + -1, *(longlong *)pcVar15 == 0)) {
        (**(code **)(*(longlong *)(pcVar15 + 8) + 0x30))(pcVar15);
      }
      plVar8 = *(longlong **)(tstate + 0xf8);
      *(longlong *)(tstate + 0xf8) = lVar10;
      if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))();
      }
      iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                            *(undefined8 *)PyExc_Exception_exref);
      puVar12 = classes_const_830___bytes_hex______;
      if (iVar7 != 0) {
        if (*(int *)classes_const_830___bytes_hex______ + 1 != 0) {
          *(int *)classes_const_830___bytes_hex______ =
               *(int *)classes_const_830___bytes_hex______ + 1;
        }
        plVar5 = *(longlong **)(tstate + 0xf8);
        *(int **)(tstate + 0xf8) = piVar4;
        plVar8 = plStackX_20;
        if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
           (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))();
          plVar8 = plStackX_20;
        }
LAB_1408d2ec1:
        plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
        *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
        *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
        plVar9 = (longlong *)plVar5[2];
        if (((plVar9 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar9)) &&
           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
          (**(code **)(plVar9[1] + 0x30))();
        }
        if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))(plVar5);
        }
        plVar5[0xc] = 0;
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if ((int)*plVar1 < 0) {
          return puVar12;
        }
        *plVar1 = *plVar1 + -1;
        if (*plVar1 != 0) {
          return puVar12;
        }
        (**(code **)(plVar1[1] + 0x30))(plVar1);
        return puVar12;
      }
      cVar6 = FUN_142cded30(tstate,&lStackX_18);
      lVar10 = lStackX_18;
      pcVar15 = (code *)0x23fa;
      if (cVar6 != '\0') {
        pcVar15 = pcVar14;
      }
      lVar3 = *(longlong *)(lStackX_18 + 0x28);
      if ((lVar3 != 0) && (*(longlong **)(lVar3 + 0x18) == plVar5)) {
        *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar3 + 0x24);
      }
      plVar8 = *(longlong **)(tstate + 0xf8);
      lStackX_18 = 0;
      *(int **)(tstate + 0xf8) = piVar4;
      if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))();
      }
    }
  }
  lStackX_18 = lVar10;
  piVar4 = *(int **)(lStackX_18 + 0x28);
  if (piVar4 == (int *)0x0) {
    pcVar15 = (code *)FUN_142cd9160(plVar5,pcVar15);
    bVar16 = pcVar15 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar4 + 6) == plVar5) goto LAB_1408d3092;
    pcVar15 = (code *)FUN_142cd9160(plVar5,pcVar15);
    *(int **)(pcVar15 + 0x10) = piVar4;
    if (*piVar4 + 1 != 0) {
      *piVar4 = *piVar4 + 1;
    }
    bVar16 = pcVar15 == _Py_NoneStruct_exref;
  }
  plVar8 = *(longlong **)(lStackX_18 + 0x28);
  if (((!bVar16) && (pcVar14 = pcVar15, pcVar15 != (code *)0x0)) && (*(int *)pcVar15 + 1 != 0)) {
    *(int *)pcVar15 = *(int *)pcVar15 + 1;
  }
  *(code **)(lStackX_18 + 0x28) = pcVar14;
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))();
  }
  if (((pcVar15 != (code *)0x0) && (-1 < *(int *)pcVar15)) &&
     (*(longlong *)pcVar15 = *(longlong *)pcVar15 + -1, *(longlong *)pcVar15 == 0)) {
    (**(code **)(*(longlong *)(pcVar15 + 8) + 0x30))(pcVar15);
  }
LAB_1408d3092:
  plVar9 = plStackX_20;
  FUN_142cdb370(plVar5,&UNK_142d0ae3c,plStackX_20,plVar1);
  plVar8 = _DAT_142dea7c8;
  if (plVar5 == _DAT_142dea7c8) {
    if ((-1 < (int)*_DAT_142dea7c8) && (*_DAT_142dea7c8 = *_DAT_142dea7c8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    _DAT_142dea7c8 = (longlong *)0x0;
  }
  plVar8 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar8 + 10) = 0xfffffffe;
  plVar5 = (longlong *)plVar8[2];
  if (((plVar5 != (longlong *)0x0) && (plVar8[2] = 0, -1 < (int)*plVar5)) &&
     (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))();
  }
  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
    (**(code **)(plVar8[1] + 0x30))(plVar8);
  }
  plVar8[0xc] = 0;
  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar8 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))();
  }
  return (undefined *)0x0;
}

