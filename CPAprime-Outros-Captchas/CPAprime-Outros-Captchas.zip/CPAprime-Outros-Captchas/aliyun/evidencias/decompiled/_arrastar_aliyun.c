
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _arrastar_aliyun(undefined *tstate,undefined *self,undefined **python_pars)

{
  int *piVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined8 uVar12;
  code *pcVar13;
  code *pcVar14;
  undefined *puVar15;
  undefined4 uVar16;
  longlong *plVar17;
  longlong *plVar18;
  int *piVar19;
  bool bVar20;
  undefined1 auStack_1d8 [32];
  longlong *plStack_1b8;
  longlong *plStack_1b0;
  longlong *plStack_1a8;
  longlong *plStack_1a0;
  longlong *plStack_198;
  longlong *plStack_190;
  longlong *plStack_188;
  longlong *plStack_180;
  longlong *plStack_178;
  longlong *plStack_170;
  longlong *plStack_168;
  longlong *plStack_160;
  longlong *plStack_158;
  longlong *plStack_150;
  longlong *plStack_148;
  longlong alStack_138 [2];
  longlong *plStack_128;
  longlong *plStack_120;
  longlong *plStack_118;
  longlong *plStack_110;
  longlong *plStack_108;
  longlong *plStack_100;
  longlong *plStack_f8;
  longlong *plStack_f0;
  longlong *plStack_e8;
  longlong *plStack_e0;
  longlong *plStack_d8;
  longlong *plStack_d0;
  longlong *plStack_c8;
  longlong *plStack_c0;
  longlong *plStack_b8;
  longlong *plStack_b0;
  longlong *plStack_a8;
  longlong *plStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_88;
  longlong *plStack_80;
  undefined *puStack_78;
  longlong *plStack_70;
  longlong *plStack_68;
  undefined *puStack_60;
  longlong *plStack_58;
  longlong *plStack_50;
  ulonglong uStack_48;
  
  plVar11 = _DAT_142dea7e8;
  uStack_48 = _DAT_142d9a1c0 ^ (ulonglong)auStack_1d8;
  plStack_f8 = (longlong *)*python_pars;
  plVar9 = (longlong *)0x0;
  plVar7 = (longlong *)python_pars[1];
  plVar18 = (longlong *)0x0;
  plVar17 = (longlong *)0x0;
  plStack_88 = (longlong *)python_pars[2];
  alStack_138[0] = 0;
  plStack_e0 = (longlong *)0x0;
  plStack_d0 = (longlong *)0x0;
  plStack_f0 = (longlong *)0x0;
  plStack_e8 = (longlong *)0x0;
  plStack_c8 = (longlong *)0x0;
  plStack_c0 = (longlong *)0x0;
  plStack_100 = (longlong *)0x0;
  plStack_b8 = (longlong *)0x0;
  plStack_d8 = (longlong *)0x0;
  plStack_b0 = (longlong *)0x0;
  plStack_a8 = (longlong *)0x0;
  plStack_a0 = (longlong *)0x0;
  plStack_98 = (longlong *)0x0;
  plStack_118 = _DAT_142dea7e8;
  plStack_90 = plVar7;
  if (_DAT_142dea7e8 == (longlong *)0x0) {
LAB_1408d95b6:
    plStack_118 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9970,_DAT_142f2aaf0,0x88);
  }
  else if ((1 < *_DAT_142dea7e8) || (_DAT_142dea7e8[2] != 0)) {
    if ((_DAT_142dea7e8 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7e8 && (*_DAT_142dea7e8 = *_DAT_142dea7e8 + -1, *plVar11 == 0)))) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
    goto LAB_1408d95b6;
  }
  plVar11 = plStack_118;
  _DAT_142dea7e8 = plStack_118;
  Nuitka_helper_140008a00(tstate,plStack_118);
  plVar6 = (longlong *)FUN_140008da0(tstate,plVar7,classes_const_309_x);
  if (plVar6 == (longlong *)0x0) {
    lVar10 = *(longlong *)(tstate + 0x70);
    uVar16 = 0x2491;
    *(undefined8 *)(tstate + 0x70) = 0;
    plVar18 = plVar9;
    goto LAB_1408dafeb;
  }
  plVar7 = (longlong *)FUN_140008da0(tstate,plVar7,classes_const_1873_w);
  if (plVar7 == (longlong *)0x0) {
    alStack_138[0] = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
LAB_1408d9651:
    uVar16 = 0x2491;
    plVar18 = plVar9;
    lVar10 = alStack_138[0];
  }
  else {
    plVar8 = (longlong *)FUN_142cc1420(plVar7,classes_const_1792_2_0);
    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))(plVar7);
    }
    if (plVar8 == (longlong *)0x0) {
      alStack_138[0] = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if (((int)*plVar6 < 0) || (*plVar6 = *plVar6 + -1, *plVar6 != 0)) goto LAB_1408d9651;
      (**(code **)(plVar6[1] + 0x30))(plVar6);
      uVar16 = 0x2491;
      plVar9 = plVar17;
      lVar10 = alStack_138[0];
    }
    else {
      plVar7 = (longlong *)FUN_142cbe7f0(plVar6,plVar8);
      plStack_80 = plVar7;
      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
      }
      plVar9 = plStack_90;
      if (plVar7 == (longlong *)0x0) {
        lVar10 = *(longlong *)(tstate + 0x70);
        uVar16 = 0x2491;
        *(undefined8 *)(tstate + 0x70) = 0;
        plVar9 = plVar17;
      }
      else {
        plStack_e0 = plVar7;
        plVar7 = (longlong *)FUN_140008da0(tstate,plStack_90,classes_const_310_y);
        if (plVar7 == (longlong *)0x0) {
          lVar10 = *(longlong *)(tstate + 0x70);
          uVar16 = 0x2492;
          *(undefined8 *)(tstate + 0x70) = 0;
          plVar9 = plVar17;
        }
        else {
          plVar9 = (longlong *)FUN_140008da0(tstate,plVar9,classes_const_1874_h);
          if (plVar9 != (longlong *)0x0) {
            plVar6 = (longlong *)FUN_142cc1420(plVar9,classes_const_1792_2_0);
            if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
            if (plVar6 != (longlong *)0x0) {
              plVar9 = (longlong *)FUN_142cbe7f0(plVar7,plVar6);
              plStack_120 = plVar9;
              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                (**(code **)(plVar7[1] + 0x30))(plVar7);
              }
              if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                (**(code **)(plVar6[1] + 0x30))(plVar6);
              }
              plVar7 = plStack_f8;
              if (plVar9 == (longlong *)0x0) {
                lVar10 = *(longlong *)(tstate + 0x70);
                uVar16 = 0x2492;
                *(undefined8 *)(tstate + 0x70) = 0;
                plVar9 = plVar17;
              }
              else {
                puStack_78 = classes_const_1744_touchStart;
                uVar16 = 0x2493;
                *(undefined4 *)(plVar11 + 5) = 0x2493;
                plStack_70 = plStack_e0;
                plStack_d0 = plVar9;
                plStack_68 = plVar9;
                plVar9 = (longlong *)
                         FUN_142cd0950(tstate,plStack_f8,classes_const_2008__toque_cru,&puStack_78);
                if (plVar9 == (longlong *)0x0) {
                  lVar10 = *(longlong *)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  plVar9 = plVar17;
                }
                else {
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  lVar10 = FUN_140a3b210(tstate);
                  if (lVar10 == 0) {
                    FUN_142cde870(tstate,alStack_138,classes_const_76_time);
                    uVar16 = 0x2494;
                    plVar9 = plVar17;
                    lVar10 = alStack_138[0];
                  }
                  else {
                    uVar16 = 0x2494;
                    *(undefined4 *)(plVar11 + 5) = 0x2494;
                    plVar9 = (longlong *)
                             FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep,
                                           *(undefined8 *)
                                            (classes_const_1767___type____T____items____0_35__ +
                                            0x18));
                    if (plVar9 == (longlong *)0x0) {
                      lVar10 = *(longlong *)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      plVar9 = plVar17;
                    }
                    else {
                      plVar11 = (longlong *)0x0;
                      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                      }
                      plVar9 = (longlong *)classes_const_717___float_special___0_;
                      plStack_110 = (longlong *)classes_const_717___float_special___0_;
                      if (*(int *)classes_const_717___float_special___0_ + 1 != 0) {
                        *(int *)classes_const_717___float_special___0_ =
                             *(int *)classes_const_717___float_special___0_ + 1;
                      }
                      plStack_f0 = (longlong *)classes_const_2009_0_35;
                      if (*(int *)classes_const_2009_0_35 + 1 != 0) {
                        *(int *)classes_const_2009_0_35 = *(int *)classes_const_2009_0_35 + 1;
                      }
                      plVar18 = (longlong *)
                                FUN_140009960(classes_const_2010___type_________items____0__12__1__)
                      ;
                      plStack_128 = plVar18;
                      plStack_108 = (longlong *)(**(code **)(plVar18[1] + 0xe0))(plVar18);
                      if (plStack_108 != (longlong *)0x0) {
                        iVar5 = 0x24b2;
LAB_1408d9940:
                        plVar18 = plStack_e8;
                        if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                           (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))(plVar11);
                        }
                        iVar4 = (int)*plStack_108 + 1;
                        if (iVar4 != 0) {
                          *(int *)plStack_108 = iVar4;
                        }
                        plStack_e8 = plStack_108;
                        if (((plVar18 != (longlong *)0x0) && (-1 < (int)*plVar18)) &&
                           (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                          (**(code **)(plVar18[1] + 0x30))();
                        }
                        if (plVar7 == (longlong *)0x0) {
                          FUN_142cd4900(tstate,alStack_138,classes_const_403_self);
                          FUN_1400048d0(tstate,alStack_138[0]);
                          lVar10 = alStack_138[0];
LAB_1408daa34:
                          plVar7 = plStack_118;
                          piVar19 = *(int **)(tstate + 0xf8);
                          alStack_138[0] = 0;
                          if ((piVar19 != (int *)0x0) && (*piVar19 + 1 != 0)) {
                            *piVar19 = *piVar19 + 1;
                          }
                          piVar1 = *(int **)(lVar10 + 0x28);
                          if (piVar1 == (int *)0x0) {
                            pcVar14 = (code *)FUN_142cd9160(plStack_118,0x249a);
                            plVar11 = *(longlong **)(lVar10 + 0x28);
                            if (pcVar14 == _Py_NoneStruct_exref) {
                              pcVar13 = (code *)0x0;
                            }
                            else {
                              pcVar13 = pcVar14;
                              if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
                                *(int *)pcVar14 = *(int *)pcVar14 + 1;
                              }
                            }
                            *(code **)(lVar10 + 0x28) = pcVar13;
                            if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                               (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))();
                            }
                            if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                               (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                               *(longlong *)pcVar14 == 0)) {
                              (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                            }
                          }
                          else {
                            pcVar14 = (code *)FUN_142cd9160(plStack_118,0x249a);
                            *(int **)(pcVar14 + 0x10) = piVar1;
                            if (*piVar1 + 1 != 0) {
                              *piVar1 = *piVar1 + 1;
                            }
                            plVar7 = *(longlong **)(lVar10 + 0x28);
                            if (pcVar14 == _Py_NoneStruct_exref) {
                              pcVar13 = (code *)0x0;
                            }
                            else {
                              pcVar13 = pcVar14;
                              if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
                                *(int *)pcVar14 = *(int *)pcVar14 + 1;
                              }
                            }
                            *(code **)(lVar10 + 0x28) = pcVar13;
                            if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                               (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))();
                            }
                            plVar7 = plStack_118;
                            if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                               (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                               *(longlong *)pcVar14 == 0)) {
                              (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                              plVar7 = plStack_118;
                            }
                          }
                          plVar11 = *(longlong **)(tstate + 0xf8);
                          *(longlong *)(tstate + 0xf8) = lVar10;
                          if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                             (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))();
                          }
                          iVar5 = FUN_140008b90(tstate,*(undefined8 *)
                                                        (*(longlong *)(tstate + 0xf8) + 8),
                                                *(undefined8 *)PyExc_Exception_exref);
                          if (iVar5 != 0) {
                            plVar11 = *(longlong **)(tstate + 0xf8);
                            *(int **)(tstate + 0xf8) = piVar19;
                            plVar18 = plStack_128;
                            if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                               (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))();
                              plVar18 = plStack_128;
                            }
                            goto LAB_1408dacf9;
                          }
                          cVar3 = FUN_142cded30(tstate,alStack_138);
                          iVar5 = 0x2499;
LAB_1408dabd3:
                          lVar10 = alStack_138[0];
                          if (cVar3 != '\0') {
                            iVar5 = 0;
                          }
                          lVar2 = *(longlong *)(alStack_138[0] + 0x28);
                          if ((lVar2 != 0) && (*(longlong **)(lVar2 + 0x18) == plVar7)) {
                            *(undefined4 *)(plVar7 + 5) = *(undefined4 *)(lVar2 + 0x24);
                          }
                          alStack_138[0] = 0;
                          plVar7 = *(longlong **)(tstate + 0xf8);
                          *(int **)(tstate + 0xf8) = piVar19;
                          plVar18 = plStack_128;
                          if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                             (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))();
                            plVar18 = plStack_128;
                          }
                          goto LAB_1408dac89;
                        }
                        plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar7,classes_const_170_driver);
                        if (plVar11 == (longlong *)0x0) {
LAB_1408daa06:
                          lVar10 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          goto LAB_1408daa34;
                        }
                        plVar18 = (longlong *)
                                  FUN_142cd7b20(tstate,plVar11,classes_const_338_execute_script);
                        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))(plVar11);
                        }
                        if (plVar18 == (longlong *)0x0) goto LAB_1408daa06;
                        plVar11 = (longlong *)
                                  FUN_142cd7b20(tstate,plVar7,classes_const_2011__JS_ALIYUN_POS);
                        plVar7 = plStack_118;
                        if (plVar11 == (longlong *)0x0) {
                          alStack_138[0] = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          lVar10 = alStack_138[0];
                          if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                            (**(code **)(plVar18[1] + 0x30))(plVar18);
                            lVar10 = alStack_138[0];
                          }
                          goto LAB_1408daa34;
                        }
                        *(undefined4 *)(plStack_118 + 5) = 0x249a;
                        plVar17 = (longlong *)FUN_142ccfd60(tstate,plVar18,plVar11);
                        if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                          (**(code **)(plVar18[1] + 0x30))(plVar18);
                        }
                        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))(plVar11);
                        }
                        if (plVar17 == (longlong *)0x0) goto LAB_1408daa06;
                        plVar11 = plVar17;
                        if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
                           (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
                          plVar11 = plStack_c8 + 1;
                          plStack_c8 = plVar17;
                          (**(code **)(*plVar11 + 0x30))();
                          plVar11 = plStack_c8;
                        }
                        plStack_c8 = plVar11;
                        iVar4 = PyObject_IsInstance(plVar17,PyDict_Type_exref);
                        if (iVar4 == -1) {
LAB_1408da9d3:
                          iVar5 = 0x249d;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        pcVar14 = _Py_FalseStruct_exref;
                        if (iVar4 != 0) {
                          pcVar14 = _Py_TrueStruct_exref;
                        }
                        iVar4 = FUN_140004970(pcVar14);
                        if (iVar4 == -1) goto LAB_1408da9d3;
                        bVar20 = iVar4 == 0;
                        if (iVar4 != 0) {
                          plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar17,classes_const_211_get);
                          if (plVar11 != (longlong *)0x0) {
                            *(undefined4 *)(plVar7 + 5) = 0x249d;
                            pcVar14 = (code *)FUN_142cccf70(tstate,plVar11,
                                                                                                                        
                                                  classes_const_1988___type____T____items_____peca___
                                                  );
                            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                            }
                            if (pcVar14 != (code *)0x0) {
                              bVar20 = pcVar14 == _Py_NoneStruct_exref;
                              if ((-1 < *(int *)pcVar14) &&
                                 (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                                 *(longlong *)pcVar14 == 0)) {
                                (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                              }
                              goto LAB_1408d9b2a;
                            }
                          }
                          goto LAB_1408da9d3;
                        }
LAB_1408d9b2a:
                        plVar11 = plStack_88;
                        plVar18 = plStack_128;
                        if (bVar20) goto LAB_1408dacf9;
                        if (plStack_88 == (longlong *)0x0) {
                          FUN_142cd4900(tstate,alStack_138,classes_const_2012_alvo_peca);
                          FUN_1400048d0(tstate,alStack_138[0]);
                          iVar5 = 0x249f;
                          lVar10 = alStack_138[0];
                          plVar18 = plStack_128;
                          goto LAB_1408dac89;
                        }
                        plVar7 = (longlong *)FUN_140008da0(tstate,plVar17,classes_const_1990_peca);
                        if (plVar7 == (longlong *)0x0) {
LAB_1408da995:
                          iVar5 = 0x249f;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar11 = (longlong *)FUN_142cc11d0(plVar11,plVar7);
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (plVar11 == (longlong *)0x0) goto LAB_1408da995;
                        plVar7 = plVar11;
                        if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
                           (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
                          plVar7 = plStack_c0 + 1;
                          plStack_c0 = plVar11;
                          (**(code **)(*plVar7 + 0x30))();
                          plVar7 = plStack_c0;
                        }
                        plStack_c0 = plVar7;
                        plVar7 = (longlong *)Nuitka_helper_142cc1650(plVar11);
                        if (plVar7 == (longlong *)0x0) {
LAB_1408da986:
                          iVar5 = 0x24a0;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        iVar4 = FUN_142ce1c20(plVar7,classes_const_1793_1_0);
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (iVar4 == -1) goto LAB_1408da986;
                        plVar7 = plStack_118;
                        plVar18 = plStack_128;
                        if (iVar4 == 1) goto LAB_1408dacf9;
                        plVar7 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_228_max);
                        if ((plVar7 == (longlong *)0x0) || (lVar10 = *plVar7, lVar10 == 0)) {
                          PyErr_PrintEx(0);
                          Py_Exit(1);
                          pcVar14 = (code *)swi(3);
                          puVar15 = (undefined *)(*pcVar14)();
                          return puVar15;
                        }
                        if (plStack_f0 == (longlong *)0x0) {
                          FUN_142cd4900(tstate,alStack_138,classes_const_2013_razao);
                          FUN_1400048d0(tstate,alStack_138[0]);
                          iVar5 = 0x24a2;
                          lVar10 = alStack_138[0];
                          plVar18 = plStack_128;
                          goto LAB_1408dac89;
                        }
                        plStack_70 = plStack_f0;
                        puStack_78 = classes_const_1499_0_15;
                        *(undefined4 *)(plStack_118 + 5) = 0x24a2;
                        plVar7 = (longlong *)FUN_142cc4ec0(tstate,lVar10,&puStack_78);
                        if (plVar7 == (longlong *)0x0) {
LAB_1408da931:
                          iVar5 = 0x24a2;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar11 = (longlong *)FUN_142cc1540(plVar11,plVar7);
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (plVar11 == (longlong *)0x0) goto LAB_1408da931;
                        plVar7 = plVar11;
                        if (((plStack_100 != (longlong *)0x0) && (-1 < (int)*plStack_100)) &&
                           (*plStack_100 = *plStack_100 + -1, *plStack_100 == 0)) {
                          plVar7 = plStack_100 + 1;
                          plStack_100 = plVar11;
                          (**(code **)(*plVar7 + 0x30))();
                          plVar7 = plStack_100;
                        }
                        plStack_100 = plVar7;
                        iVar4 = FUN_142ce1250(plVar11,classes_const_2014_120);
                        puVar15 = classes_const_2014_120;
                        if (iVar4 == -1) {
                          iVar5 = 0x24a3;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar7 = plVar11;
                        if (iVar4 == 1) {
                          plStack_100 = (longlong *)classes_const_2014_120;
                          if (*(int *)classes_const_2014_120 + 1 != 0) {
                            *(int *)classes_const_2014_120 = *(int *)classes_const_2014_120 + 1;
                          }
                          plVar7 = (longlong *)puVar15;
                          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                          }
                        }
                        iVar4 = FUN_142ce2c80(plVar7,classes_const_2015__120);
                        puVar15 = classes_const_2015__120;
                        if (iVar4 == -1) {
                          iVar5 = 0x24a5;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar11 = plVar7;
                        if (iVar4 == 1) {
                          plStack_100 = (longlong *)classes_const_2015__120;
                          if (*(int *)classes_const_2015__120 + 1 != 0) {
                            *(int *)classes_const_2015__120 = *(int *)classes_const_2015__120 + 1;
                          }
                          plVar11 = (longlong *)puVar15;
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))();
                          }
                        }
                        plVar17 = (longlong *)FUN_140008da0(tstate,plVar17,classes_const_1990_peca);
                        plVar7 = plStack_b8;
                        if (plVar17 == (longlong *)0x0) {
                          iVar5 = 0x24a7;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar9 = plVar17;
                        if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
                           (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
                          plVar9 = plStack_b8 + 1;
                          plStack_b8 = plVar17;
                          (**(code **)(*plVar9 + 0x30))(plVar7);
                          plVar9 = plStack_b8;
                        }
                        plStack_b8 = plVar9;
                        plVar9 = plStack_d8;
                        plVar7 = plStack_110;
                        if (plStack_110 == (longlong *)0x0) {
                          FUN_142cd4900(tstate,alStack_138,classes_const_2016_dedo);
                          FUN_1400048d0(tstate,alStack_138[0]);
                          iVar5 = 0x24a8;
                          lVar10 = alStack_138[0];
                          plVar18 = plStack_128;
                          goto LAB_1408dac89;
                        }
                        plStack_d8 = plStack_110;
                        iVar4 = (int)*plStack_110 + 1;
                        if (iVar4 != 0) {
                          *(int *)plStack_110 = iVar4;
                        }
                        if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
                           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                          (**(code **)(plVar9[1] + 0x30))(plVar9,plVar9);
                        }
                        plVar9 = (longlong *)func_0x000142cbe2a0(plVar7,plVar11);
                        plVar11 = plStack_b0;
                        if (plVar9 == (longlong *)0x0) {
                          iVar5 = 0x24a9;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar18 = plVar9;
                        if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
                           (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
                          plVar18 = plStack_b0 + 1;
                          plStack_b0 = plVar9;
                          (**(code **)(*plVar18 + 0x30))(plVar11);
                          plVar18 = plStack_b0;
                        }
                        while( true ) {
                          plStack_b0 = plVar18;
                          if (plVar7 == (longlong *)0x0) {
                            FUN_142cd4900(tstate,alStack_138,classes_const_2016_dedo);
                            FUN_1400048d0(tstate,alStack_138[0]);
                            iVar5 = 0x24aa;
                            lVar10 = alStack_138[0];
                            plVar18 = plStack_128;
                            goto LAB_1408dac89;
                          }
                          plVar11 = (longlong *)FUN_142cc11d0(plVar7,plVar9);
                          if (plVar11 == (longlong *)0x0) goto LAB_1408da52d;
                          plVar18 = (longlong *)Nuitka_helper_142cc1650(plVar11);
                          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                          }
                          if (plVar18 == (longlong *)0x0) goto LAB_1408da52d;
                          plVar11 = (longlong *)FUN_142ce1790(plVar18,classes_const_213_0_5);
                          if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                            (**(code **)(plVar18[1] + 0x30))(plVar18);
                          }
                          if (plVar11 == (longlong *)0x0) goto LAB_1408da52d;
                          iVar4 = FUN_140004970(plVar11);
                          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                          }
                          if (iVar4 == -1) goto LAB_1408da52d;
                          if (iVar4 == 0) break;
                          plVar11 = (longlong *)FUN_142cc11d0(plVar9,plVar7);
                          if (plVar11 == (longlong *)0x0) {
LAB_1408da5c1:
                            iVar5 = 0x24ab;
                            plVar18 = plStack_128;
                            goto LAB_1408dac7d;
                          }
                          plVar18 = (longlong *)Nuitka_helper_142cc1650(plVar11);
                          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                          }
                          if (plVar18 == (longlong *)0x0) goto LAB_1408da5c1;
                          iVar4 = FUN_142ce2c80(plVar18,classes_const_721_6);
                          if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                            (**(code **)(plVar18[1] + 0x30))(plVar18);
                          }
                          if (iVar4 == -1) goto LAB_1408da5c1;
                          if (iVar4 == 1) {
                            iVar4 = (int)*plVar9 + 1;
                            plVar11 = plVar9;
                            if (iVar4 != 0) {
                              *(int *)plVar9 = iVar4;
                            }
                          }
                          else {
                            iVar4 = FUN_142ce13d0(plVar9,plVar7);
                            if (iVar4 == -1) {
                              iVar5 = 0x24ad;
                              plVar18 = plStack_128;
                              goto LAB_1408dac7d;
                            }
                            if (iVar4 == 1) {
                              plVar11 = (longlong *)FUN_142cbe6d0();
                              if (plVar11 == (longlong *)0x0) {
                                iVar5 = 0x24ae;
                                plVar18 = plStack_128;
                                goto LAB_1408dac7d;
                              }
                            }
                            else {
                              plVar11 = (longlong *)FUN_142cc10e0(plVar7,classes_const_721_6);
                              if (plVar11 == (longlong *)0x0) {
                                iVar5 = 0x24b0;
                                plVar18 = plStack_128;
                                goto LAB_1408dac7d;
                              }
                            }
                          }
                          plStack_110 = plVar11;
                          plVar11 = plStack_110;
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
                          plVar7 = (longlong *)
                                   FUN_142cd7b20(tstate,plStack_f8,classes_const_2008__toque_cru);
                          puVar15 = classes_const_2018_touchMove;
                          if (plVar7 == (longlong *)0x0) {
LAB_1408da55c:
                            iVar5 = 0x24b1;
                            plVar18 = plStack_128;
                            goto LAB_1408dac7d;
                          }
                          plVar11 = (longlong *)FUN_142cbe7f0(plStack_e0,plVar11);
                          if (plVar11 == (longlong *)0x0) {
                            alStack_138[0] = *(longlong *)(tstate + 0x70);
                            *(undefined8 *)(tstate + 0x70) = 0;
                            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                            }
                            iVar5 = 0x24b1;
                            lVar10 = alStack_138[0];
                            plVar18 = plStack_128;
                            goto LAB_1408dac89;
                          }
                          puStack_60 = puVar15;
                          *(undefined4 *)(plStack_118 + 5) = 0x24b1;
                          plStack_50 = plStack_d0;
                          plStack_58 = plVar11;
                          plVar18 = (longlong *)FUN_142cc5e90(tstate,plVar7,&puStack_60);
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
                          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                          }
                          if (plVar18 == (longlong *)0x0) goto LAB_1408da55c;
                          if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                            (**(code **)(plVar18[1] + 0x30))(plVar18);
                          }
                          lVar10 = FUN_140a3b210(tstate);
                          if (lVar10 == 0) {
                            FUN_142cde870(tstate,alStack_138,classes_const_76_time);
                            lVar10 = alStack_138[0];
                            plVar18 = plStack_128;
                            goto LAB_1408dac89;
                          }
                          *(undefined4 *)(plStack_118 + 5) = 0x24b2;
                          plVar7 = (longlong *)
                                   FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep,
                                                 *(undefined8 *)
                                                  (
                                                  classes_const_2021___type____T____items____0_012__
                                                  + 0x18));
                          plVar18 = plStack_128;
                          if (plVar7 == (longlong *)0x0) goto LAB_1408dac7d;
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
                          if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                              (iVar4 = Py_MakePendingCalls(), iVar4 < 0)) &&
                             (*(longlong *)(tstate + 0x70) != 0)) goto LAB_1408da52d;
                          if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                            PyEval_SaveThread();
                            PyEval_AcquireThread(tstate);
                          }
                          plVar7 = plStack_110;
                          plVar18 = plStack_b0;
                          if (*(longlong *)(tstate + 0x90) != 0) {
                            plVar7 = *(longlong **)(tstate + 0x70);
                            *(undefined8 *)(tstate + 0x90) = 0;
                            uVar12 = FUN_142cd9e70(tstate);
                            *(undefined8 *)(tstate + 0x70) = uVar12;
                            if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                               (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                            }
LAB_1408da52d:
                            iVar5 = 0x24aa;
                            plVar18 = plStack_128;
                            goto LAB_1408dac7d;
                          }
                        }
                        lVar10 = FUN_140a3b210(tstate);
                        plVar7 = plStack_118;
                        if (lVar10 == 0) {
                          FUN_142cde870(tstate,alStack_138,classes_const_76_time);
                          iVar5 = 0x24b3;
                          lVar10 = alStack_138[0];
                          plVar18 = plStack_128;
                          goto LAB_1408dac89;
                        }
                        *(undefined4 *)(plStack_118 + 5) = 0x24b3;
                        plVar11 = (longlong *)
                                  FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep,
                                                *(undefined8 *)
                                                 (classes_const_1551___type____T____items____0_3__ +
                                                 0x18));
                        if (plVar11 == (longlong *)0x0) {
                          iVar5 = 0x24b3;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))(plVar11);
                        }
                        plVar11 = plStack_f8;
                        plVar9 = (longlong *)
                                 FUN_142cd7b20(tstate,plStack_f8,classes_const_170_driver);
                        if (plVar9 == (longlong *)0x0) {
LAB_1408da6b9:
                          lVar10 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408da6c3:
                          plVar7 = plStack_118;
                          piVar19 = *(int **)(tstate + 0xf8);
                          alStack_138[0] = 0;
                          if ((piVar19 != (int *)0x0) && (*piVar19 + 1 != 0)) {
                            *piVar19 = *piVar19 + 1;
                          }
                          piVar1 = *(int **)(lVar10 + 0x28);
                          if (piVar1 == (int *)0x0) {
                            pcVar14 = (code *)FUN_142cd9160(plStack_118,0x24b5);
                            plVar11 = *(longlong **)(lVar10 + 0x28);
                            if (pcVar14 == _Py_NoneStruct_exref) {
                              pcVar13 = (code *)0x0;
                            }
                            else {
                              pcVar13 = pcVar14;
                              if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
                                *(int *)pcVar14 = *(int *)pcVar14 + 1;
                              }
                            }
                            *(code **)(lVar10 + 0x28) = pcVar13;
                            if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                               (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))();
                            }
                            if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                               (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                               *(longlong *)pcVar14 == 0)) {
                              (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                            }
                          }
                          else {
                            pcVar14 = (code *)FUN_142cd9160(plStack_118,0x24b5);
                            *(int **)(pcVar14 + 0x10) = piVar1;
                            if (*piVar1 + 1 != 0) {
                              *piVar1 = *piVar1 + 1;
                            }
                            plVar7 = *(longlong **)(lVar10 + 0x28);
                            if (pcVar14 == _Py_NoneStruct_exref) {
                              pcVar13 = (code *)0x0;
                            }
                            else {
                              pcVar13 = pcVar14;
                              if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
                                *(int *)pcVar14 = *(int *)pcVar14 + 1;
                              }
                            }
                            *(code **)(lVar10 + 0x28) = pcVar13;
                            if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                               (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))();
                            }
                            plVar7 = plStack_118;
                            if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                               (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                               *(longlong *)pcVar14 == 0)) {
                              (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                              plVar7 = plStack_118;
                            }
                          }
                          plVar11 = *(longlong **)(tstate + 0xf8);
                          *(longlong *)(tstate + 0xf8) = lVar10;
                          if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                             (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))();
                          }
                          iVar5 = FUN_140008b90(tstate,*(undefined8 *)
                                                        (*(longlong *)(tstate + 0xf8) + 8),
                                                *(undefined8 *)PyExc_Exception_exref);
                          if (iVar5 == 0) {
                            cVar3 = FUN_142cded30(tstate,alStack_138);
                            iVar5 = 0x24b4;
                            goto LAB_1408dabd3;
                          }
                          plVar11 = *(longlong **)(tstate + 0xf8);
                          *(int **)(tstate + 0xf8) = piVar19;
                          plVar18 = plStack_128;
                          plVar9 = plStack_110;
                          if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                             (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))();
                            plVar18 = plStack_128;
                            plVar9 = plStack_110;
                          }
                          goto LAB_1408dacf9;
                        }
                        plVar18 = (longlong *)
                                  FUN_142cd7b20(tstate,plVar9,classes_const_338_execute_script);
                        if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                          (**(code **)(plVar9[1] + 0x30))(plVar9);
                        }
                        if (plVar18 == (longlong *)0x0) goto LAB_1408da6b9;
                        plVar11 = (longlong *)
                                  FUN_142cd7b20(tstate,plVar11,classes_const_2011__JS_ALIYUN_POS);
                        if (plVar11 == (longlong *)0x0) {
                          alStack_138[0] = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          lVar10 = alStack_138[0];
                          if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                            (**(code **)(plVar18[1] + 0x30))(plVar18);
                            lVar10 = alStack_138[0];
                          }
                          goto LAB_1408da6c3;
                        }
                        *(undefined4 *)(plVar7 + 5) = 0x24b5;
                        plVar6 = (longlong *)FUN_142ccfd60(tstate,plVar18,plVar11);
                        if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                          (**(code **)(plVar18[1] + 0x30))(plVar18);
                        }
                        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))(plVar11);
                        }
                        if (plVar6 == (longlong *)0x0) goto LAB_1408da6b9;
                        plVar11 = plVar6;
                        if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
                           (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
                          plVar11 = plStack_a8 + 1;
                          plStack_a8 = plVar6;
                          (**(code **)(*plVar11 + 0x30))();
                          plVar11 = plStack_a8;
                        }
                        plStack_a8 = plVar11;
                        iVar4 = PyObject_IsInstance(plVar6,PyDict_Type_exref);
                        if (iVar4 == -1) {
LAB_1408da5d0:
                          iVar5 = 0x24b8;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        bVar20 = iVar4 != 0;
                        if (iVar4 != 0) {
                          plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_211_get);
                          if (plVar11 != (longlong *)0x0) {
                            *(undefined4 *)(plVar7 + 5) = 0x24b8;
                            pcVar14 = (code *)FUN_142cccf70(tstate,plVar11,
                                                                                                                        
                                                  classes_const_1988___type____T____items_____peca___
                                                  );
                            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                            }
                            if (pcVar14 != (code *)0x0) {
                              bVar20 = pcVar14 != _Py_NoneStruct_exref;
                              if ((-1 < *(int *)pcVar14) &&
                                 (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                                 *(longlong *)pcVar14 == 0)) {
                                (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                              }
                              goto LAB_1408da2b2;
                            }
                          }
                          goto LAB_1408da5d0;
                        }
LAB_1408da2b2:
                        plVar9 = plStack_110;
                        plVar7 = plStack_f0;
                        if (!bVar20) goto LAB_1408da486;
                        plVar7 = (longlong *)FUN_140008da0(tstate,plVar6,classes_const_1990_peca);
                        if (plVar7 == (longlong *)0x0) {
LAB_1408da644:
                          iVar5 = 0x24b9;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar11 = (longlong *)FUN_142cc11d0(plVar7,plVar17);
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (plVar11 == (longlong *)0x0) goto LAB_1408da644;
                        plVar7 = plVar11;
                        if (((plStack_a0 != (longlong *)0x0) && (-1 < (int)*plStack_a0)) &&
                           (*plStack_a0 = *plStack_a0 + -1, *plStack_a0 == 0)) {
                          plVar7 = plStack_a0 + 1;
                          plStack_a0 = plVar11;
                          (**(code **)(*plVar7 + 0x30))();
                          plVar7 = plStack_a0;
                        }
                        plStack_a0 = plVar7;
                        plVar9 = plStack_110;
                        plVar18 = (longlong *)func_0x000142cc10b0(plStack_110,plStack_d8);
                        plVar7 = plStack_98;
                        if (plVar18 == (longlong *)0x0) {
                          iVar5 = 0x24ba;
                          plVar18 = plStack_128;
                          goto LAB_1408dac7d;
                        }
                        plVar17 = plVar18;
                        if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
                           (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
                          plVar17 = plStack_98 + 1;
                          plStack_98 = plVar18;
                          (**(code **)(*plVar17 + 0x30))(plVar7);
                          plVar17 = plStack_98;
                        }
                        plStack_98 = plVar17;
                        plVar7 = (longlong *)Nuitka_helper_142cc1650(plVar18);
                        if (plVar7 != (longlong *)0x0) {
                          iVar4 = FUN_142ce1250(plVar7,classes_const_1376_3);
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
                          if (iVar4 == -1) goto LAB_1408da626;
                          plVar7 = plStack_f0;
                          if (iVar4 != 1) {
LAB_1408da486:
                            plStack_f0 = plVar7;
                            if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                                (iVar4 = Py_MakePendingCalls(), iVar4 < 0)) &&
                               (plVar18 = plStack_128, *(longlong *)(tstate + 0x70) != 0))
                            goto LAB_1408dac77;
                            if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                              PyEval_SaveThread();
                              PyEval_AcquireThread(tstate);
                            }
                            plVar11 = plStack_108;
                            plVar18 = plStack_128;
                            if (*(longlong *)(tstate + 0x90) != 0) {
                              plVar7 = *(longlong **)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x90) = 0;
                              uVar12 = FUN_142cd9e70(tstate);
                              *(undefined8 *)(tstate + 0x70) = uVar12;
                              plVar18 = plStack_128;
                              if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                                 (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                                plVar18 = plStack_128;
                              }
                              goto LAB_1408dac77;
                            }
                            plStack_108 = (longlong *)
                                          (**(code **)(plStack_128[1] + 0xe0))(plStack_128);
                            plVar7 = plStack_f8;
                            if (plStack_108 == (longlong *)0x0) goto LAB_1408dac27;
                            goto LAB_1408d9940;
                          }
                          plVar7 = (longlong *)Nuitka_helper_142cc1650(plVar11);
                          if (plVar7 != (longlong *)0x0) {
                            iVar4 = FUN_142ce10d0(plVar7,classes_const_213_0_5);
                            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                            }
                            if (iVar4 == -1) goto LAB_1408da626;
                            plVar7 = plStack_f0;
                            if (iVar4 != 1) goto LAB_1408da486;
                            plVar11 = (longlong *)Nuitka_helper_142cc1650(plVar11);
                            if (plVar11 != (longlong *)0x0) {
                              plVar18 = (longlong *)Nuitka_helper_142cc1650(plVar18);
                              if (plVar18 == (longlong *)0x0) {
                                alStack_138[0] = *(longlong *)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                                if ((-1 < (int)*plVar11) &&
                                   (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                                  (**(code **)(plVar11[1] + 0x30))(plVar11);
                                }
                                iVar5 = 0x24bc;
                                lVar10 = alStack_138[0];
                                plVar18 = plStack_128;
                                goto LAB_1408dac89;
                              }
                              plVar7 = (longlong *)FUN_142cc1540(plVar11,plVar18);
                              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0))
                              {
                                (**(code **)(plVar11[1] + 0x30))(plVar11);
                              }
                              if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0))
                              {
                                (**(code **)(plVar18[1] + 0x30))(plVar18);
                              }
                              if (plVar7 != (longlong *)0x0) {
                                if ((-1 < (int)*plStack_f0) &&
                                   (*plStack_f0 = *plStack_f0 + -1, *plStack_f0 == 0)) {
                                  plVar11 = plStack_f0 + 1;
                                  plStack_f0 = plVar7;
                                  (**(code **)(*plVar11 + 0x30))();
                                  plVar7 = plStack_f0;
                                }
                                goto LAB_1408da486;
                              }
                            }
                            iVar5 = 0x24bc;
                            plVar18 = plStack_128;
                            goto LAB_1408dac7d;
                          }
                        }
LAB_1408da626:
                        iVar5 = 0x24bb;
                        plVar18 = plStack_128;
                        goto LAB_1408dac7d;
                      }
LAB_1408dac27:
                      plVar11 = *(longlong **)(tstate + 0x70);
                      plVar7 = plStack_118;
                      if (plVar11 == (longlong *)0x0) {
LAB_1408dacf9:
                        if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
                           (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
                          (**(code **)(plStack_e8[1] + 0x30))();
                        }
                        if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                          (**(code **)(plVar18[1] + 0x30))(plVar18);
                        }
                        lVar10 = FUN_140a3b210(tstate);
                        if (lVar10 == 0) {
                          FUN_142cde870(tstate,alStack_138,classes_const_76_time);
                          iVar5 = 0x24bd;
                          lVar10 = alStack_138[0];
                        }
                        else {
                          iVar5 = 0x24bd;
                          *(undefined4 *)(plVar7 + 5) = 0x24bd;
                          plVar11 = (longlong *)
                                    FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep,
                                                  *(undefined8 *)
                                                   (
                                                  classes_const_2022___type____T____items____0_25__
                                                  + 0x18));
                          if (plVar11 != (longlong *)0x0) {
                            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                            }
                            plVar11 = plStack_f8;
                            if (plStack_f8 == (longlong *)0x0) {
                              FUN_142cd4900(tstate,alStack_138,classes_const_403_self);
                              FUN_1400048d0(tstate,alStack_138[0]);
                              uVar16 = 0x24c1;
                              plVar11 = plStack_118;
                              plVar9 = plStack_100;
                              plVar18 = plStack_110;
                              lVar10 = alStack_138[0];
                            }
                            else {
                              uVar16 = 0x24c1;
                              *(undefined4 *)(plVar7 + 5) = 0x24c1;
                              plVar7 = (longlong *)
                                       FUN_142cd12f0(tstate,plStack_f8,classes_const_2008__toque_cru
                                                     ,*(undefined8 *)
                                                       (
                                                  classes_const_2023___type____T____items_____touchEnd___
                                                  + 0x18));
                              if (plVar7 != (longlong *)0x0) {
                                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  (**(code **)(plVar7[1] + 0x30))();
                                }
                                FUN_140008990(tstate);
                                if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                  *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                                }
                                if ((-1 < (int)*plStack_80) &&
                                   (*plStack_80 = *plStack_80 + -1, *plStack_80 == 0)) {
                                  (**(code **)(plStack_e0[1] + 0x30))();
                                }
                                if ((-1 < (int)*plStack_120) &&
                                   (*plStack_120 = *plStack_120 + -1, *plStack_120 == 0)) {
                                  (**(code **)(plStack_d0[1] + 0x30))();
                                }
                                if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
                                   (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                                }
                                if (((plStack_f0 != (longlong *)0x0) && (-1 < (int)*plStack_f0)) &&
                                   (*plStack_f0 = *plStack_f0 + -1, *plStack_f0 == 0)) {
                                  (**(code **)(plStack_f0[1] + 0x30))();
                                }
                                if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
                                   (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
                                  (**(code **)(plStack_e8[1] + 0x30))();
                                }
                                if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
                                   (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
                                  (**(code **)(plStack_c8[1] + 0x30))();
                                }
                                if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
                                   (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
                                  (**(code **)(plStack_c0[1] + 0x30))();
                                }
                                if (((plStack_100 != (longlong *)0x0) && (-1 < (int)*plStack_100))
                                   && (*plStack_100 = *plStack_100 + -1, *plStack_100 == 0)) {
                                  (**(code **)(plStack_100[1] + 0x30))();
                                }
                                if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
                                   (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
                                  (**(code **)(plStack_b8[1] + 0x30))();
                                }
                                if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8)) &&
                                   (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
                                  (**(code **)(plStack_d8[1] + 0x30))();
                                }
                                if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
                                   (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
                                  (**(code **)(plStack_b0[1] + 0x30))();
                                }
                                if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
                                   (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
                                  (**(code **)(plStack_a8[1] + 0x30))();
                                }
                                if (((plStack_a0 != (longlong *)0x0) && (-1 < (int)*plStack_a0)) &&
                                   (*plStack_a0 = *plStack_a0 + -1, *plStack_a0 == 0)) {
                                  (**(code **)(plStack_a0[1] + 0x30))();
                                }
                                if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
                                   (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
                                  (**(code **)(plStack_98[1] + 0x30))();
                                }
                                if ((-1 < (int)*plVar11) &&
                                   (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                                  (**(code **)(plVar11[1] + 0x30))(plVar11);
                                }
                                if ((-1 < (int)*plStack_90) &&
                                   (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
                                  (**(code **)(plStack_90[1] + 0x30))();
                                }
                                if ((-1 < (int)*plStack_88) &&
                                   (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
                                  (**(code **)(plStack_88[1] + 0x30))(plStack_88);
                                }
                                goto LAB_1408db53f;
                              }
                              lVar10 = *(longlong *)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                              plVar11 = plStack_118;
                              plVar9 = plStack_100;
                              plVar18 = plStack_110;
                            }
                            goto LAB_1408dafeb;
                          }
                          lVar10 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                        }
                      }
                      else {
                        plVar7 = (longlong *)plVar11[1];
                        if ((*(uint *)((longlong *)plVar11[1] + 0x15) & 0x40000000) == 0) {
                          plVar7 = plVar11;
                        }
                        if ((plVar7 == *(longlong **)PyExc_StopIteration_exref) ||
                           (((*(int *)(plVar7[1] + 0xa8) < 0 &&
                             ((*(uint *)(plVar7 + 0x15) & 0x40000000) != 0)) &&
                            (cVar3 = Nuitka_helper_142cdd950(), cVar3 == '\x01')))) {
                          *(undefined8 *)(tstate + 0x70) = 0;
                          plVar7 = plStack_118;
                          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                            plVar7 = plStack_118;
                          }
                          goto LAB_1408dacf9;
                        }
LAB_1408dac77:
                        iVar5 = 0x2498;
LAB_1408dac7d:
                        lVar10 = *(longlong *)(tstate + 0x70);
                        *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408dac89:
                        alStack_138[0] = 0;
                        if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
                           (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
                          (**(code **)(plStack_e8[1] + 0x30))();
                        }
                        if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                          (**(code **)(plVar18[1] + 0x30))(plVar18);
                        }
                      }
                      plVar11 = plStack_118;
                      piVar19 = *(int **)(tstate + 0xf8);
                      alStack_138[0] = 0;
                      if ((piVar19 != (int *)0x0) && (*piVar19 + 1 != 0)) {
                        *piVar19 = *piVar19 + 1;
                      }
                      piVar1 = *(int **)(lVar10 + 0x28);
                      if (piVar1 == (int *)0x0) {
                        pcVar14 = (code *)FUN_142cd9160(plStack_118,iVar5);
                        bVar20 = pcVar14 == _Py_NoneStruct_exref;
LAB_1408dadf7:
                        plVar7 = *(longlong **)(lVar10 + 0x28);
                        if (bVar20) {
                          pcVar13 = (code *)0x0;
                        }
                        else {
                          pcVar13 = pcVar14;
                          if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
                            *(int *)pcVar14 = *(int *)pcVar14 + 1;
                          }
                        }
                        *(code **)(lVar10 + 0x28) = pcVar13;
                        if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))();
                        }
                        if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                           (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                           *(longlong *)pcVar14 == 0)) {
                          (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
                        }
                      }
                      else if (iVar5 != 0) {
                        pcVar14 = (code *)FUN_142cd9160(plStack_118,iVar5);
                        *(int **)(pcVar14 + 0x10) = piVar1;
                        if (*piVar1 + 1 != 0) {
                          *piVar1 = *piVar1 + 1;
                        }
                        bVar20 = pcVar14 == _Py_NoneStruct_exref;
                        goto LAB_1408dadf7;
                      }
                      plVar7 = *(longlong **)(tstate + 0xf8);
                      *(longlong *)(tstate + 0xf8) = lVar10;
                      if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                        (**(code **)(plVar7[1] + 0x30))();
                      }
                      if (plStack_f8 == (longlong *)0x0) {
                        FUN_142cd4900(tstate,alStack_138,classes_const_403_self);
                        FUN_1400048d0(tstate,alStack_138[0]);
                        uVar16 = 0x24c1;
                        lVar10 = alStack_138[0];
                      }
                      else {
                        uVar16 = 0x24c1;
                        *(undefined4 *)(plVar11 + 5) = 0x24c1;
                        plVar7 = (longlong *)
                                 FUN_142cd12f0(tstate,plStack_f8,classes_const_2008__toque_cru,
                                               *(undefined8 *)
                                                (
                                                classes_const_2023___type____T____items_____touchEnd___
                                                + 0x18));
                        if (plVar7 == (longlong *)0x0) {
                          lVar10 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                        }
                        else {
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
                          cVar3 = FUN_142cded30(tstate,alStack_138);
                          uVar16 = 0x2497;
                          if (cVar3 != '\0') {
                            uVar16 = 0;
                          }
                          lVar2 = *(longlong *)(alStack_138[0] + 0x28);
                          lVar10 = alStack_138[0];
                          if ((lVar2 != 0) && (*(longlong **)(lVar2 + 0x18) == plVar11)) {
                            *(undefined4 *)(plVar11 + 5) = *(undefined4 *)(lVar2 + 0x24);
                          }
                        }
                      }
                      plVar7 = *(longlong **)(tstate + 0xf8);
                      alStack_138[0] = 0;
                      *(int **)(tstate + 0xf8) = piVar19;
                      plVar9 = plStack_100;
                      plVar18 = plStack_110;
                      if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                        (**(code **)(plVar7[1] + 0x30))();
                        plVar9 = plStack_100;
                        plVar18 = plStack_110;
                      }
                    }
                  }
                }
              }
              goto LAB_1408dafeb;
            }
          }
          alStack_138[0] = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
            (**(code **)(plVar7[1] + 0x30))(plVar7);
          }
          uVar16 = 0x2492;
          plVar9 = plVar17;
          lVar10 = alStack_138[0];
        }
      }
    }
  }
LAB_1408dafeb:
  alStack_138[0] = lVar10;
  piVar19 = *(int **)(alStack_138[0] + 0x28);
  if (piVar19 == (int *)0x0) {
    pcVar14 = (code *)FUN_142cd9160(plVar11,uVar16);
    bVar20 = pcVar14 == _Py_NoneStruct_exref;
LAB_1408db035:
    plVar7 = *(longlong **)(alStack_138[0] + 0x28);
    if (bVar20) {
      pcVar13 = (code *)0x0;
    }
    else {
      pcVar13 = pcVar14;
      if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
        *(int *)pcVar14 = *(int *)pcVar14 + 1;
      }
    }
    *(code **)(alStack_138[0] + 0x28) = pcVar13;
    if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))();
    }
    if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
       (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
      (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
    }
  }
  else if (*(longlong **)(piVar19 + 6) != plVar11) {
    pcVar14 = (code *)FUN_142cd9160(plVar11,uVar16);
    *(int **)(pcVar14 + 0x10) = piVar19;
    if (*piVar19 + 1 != 0) {
      *piVar19 = *piVar19 + 1;
    }
    bVar20 = pcVar14 == _Py_NoneStruct_exref;
    goto LAB_1408db035;
  }
  plVar6 = plStack_e8;
  plVar17 = plStack_f8;
  plStack_148 = plStack_98;
  plStack_150 = plStack_a0;
  plStack_158 = plStack_a8;
  plStack_160 = plStack_b0;
  plStack_168 = plStack_d8;
  plStack_170 = plStack_b8;
  plStack_180 = plStack_c0;
  plStack_188 = plStack_c8;
  plStack_190 = plStack_e8;
  plStack_198 = plStack_f0;
  plStack_1a8 = plStack_d0;
  plStack_1b0 = plStack_e0;
  plStack_1b8 = plStack_88;
  plStack_1a0 = plVar18;
  plStack_178 = plVar9;
  FUN_142cdb370(plVar11,&UNK_142d0b9b8,plStack_f8,plStack_90);
  plVar7 = _DAT_142dea7e8;
  if (plVar11 == _DAT_142dea7e8) {
    if ((-1 < (int)*_DAT_142dea7e8) && (*_DAT_142dea7e8 = *_DAT_142dea7e8 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))();
    }
    _DAT_142dea7e8 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar10 = alStack_138[0];
  alStack_138[0] = 0;
  if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
     (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
    (**(code **)(plStack_e0[1] + 0x30))();
  }
  if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
     (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
    (**(code **)(plStack_d0[1] + 0x30))();
  }
  if (((plVar18 != (longlong *)0x0) && (-1 < (int)*plVar18)) &&
     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
    (**(code **)(plVar18[1] + 0x30))(plVar18);
  }
  if (((plStack_f0 != (longlong *)0x0) && (-1 < (int)*plStack_f0)) &&
     (*plStack_f0 = *plStack_f0 + -1, *plStack_f0 == 0)) {
    (**(code **)(plStack_f0[1] + 0x30))();
  }
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
     (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
    (**(code **)(plStack_c8[1] + 0x30))();
  }
  if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
     (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
    (**(code **)(plStack_c0[1] + 0x30))();
  }
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
     (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
    (**(code **)(plStack_b8[1] + 0x30))();
  }
  if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8)) &&
     (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
    (**(code **)(plStack_d8[1] + 0x30))();
  }
  if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
     (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
    (**(code **)(plStack_b0[1] + 0x30))();
  }
  if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
     (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
    (**(code **)(plStack_a8[1] + 0x30))();
  }
  if (((plStack_a0 != (longlong *)0x0) && (-1 < (int)*plStack_a0)) &&
     (*plStack_a0 = *plStack_a0 + -1, *plStack_a0 == 0)) {
    (**(code **)(plStack_a0[1] + 0x30))();
  }
  if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
     (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
    (**(code **)(plStack_98[1] + 0x30))();
  }
  alStack_138[0] = lVar10;
  if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
    (**(code **)(plVar17[1] + 0x30))(plVar17);
  }
  if ((-1 < (int)*plStack_90) && (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
    (**(code **)(plStack_90[1] + 0x30))();
  }
  if ((-1 < (int)*plStack_88) && (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
    (**(code **)(plStack_88[1] + 0x30))();
  }
  plVar7 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = alStack_138[0];
  if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)
     ) {
    (**(code **)(plVar7[1] + 0x30))();
  }
LAB_1408db53f:
  puVar15 = (undefined *)FUN_142cfc380(uStack_48 ^ (ulonglong)auStack_1d8);
  return puVar15;
}

