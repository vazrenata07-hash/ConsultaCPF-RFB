
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * resolver_geetest_se_aparecer(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong *plVar2;
  int *piVar3;
  int *piVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  code *pcVar8;
  longlong lVar9;
  code *pcVar10;
  code *pcVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  undefined8 uVar15;
  bool bVar16;
  code *pcStackX_18;
  longlong *plStackX_20;
  
  plVar5 = _DAT_142dea7a8;
  plVar1 = (longlong *)python_pars[1];
  plVar13 = (longlong *)0x0;
  plVar2 = (longlong *)*python_pars;
  iVar7 = 0;
  pcStackX_18 = (code *)0x0;
  plStackX_20 = (longlong *)0x0;
  if (_DAT_142dea7a8 == (longlong *)0x0) {
LAB_1408d0228:
    _DAT_142dea7a8 = (longlong *)FUN_142cd81e0(tstate,_DAT_142dea118,_DAT_142f2aaf0,0x18);
  }
  else if ((1 < *_DAT_142dea7a8) || (_DAT_142dea7a8[2] != 0)) {
    if ((_DAT_142dea7a8 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7a8 && (*_DAT_142dea7a8 = *_DAT_142dea7a8 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408d0228;
  }
  plVar5 = _DAT_142dea7a8;
  Nuitka_helper_140008a00(tstate,_DAT_142dea7a8);
  pcVar8 = (code *)FUN_142cd7b20(tstate,plVar2,classes_const_170_driver);
  if (pcVar8 == (code *)0x0) {
    pcVar8 = *(code **)(tstate + 0x70);
    uVar15 = 0x2377;
    *(undefined8 *)(tstate + 0x70) = 0;
  }
  else {
    if (pcVar8 == _Py_TrueStruct_exref) {
LAB_1408d0296:
      iVar7 = 1;
    }
    else if ((pcVar8 != _Py_FalseStruct_exref) && (pcVar8 != _Py_NoneStruct_exref)) {
      lVar9 = *(longlong *)(pcVar8 + 8);
      if ((*(longlong *)(lVar9 + 0x60) == 0) ||
         (pcVar10 = *(code **)(*(longlong *)(lVar9 + 0x60) + 0x48), pcVar10 == (code *)0x0)) {
        if ((*(undefined8 **)(lVar9 + 0x70) == (undefined8 *)0x0) ||
           (pcVar10 = (code *)**(undefined8 **)(lVar9 + 0x70), pcVar10 == (code *)0x0)) {
          if ((*(undefined8 **)(lVar9 + 0x68) == (undefined8 *)0x0) ||
             (pcVar10 = (code *)**(undefined8 **)(lVar9 + 0x68), pcVar10 == (code *)0x0))
          goto LAB_1408d0296;
          lVar9 = (*pcVar10)(pcVar8);
        }
        else {
          lVar9 = (*pcVar10)(pcVar8);
        }
      }
      else {
        iVar7 = (*pcVar10)(pcVar8);
        lVar9 = (longlong)iVar7;
      }
      if (lVar9 < 1) {
        iVar7 = -(uint)(lVar9 != 0);
      }
      else {
        iVar7 = 1;
      }
    }
    if ((-1 < *(int *)pcVar8) &&
       (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
      (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
    }
    if (iVar7 == -1) {
      pcVar8 = *(code **)(tstate + 0x70);
      uVar15 = 0x2377;
      *(undefined8 *)(tstate + 0x70) = 0;
      plVar13 = (longlong *)0x0;
    }
    else {
      if (iVar7 == 0) {
LAB_1408d0342:
        pcVar8 = _Py_FalseStruct_exref;
        if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
          *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
        }
LAB_1408d0987:
        plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
        *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
        *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
        plVar14 = (longlong *)plVar5[2];
        if (((plVar14 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar14)) &&
           (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
          (**(code **)(plVar14[1] + 0x30))();
        }
        if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))(plVar5);
        }
        plVar5[0xc] = 0;
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
          (**(code **)(plVar2[1] + 0x30))(plVar2);
        }
        if ((int)*plVar1 < 0) {
          return pcVar8;
        }
        *plVar1 = *plVar1 + -1;
        if (*plVar1 != 0) {
          return pcVar8;
        }
        (**(code **)(plVar1[1] + 0x30))();
        return pcVar8;
      }
      lVar9 = FUN_140a38520(tstate);
      if (lVar9 == 0) {
        FUN_142cde870(tstate,&pcStackX_18,classes_const_205_Navegacao);
        pcVar8 = pcStackX_18;
LAB_1408d03ca:
        piVar4 = *(int **)(tstate + 0xf8);
        pcStackX_18 = (code *)0x0;
        if ((piVar4 != (int *)0x0) && (*piVar4 + 1 != 0)) {
          *piVar4 = *piVar4 + 1;
        }
        piVar3 = *(int **)(pcVar8 + 0x28);
        pcVar10 = (code *)FUN_142cd9160(plVar5,0x237a);
        if (piVar3 != (int *)0x0) {
          *(int **)(pcVar10 + 0x10) = piVar3;
          if (*piVar3 + 1 != 0) {
            *piVar3 = *piVar3 + 1;
          }
        }
        plVar13 = *(longlong **)(pcVar8 + 0x28);
        if (pcVar10 == _Py_NoneStruct_exref) {
          pcVar11 = (code *)0x0;
        }
        else {
          pcVar11 = pcVar10;
          if ((pcVar10 != (code *)0x0) && (*(int *)pcVar10 + 1 != 0)) {
            *(int *)pcVar10 = *(int *)pcVar10 + 1;
          }
        }
        *(code **)(pcVar8 + 0x28) = pcVar11;
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))();
        }
        if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
           (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
          (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
        }
        plVar13 = *(longlong **)(tstate + 0xf8);
        *(code **)(tstate + 0xf8) = pcVar8;
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))();
        }
        iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                              *(undefined8 *)PyExc_Exception_exref);
        if (iVar7 == 0) {
          cVar6 = FUN_142cded30(tstate,&pcStackX_18);
          pcVar8 = pcStackX_18;
          uVar15 = 0x2379;
          if (cVar6 != '\0') {
            uVar15 = 0;
          }
          lVar9 = *(longlong *)(pcStackX_18 + 0x28);
          if ((lVar9 != 0) && (*(longlong **)(lVar9 + 0x18) == plVar5)) {
            *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar9 + 0x24);
          }
          pcStackX_18 = (code *)0x0;
          plVar14 = *(longlong **)(tstate + 0xf8);
          *(int **)(tstate + 0xf8) = piVar4;
          plVar13 = plStackX_20;
          if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
             (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))();
            plVar13 = plStackX_20;
          }
          goto LAB_1408d07ba;
        }
        plVar13 = *(longlong **)(tstate + 0xf8);
        *(int **)(tstate + 0xf8) = piVar4;
        plVar14 = plStackX_20;
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))();
          plVar14 = plStackX_20;
        }
      }
      else {
        plVar14 = (longlong *)FUN_142cd7b20(tstate,lVar9,classes_const_1838_CAPTCHA_SOLVER);
        if (plVar14 == (longlong *)0x0) {
LAB_1408d03c2:
          pcVar8 = *(code **)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408d03ca;
        }
        iVar7 = FUN_140004970(plVar14);
        if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
          (**(code **)(plVar14[1] + 0x30))(plVar14);
        }
        if (iVar7 == -1) goto LAB_1408d03c2;
        plVar14 = plVar13;
        plVar13 = (longlong *)0x0;
        if (iVar7 == 0) goto LAB_1408d0342;
      }
      uVar15 = 0x237e;
      *(undefined4 *)(plVar5 + 5) = 0x237e;
      plVar12 = (longlong *)FUN_142cd06a0(tstate,plVar2,classes_const_1948__geetest_na_tela);
      plVar13 = plVar14;
      if (plVar12 == (longlong *)0x0) {
        pcVar8 = *(code **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
      }
      else {
        iVar7 = FUN_140004970(plVar12);
        if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
          (**(code **)(plVar12[1] + 0x30))(plVar12);
        }
        if (iVar7 != -1) {
          if (iVar7 == 0) goto LAB_1408d0342;
          uVar15 = 0x2380;
          *(undefined4 *)(plVar5 + 5) = 0x2380;
          plVar13 = (longlong *)
                    FUN_142cd06a0(tstate,plVar2,classes_const_1840__pausar_clique_centro);
          if (plVar13 != (longlong *)0x0) {
            *(undefined4 *)(plVar5 + 5) = 0x2382;
            pcVar8 = (code *)FUN_142cd12f0(tstate,plVar2,classes_const_1949__resolver_geetest_slider
                                           ,plVar1);
            if (pcVar8 == (code *)0x0) {
              lVar9 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              piVar4 = *(int **)(tstate + 0xf8);
              if ((piVar4 != (int *)0x0) && (*piVar4 + 1 != 0)) {
                *piVar4 = *piVar4 + 1;
              }
              piVar3 = *(int **)(lVar9 + 0x28);
              pcStackX_18 = pcVar8;
              pcVar8 = (code *)FUN_142cd9160(plVar5,0x2382);
              if (piVar3 != (int *)0x0) {
                *(int **)(pcVar8 + 0x10) = piVar3;
                if (*piVar3 + 1 != 0) {
                  *piVar3 = *piVar3 + 1;
                }
              }
              plVar14 = *(longlong **)(lVar9 + 0x28);
              if (pcVar8 == _Py_NoneStruct_exref) {
                pcVar10 = (code *)0x0;
              }
              else {
                pcVar10 = pcVar8;
                if ((pcVar8 != (code *)0x0) && (*(int *)pcVar8 + 1 != 0)) {
                  *(int *)pcVar8 = *(int *)pcVar8 + 1;
                }
              }
              *(code **)(lVar9 + 0x28) = pcVar10;
              if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
                 (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                (**(code **)(plVar14[1] + 0x30))();
              }
              if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
                 (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
              }
              plVar14 = *(longlong **)(tstate + 0xf8);
              *(longlong *)(tstate + 0xf8) = lVar9;
              if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
                 (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                (**(code **)(plVar14[1] + 0x30))();
              }
              uVar15 = 0x2384;
              *(undefined4 *)(plVar5 + 5) = 0x2384;
              plVar14 = (longlong *)
                        FUN_142cd12f0(tstate,plVar2,classes_const_1842__voltar_clique_centro,plVar13
                                     );
              if (plVar14 == (longlong *)0x0) {
                pcVar8 = *(code **)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
              }
              else {
                if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                  (**(code **)(plVar14[1] + 0x30))(plVar14);
                }
                cVar6 = FUN_142cded30(tstate,&pcStackX_18);
                uVar15 = 0x2381;
                if (cVar6 != '\0') {
                  uVar15 = 0;
                }
                lVar9 = *(longlong *)(pcStackX_18 + 0x28);
                pcVar8 = pcStackX_18;
                if ((lVar9 != 0) && (*(longlong **)(lVar9 + 0x18) == plVar5)) {
                  *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar9 + 0x24);
                }
              }
              plVar14 = *(longlong **)(tstate + 0xf8);
              pcStackX_18 = (code *)0x0;
              *(int **)(tstate + 0xf8) = piVar4;
              if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
                 (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                (**(code **)(plVar14[1] + 0x30))();
              }
              goto LAB_1408d07ba;
            }
            uVar15 = 0x2384;
            *(undefined4 *)(plVar5 + 5) = 0x2384;
            plVar12 = (longlong *)
                      FUN_142cd12f0(tstate,plVar2,classes_const_1842__voltar_clique_centro,plVar13);
            plVar14 = plVar13;
            if (plVar12 != (longlong *)0x0) {
              if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                (**(code **)(plVar12[1] + 0x30))(plVar12);
              }
              goto LAB_1408d0987;
            }
          }
        }
        pcVar8 = *(code **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        plVar13 = plVar14;
      }
    }
  }
LAB_1408d07ba:
  piVar4 = *(int **)(pcVar8 + 0x28);
  pcStackX_18 = pcVar8;
  if (piVar4 == (int *)0x0) {
    pcVar8 = (code *)FUN_142cd9160(plVar5,uVar15);
    bVar16 = pcVar8 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar4 + 6) == plVar5) goto LAB_1408d085a;
    pcVar8 = (code *)FUN_142cd9160(plVar5,uVar15);
    *(int **)(pcVar8 + 0x10) = piVar4;
    if (*piVar4 + 1 != 0) {
      *piVar4 = *piVar4 + 1;
    }
    bVar16 = pcVar8 == _Py_NoneStruct_exref;
  }
  plVar14 = *(longlong **)(pcStackX_18 + 0x28);
  if (bVar16) {
    pcVar10 = (code *)0x0;
  }
  else {
    pcVar10 = pcVar8;
    if ((pcVar8 != (code *)0x0) && (*(int *)pcVar8 + 1 != 0)) {
      *(int *)pcVar8 = *(int *)pcVar8 + 1;
    }
  }
  *(code **)(pcStackX_18 + 0x28) = pcVar10;
  if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
     (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
    (**(code **)(plVar14[1] + 0x30))();
  }
  if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
     (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
    (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
  }
LAB_1408d085a:
  FUN_142cdb370(plVar5,&UNK_142d0b25c,plVar2,plVar1,plVar13);
  plVar14 = _DAT_142dea7a8;
  if (plVar5 == _DAT_142dea7a8) {
    if ((-1 < (int)*_DAT_142dea7a8) && (*_DAT_142dea7a8 = *_DAT_142dea7a8 + -1, *plVar14 == 0)) {
      (**(code **)(plVar14[1] + 0x30))();
    }
    _DAT_142dea7a8 = (longlong *)0x0;
  }
  plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
  plVar14 = (longlong *)plVar5[2];
  if (((plVar14 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar14)) &&
     (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
    (**(code **)(plVar14[1] + 0x30))();
  }
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  pcVar8 = pcStackX_18;
  plVar5[0xc] = 0;
  pcStackX_18 = (code *)0x0;
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  pcStackX_18 = pcVar8;
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))(plVar2);
  }
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(code **)(tstate + 0x70) = pcStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

