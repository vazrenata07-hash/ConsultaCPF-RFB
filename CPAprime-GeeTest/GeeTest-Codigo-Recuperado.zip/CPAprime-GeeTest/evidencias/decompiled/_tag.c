
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _tag(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong lVar2;
  int *piVar3;
  int *piVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  int iVar8;
  longlong *plVar9;
  undefined *puVar10;
  code *pcVar11;
  code *pcVar12;
  code *pcVar13;
  bool bVar14;
  longlong alStackX_18 [2];
  
  plVar5 = _DAT_142dea718;
  plVar1 = (longlong *)*python_pars;
  if (_DAT_142dea718 == (longlong *)0x0) {
LAB_1408b5f96:
    _DAT_142dea718 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9da0,_DAT_142f2aaf0,8);
  }
  else if ((1 < *_DAT_142dea718) || (_DAT_142dea718[2] != 0)) {
    if ((_DAT_142dea718 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea718 && (*_DAT_142dea718 = *_DAT_142dea718 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408b5f96;
  }
  plVar5 = _DAT_142dea718;
  Nuitka_helper_140008a00(tstate,_DAT_142dea718);
  puVar10 = classes_const_1749__b_s_;
  plVar9 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_145_id_browser);
  pcVar13 = (code *)0x0;
  if (plVar9 != (longlong *)0x0) {
    puVar10 = (undefined *)FUN_142cbff90(puVar10,plVar9);
    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    if (puVar10 != (undefined *)0x0) goto LAB_1408b6151;
  }
  lVar2 = *(longlong *)(tstate + 0x70);
  *(undefined8 *)(tstate + 0x70) = 0;
  piVar3 = *(int **)(tstate + 0xf8);
  alStackX_18[0] = 0;
  if ((piVar3 != (int *)0x0) && (*piVar3 + 1 != 0)) {
    *piVar3 = *piVar3 + 1;
  }
  piVar4 = *(int **)(lVar2 + 0x28);
  pcVar11 = (code *)FUN_142cd9160(plVar5,0x2054);
  if (piVar4 != (int *)0x0) {
    *(int **)(pcVar11 + 0x10) = piVar4;
    if (*piVar4 + 1 != 0) {
      *piVar4 = *piVar4 + 1;
    }
  }
  plVar9 = *(longlong **)(lVar2 + 0x28);
  pcVar12 = pcVar13;
  if (((pcVar11 != _Py_NoneStruct_exref) && (pcVar12 = pcVar11, pcVar11 != (code *)0x0)) &&
     (*(int *)pcVar11 + 1 != 0)) {
    *(int *)pcVar11 = *(int *)pcVar11 + 1;
  }
  *(code **)(lVar2 + 0x28) = pcVar12;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
     (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
    (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
  }
  plVar9 = *(longlong **)(tstate + 0xf8);
  *(longlong *)(tstate + 0xf8) = lVar2;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  iVar8 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                        *(undefined8 *)PyExc_Exception_exref);
  puVar10 = classes_const_1750__b__;
  if (iVar8 != 0) {
    if (*(int *)classes_const_1750__b__ + 1 != 0) {
      *(int *)classes_const_1750__b__ = *(int *)classes_const_1750__b__ + 1;
    }
    plVar5 = *(longlong **)(tstate + 0xf8);
    *(int **)(tstate + 0xf8) = piVar3;
    if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
       (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))();
    }
LAB_1408b6151:
    plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
    *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
    *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
    plVar9 = (longlong *)plVar5[2];
    if (((plVar9 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar9)) &&
       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))();
    }
    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    plVar5[0xc] = 0;
    if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
      (**(code **)(plVar1[1] + 0x30))(plVar1);
    }
    return puVar10;
  }
  cVar7 = FUN_142cded30(tstate,alStackX_18);
  lVar2 = alStackX_18[0];
  pcVar11 = (code *)0x2053;
  if (cVar7 != '\0') {
    pcVar11 = pcVar13;
  }
  lVar6 = *(longlong *)(alStackX_18[0] + 0x28);
  if ((lVar6 != 0) && (*(longlong **)(lVar6 + 0x18) == plVar5)) {
    *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar6 + 0x24);
  }
  plVar9 = *(longlong **)(tstate + 0xf8);
  alStackX_18[0] = 0;
  *(int **)(tstate + 0xf8) = piVar3;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  piVar3 = *(int **)(lVar2 + 0x28);
  alStackX_18[0] = lVar2;
  if (piVar3 == (int *)0x0) {
    pcVar11 = (code *)FUN_142cd9160(plVar5,pcVar11);
    bVar14 = pcVar11 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar3 + 6) == plVar5) goto LAB_1408b62c1;
    pcVar11 = (code *)FUN_142cd9160(plVar5,pcVar11);
    *(int **)(pcVar11 + 0x10) = piVar3;
    if (*piVar3 + 1 != 0) {
      *piVar3 = *piVar3 + 1;
    }
    bVar14 = pcVar11 == _Py_NoneStruct_exref;
  }
  plVar9 = *(longlong **)(alStackX_18[0] + 0x28);
  if (((!bVar14) && (pcVar13 = pcVar11, pcVar11 != (code *)0x0)) && (*(int *)pcVar11 + 1 != 0)) {
    *(int *)pcVar11 = *(int *)pcVar11 + 1;
  }
  *(code **)(alStackX_18[0] + 0x28) = pcVar13;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
     (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
    (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
  }
LAB_1408b62c1:
  FUN_142cdb370(plVar5,&UNK_142d0ae4c,plVar1);
  plVar9 = _DAT_142dea718;
  if (plVar5 == _DAT_142dea718) {
    if ((-1 < (int)*_DAT_142dea718) && (*_DAT_142dea718 = *_DAT_142dea718 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))();
    }
    _DAT_142dea718 = (longlong *)0x0;
  }
  plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
  plVar9 = (longlong *)plVar5[2];
  if (((plVar9 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar9)) &&
     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  plVar5[0xc] = 0;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = alStackX_18[0];
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

