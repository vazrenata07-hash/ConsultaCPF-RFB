
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _baixar_data_url(undefined *tstate,undefined *self,undefined **python_pars)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  code *pcVar7;
  code *pcVar8;
  longlong lVar9;
  code *pcVar10;
  longlong *plVar11;
  longlong *plVar12;
  code *pcVar13;
  undefined *puVar14;
  undefined8 uVar15;
  longlong *plVar16;
  code *pcVar17;
  bool bVar18;
  undefined1 auStack_128 [32];
  code *pcStack_108;
  code *pcStack_100;
  longlong *plStack_f8;
  code *pcStack_f0;
  code *pcStack_e8;
  longlong *plStack_e0;
  code *pcStack_d8;
  longlong *plStack_d0;
  code *pcStack_c0;
  code *pcStack_b8;
  code *pcStack_b0;
  longlong *plStack_a8;
  longlong *plStack_a0;
  code *pcStack_98;
  code *pcStack_90;
  code *pcStack_88;
  longlong *plStack_80;
  longlong *plStack_78;
  longlong *plStack_70;
  longlong *plStack_68;
  longlong *plStack_60;
  undefined *puStack_58;
  code *pcStack_50;
  longlong *plStack_48;
  ulonglong uStack_40;
  
  plVar16 = _DAT_142dea708;
  uStack_40 = _DAT_142d9a1c0 ^ (ulonglong)auStack_128;
  plStack_60 = (longlong *)*python_pars;
  pcVar10 = (code *)0x0;
  plVar5 = (longlong *)python_pars[1];
  pcVar17 = (code *)0x0;
  pcStack_c0 = (code *)0x0;
  pcStack_88 = (code *)0x0;
  plStack_80 = (longlong *)0x0;
  pcStack_90 = (code *)0x0;
  plStack_78 = (longlong *)0x0;
  pcStack_98 = (code *)0x0;
  plStack_70 = (longlong *)0x0;
  plStack_a0 = _DAT_142dea708;
  plStack_68 = plVar5;
  if (_DAT_142dea708 == (longlong *)0x0) {
LAB_1408b4196:
    plStack_a0 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9990,_DAT_142f2aaf0,0x50);
  }
  else if ((1 < *_DAT_142dea708) || (_DAT_142dea708[2] != 0)) {
    if ((_DAT_142dea708 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea708 && (*_DAT_142dea708 = *_DAT_142dea708 + -1, *plVar16 == 0)))) {
      (**(code **)(plVar16[1] + 0x30))(plVar16);
    }
    goto LAB_1408b4196;
  }
  plVar16 = plStack_a0;
  _DAT_142dea708 = plStack_a0;
  Nuitka_helper_140008a00(tstate,plStack_a0);
  iVar4 = FUN_140004970(plVar5);
  if (iVar4 == -1) {
    pcVar8 = *(code **)(tstate + 0x70);
    uVar15 = 0x2012;
    *(undefined8 *)(tstate + 0x70) = 0;
    pcVar13 = pcVar10;
  }
  else {
    pcVar8 = pcVar10;
    plVar6 = (longlong *)classes_const_102_;
    pcVar13 = pcVar10;
    if (iVar4 == 0) {
LAB_1408b51af:
      iVar4 = (int)*plVar6 + 1;
      pcVar7 = pcVar10;
      if (iVar4 != 0) {
        *(int *)plVar6 = iVar4;
      }
LAB_1408b51ba:
      pcVar10 = pcStack_90;
      plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
      *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
      *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
      plVar16 = (longlong *)plVar5[2];
      if (((plVar16 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar16)) &&
         (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
        (**(code **)(plVar16[1] + 0x30))();
      }
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
      plVar5[0xc] = 0;
      if (pcVar7 != (code *)0x0) {
LAB_1408b556a:
        if ((-1 < *(int *)pcVar7) &&
           (*(longlong *)pcVar7 = *(longlong *)pcVar7 + -1, *(longlong *)pcVar7 == 0)) {
          (**(code **)(*(longlong *)(pcVar7 + 8) + 0x30))(pcVar7);
        }
      }
      if (((pcStack_88 != (code *)0x0) && (-1 < *(int *)pcStack_88)) &&
         (*(longlong *)pcStack_88 = *(longlong *)pcStack_88 + -1, *(longlong *)pcStack_88 == 0)) {
        (**(code **)(*(longlong *)(pcStack_88 + 8) + 0x30))();
      }
      if (((plStack_80 != (longlong *)0x0) && (-1 < (int)*plStack_80)) &&
         (*plStack_80 = *plStack_80 + -1, *plStack_80 == 0)) {
        (**(code **)(plStack_80[1] + 0x30))();
      }
      if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
         (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
        (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
      }
      if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
         (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
        (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
      }
      if (((plStack_78 != (longlong *)0x0) && (-1 < (int)*plStack_78)) &&
         (*plStack_78 = *plStack_78 + -1, *plStack_78 == 0)) {
        (**(code **)(plStack_78[1] + 0x30))();
      }
      if (((pcVar13 != (code *)0x0) && (-1 < *(int *)pcVar13)) &&
         (*(longlong *)pcVar13 = *(longlong *)pcVar13 + -1, *(longlong *)pcVar13 == 0)) {
        (**(code **)(*(longlong *)(pcVar13 + 8) + 0x30))(pcVar13);
      }
      if (((plStack_70 != (longlong *)0x0) && (-1 < (int)*plStack_70)) &&
         (*plStack_70 = *plStack_70 + -1, *plStack_70 == 0)) {
        (**(code **)(plStack_70[1] + 0x30))();
      }
      if ((-1 < (int)*plStack_60) && (*plStack_60 = *plStack_60 + -1, *plStack_60 == 0)) {
        (**(code **)(plStack_60[1] + 0x30))();
      }
      if ((-1 < (int)*plStack_68) && (*plStack_68 = *plStack_68 + -1, *plStack_68 == 0)) {
        (**(code **)(plStack_68[1] + 0x30))(plStack_68);
      }
      goto LAB_1408b5673;
    }
    plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar5,classes_const_1434_startswith);
    if (plVar5 == (longlong *)0x0) {
      pcVar8 = *(code **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      uVar15 = 0x2014;
      pcVar10 = pcVar17;
      pcVar13 = (code *)0x0;
    }
    else {
      uVar15 = 0x2014;
      *(undefined4 *)(plVar16 + 5) = 0x2014;
      plVar6 = (longlong *)
               FUN_142cccf70(tstate,plVar5,classes_const_1724___type____T____items_____data____);
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
      if (plVar6 == (longlong *)0x0) {
        pcVar8 = *(code **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        pcVar10 = pcVar17;
        pcVar13 = (code *)0x0;
      }
      else {
        iVar4 = FUN_140004970(plVar6);
        if (iVar4 == -1) {
          pcStack_c0 = *(code **)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
            (**(code **)(plVar6[1] + 0x30))(plVar6);
          }
          pcVar10 = pcVar17;
          pcVar13 = (code *)0x0;
          pcVar8 = pcStack_c0;
        }
        else {
          if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
            (**(code **)(plVar6[1] + 0x30))(plVar6);
          }
          plVar5 = plStack_60;
          if (iVar4 != 0) {
            iVar4 = (int)*plStack_68 + 1;
            pcVar7 = pcVar10;
            if (iVar4 != 0) {
              *(int *)plStack_68 = iVar4;
              pcVar7 = (code *)0x0;
              pcVar8 = pcVar17;
              pcVar13 = (code *)0x0;
            }
            goto LAB_1408b51ba;
          }
          pcVar7 = (code *)FUN_142cc1aa0(tstate,plStack_60,classes_const_1725__cache_img_captcha,
                                         _Py_NoneStruct_exref);
          if (pcVar7 == (code *)0x0) {
            pcVar8 = *(code **)(tstate + 0x70);
            uVar15 = 0x2016;
            *(undefined8 *)(tstate + 0x70) = 0;
            pcVar10 = pcVar17;
            pcVar13 = (code *)0x0;
          }
          else if (pcVar7 == _Py_NoneStruct_exref) {
            pcVar8 = (code *)FUN_142cd8040(tstate);
            pcStack_b0 = pcVar8;
            if ((-1 < *(int *)pcVar7) &&
               (*(longlong *)pcVar7 = *(longlong *)pcVar7 + -1, *(longlong *)pcVar7 == 0)) {
              (**(code **)(*(longlong *)(pcVar7 + 8) + 0x30))(pcVar7);
            }
            cVar3 = FUN_142ce4bf0(tstate,plVar5,classes_const_1725__cache_img_captcha,pcVar8);
            if (cVar3 == '\0') {
              pcVar8 = *(code **)(tstate + 0x70);
              uVar15 = 0x2019;
              *(undefined8 *)(tstate + 0x70) = 0;
              pcVar13 = pcStack_b0;
            }
            else {
              pcVar7 = pcVar8;
              if (pcVar8 != (code *)0x0) goto LAB_1408b43bf;
              FUN_142cd4900(tstate,&pcStack_c0,classes_const_1726_cache);
              FUN_1400048d0(tstate,pcStack_c0);
              uVar15 = 0x201a;
              pcVar10 = pcVar17;
              pcVar13 = pcStack_b0;
              pcVar8 = pcStack_c0;
            }
          }
          else {
LAB_1408b43bf:
            plVar6 = plStack_68;
            pcStack_b0 = pcVar7;
            iVar4 = PySequence_Contains(pcVar7,plStack_68);
            if (iVar4 == -1) {
              pcVar8 = *(code **)(tstate + 0x70);
              uVar15 = 0x201a;
              *(undefined8 *)(tstate + 0x70) = 0;
              pcVar10 = pcVar17;
              pcVar13 = pcStack_b0;
            }
            else if (iVar4 == 1) {
              lVar9 = FUN_140008da0(tstate,pcVar7,plVar6);
              pcVar8 = pcVar17;
              pcVar13 = (code *)0x0;
              if (lVar9 != 0) goto LAB_1408b51ba;
              pcVar8 = *(code **)(tstate + 0x70);
              uVar15 = 0x201b;
              *(undefined8 *)(tstate + 0x70) = 0;
              pcVar10 = pcVar17;
              pcVar13 = pcStack_b0;
            }
            else {
              *(undefined4 *)(plVar16 + 5) = 0x201d;
              pcVar8 = (code *)FUN_142cd06a0(tstate,plVar5,classes_const_630__proxies_api);
              if (pcVar8 == (code *)0x0) {
                lVar9 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                piVar2 = *(int **)(tstate + 0xf8);
                if ((piVar2 != (int *)0x0) && (*piVar2 + 1 != 0)) {
                  *piVar2 = *piVar2 + 1;
                }
                piVar1 = *(int **)(lVar9 + 0x28);
                pcStack_c0 = pcVar8;
                pcVar8 = (code *)FUN_142cd9160(plVar16,0x201d);
                if (piVar1 != (int *)0x0) {
                  *(int **)(pcVar8 + 0x10) = piVar1;
                  if (*piVar1 + 1 != 0) {
                    *piVar1 = *piVar1 + 1;
                  }
                }
                plVar5 = *(longlong **)(lVar9 + 0x28);
                if (pcVar8 == _Py_NoneStruct_exref) {
                  pcVar7 = (code *)0x0;
                }
                else {
                  pcVar7 = pcVar8;
                  if ((pcVar8 != (code *)0x0) && (*(int *)pcVar8 + 1 != 0)) {
                    *(int *)pcVar8 = *(int *)pcVar8 + 1;
                  }
                }
                *(code **)(lVar9 + 0x28) = pcVar7;
                if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
                   (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                  (**(code **)(plVar5[1] + 0x30))();
                }
                if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
                   (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                  (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
                }
                plVar5 = *(longlong **)(tstate + 0xf8);
                *(longlong *)(tstate + 0xf8) = lVar9;
                if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
                   (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                  (**(code **)(plVar5[1] + 0x30))();
                }
                iVar4 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                                      *(undefined8 *)PyExc_Exception_exref);
                if (iVar4 == 0) {
                  cVar3 = FUN_142cded30(tstate,&pcStack_c0);
                  pcVar8 = pcStack_c0;
                  uVar15 = 0x201c;
                  if (cVar3 != '\0') {
                    uVar15 = 0;
                  }
                  lVar9 = *(longlong *)(pcStack_c0 + 0x28);
                  if ((lVar9 != 0) && (*(longlong **)(lVar9 + 0x18) == plVar16)) {
                    *(undefined4 *)(plVar16 + 5) = *(undefined4 *)(lVar9 + 0x24);
                  }
                  pcStack_c0 = (code *)0x0;
                  plVar5 = *(longlong **)(tstate + 0xf8);
                  *(int **)(tstate + 0xf8) = piVar2;
                  pcVar13 = pcStack_b0;
                  if (((plVar5 != (longlong *)0x0) && (pcVar10 = pcVar17, -1 < (int)*plVar5)) &&
                     (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                    (**(code **)(plVar5[1] + 0x30))();
                    pcVar13 = pcStack_b0;
                  }
                  goto LAB_1408b52e1;
                }
                pcStack_88 = _Py_NoneStruct_exref;
                if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                  *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                }
                plVar6 = *(longlong **)(tstate + 0xf8);
                *(int **)(tstate + 0xf8) = piVar2;
                plVar5 = plStack_60;
                pcVar8 = pcStack_88;
                if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) &&
                   (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))();
                  plVar5 = plStack_60;
                  pcVar8 = pcStack_88;
                }
              }
              pcStack_88 = pcVar8;
              puVar14 = classes_const_599_User_Agent;
              plVar5 = (longlong *)
                       FUN_142cc1aa0(tstate,plVar5,classes_const_165_MobileUA,classes_const_102_);
              if (plVar5 == (longlong *)0x0) {
                pcVar8 = *(code **)(tstate + 0x70);
                uVar15 = 0x2020;
                *(undefined8 *)(tstate + 0x70) = 0;
                pcVar10 = pcVar17;
                pcVar13 = pcStack_b0;
              }
              else {
                iVar4 = FUN_140004970(plVar5);
                if (iVar4 != -1) {
                  if (iVar4 != 1) {
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    plVar5 = (longlong *)classes_const_1727_Mozilla_5_0;
                    if (*(int *)classes_const_1727_Mozilla_5_0 + 1 != 0) {
                      *(int *)classes_const_1727_Mozilla_5_0 =
                           *(int *)classes_const_1727_Mozilla_5_0 + 1;
                    }
                  }
                  plStack_80 = (longlong *)_PyDict_NewPresized(1);
                  PyDict_SetItem(plStack_80,puVar14,plVar5);
                  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                    (**(code **)(plVar5[1] + 0x30))(plVar5);
                  }
                  pcVar8 = _DAT_142d9a260;
                  if (*(int *)_DAT_142d9a260 + 1 != 0) {
                    *(int *)_DAT_142d9a260 = *(int *)_DAT_142d9a260 + 1;
                    pcVar13 = (code *)0x0;
                  }
LAB_1408b46d0:
                  cVar3 = Nuitka_helper_142ce0450(pcVar8,3);
                  pcVar17 = pcStack_90;
                  if (cVar3 != '\0') {
                    FUN_140008990(tstate);
                    pcVar7 = pcStack_b0;
                    pcVar10 = pcStack_90;
                    if (*(int *)classes_const_102_ + 1 != 0) {
                      *(int *)classes_const_102_ = *(int *)classes_const_102_ + 1;
                    }
                    goto LAB_1408b556a;
                  }
                  if (pcVar8 == (code *)0x0) {
                    FUN_142cd4900(tstate,&pcStack_c0,classes_const_1483_tentativa);
                    FUN_1400048d0(tstate,pcStack_c0);
                    uVar15 = 0x2023;
                    pcVar10 = (code *)0x0;
                    pcVar13 = pcStack_b0;
                    pcVar8 = pcStack_c0;
                    goto LAB_1408b52e1;
                  }
                  pcVar10 = (code *)FUN_142cbe350(pcVar8,1);
                  pcStack_b8 = pcVar10;
                  if ((-1 < *(int *)pcVar8) &&
                     (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                    (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
                  }
                  pcVar8 = _Py_NoneStruct_exref;
                  pcStack_90 = _Py_NoneStruct_exref;
                  if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                    *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                  }
                  if (((pcVar17 != (code *)0x0) && (-1 < *(int *)pcVar17)) &&
                     (*(longlong *)pcVar17 = *(longlong *)pcVar17 + -1, *(longlong *)pcVar17 == 0))
                  {
                    (**(code **)(*(longlong *)(pcVar17 + 8) + 0x30))();
                  }
                  cVar3 = Nuitka_helper_142cdee20(pcVar10,3);
                  pcVar17 = pcVar8;
                  if (cVar3 != '\0') {
                    if (pcStack_88 == (code *)0x0) {
                      FUN_142cd4900(tstate,&pcStack_c0,classes_const_631_proxies);
                      FUN_1400048d0(tstate,pcStack_c0);
                      uVar15 = 0x2026;
                      pcVar13 = pcStack_b0;
                      pcVar8 = pcStack_c0;
                      goto LAB_1408b52e1;
                    }
                    pcStack_90 = pcStack_88;
                    if (*(int *)pcStack_88 + 1 != 0) {
                      *(int *)pcStack_88 = *(int *)pcStack_88 + 1;
                    }
                    pcVar17 = pcStack_88;
                    if ((-1 < *(int *)pcVar8) &&
                       (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                      (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))();
                    }
                  }
                  lVar9 = FUN_140a3a880(tstate);
                  if (lVar9 != 0) {
                    plVar5 = (longlong *)FUN_142cd7b20(tstate,lVar9,classes_const_211_get);
                    if (plVar5 == (longlong *)0x0) {
                      pcVar17 = *(code **)(tstate + 0x70);
                      iVar4 = 0x2028;
                      *(undefined8 *)(tstate + 0x70) = 0;
                      goto LAB_1408b4e1b;
                    }
                    if (plStack_68 == (longlong *)0x0) {
                      puVar14 = classes_const_691_url;
                      if ((-1 < (int)*plVar5) &&
                         (*plVar5 = *plVar5 + -1, puVar14 = classes_const_691_url, *plVar5 == 0)) {
                        (**(code **)(plVar5[1] + 0x30))(plVar5);
                        puVar14 = classes_const_691_url;
                      }
LAB_1408b4814:
                      FUN_142cd4900(tstate,&pcStack_c0,puVar14);
                      FUN_1400048d0(tstate,pcStack_c0);
                      iVar4 = 0x2028;
                      pcVar17 = pcStack_c0;
                      goto LAB_1408b4e1b;
                    }
                    if (plStack_80 == (longlong *)0x0) {
                      puVar14 = classes_const_1728_cabecalho;
                      if ((-1 < (int)*plVar5) &&
                         (*plVar5 = *plVar5 + -1, puVar14 = classes_const_1728_cabecalho,
                         *plVar5 == 0)) {
                        (**(code **)(plVar5[1] + 0x30))(plVar5);
                        puVar14 = classes_const_1728_cabecalho;
                      }
                      goto LAB_1408b4814;
                    }
                    puStack_58 = classes_const_116_8;
                    *(undefined4 *)(plVar16 + 5) = 0x2028;
                    plStack_a8 = plStack_68;
                    plStack_48 = plStack_80;
                    pcStack_108 = (code *)
                                  classes_const_1729___type____T____items_____timeout____proxies____headers___
                    ;
                    pcStack_50 = pcVar17;
                    plVar6 = (longlong *)FUN_142cc4990(tstate,plVar5,&plStack_a8,&puStack_58);
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (plVar6 == (longlong *)0x0) {
                      pcVar17 = *(code **)(tstate + 0x70);
                      iVar4 = 0x2028;
                      *(undefined8 *)(tstate + 0x70) = 0;
                      pcVar10 = pcStack_b8;
                      goto LAB_1408b4e1b;
                    }
                    plVar5 = plVar6;
                    if (((plStack_78 != (longlong *)0x0) && (-1 < (int)*plStack_78)) &&
                       (*plStack_78 = *plStack_78 + -1, *plStack_78 == 0)) {
                      plVar5 = plStack_78 + 1;
                      plStack_78 = plVar6;
                      (**(code **)(*plVar5 + 0x30))();
                      plVar5 = plStack_78;
                    }
                    plStack_78 = plVar5;
                    plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_688_status_code);
                    if (plVar5 == (longlong *)0x0) {
LAB_1408b4907:
                      pcStack_c0 = *(code **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408b4913:
                      iVar4 = 0x2029;
                      pcVar17 = pcStack_c0;
                      pcVar10 = pcStack_b8;
                      goto LAB_1408b4e1b;
                    }
                    iVar4 = FUN_142cdf450(plVar5,classes_const_1232_200);
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (iVar4 == -1) goto LAB_1408b4907;
                    if (iVar4 != 1) goto LAB_1408b50ad;
                    plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_1235_content);
                    if (plVar5 == (longlong *)0x0) goto LAB_1408b4907;
                    iVar4 = FUN_140004970(plVar5);
                    if (iVar4 == -1) {
                      pcStack_c0 = *(code **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if (-1 < (int)*plVar5) {
                        *plVar5 = *plVar5 + -1;
                        if (*plVar5 == 0) {
                          (**(code **)(plVar5[1] + 0x30))(plVar5);
                        }
                        iVar4 = 0x2029;
                        pcVar17 = pcStack_c0;
                        pcVar10 = pcStack_b8;
                        goto LAB_1408b4e1b;
                      }
                      goto LAB_1408b4913;
                    }
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (iVar4 == 0) goto LAB_1408b50ad;
                    plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_1730_headers);
                    if (plVar5 == (longlong *)0x0) {
LAB_1408b49e4:
                      pcVar17 = *(code **)(tstate + 0x70);
                      iVar4 = 0x202a;
                      *(undefined8 *)(tstate + 0x70) = 0;
                      pcVar10 = pcStack_b8;
                      goto LAB_1408b4e1b;
                    }
                    plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar5,classes_const_211_get);
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (plVar11 == (longlong *)0x0) goto LAB_1408b49e4;
                    *(undefined4 *)(plVar16 + 5) = 0x202a;
                    plVar5 = (longlong *)
                             FUN_142ccd7d0(tstate,plVar11,
                                           classes_const_1731___type____T____items_____Content_Type____image_png___
                                          );
                    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                      (**(code **)(plVar11[1] + 0x30))(plVar11);
                    }
                    if (plVar5 == (longlong *)0x0) goto LAB_1408b49e4;
                    plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar5,classes_const_529_split);
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (plVar11 == (longlong *)0x0) goto LAB_1408b49e4;
                    *(undefined4 *)(plVar16 + 5) = 0x202a;
                    plVar5 = (longlong *)
                             FUN_142cccf70(tstate,plVar11,
                                           classes_const_1732___type____T____items_________);
                    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                      (**(code **)(plVar11[1] + 0x30))(plVar11);
                    }
                    if (plVar5 == (longlong *)0x0) goto LAB_1408b49e4;
                    plVar11 = (longlong *)FUN_140008f40(tstate,plVar5,_DAT_142d9a260,0);
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (plVar11 == (longlong *)0x0) goto LAB_1408b49e4;
                    plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar11,classes_const_9_strip);
                    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                      (**(code **)(plVar11[1] + 0x30))(plVar11);
                    }
                    if (plVar5 == (longlong *)0x0) goto LAB_1408b49e4;
                    *(undefined4 *)(plVar16 + 5) = 0x202a;
                    pcVar10 = (code *)FUN_142cc3220(tstate,plVar5);
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (pcVar10 == (code *)0x0) goto LAB_1408b49e4;
                    pcStack_98 = pcVar10;
                    if (((pcVar13 != (code *)0x0) && (-1 < *(int *)pcVar13)) &&
                       (*(longlong *)pcVar13 = *(longlong *)pcVar13 + -1, *(longlong *)pcVar13 == 0)
                       ) {
                      (**(code **)(*(longlong *)(pcVar13 + 8) + 0x30))(pcVar13);
                    }
                    plVar5 = (longlong *)FUN_142cd7b20(tstate,pcVar10,classes_const_1434_startswith)
                    ;
                    if (plVar5 == (longlong *)0x0) {
LAB_1408b4ba7:
                      pcVar17 = *(code **)(tstate + 0x70);
                      iVar4 = 0x202b;
                      *(undefined8 *)(tstate + 0x70) = 0;
                      pcVar10 = pcStack_b8;
                      goto LAB_1408b4e1b;
                    }
                    *(undefined4 *)(plVar16 + 5) = 0x202b;
                    plVar11 = (longlong *)
                              FUN_142cccf70(tstate,plVar5,
                                            classes_const_1733___type____T____items_____image____);
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                    }
                    if (plVar11 == (longlong *)0x0) goto LAB_1408b4ba7;
                    iVar4 = FUN_140004970(plVar11);
                    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                      (**(code **)(plVar11[1] + 0x30))(plVar11);
                    }
                    puVar14 = classes_const_1734_image_png;
                    if (iVar4 == -1) goto LAB_1408b4ba7;
                    if (iVar4 == 0) {
                      pcStack_98 = (code *)classes_const_1734_image_png;
                      if (*(int *)classes_const_1734_image_png + 1 != 0) {
                        *(int *)classes_const_1734_image_png =
                             *(int *)classes_const_1734_image_png + 1;
                      }
                      if ((-1 < *(int *)pcVar10) &&
                         (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1,
                         *(longlong *)pcVar10 == 0)) {
                        (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
                      }
                      if (puVar14 == (undefined *)0x0) {
                        FUN_142cd4900(tstate,&pcStack_c0,classes_const_179_tipo);
                        FUN_1400048d0(tstate,pcStack_c0);
                        iVar4 = 0x202e;
                        pcVar17 = pcStack_c0;
                        pcVar10 = pcStack_b8;
                        goto LAB_1408b4e1b;
                      }
                      pcStack_98 = (code *)puVar14;
                      pcVar10 = (code *)puVar14;
                    }
                    puVar14 = classes_const_1735_data__s_base64__s;
                    plVar5 = (longlong *)FUN_142cd9440(tstate,2);
                    if (*(int *)pcVar10 + 1 != 0) {
                      *(int *)pcVar10 = *(int *)pcVar10 + 1;
                    }
                    plVar5[3] = (longlong)pcVar10;
                    lVar9 = FUN_140a39450(tstate);
                    if (lVar9 == 0) {
                      FUN_142cde870(tstate,&pcStack_c0,classes_const_827_base64);
                      goto LAB_1408b4df4;
                    }
                    plVar11 = (longlong *)FUN_142cd7b20(tstate,lVar9,classes_const_1736_b64encode);
                    if (plVar11 != (longlong *)0x0) {
                      plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_1235_content);
                      plVar16 = plStack_a0;
                      if (plVar6 == (longlong *)0x0) {
                        pcStack_c0 = *(code **)(tstate + 0x70);
                        *(undefined8 *)(tstate + 0x70) = 0;
                        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))(plVar11);
                        }
                        goto LAB_1408b4df4;
                      }
                      *(undefined4 *)(plStack_a0 + 5) = 0x202e;
                      plVar12 = (longlong *)FUN_142ccfd60(tstate,plVar11,plVar6);
                      if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                        (**(code **)(plVar11[1] + 0x30))(plVar11);
                      }
                      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                      }
                      if (plVar12 != (longlong *)0x0) {
                        plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar12,classes_const_471_decode);
                        if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                          (**(code **)(plVar12[1] + 0x30))(plVar12);
                        }
                        if (plVar6 != (longlong *)0x0) {
                          *(undefined4 *)(plVar16 + 5) = 0x202e;
                          lVar9 = FUN_142cccf70(tstate,plVar6,
                                                classes_const_1737___type____T____items_____ascii___
                                               );
                          if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                            (**(code **)(plVar6[1] + 0x30))(plVar6);
                          }
                          if (lVar9 != 0) {
                            plVar5[4] = lVar9;
                            plVar6 = (longlong *)FUN_142cbffc0(puVar14,plVar5);
                            if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                              (**(code **)(plVar5[1] + 0x30))(plVar5);
                            }
                            if (plVar6 == (longlong *)0x0) {
                              pcVar17 = *(code **)(tstate + 0x70);
                              iVar4 = 0x202d;
                              *(undefined8 *)(tstate + 0x70) = 0;
                              pcVar10 = pcStack_b8;
                              goto LAB_1408b4e1b;
                            }
                            plVar5 = plVar6;
                            if (((plStack_70 != (longlong *)0x0) && (-1 < (int)*plStack_70)) &&
                               (*plStack_70 = *plStack_70 + -1, *plStack_70 == 0)) {
                              plVar5 = plStack_70 + 1;
                              plStack_70 = plVar6;
                              (**(code **)(*plVar5 + 0x30))();
                              plVar5 = plStack_70;
                            }
                            plStack_70 = plVar5;
                            pcVar10 = pcStack_b0;
                            plVar5 = (longlong *)FUN_142cc1f90(tstate,pcStack_b0);
                            if (plVar5 == (longlong *)0x0) {
                              pcVar17 = *(code **)(tstate + 0x70);
                              iVar4 = 0x202f;
                              *(undefined8 *)(tstate + 0x70) = 0;
                              pcVar10 = pcStack_b8;
                            }
                            else {
                              cVar3 = Nuitka_helper_142ce0f60(plVar5,0x28);
                              if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                                (**(code **)(plVar5[1] + 0x30))(plVar5);
                              }
                              if (cVar3 == '\0') {
LAB_1408b4f94:
                                cVar3 = FUN_140029450(tstate,pcVar10,plStack_68,plVar6);
                                pcVar8 = pcStack_b8;
                                pcVar13 = pcStack_98;
                                if (cVar3 != '\0') goto LAB_1408b51af;
                                pcVar17 = *(code **)(tstate + 0x70);
                                iVar4 = 0x2031;
                                *(undefined8 *)(tstate + 0x70) = 0;
                                pcVar10 = pcStack_b8;
                              }
                              else {
                                plVar5 = (longlong *)
                                         FUN_142cd7b20(tstate,pcVar10,classes_const_1738_clear);
                                if (plVar5 != (longlong *)0x0) {
                                  *(undefined4 *)(plVar16 + 5) = 0x2030;
                                  plVar11 = (longlong *)FUN_142cc3220(tstate,plVar5);
                                  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0))
                                  {
                                    (**(code **)(plVar5[1] + 0x30))(plVar5);
                                  }
                                  if (plVar11 != (longlong *)0x0) {
                                    if ((-1 < (int)*plVar11) &&
                                       (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                                      (**(code **)(plVar11[1] + 0x30))(plVar11);
                                    }
                                    goto LAB_1408b4f94;
                                  }
                                }
                                pcVar17 = *(code **)(tstate + 0x70);
                                iVar4 = 0x2030;
                                *(undefined8 *)(tstate + 0x70) = 0;
                                pcVar10 = pcStack_b8;
                              }
                            }
                            goto LAB_1408b4e1b;
                          }
                        }
                      }
                    }
                    pcStack_c0 = *(code **)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408b4df4:
                    iVar4 = 0x202e;
                    pcVar17 = pcStack_c0;
                    plVar16 = plStack_a0;
                    pcVar10 = pcStack_b8;
                    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))(plVar5);
                      pcVar17 = pcStack_c0;
                      plVar16 = plStack_a0;
                      pcVar10 = pcStack_b8;
                    }
                    goto LAB_1408b4e1b;
                  }
                  FUN_142cde870(tstate,&pcStack_c0,classes_const_628_requests);
                  iVar4 = 0x2028;
                  pcVar17 = pcStack_c0;
LAB_1408b4e1b:
                  piVar2 = *(int **)(tstate + 0xf8);
                  pcStack_c0 = (code *)0x0;
                  if ((piVar2 != (int *)0x0) && (*piVar2 + 1 != 0)) {
                    *piVar2 = *piVar2 + 1;
                  }
                  piVar1 = *(int **)(pcVar17 + 0x28);
                  if (piVar1 == (int *)0x0) {
                    pcVar8 = (code *)FUN_142cd9160(plVar16,iVar4);
                    bVar18 = pcVar8 == _Py_NoneStruct_exref;
LAB_1408b4fee:
                    plVar5 = *(longlong **)(pcVar17 + 0x28);
                    if (bVar18) {
                      pcVar13 = (code *)0x0;
                    }
                    else {
                      pcVar13 = pcVar8;
                      if ((pcVar8 != (code *)0x0) && (*(int *)pcVar8 + 1 != 0)) {
                        *(int *)pcVar8 = *(int *)pcVar8 + 1;
                      }
                    }
                    *(code **)(pcVar17 + 0x28) = pcVar13;
                    if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
                       (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))();
                    }
                    if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
                       (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                      (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
                    }
                  }
                  else if (iVar4 != 0) {
                    pcVar8 = (code *)FUN_142cd9160(plVar16,iVar4);
                    *(int **)(pcVar8 + 0x10) = piVar1;
                    if (*piVar1 + 1 != 0) {
                      *piVar1 = *piVar1 + 1;
                    }
                    bVar18 = pcVar8 == _Py_NoneStruct_exref;
                    goto LAB_1408b4fee;
                  }
                  plVar5 = *(longlong **)(tstate + 0xf8);
                  *(code **)(tstate + 0xf8) = pcVar17;
                  if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
                     (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                    (**(code **)(plVar5[1] + 0x30))();
                  }
                  iVar4 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                                        *(undefined8 *)PyExc_Exception_exref);
                  if (iVar4 == 0) {
                    cVar3 = FUN_142cded30(tstate,&pcStack_c0);
                    pcVar8 = pcStack_c0;
                    uVar15 = 0x2027;
                    if (cVar3 != '\0') {
                      uVar15 = 0;
                    }
                    lVar9 = *(longlong *)(pcStack_c0 + 0x28);
                    if ((lVar9 != 0) && (*(longlong **)(lVar9 + 0x18) == plVar16)) {
                      *(undefined4 *)(plVar16 + 5) = *(undefined4 *)(lVar9 + 0x24);
                    }
                    pcStack_c0 = (code *)0x0;
                    plVar5 = *(longlong **)(tstate + 0xf8);
                    *(int **)(tstate + 0xf8) = piVar2;
                    pcVar13 = pcStack_b0;
                    if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
                       (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                      (**(code **)(plVar5[1] + 0x30))();
                      pcVar13 = pcStack_b0;
                    }
                    goto LAB_1408b52e1;
                  }
                  plVar5 = *(longlong **)(tstate + 0xf8);
                  *(int **)(tstate + 0xf8) = piVar2;
                  if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
                     (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                    (**(code **)(plVar5[1] + 0x30))();
                  }
LAB_1408b50ad:
                  if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                      (iVar4 = Py_MakePendingCalls(), iVar4 < 0)) &&
                     (pcVar8 = *(code **)(tstate + 0x70), pcVar8 != (code *)0x0)) {
LAB_1408b52a2:
                    uVar15 = 0x2022;
                    *(undefined8 *)(tstate + 0x70) = 0;
                    pcVar10 = pcStack_b8;
                    pcVar13 = pcStack_b0;
                    goto LAB_1408b52e1;
                  }
                  if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                    PyEval_SaveThread();
                    PyEval_AcquireThread(tstate);
                  }
                  pcVar10 = pcStack_b8;
                  if (*(longlong *)(tstate + 0x90) != 0) {
                    plVar5 = *(longlong **)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x90) = 0;
                    pcVar8 = (code *)FUN_142cd9e70(tstate);
                    *(code **)(tstate + 0x70) = pcVar8;
                    if ((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) {
                      *plVar5 = *plVar5 + -1;
                      if (*plVar5 == 0) {
                        (**(code **)(plVar5[1] + 0x30))(plVar5);
                      }
                      pcVar8 = *(code **)(tstate + 0x70);
                    }
                    goto LAB_1408b52a2;
                  }
                  pcVar8 = pcStack_b8;
                  pcVar13 = pcStack_98;
                  if (pcStack_b8 == (code *)0x0) goto LAB_1408b5243;
                  goto LAB_1408b46d0;
                }
                pcStack_c0 = *(code **)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                  (**(code **)(plVar5[1] + 0x30))(plVar5);
                }
                uVar15 = 0x2020;
                pcVar10 = pcVar17;
                pcVar13 = pcStack_b0;
                pcVar8 = pcStack_c0;
              }
            }
          }
        }
      }
    }
  }
  goto LAB_1408b52e1;
LAB_1408b5243:
  FUN_142cd4900(tstate,&pcStack_c0,classes_const_1483_tentativa);
  FUN_1400048d0(tstate,pcStack_c0);
  uVar15 = 0x2022;
  pcVar13 = pcStack_b0;
  pcVar8 = pcStack_c0;
LAB_1408b52e1:
  pcStack_c0 = pcVar8;
  piVar2 = *(int **)(pcStack_c0 + 0x28);
  if (piVar2 == (int *)0x0) {
    pcVar17 = (code *)FUN_142cd9160(plVar16,uVar15);
    bVar18 = pcVar17 == _Py_NoneStruct_exref;
LAB_1408b532d:
    plVar5 = *(longlong **)(pcStack_c0 + 0x28);
    if (bVar18) {
      pcVar8 = (code *)0x0;
    }
    else {
      pcVar8 = pcVar17;
      if ((pcVar17 != (code *)0x0) && (*(int *)pcVar17 + 1 != 0)) {
        *(int *)pcVar17 = *(int *)pcVar17 + 1;
      }
    }
    *(code **)(pcStack_c0 + 0x28) = pcVar8;
    if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
       (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))();
    }
    if (((pcVar17 != (code *)0x0) && (-1 < *(int *)pcVar17)) &&
       (*(longlong *)pcVar17 = *(longlong *)pcVar17 + -1, *(longlong *)pcVar17 == 0)) {
      (**(code **)(*(longlong *)(pcVar17 + 8) + 0x30))(pcVar17);
    }
  }
  else if (*(longlong **)(piVar2 + 6) != plVar16) {
    pcVar17 = (code *)FUN_142cd9160(plVar16,uVar15);
    *(int **)(pcVar17 + 0x10) = piVar2;
    if (*piVar2 + 1 != 0) {
      *piVar2 = *piVar2 + 1;
    }
    bVar18 = pcVar17 == _Py_NoneStruct_exref;
    goto LAB_1408b532d;
  }
  pcVar8 = pcStack_90;
  pcVar17 = pcStack_98;
  plStack_d0 = plStack_70;
  pcStack_d8 = pcStack_98;
  plStack_e0 = plStack_78;
  pcStack_e8 = pcStack_90;
  plStack_f8 = plStack_80;
  pcStack_100 = pcStack_88;
  pcStack_108 = pcVar13;
  pcStack_f0 = pcVar10;
  FUN_142cdb370(plVar16,&UNK_142d0b418,plStack_60,plStack_68);
  plVar5 = _DAT_142dea708;
  if (plVar16 == _DAT_142dea708) {
    if ((-1 < (int)*_DAT_142dea708) && (*_DAT_142dea708 = *_DAT_142dea708 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))();
    }
    _DAT_142dea708 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  pcVar7 = pcStack_c0;
  pcStack_c0 = (code *)0x0;
  if (((pcVar13 != (code *)0x0) && (-1 < *(int *)pcVar13)) &&
     (*(longlong *)pcVar13 = *(longlong *)pcVar13 + -1, *(longlong *)pcVar13 == 0)) {
    (**(code **)(*(longlong *)(pcVar13 + 8) + 0x30))(pcVar13);
  }
  if (((pcStack_88 != (code *)0x0) && (-1 < *(int *)pcStack_88)) &&
     (*(longlong *)pcStack_88 = *(longlong *)pcStack_88 + -1, *(longlong *)pcStack_88 == 0)) {
    (**(code **)(*(longlong *)(pcStack_88 + 8) + 0x30))();
  }
  if (((plStack_80 != (longlong *)0x0) && (-1 < (int)*plStack_80)) &&
     (*plStack_80 = *plStack_80 + -1, *plStack_80 == 0)) {
    (**(code **)(plStack_80[1] + 0x30))();
  }
  if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
     (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
    (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
  }
  if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
     (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
    (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
  }
  if (((plStack_78 != (longlong *)0x0) && (-1 < (int)*plStack_78)) &&
     (*plStack_78 = *plStack_78 + -1, *plStack_78 == 0)) {
    (**(code **)(plStack_78[1] + 0x30))();
  }
  if (((pcVar17 != (code *)0x0) && (-1 < *(int *)pcVar17)) &&
     (*(longlong *)pcVar17 = *(longlong *)pcVar17 + -1, *(longlong *)pcVar17 == 0)) {
    (**(code **)(*(longlong *)(pcVar17 + 8) + 0x30))(pcVar17);
  }
  if (((plStack_70 != (longlong *)0x0) && (-1 < (int)*plStack_70)) &&
     (*plStack_70 = *plStack_70 + -1, *plStack_70 == 0)) {
    (**(code **)(plStack_70[1] + 0x30))();
  }
  pcStack_c0 = pcVar7;
  if ((-1 < (int)*plStack_60) && (*plStack_60 = *plStack_60 + -1, *plStack_60 == 0)) {
    (**(code **)(plStack_60[1] + 0x30))();
  }
  if ((-1 < (int)*plStack_68) && (*plStack_68 = *plStack_68 + -1, *plStack_68 == 0)) {
    (**(code **)(plStack_68[1] + 0x30))();
  }
  plVar5 = *(longlong **)(tstate + 0x70);
  *(code **)(tstate + 0x70) = pcStack_c0;
  if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)
     ) {
    (**(code **)(plVar5[1] + 0x30))();
  }
LAB_1408b5673:
  puVar14 = (undefined *)FUN_142cfc380(uStack_40 ^ (ulonglong)auStack_128);
  return puVar14;
}

