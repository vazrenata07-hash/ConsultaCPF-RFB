
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _geetest_click_marcas(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  longlong lVar3;
  longlong *plVar4;
  char cVar5;
  int iVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  int *piVar10;
  code *pcVar11;
  longlong lVar12;
  code *pcVar13;
  bool bVar14;
  longlong alStackX_18 [2];
  
  plVar4 = _DAT_142dea738;
  plVar1 = (longlong *)*python_pars;
  if (_DAT_142dea738 == (longlong *)0x0) {
LAB_1408b8e14:
    _DAT_142dea738 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9b70,_DAT_142f2aaf0,8);
  }
  else if ((1 < *_DAT_142dea738) || (_DAT_142dea738[2] != 0)) {
    if ((_DAT_142dea738 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea738 && (*_DAT_142dea738 = *_DAT_142dea738 + -1, *plVar4 == 0)))) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    goto LAB_1408b8e14;
  }
  plVar4 = _DAT_142dea738;
  Nuitka_helper_140008a00(tstate,_DAT_142dea738);
  plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
  if (plVar7 == (longlong *)0x0) {
LAB_1408b8e73:
    lVar12 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    pcVar13 = (code *)0x2124;
  }
  else {
    iVar6 = FUN_140004970(plVar7);
    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))(plVar7);
    }
    piVar10 = _DAT_142d9a270;
    if (iVar6 == -1) goto LAB_1408b8e73;
    if (iVar6 == 0) {
      if (*_DAT_142d9a270 + 1 != 0) {
        *_DAT_142d9a270 = *_DAT_142d9a270 + 1;
      }
      goto LAB_1408b8ec0;
    }
    plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
    if (plVar7 == (longlong *)0x0) {
LAB_1408b900d:
      lVar12 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar7,classes_const_338_execute_script);
      if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
        (**(code **)(plVar7[1] + 0x30))(plVar7);
      }
      if (plVar8 == (longlong *)0x0) goto LAB_1408b900d;
      plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1770__JS_GEETEST_CLICK_MARCAS);
      if (plVar7 != (longlong *)0x0) {
        *(undefined4 *)(plVar4 + 5) = 0x2127;
        plVar9 = (longlong *)FUN_142ccfd60(tstate,plVar8,plVar7);
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
          (**(code **)(plVar7[1] + 0x30))(plVar7);
        }
        if (plVar9 != (longlong *)0x0) {
          piVar10 = (int *)PyNumber_Long(plVar9);
          if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
            (**(code **)(plVar9[1] + 0x30))(plVar9);
          }
          if (piVar10 != (int *)0x0) goto LAB_1408b8ec0;
        }
        goto LAB_1408b900d;
      }
      alStackX_18[0] = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      lVar12 = alStackX_18[0];
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
        lVar12 = alStackX_18[0];
      }
    }
    piVar2 = *(int **)(tstate + 0xf8);
    alStackX_18[0] = 0;
    if ((piVar2 != (int *)0x0) && (*piVar2 + 1 != 0)) {
      *piVar2 = *piVar2 + 1;
    }
    piVar10 = *(int **)(lVar12 + 0x28);
    pcVar13 = (code *)FUN_142cd9160(plVar4,0x2127);
    if (piVar10 != (int *)0x0) {
      *(int **)(pcVar13 + 0x10) = piVar10;
      if (*piVar10 + 1 != 0) {
        *piVar10 = *piVar10 + 1;
      }
    }
    plVar7 = *(longlong **)(lVar12 + 0x28);
    pcVar11 = (code *)0x0;
    if (((pcVar13 != _Py_NoneStruct_exref) && (pcVar11 = pcVar13, pcVar13 != (code *)0x0)) &&
       (*(int *)pcVar13 + 1 != 0)) {
      *(int *)pcVar13 = *(int *)pcVar13 + 1;
    }
    *(code **)(lVar12 + 0x28) = pcVar11;
    if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))();
    }
    if (((pcVar13 != (code *)0x0) && (-1 < *(int *)pcVar13)) &&
       (*(longlong *)pcVar13 = *(longlong *)pcVar13 + -1, *(longlong *)pcVar13 == 0)) {
      (**(code **)(*(longlong *)(pcVar13 + 8) + 0x30))(pcVar13);
    }
    plVar7 = *(longlong **)(tstate + 0xf8);
    *(longlong *)(tstate + 0xf8) = lVar12;
    if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))();
    }
    iVar6 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    piVar10 = _DAT_142d9a270;
    if (iVar6 != 0) {
      if (*_DAT_142d9a270 + 1 != 0) {
        *_DAT_142d9a270 = *_DAT_142d9a270 + 1;
      }
      plVar4 = *(longlong **)(tstate + 0xf8);
      *(int **)(tstate + 0xf8) = piVar2;
      if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
         (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))();
      }
LAB_1408b8ec0:
      FUN_140008990(tstate);
      if ((int)*plVar1 < 0) {
        return (undefined *)piVar10;
      }
      *plVar1 = *plVar1 + -1;
      if (*plVar1 != 0) {
        return (undefined *)piVar10;
      }
      (**(code **)(plVar1[1] + 0x30))(plVar1);
      return (undefined *)piVar10;
    }
    cVar5 = FUN_142cded30(tstate,alStackX_18);
    lVar12 = alStackX_18[0];
    pcVar13 = (code *)0x2126;
    if (cVar5 != '\0') {
      pcVar13 = (code *)0x0;
    }
    lVar3 = *(longlong *)(alStackX_18[0] + 0x28);
    if ((lVar3 != 0) && (*(longlong **)(lVar3 + 0x18) == plVar4)) {
      *(undefined4 *)(plVar4 + 5) = *(undefined4 *)(lVar3 + 0x24);
    }
    plVar7 = *(longlong **)(tstate + 0xf8);
    alStackX_18[0] = 0;
    *(int **)(tstate + 0xf8) = piVar2;
    if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))();
    }
  }
  pcVar11 = (code *)0x0;
  piVar10 = *(int **)(lVar12 + 0x28);
  alStackX_18[0] = lVar12;
  if (piVar10 == (int *)0x0) {
    pcVar13 = (code *)FUN_142cd9160(plVar4,pcVar13);
    bVar14 = pcVar13 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar10 + 6) == plVar4) goto LAB_1408b9256;
    pcVar13 = (code *)FUN_142cd9160(plVar4,pcVar13);
    *(int **)(pcVar13 + 0x10) = piVar10;
    if (*piVar10 + 1 != 0) {
      *piVar10 = *piVar10 + 1;
    }
    bVar14 = pcVar13 == _Py_NoneStruct_exref;
  }
  plVar7 = *(longlong **)(alStackX_18[0] + 0x28);
  if (((!bVar14) && (pcVar11 = pcVar13, pcVar13 != (code *)0x0)) && (*(int *)pcVar13 + 1 != 0)) {
    *(int *)pcVar13 = *(int *)pcVar13 + 1;
  }
  *(code **)(alStackX_18[0] + 0x28) = pcVar11;
  if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)
     ) {
    (**(code **)(plVar7[1] + 0x30))();
  }
  if (((pcVar13 != (code *)0x0) && (-1 < *(int *)pcVar13)) &&
     (*(longlong *)pcVar13 = *(longlong *)pcVar13 + -1, *(longlong *)pcVar13 == 0)) {
    (**(code **)(*(longlong *)(pcVar13 + 8) + 0x30))(pcVar13);
  }
LAB_1408b9256:
  FUN_142cdb370(plVar4,&UNK_142d0ae4c,plVar1);
  plVar7 = _DAT_142dea738;
  if (plVar4 == _DAT_142dea738) {
    if ((-1 < (int)*_DAT_142dea738) && (*_DAT_142dea738 = *_DAT_142dea738 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))();
    }
    _DAT_142dea738 = (longlong *)0x0;
  }
  plVar4 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar4 + 10) = 0xfffffffe;
  plVar7 = (longlong *)plVar4[2];
  if (((plVar7 != (longlong *)0x0) && (plVar4[2] = 0, -1 < (int)*plVar7)) &&
     (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
    (**(code **)(plVar7[1] + 0x30))();
  }
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))(plVar4);
  }
  plVar4[0xc] = 0;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = alStackX_18[0];
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

