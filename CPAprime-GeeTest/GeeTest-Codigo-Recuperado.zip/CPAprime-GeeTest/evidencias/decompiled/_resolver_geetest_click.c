
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _resolver_geetest_click(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  code *pcVar17;
  undefined8 uVar18;
  longlong *plVar19;
  code *pcVar20;
  undefined *puVar21;
  undefined4 uVar22;
  longlong *plVar23;
  longlong *plVar24;
  int *piVar25;
  bool bVar26;
  longlong *plStackX_18;
  longlong *plStackX_20;
  undefined8 in_stack_fffffffffffffd58;
  undefined8 uVar27;
  longlong *plStack_1b0;
  code *pcStack_1a8;
  longlong *plStack_1a0;
  longlong *plStack_198;
  longlong *plStack_190;
  longlong *plStack_178;
  longlong *plStack_170;
  longlong *plStack_168;
  longlong *plStack_160;
  longlong *plStack_158;
  longlong *plStack_150;
  longlong *plStack_148;
  longlong *plStack_140;
  longlong *plStack_138;
  longlong *plStack_128;
  longlong *plStack_120;
  longlong *plStack_118;
  longlong *plStack_110;
  longlong *plStack_108;
  longlong *plStack_100;
  longlong *plStack_f8;
  longlong *plStack_f0;
  longlong *plStack_e8;
  longlong *plStack_e0;
  longlong *plStack_d8;
  longlong *plStack_d0;
  longlong *plStack_c8;
  longlong *plStack_a8;
  longlong *plStack_a0;
  undefined *puStack_98;
  longlong *plStack_90;
  undefined *puStack_88;
  longlong *plStack_80;
  undefined *puStack_78;
  longlong *plStack_70;
  undefined *puStack_68;
  longlong *plStack_60;
  longlong *plStack_58;
  longlong *plStack_50;
  longlong *plStack_48;
  longlong *plStack_40;
  
  plVar1 = (longlong *)*python_pars;
  plVar2 = (longlong *)python_pars[1];
  plStackX_20 = (longlong *)0x0;
  plStack_d0 = (longlong *)0x0;
  plStack_148 = (longlong *)0x0;
  plStack_c8 = (longlong *)0x0;
  plStack_100 = (longlong *)0x0;
  plStack_f8 = (longlong *)0x0;
  plStack_1a0 = (longlong *)0x0;
  plStack_168 = (longlong *)0x0;
  plStack_140 = (longlong *)0x0;
  plStack_118 = (longlong *)0x0;
  plStack_110 = (longlong *)0x0;
  plStack_f0 = (longlong *)0x0;
  plStack_108 = (longlong *)0x0;
  plStack_128 = (longlong *)0x0;
  plStack_e8 = (longlong *)0x0;
  plStack_e0 = (longlong *)0x0;
  plStack_1b0 = (longlong *)0x0;
  plStack_198 = (longlong *)0x0;
  plStack_190 = (longlong *)0x0;
  plStack_120 = (longlong *)0x0;
  plStack_158 = (longlong *)0x0;
  plStack_160 = (longlong *)0x0;
  plStack_138 = (longlong *)0x0;
  plStack_d8 = (longlong *)0x0;
  pcStack_1a8 = (code *)0x0;
  plStack_170 = _DAT_142d9a260;
  plStack_178 = _DAT_142d9a260;
  iVar5 = (int)*_DAT_142d9a260 + 1;
  if (iVar5 != 0) {
    *(int *)_DAT_142d9a260 = iVar5;
    plStack_170 = _DAT_142d9a260;
  }
  plStack_150 = plStack_170;
  iVar5 = (int)*plStack_170 + 1;
  if (iVar5 != 0) {
    _DAT_142d9a260 = plStack_170;
    *(int *)plStack_170 = iVar5;
    plStack_170 = _DAT_142d9a260;
  }
  iVar5 = (int)*plStack_170 + 1;
  _DAT_142d9a260 = plStack_170;
  if (iVar5 != 0) {
    *(int *)plStack_170 = iVar5;
  }
  plVar3 = _DAT_142dea770;
  if (_DAT_142dea770 != (longlong *)0x0) {
    if ((*_DAT_142dea770 < 2) && (_DAT_142dea770[2] == 0)) goto LAB_1408c2cda;
    if ((_DAT_142dea770 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea770 && (*_DAT_142dea770 = *_DAT_142dea770 + -1, *plVar3 == 0)))) {
      (**(code **)(plVar3[1] + 0x30))(plVar3);
    }
  }
  _DAT_142dea770 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9d38,_DAT_142f2aaf0,0xf0);
LAB_1408c2cda:
  plVar3 = _DAT_142dea770;
  plVar6 = plVar2;
  Nuitka_helper_140008a00(tstate,_DAT_142dea770);
LAB_1408c2ce5:
  plVar19 = plStack_148;
  plVar9 = plStack_150;
  pcVar20 = pcStack_1a8;
  plVar6 = (longlong *)FUN_142ce3260(plStack_178,plVar6);
  if (plVar6 == (longlong *)0x0) goto LAB_1408c5b3d;
  iVar5 = FUN_140004970(plVar6);
  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  if (iVar5 == -1) goto LAB_1408c5b3d;
  if (iVar5 == 0) {
    FUN_140008990(tstate);
    pcVar20 = _Py_FalseStruct_exref;
    if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
      *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
    }
    goto LAB_1408c7932;
  }
  if (plVar1 == (longlong *)0x0) {
    FUN_142cd4900(tstate,&plStackX_20,classes_const_403_self);
    FUN_1400048d0(tstate,plStackX_20);
LAB_1408c75ff:
    plVar6 = plStackX_20;
    plStackX_20 = (longlong *)0x0;
    piVar25 = *(int **)(tstate + 0xf8);
    plStackX_18 = plVar6;
    if ((piVar25 != (int *)0x0) && (*piVar25 + 1 != 0)) {
      *piVar25 = *piVar25 + 1;
    }
    if (plVar6[5] == 0) {
      plVar9 = (longlong *)FUN_142cd9160(plVar3,0x21c7);
    }
    else {
      plVar9 = (longlong *)FUN_140008a80(plVar6[5],plVar3,0x21c7);
    }
    Nuitka_helper_140008ab0(plVar6,plVar9);
    if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    FUN_14005a9a0(tstate,&plStackX_18);
    iVar5 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    if (iVar5 == 0) {
      cVar4 = FUN_142cded30(tstate,&plStackX_20);
      uVar22 = 0x21c6;
      if (cVar4 != '\0') {
        uVar22 = 0;
      }
      lVar10 = plStackX_20[5];
      plVar9 = plStackX_20;
      if ((lVar10 != 0) && (*(longlong **)(lVar10 + 0x18) == plVar3)) {
        *(undefined4 *)(plVar3 + 5) = *(undefined4 *)(lVar10 + 0x24);
      }
LAB_1408c78dd:
      plVar6 = *(longlong **)(tstate + 0xf8);
      *(int **)(tstate + 0xf8) = piVar25;
      goto LAB_1408c78f6;
    }
    plVar6 = *(longlong **)(tstate + 0xf8);
    iVar5 = (int)*plVar6 + 1;
    if (iVar5 != 0) {
      *(int *)plVar6 = iVar5;
    }
    uVar18 = FUN_1400776a0(classes_const_257_print);
    puVar21 = classes_const_1849__s__geetest_ordem__o_script_nao_rodou___s;
    if (plVar1 == (longlong *)0x0) {
      FUN_142cd4900(tstate,&plStackX_20,classes_const_403_self);
      FUN_1400048d0(tstate,plStackX_20);
      plVar9 = plStackX_20;
LAB_1408c7802:
      plStackX_20 = (longlong *)0x0;
      uVar22 = 0x21c9;
      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      goto LAB_1408c78dd;
    }
    *(undefined4 *)(plVar3 + 5) = 0x21c9;
    lVar10 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
    if (lVar10 == 0) {
LAB_1408c77dc:
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      goto LAB_1408c7802;
    }
    plVar9 = (longlong *)FUN_142cd9440(tstate,2);
    plVar9[3] = lVar10;
    iVar5 = (int)*plVar6 + 1;
    if (iVar5 != 0) {
      *(int *)plVar6 = iVar5;
    }
    plVar9[4] = (longlong)plVar6;
    plVar19 = (longlong *)FUN_142cbffc0(puVar21,plVar9);
    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    if (plVar19 == (longlong *)0x0) goto LAB_1408c77dc;
    *(undefined4 *)(plVar3 + 5) = 0x21c9;
    plVar9 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar19);
    if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
      (**(code **)(plVar19[1] + 0x30))(plVar19);
    }
    if (plVar9 == (longlong *)0x0) goto LAB_1408c77dc;
    goto LAB_1408c7824;
  }
  plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
  if (plVar6 == (longlong *)0x0) {
LAB_1408c75c8:
    plStackX_20 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    goto LAB_1408c75ff;
  }
  plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_338_execute_script);
  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  if (plVar7 == (longlong *)0x0) goto LAB_1408c75c8;
  plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1848__JS_GEETEST_CLICK_URLS);
  if (plVar6 == (longlong *)0x0) {
    plStackX_20 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))(plVar7);
    }
    goto LAB_1408c75ff;
  }
  *(undefined4 *)(plVar3 + 5) = 0x21c7;
  plVar8 = (longlong *)FUN_142ccfd60(tstate,plVar7,plVar6);
  if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
    (**(code **)(plVar7[1] + 0x30))(plVar7);
  }
  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  if (plVar8 == (longlong *)0x0) goto LAB_1408c75c8;
  if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
     (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
    (**(code **)(plStack_d0[1] + 0x30))();
  }
  iVar5 = PyObject_IsInstance(plVar8,PyDict_Type_exref);
  plStack_d0 = plVar8;
  if (iVar5 == -1) {
LAB_1408c757c:
    plVar9 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    uVar22 = 0x21cb;
  }
  else {
    pcVar17 = _Py_FalseStruct_exref;
    if (iVar5 != 0) {
      pcVar17 = _Py_TrueStruct_exref;
    }
    iVar5 = FUN_140004970(pcVar17);
    if (iVar5 == -1) goto LAB_1408c757c;
    if (iVar5 != 0) {
      plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_211_get);
      if (plVar6 != (longlong *)0x0) {
        *(undefined4 *)(plVar3 + 5) = 0x21cb;
        plVar7 = (longlong *)
                 FUN_142cccf70(tstate,plVar6,classes_const_1850___type____T____items_____ok___);
        if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
          (**(code **)(plVar6[1] + 0x30))(plVar6);
        }
        if (plVar7 != (longlong *)0x0) {
          iVar5 = FUN_140004970(plVar7);
          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
            (**(code **)(plVar7[1] + 0x30))(plVar7);
          }
          if (iVar5 != -1) goto LAB_1408c2eda;
        }
      }
      goto LAB_1408c757c;
    }
LAB_1408c2eda:
    puVar21 = classes_const_102_;
    if (iVar5 == 0) {
      plStack_148 = (longlong *)classes_const_102_;
      if (*(int *)classes_const_102_ + 1 != 0) {
        *(int *)classes_const_102_ = *(int *)classes_const_102_ + 1;
      }
      if (((plVar19 != (longlong *)0x0) && (-1 < (int)*plVar19)) &&
         (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
        (**(code **)(plVar19[1] + 0x30))();
      }
      iVar5 = PyObject_IsInstance(plVar8,PyDict_Type_exref);
      if (iVar5 == -1) {
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar22 = 0x21cd;
      }
      else {
        plVar6 = (longlong *)puVar21;
        if (iVar5 != 0) {
          plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_211_get);
          uVar22 = 0x21ce;
          if (plVar6 != (longlong *)0x0) {
            *(undefined4 *)(plVar3 + 5) = 0x21ce;
            plVar9 = (longlong *)
                     FUN_142ccd7d0(tstate,plVar6,
                                   classes_const_1851___type____T____items_____erro_______);
            if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
              (**(code **)(plVar6[1] + 0x30))(plVar6);
            }
            if (plVar9 != (longlong *)0x0) {
              plVar6 = (longlong *)FUN_142cc2ce0(plVar9);
              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              if (plVar6 != (longlong *)0x0) {
                if ((-1 < *(int *)puVar21) &&
                   (*(longlong *)puVar21 = *(longlong *)puVar21 + -1, *(longlong *)puVar21 == 0)) {
                  (**(code **)(*(longlong *)(puVar21 + 8) + 0x30))(puVar21);
                }
                goto LAB_1408c2fdf;
              }
            }
          }
          goto LAB_1408c5c12;
        }
LAB_1408c2fdf:
        iVar5 = PySequence_Contains(classes_const_1852___type____T____items_____sem_pergunta____sem_foto___
                                    ,plVar6);
        plStack_148 = plVar6;
        if (iVar5 == -1) {
          plVar9 = *(longlong **)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          uVar22 = 0x21cf;
        }
        else if (iVar5 == 1) {
          if (plStack_150 == (longlong *)0x0) {
            FUN_142cd4900(tstate,&plStackX_20,classes_const_1853_esperas);
            FUN_1400048d0(tstate,plStackX_20);
            uVar22 = 0x21d0;
            plVar9 = plStackX_20;
          }
          else {
            plVar9 = (longlong *)FUN_142cbe350(plStack_150,1);
            if ((-1 < (int)*plStack_150) && (*plStack_150 = *plStack_150 + -1, *plStack_150 == 0)) {
              (**(code **)(plStack_150[1] + 0x30))(plStack_150);
            }
            cVar4 = Nuitka_helper_142ce1a90(plVar9,6);
            plStack_150 = plVar9;
            if (cVar4 == '\0') goto LAB_1408c5bd7;
            lVar10 = FUN_140a3b210(tstate);
            if (lVar10 == 0) {
              FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
              uVar22 = 0x21d2;
              plVar9 = plStackX_20;
            }
            else {
              *(undefined4 *)(plVar3 + 5) = 0x21d2;
              plVar6 = (longlong *)FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep);
              if (plVar6 != (longlong *)0x0) {
                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                }
                goto LAB_1408c30a1;
              }
              plVar9 = *(longlong **)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              uVar22 = 0x21d2;
            }
          }
        }
        else {
LAB_1408c5bd7:
          uVar18 = FUN_1400776a0(classes_const_257_print);
          puVar21 = classes_const_1855__s__geetest_ordem__nao_consegui_ler_o_desafio___s;
          uVar22 = 0x21d5;
          *(undefined4 *)(plVar3 + 5) = 0x21d5;
          lVar10 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
          if (lVar10 == 0) goto LAB_1408c5c12;
          plVar9 = (longlong *)FUN_142cd9440(tstate,2);
          plVar9[3] = lVar10;
          iVar5 = (int)*plVar6 + 1;
          if (iVar5 != 0) {
            *(int *)plVar6 = iVar5;
          }
          plVar9[4] = (longlong)plVar6;
          plVar19 = (longlong *)FUN_142cbffc0(puVar21,plVar9);
          if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
            (**(code **)(plVar9[1] + 0x30))(plVar9);
          }
          if (plVar19 == (longlong *)0x0) {
            plVar9 = *(longlong **)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
          }
          else {
            *(undefined4 *)(plVar3 + 5) = 0x21d4;
            plVar6 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar19);
            if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
              (**(code **)(plVar19[1] + 0x30))(plVar19);
            }
            if (plVar6 != (longlong *)0x0) {
              pcVar20 = _Py_FalseStruct_exref;
              if ((-1 < (int)*plVar6) &&
                 (*plVar6 = *plVar6 + -1, pcVar20 = _Py_FalseStruct_exref, *plVar6 == 0)) {
                lVar10 = plVar6[1];
                goto LAB_1408c5cf2;
              }
              goto LAB_1408c5cfc;
            }
            plVar9 = *(longlong **)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            uVar22 = 0x21d4;
          }
        }
      }
    }
    else {
      plStack_150 = _DAT_142d9a260;
      iVar5 = (int)*_DAT_142d9a260 + 1;
      if (iVar5 != 0) {
        *(int *)_DAT_142d9a260 = iVar5;
      }
      if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))();
      }
      *(undefined4 *)(plVar3 + 5) = 0x21dd;
      plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1856__geetest_click_marcas);
      if (plVar6 == (longlong *)0x0) {
LAB_1408c755e:
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar22 = 0x21dd;
      }
      else {
        iVar5 = FUN_142ce1250(plVar6,_DAT_142d9a260);
        if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
          (**(code **)(plVar6[1] + 0x30))(plVar6);
        }
        if (iVar5 == -1) goto LAB_1408c755e;
        if (iVar5 != 1) goto LAB_1408c3631;
        lVar10 = FUN_140a3b210(tstate);
        if (lVar10 == 0) {
          FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
          uVar22 = 0x21de;
          plVar9 = plStackX_20;
        }
        else {
          *(undefined4 *)(plVar3 + 5) = 0x21de;
          plVar6 = (longlong *)FUN_142cd06a0(tstate,lVar10,classes_const_76_time);
          if (plVar6 == (longlong *)0x0) {
            plVar9 = *(longlong **)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            uVar22 = 0x21de;
          }
          else {
            plVar9 = (longlong *)Nuitka_helper_142cbe650(plVar6,classes_const_1857_6_0);
            if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
              (**(code **)(plVar6[1] + 0x30))(plVar6);
            }
            if (plVar9 != (longlong *)0x0) {
              if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
                 (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
                (**(code **)(plStack_c8[1] + 0x30))();
              }
              do {
                lVar10 = FUN_140a3b210(tstate);
                plStack_c8 = plVar9;
                if (lVar10 == 0) {
                  FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                  uVar22 = 0x21df;
                  plVar9 = plStackX_20;
                  goto LAB_1408c6191;
                }
                *(undefined4 *)(plVar3 + 5) = 0x21df;
                plVar6 = (longlong *)FUN_142cd06a0(tstate,lVar10,classes_const_76_time);
                if (plVar6 == (longlong *)0x0) goto LAB_1408c33bd;
                plVar19 = (longlong *)FUN_142ce3540(plVar6,plVar9);
                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                }
                if (plVar19 == (longlong *)0x0) goto LAB_1408c33bd;
                iVar5 = FUN_140004970(plVar19);
                if (iVar5 == -1) {
                  plStackX_20 = *(longlong **)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                    (**(code **)(plVar19[1] + 0x30))(plVar19);
                  }
                  uVar22 = 0x21df;
                  plVar9 = plStackX_20;
                  goto LAB_1408c6191;
                }
                if (iVar5 == 1) {
                  if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                    (**(code **)(plVar19[1] + 0x30))(plVar19);
                  }
                  *(undefined4 *)(plVar3 + 5) = 0x21df;
                  plVar6 = (longlong *)
                           FUN_142cd06a0(tstate,plVar1,classes_const_1856__geetest_click_marcas);
                  if (plVar6 != (longlong *)0x0) {
                    plVar19 = (longlong *)FUN_142ce1890(plVar6,_DAT_142d9a260);
                    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                    }
                    if (plVar19 != (longlong *)0x0) goto LAB_1408c32c4;
                  }
                  goto LAB_1408c33bd;
                }
LAB_1408c32c4:
                iVar5 = FUN_140004970(plVar19);
                if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                  (**(code **)(plVar19[1] + 0x30))(plVar19);
                }
                if (iVar5 == -1) goto LAB_1408c33bd;
                if (iVar5 == 0) goto LAB_1408c33de;
                lVar10 = FUN_140a3b210();
                if (lVar10 == 0) {
                  FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                  uVar22 = 0x21e0;
                  plVar9 = plStackX_20;
                  goto LAB_1408c6191;
                }
                *(undefined4 *)(plVar3 + 5) = 0x21e0;
                plVar6 = (longlong *)FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep);
                if (plVar6 == (longlong *)0x0) {
                  plVar9 = *(longlong **)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  uVar22 = 0x21e0;
                  goto LAB_1408c6191;
                }
                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                }
                if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                    (iVar5 = Py_MakePendingCalls(), iVar5 < 0)) &&
                   (*(longlong *)(tstate + 0x70) != 0)) goto LAB_1408c33bd;
                if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                  PyEval_SaveThread();
                  PyEval_AcquireThread(tstate);
                }
                if (*(longlong *)(tstate + 0x90) != 0) {
                  *(undefined8 *)(tstate + 0x90) = 0;
                  plVar6 = *(longlong **)(tstate + 0x70);
                  uVar18 = FUN_142cd9e70(tstate);
                  *(undefined8 *)(tstate + 0x70) = uVar18;
                  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) &&
                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                  }
LAB_1408c33bd:
                  plVar9 = *(longlong **)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  uVar22 = 0x21df;
                  goto LAB_1408c6191;
                }
              } while( true );
            }
            plVar9 = *(longlong **)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            uVar22 = 0x21de;
          }
        }
      }
    }
  }
  goto LAB_1408c6191;
LAB_1408c3920:
  if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
    PyEval_SaveThread();
    PyEval_AcquireThread(tstate);
  }
  if (*(longlong *)(tstate + 0x90) != 0) {
    *(undefined8 *)(tstate + 0x90) = 0;
    plVar6 = *(longlong **)(tstate + 0x70);
    uVar18 = FUN_142cd9e70(tstate);
    *(undefined8 *)(tstate + 0x70) = uVar18;
    if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) &&
       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
LAB_1408c3983:
    plVar9 = *(longlong **)(tstate + 0x70);
    uVar22 = 0x21f0;
    *(undefined8 *)(tstate + 0x70) = 0;
    goto LAB_1408c6157;
  }
  goto LAB_1408c3811;
LAB_1408c4588:
  if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
    PyEval_SaveThread();
    PyEval_AcquireThread(tstate);
  }
  plVar7 = plVar13;
  if (*(longlong *)(tstate + 0x90) != 0) {
    *(undefined8 *)(tstate + 0x90) = 0;
    plVar6 = *(longlong **)(tstate + 0x70);
    plVar9 = (longlong *)FUN_142cd9e70(tstate);
    *(longlong **)(tstate + 0x70) = plVar9;
    if ((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) {
      *plVar6 = *plVar6 + -1;
      if (*plVar6 == 0) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      plVar9 = *(longlong **)(tstate + 0x70);
    }
LAB_1408c45e8:
    *(undefined8 *)(tstate + 0x70) = 0;
    plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2207);
    goto LAB_1408c6455;
  }
  goto LAB_1408c41f0;
code_r0x0001408c59a8:
  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  cVar4 = FUN_140008af0(tstate);
  if (cVar4 == '\0') {
LAB_1408c59cd:
    plVar9 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    uVar22 = 0x223c;
    goto LAB_1408c6191;
  }
  goto LAB_1408c56d7;
LAB_1408c6a81:
  FUN_142cd4900(tstate,&plStackX_20,classes_const_1847_respostas);
  FUN_1400048d0(tstate,plStackX_20);
  uVar22 = 0x21c5;
  plVar9 = plStackX_20;
LAB_1408c6191:
  plStackX_20 = plVar9;
  piVar25 = (int *)plStackX_20[5];
  if (piVar25 == (int *)0x0) {
    pcVar20 = (code *)FUN_142cd9160(plVar3,uVar22);
    bVar26 = pcVar20 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar25 + 6) == plVar3) goto LAB_1408c7cd6;
    pcVar20 = (code *)FUN_142cd9160(plVar3,uVar22);
    *(int **)(pcVar20 + 0x10) = piVar25;
    if (*piVar25 + 1 != 0) {
      *piVar25 = *piVar25 + 1;
    }
    bVar26 = pcVar20 == _Py_NoneStruct_exref;
  }
  plVar6 = (longlong *)plStackX_20[5];
  if (bVar26) {
    pcVar17 = (code *)0x0;
  }
  else {
    pcVar17 = pcVar20;
    if ((pcVar20 != (code *)0x0) && (*(int *)pcVar20 + 1 != 0)) {
      *(int *)pcVar20 = *(int *)pcVar20 + 1;
    }
  }
  plStackX_20[5] = (longlong)pcVar17;
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))();
  }
  if (((pcVar20 != (code *)0x0) && (-1 < *(int *)pcVar20)) &&
     (*(longlong *)pcVar20 = *(longlong *)pcVar20 + -1, *(longlong *)pcVar20 == 0)) {
    (**(code **)(*(longlong *)(pcVar20 + 8) + 0x30))(pcVar20);
  }
LAB_1408c7cd6:
  FUN_142cdb370(plVar3,&UNK_142d0b530,plVar1,plVar2,plStack_178,plStack_150,plStack_170,plStack_d0,0
                ,plStack_148,plStack_c8,plStack_100,plStack_f8,plStack_1a0,plStack_168,plStack_140,
                plStack_118,plStack_110,plStack_f0,plStack_108,plStack_128,plStack_e8,plStack_e0,
                plStack_1b0,plStack_198,plStack_190,plStack_120,plStack_158,plStack_160,plStack_138,
                plStack_d8,pcStack_1a8);
  plVar6 = _DAT_142dea770;
  if (plVar3 == _DAT_142dea770) {
    if ((-1 < (int)*_DAT_142dea770) && (*_DAT_142dea770 = *_DAT_142dea770 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))();
    }
    _DAT_142dea770 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  plVar3 = plStackX_20;
  plStackX_20 = (longlong *)0x0;
  if (((plStack_178 != (longlong *)0x0) && (-1 < (int)*plStack_178)) &&
     (*plStack_178 = *plStack_178 + -1, *plStack_178 == 0)) {
    (**(code **)(plStack_178[1] + 0x30))();
  }
  if (((plStack_150 != (longlong *)0x0) && (-1 < (int)*plStack_150)) &&
     (*plStack_150 = *plStack_150 + -1, *plStack_150 == 0)) {
    (**(code **)(plStack_150[1] + 0x30))();
  }
  if (((plStack_170 != (longlong *)0x0) && (-1 < (int)*plStack_170)) &&
     (*plStack_170 = *plStack_170 + -1, *plStack_170 == 0)) {
    (**(code **)(plStack_170[1] + 0x30))();
  }
  if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
     (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
    (**(code **)(plStack_d0[1] + 0x30))();
  }
  if (((plStack_148 != (longlong *)0x0) && (-1 < (int)*plStack_148)) &&
     (*plStack_148 = *plStack_148 + -1, *plStack_148 == 0)) {
    (**(code **)(plStack_148[1] + 0x30))();
  }
  if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
     (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
    (**(code **)(plStack_c8[1] + 0x30))();
  }
  if (((plStack_100 != (longlong *)0x0) && (-1 < (int)*plStack_100)) &&
     (*plStack_100 = *plStack_100 + -1, *plStack_100 == 0)) {
    (**(code **)(plStack_100[1] + 0x30))();
  }
  if (((plStack_f8 != (longlong *)0x0) && (-1 < (int)*plStack_f8)) &&
     (*plStack_f8 = *plStack_f8 + -1, *plStack_f8 == 0)) {
    (**(code **)(plStack_f8[1] + 0x30))();
  }
  if (((plStack_1a0 != (longlong *)0x0) && (-1 < (int)*plStack_1a0)) &&
     (*plStack_1a0 = *plStack_1a0 + -1, *plStack_1a0 == 0)) {
    (**(code **)(plStack_1a0[1] + 0x30))();
  }
  if (((plStack_168 != (longlong *)0x0) && (-1 < (int)*plStack_168)) &&
     (*plStack_168 = *plStack_168 + -1, *plStack_168 == 0)) {
    (**(code **)(plStack_168[1] + 0x30))();
  }
  if (((plStack_140 != (longlong *)0x0) && (-1 < (int)*plStack_140)) &&
     (*plStack_140 = *plStack_140 + -1, *plStack_140 == 0)) {
    (**(code **)(plStack_140[1] + 0x30))();
  }
  if (((plStack_118 != (longlong *)0x0) && (-1 < (int)*plStack_118)) &&
     (*plStack_118 = *plStack_118 + -1, *plStack_118 == 0)) {
    (**(code **)(plStack_118[1] + 0x30))();
  }
  if (((plStack_110 != (longlong *)0x0) && (-1 < (int)*plStack_110)) &&
     (*plStack_110 = *plStack_110 + -1, *plStack_110 == 0)) {
    (**(code **)(plStack_110[1] + 0x30))();
  }
  if (((plStack_f0 != (longlong *)0x0) && (-1 < (int)*plStack_f0)) &&
     (*plStack_f0 = *plStack_f0 + -1, *plStack_f0 == 0)) {
    (**(code **)(plStack_f0[1] + 0x30))();
  }
  if (((plStack_108 != (longlong *)0x0) && (-1 < (int)*plStack_108)) &&
     (*plStack_108 = *plStack_108 + -1, *plStack_108 == 0)) {
    (**(code **)(plStack_108[1] + 0x30))();
  }
  if (((plStack_128 != (longlong *)0x0) && (-1 < (int)*plStack_128)) &&
     (*plStack_128 = *plStack_128 + -1, *plStack_128 == 0)) {
    (**(code **)(plStack_128[1] + 0x30))();
  }
  if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
     (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
    (**(code **)(plStack_e8[1] + 0x30))();
  }
  if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
     (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
    (**(code **)(plStack_e0[1] + 0x30))();
  }
  if (((plStack_1b0 != (longlong *)0x0) && (-1 < (int)*plStack_1b0)) &&
     (*plStack_1b0 = *plStack_1b0 + -1, *plStack_1b0 == 0)) {
    (**(code **)(plStack_1b0[1] + 0x30))();
  }
  if (((plStack_198 != (longlong *)0x0) && (-1 < (int)*plStack_198)) &&
     (*plStack_198 = *plStack_198 + -1, *plStack_198 == 0)) {
    (**(code **)(plStack_198[1] + 0x30))();
  }
  if (((plStack_190 != (longlong *)0x0) && (-1 < (int)*plStack_190)) &&
     (*plStack_190 = *plStack_190 + -1, *plStack_190 == 0)) {
    (**(code **)(plStack_190[1] + 0x30))();
  }
  if (((plStack_120 != (longlong *)0x0) && (-1 < (int)*plStack_120)) &&
     (*plStack_120 = *plStack_120 + -1, *plStack_120 == 0)) {
    (**(code **)(plStack_120[1] + 0x30))();
  }
  if (((plStack_158 != (longlong *)0x0) && (-1 < (int)*plStack_158)) &&
     (*plStack_158 = *plStack_158 + -1, *plStack_158 == 0)) {
    (**(code **)(plStack_158[1] + 0x30))(plStack_158);
  }
  if (((plStack_160 != (longlong *)0x0) && (-1 < (int)*plStack_160)) &&
     (*plStack_160 = *plStack_160 + -1, *plStack_160 == 0)) {
    (**(code **)(plStack_160[1] + 0x30))(plStack_160);
  }
  if (((plStack_138 != (longlong *)0x0) && (-1 < (int)*plStack_138)) &&
     (*plStack_138 = *plStack_138 + -1, *plStack_138 == 0)) {
    (**(code **)(plStack_138[1] + 0x30))();
  }
  if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8)) &&
     (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
    (**(code **)(plStack_d8[1] + 0x30))();
  }
  if (((pcStack_1a8 != (code *)0x0) && (-1 < *(int *)pcStack_1a8)) &&
     (*(longlong *)pcStack_1a8 = *(longlong *)pcStack_1a8 + -1, *(longlong *)pcStack_1a8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_1a8 + 8) + 0x30))(pcStack_1a8);
  }
  plStackX_20 = plVar3;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))();
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong **)(tstate + 0x70) = plStackX_20;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
LAB_1408c33de:
  *(undefined4 *)(plVar3 + 5) = 0x21e1;
  plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1856__geetest_click_marcas);
  if (plVar6 == (longlong *)0x0) {
    plVar9 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    uVar22 = 0x21e1;
    goto LAB_1408c6191;
  }
  if (((plStack_100 != (longlong *)0x0) && (-1 < (int)*plStack_100)) &&
     (*plStack_100 = *plStack_100 + -1, *plStack_100 == 0)) {
    (**(code **)(plStack_100[1] + 0x30))();
  }
  iVar5 = FUN_142ce1250(plVar6,_DAT_142d9a260);
  plStack_100 = plVar6;
  if (iVar5 == -1) {
    plVar9 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    uVar22 = 0x21e2;
    goto LAB_1408c6191;
  }
  if (iVar5 == 1) {
    if (plStack_170 == (longlong *)0x0) {
      FUN_142cd4900(tstate,&plStackX_20,classes_const_1859_limpezas);
      FUN_1400048d0(tstate,plStackX_20);
      uVar22 = 0x21e3;
      plVar9 = plStackX_20;
      goto LAB_1408c6191;
    }
    plVar9 = (longlong *)FUN_142cbe350(plStack_170,1);
    if ((-1 < (int)*plStack_170) && (*plStack_170 = *plStack_170 + -1, *plStack_170 == 0)) {
      (**(code **)(plStack_170[1] + 0x30))(plStack_170);
    }
    cVar4 = Nuitka_helper_142ce0f60(plVar9,3);
    plStack_170 = plVar9;
    if (cVar4 == '\0') {
      plVar9 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
      puVar21 = classes_const_1861__s__geetest_ordem__sobraram__d_marcas_da_rodada_anterior___pedind
      ;
      if ((plVar9 == (longlong *)0x0) || (lVar10 = *plVar9, lVar10 == 0)) goto LAB_1408c6e7b;
      *(undefined4 *)(plVar3 + 5) = 0x21e9;
      lVar11 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
      if (lVar11 == 0) {
LAB_1408c5e1c:
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar22 = 0x21e9;
        goto LAB_1408c6191;
      }
      plVar9 = (longlong *)FUN_142cd9440(tstate,2);
      plVar9[3] = lVar11;
      iVar5 = (int)*plVar6 + 1;
      if (iVar5 != 0) {
        *(int *)plVar6 = iVar5;
      }
      plVar9[4] = (longlong)plVar6;
      plVar6 = (longlong *)FUN_142cbffc0(puVar21,plVar9);
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      if (plVar6 == (longlong *)0x0) goto LAB_1408c5e1c;
      *(undefined4 *)(plVar3 + 5) = 0x21e8;
      plVar9 = (longlong *)FUN_142ccfd60(tstate,lVar10,plVar6);
      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      if (plVar9 == (longlong *)0x0) {
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar22 = 0x21e8;
        goto LAB_1408c6191;
      }
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      *(undefined4 *)(plVar3 + 5) = 0x21ea;
      plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1862__geetest_refresh);
      if (plVar6 == (longlong *)0x0) {
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar22 = 0x21ea;
        goto LAB_1408c6191;
      }
      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      lVar10 = FUN_140a3b210(tstate);
      if (lVar10 == 0) {
        FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
        uVar22 = 0x21eb;
        plVar9 = plStackX_20;
        goto LAB_1408c6191;
      }
      *(undefined4 *)(plVar3 + 5) = 0x21eb;
      plVar6 = (longlong *)FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep);
      if (plVar6 == (longlong *)0x0) {
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar22 = 0x21eb;
        goto LAB_1408c6191;
      }
      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      goto LAB_1408c30a1;
    }
    uVar18 = FUN_1400776a0(classes_const_257_print);
    puVar21 = classes_const_1860__s__geetest_ordem__as_marcas_nao_limpam___desisto;
    *(undefined4 *)(plVar3 + 5) = 0x21e6;
    plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
    uVar22 = 0x21e6;
    if (plVar6 == (longlong *)0x0) {
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      goto LAB_1408c6191;
    }
    plVar9 = (longlong *)FUN_142cbff90(puVar21,plVar6);
    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
    if (plVar9 == (longlong *)0x0) {
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      goto LAB_1408c6191;
    }
    uVar22 = 0x21e5;
  }
  else {
LAB_1408c3631:
    plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1864__baixar_bytes);
    if (plVar6 == (longlong *)0x0) {
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      uVar22 = 0x21ee;
      goto LAB_1408c6191;
    }
    plVar9 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_211_get);
    if (plVar9 == (longlong *)0x0) {
      plStackX_20 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      uVar22 = 0x21ee;
      plVar9 = plStackX_20;
      goto LAB_1408c6191;
    }
    *(undefined4 *)(plVar3 + 5) = 0x21ee;
    plVar19 = (longlong *)
              FUN_142ccd7d0(tstate,plVar9,classes_const_1865___type____T____items_____foto_______);
    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    if (plVar19 == (longlong *)0x0) {
      plStackX_20 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
        (**(code **)(plVar6[1] + 0x30))(plVar6);
      }
      uVar22 = 0x21ee;
      plVar9 = plStackX_20;
      goto LAB_1408c6191;
    }
    *(undefined4 *)(plVar3 + 5) = 0x21ee;
    plVar9 = (longlong *)FUN_142ccfd60(tstate,plVar6,plVar19);
    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
    if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
      (**(code **)(plVar19[1] + 0x30))(plVar19);
    }
    if (plVar9 == (longlong *)0x0) {
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      uVar22 = 0x21ee;
      goto LAB_1408c6191;
    }
    if (((plStack_f8 != (longlong *)0x0) && (-1 < (int)*plStack_f8)) &&
       (*plStack_f8 = *plStack_f8 + -1, *plStack_f8 == 0)) {
      (**(code **)(plStack_f8[1] + 0x30))();
    }
    plVar6 = (longlong *)FUN_142cd8f90(tstate,0);
    if (((plStack_1a0 != (longlong *)0x0) && (-1 < (int)*plStack_1a0)) &&
       (*plStack_1a0 = *plStack_1a0 + -1, *plStack_1a0 == 0)) {
      (**(code **)(plStack_1a0[1] + 0x30))(plStack_1a0);
    }
    plVar19 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_211_get);
    plStack_1a0 = plVar6;
    plStack_f8 = plVar9;
    if (plVar19 == (longlong *)0x0) {
LAB_1408c744e:
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      uVar22 = 0x21f0;
      goto LAB_1408c6191;
    }
    *(undefined4 *)(plVar3 + 5) = 0x21f0;
    plVar7 = (longlong *)
             FUN_142cccf70(tstate,plVar19,classes_const_1866___type____T____items_____icones___);
    if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
      (**(code **)(plVar19[1] + 0x30))(plVar19);
    }
    if (plVar7 == (longlong *)0x0) goto LAB_1408c744e;
    iVar5 = FUN_140004970(plVar7);
    if (iVar5 == -1) {
      plStackX_20 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
        (**(code **)(plVar7[1] + 0x30))(plVar7);
      }
      uVar22 = 0x21f0;
      plVar9 = plStackX_20;
      goto LAB_1408c6191;
    }
    if (iVar5 != 1) {
      if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
        (**(code **)(plVar7[1] + 0x30))(plVar7);
      }
      plVar7 = (longlong *)FUN_142cd8f90(tstate,0);
    }
    plVar19 = (longlong *)FUN_140009850(tstate,plVar7);
    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))(plVar7);
    }
    if (plVar19 == (longlong *)0x0) goto LAB_1408c744e;
    plVar7 = (longlong *)0x0;
LAB_1408c3811:
    uVar22 = (undefined4)((ulonglong)in_stack_fffffffffffffd58 >> 0x20);
    if (*(code **)(plVar19[1] + 0xe0) != (code *)0x0) {
      plVar12 = (longlong *)(**(code **)(plVar19[1] + 0xe0))(plVar19);
      uVar22 = (undefined4)((ulonglong)in_stack_fffffffffffffd58 >> 0x20);
      if (plVar12 == (longlong *)0x0) goto LAB_1408c39c2;
      if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
        (**(code **)(plVar7[1] + 0x30))();
      }
      iVar5 = (int)*plVar12 + 1;
      if (iVar5 != 0) {
        *(int *)plVar12 = iVar5;
      }
      if (((plStack_168 != (longlong *)0x0) && (-1 < (int)*plStack_168)) &&
         (*plStack_168 = *plStack_168 + -1, *plStack_168 == 0)) {
        (**(code **)(plStack_168[1] + 0x30))();
      }
      *(undefined4 *)(plVar3 + 5) = 0x21f1;
      plVar13 = (longlong *)FUN_142cd12f0(tstate,plVar1,classes_const_1864__baixar_bytes);
      plVar7 = plVar12;
      plStack_168 = plVar12;
      if (plVar13 != (longlong *)0x0) {
        if (((plStack_140 != (longlong *)0x0) && (-1 < (int)*plStack_140)) &&
           (*plStack_140 = *plStack_140 + -1, *plStack_140 == 0)) {
          (**(code **)(plStack_140[1] + 0x30))(plStack_140);
        }
        iVar5 = FUN_140004970();
        plStack_140 = plVar13;
        if (iVar5 == -1) {
          uVar22 = 0x21f2;
          plVar9 = *(longlong **)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408c6157;
        }
        if (iVar5 != 0) {
          if (plVar6 == (longlong *)0x0) {
            FUN_142cd4900(tstate,&plStackX_20,classes_const_1867_icones);
            FUN_1400048d0(tstate,plStackX_20);
            uVar22 = 0x21f3;
            plVar9 = plStackX_20;
            goto LAB_1408c6157;
          }
          FUN_142cd7140(plVar6,plVar13);
        }
        if ((((*(ulonglong *)(tstate + 0x18) & 6) == 0) ||
            (iVar5 = Py_MakePendingCalls(), -1 < iVar5)) || (*(longlong *)(tstate + 0x70) == 0))
        goto LAB_1408c3920;
        goto LAB_1408c3983;
      }
      uVar22 = 0x21f1;
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      goto LAB_1408c6157;
    }
    Nuitka_helper_142ce5050(&UNK_142d0adb0,plVar19);
LAB_1408c39c2:
    plVar12 = *(longlong **)(tstate + 0x70);
    if (plVar12 != (longlong *)0x0) {
      cVar4 = FUN_140008d40(tstate,plVar12,*(undefined8 *)PyExc_StopIteration_exref);
      if (cVar4 == '\0') {
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar22 = 0x21f0;
        plStackX_20 = (longlong *)0x0;
        if (plVar7 != (longlong *)0x0) {
LAB_1408c6157:
          plStackX_20 = (longlong *)0x0;
          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
            (**(code **)(plVar7[1] + 0x30))(plVar7);
          }
        }
        if (((int)*plVar19 < 0) || (*plVar19 = *plVar19 + -1, *plVar19 != 0)) goto LAB_1408c6191;
        lVar10 = plVar19[1];
        goto LAB_1408c617f;
      }
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
        (**(code **)(plVar12[1] + 0x30))(plVar12);
      }
    }
    if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))(plVar7);
    }
    if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
      (**(code **)(plVar19[1] + 0x30))(plVar19);
    }
    iVar5 = FUN_140004970(plVar9);
    if (iVar5 == -1) {
LAB_1408c73f2:
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      uVar22 = 0x21f4;
      goto LAB_1408c6191;
    }
    cVar4 = iVar5 == 0;
    if (iVar5 != 0) {
      if (plVar6 == (longlong *)0x0) {
        FUN_142cd4900(tstate,&plStackX_20,classes_const_1867_icones);
        FUN_1400048d0(tstate,plStackX_20);
        uVar22 = 0x21f4;
        plVar9 = plStackX_20;
        goto LAB_1408c6191;
      }
      plVar19 = (longlong *)FUN_142cc1f90(tstate,plVar6);
      if (plVar19 == (longlong *)0x0) goto LAB_1408c73f2;
      cVar4 = Nuitka_helper_142ce2960(plVar19,2);
      if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
        (**(code **)(plVar19[1] + 0x30))(plVar19);
      }
    }
    if (cVar4 == '\0') {
      plVar19 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1869__achar_figuras_na_foto);
      if (plVar19 == (longlong *)0x0) {
        plVar6 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
      }
      else if (plVar6 == (longlong *)0x0) {
        if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
          (**(code **)(plVar19[1] + 0x30))(plVar19);
        }
        FUN_142cd4900(tstate,&plStackX_20,classes_const_1867_icones);
        FUN_1400048d0(tstate,plStackX_20);
        plVar6 = plStackX_20;
      }
      else {
        *(undefined4 *)(plVar3 + 5) = 0x21f9;
        plStack_a8 = plVar9;
        plStack_a0 = plVar6;
        plVar6 = (longlong *)FUN_142cc4ec0(tstate,plVar19,&plStack_a8);
        if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
          (**(code **)(plVar19[1] + 0x30))(plVar19);
        }
        if (plVar6 != (longlong *)0x0) {
          plVar9 = (longlong *)FUN_1400099f0(plVar6);
          if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
            (**(code **)(plVar6[1] + 0x30))(plVar6);
          }
          if (plVar9 != (longlong *)0x0) {
            uVar18 = CONCAT44(uVar22,2);
            plVar19 = (longlong *)FUN_140009d90(tstate,&plStackX_20,plVar9,0,uVar18);
            if (plVar19 == (longlong *)0x0) {
              plVar19 = (longlong *)0x0;
LAB_1408c702a:
              plVar7 = (longlong *)0x0;
            }
            else {
              uVar18 = CONCAT44((int)((ulonglong)uVar18 >> 0x20),2);
              plVar7 = (longlong *)FUN_140009d90(tstate,&plStackX_20,plVar9,1,uVar18);
              uVar22 = (undefined4)((ulonglong)uVar18 >> 0x20);
              if (plVar7 == (longlong *)0x0) goto LAB_1408c702a;
              cVar4 = FUN_140009c30(tstate,&plStackX_20,plVar9,2);
              if (cVar4 != '\0') {
                if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                }
                iVar5 = (int)*plVar19 + 1;
                if (iVar5 != 0) {
                  *(int *)plVar19 = iVar5;
                }
                if (((plStack_118 != (longlong *)0x0) && (-1 < (int)*plStack_118)) &&
                   (*plStack_118 = *plStack_118 + -1, *plStack_118 == 0)) {
                  (**(code **)(plStack_118[1] + 0x30))();
                }
                if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                  (**(code **)(plVar19[1] + 0x30))(plVar19);
                }
                iVar5 = (int)*plVar7 + 1;
                if (iVar5 != 0) {
                  *(int *)plVar7 = iVar5;
                }
                if (((plStack_110 != (longlong *)0x0) && (-1 < (int)*plStack_110)) &&
                   (*plStack_110 = *plStack_110 + -1, *plStack_110 == 0)) {
                  (**(code **)(plStack_110[1] + 0x30))();
                }
                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                }
                iVar5 = FUN_140004970(plVar19);
                plStack_118 = plVar19;
                plStack_110 = plVar7;
                if (iVar5 == -1) {
                  plVar9 = *(longlong **)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  uVar22 = 0x21fd;
                  goto LAB_1408c6191;
                }
                if (iVar5 == 0) {
                  uVar18 = FUN_1400776a0(classes_const_257_print);
                  puVar21 = classes_const_1871__s__geetest_ordem__nao_localizei_as_figuras;
                  uVar22 = 0x21fe;
                  *(undefined4 *)(plVar3 + 5) = 0x21fe;
                  plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
                  if (plVar6 == (longlong *)0x0) goto LAB_1408c5c12;
                  plVar9 = (longlong *)FUN_142cbff90(puVar21,plVar6);
                  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                  }
                  if (plVar9 == (longlong *)0x0) goto LAB_1408c5c12;
                  goto LAB_1408c5ede;
                }
                plVar6 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_211_get);
                if (plVar6 == (longlong *)0x0) {
LAB_1408c6f77:
                  plVar9 = *(longlong **)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  uVar22 = 0x2202;
                  goto LAB_1408c6191;
                }
                *(undefined4 *)(plVar3 + 5) = 0x2202;
                plVar9 = (longlong *)
                         FUN_142cccf70(tstate,plVar6,
                                       classes_const_1872___type____T____items_____caixa___);
                plStackX_18 = plVar9;
                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                }
                if (plVar9 == (longlong *)0x0) goto LAB_1408c6f77;
                iVar5 = FUN_140004970(plVar9);
                if (iVar5 == -1) {
                  plStackX_20 = *(longlong **)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  uVar22 = 0x2202;
                  plVar9 = plStackX_20;
                  goto LAB_1408c6191;
                }
                if (iVar5 != 1) {
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  plVar9 = (longlong *)FUN_142cd8040(tstate);
                  plStackX_18 = plVar9;
                }
                if (((plStack_f0 != (longlong *)0x0) && (-1 < (int)*plStack_f0)) &&
                   (*plStack_f0 = *plStack_f0 + -1, *plStack_f0 == 0)) {
                  (**(code **)(plStack_f0[1] + 0x30))(plStack_f0);
                }
                plVar6 = (longlong *)FUN_1400099f0(plVar7);
                plStack_f0 = plVar9;
                if (plVar6 == (longlong *)0x0) {
                  plVar9 = *(longlong **)(tstate + 0x70);
                  uVar22 = 0x2203;
                  *(undefined8 *)(tstate + 0x70) = 0;
                  goto LAB_1408c6191;
                }
                uVar18 = CONCAT44(uVar22,2);
                plVar7 = (longlong *)FUN_140009d90(tstate,&plStackX_20,plVar6,0,uVar18);
                if (plVar7 == (longlong *)0x0) {
                  plVar7 = (longlong *)0x0;
                }
                else {
                  in_stack_fffffffffffffd58 = CONCAT44((int)((ulonglong)uVar18 >> 0x20),2);
                  plVar8 = (longlong *)
                           FUN_140009d90(tstate,&plStackX_20,plVar6,1,in_stack_fffffffffffffd58);
                  if (plVar8 != (longlong *)0x0) {
                    cVar4 = FUN_140009c30(tstate,&plStackX_20,plVar6,2);
                    if (cVar4 == '\0') goto LAB_1408c6eba;
                    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                    }
                    iVar5 = (int)*plVar7 + 1;
                    if (iVar5 != 0) {
                      *(int *)plVar7 = iVar5;
                    }
                    if (((plStack_108 != (longlong *)0x0) && (-1 < (int)*plStack_108)) &&
                       (*plStack_108 = *plStack_108 + -1, *plStack_108 == 0)) {
                      (**(code **)(plStack_108[1] + 0x30))();
                    }
                    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    iVar5 = (int)*plVar8 + 1;
                    if (iVar5 != 0) {
                      *(int *)plVar8 = iVar5;
                    }
                    if (((plStack_128 != (longlong *)0x0) && (-1 < (int)*plStack_128)) &&
                       (*plStack_128 = *plStack_128 + -1, *plStack_128 == 0)) {
                      (**(code **)(plStack_128[1] + 0x30))();
                    }
                    if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                    }
                    plVar6 = (longlong *)FUN_142cd7b20(tstate,plStackX_18,classes_const_211_get);
                    puVar21 = classes_const_1873_w;
                    plStack_128 = plVar8;
                    plStack_108 = plVar7;
                    if (plVar6 == (longlong *)0x0) {
LAB_1408c6e96:
                      plVar9 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      uVar22 = 0x2204;
                      goto LAB_1408c6191;
                    }
                    *(undefined4 *)(plVar3 + 5) = 0x2204;
                    puStack_98 = puVar21;
                    plStack_90 = plVar7;
                    plVar9 = (longlong *)FUN_142cc4ec0(tstate,plVar6,&puStack_98);
                    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                    }
                    if (plVar9 == (longlong *)0x0) goto LAB_1408c6e96;
                    plVar6 = (longlong *)Nuitka_helper_142ce5200(plVar9);
                    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                    }
                    if (plVar6 == (longlong *)0x0) goto LAB_1408c6e96;
                    plVar9 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_228_max);
                    puVar21 = classes_const_1793_1_0;
                    if ((plVar9 == (longlong *)0x0) || (lVar10 = *plVar9, lVar10 == 0)) {
LAB_1408c6e7b:
                      PyErr_PrintEx(0);
                      Py_Exit(1);
                      pcVar20 = (code *)swi(3);
                      puVar21 = (undefined *)(*pcVar20)();
                      return puVar21;
                    }
                    plVar9 = (longlong *)Nuitka_helper_142ce5200(plVar7);
                    if (plVar9 == (longlong *)0x0) {
LAB_1408c6e48:
                      plStackX_20 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                      }
                      uVar22 = 0x2204;
                      plVar9 = plStackX_20;
                      goto LAB_1408c6191;
                    }
                    *(undefined4 *)(plVar3 + 5) = 0x2204;
                    puStack_88 = puVar21;
                    plStack_80 = plVar9;
                    plVar7 = (longlong *)FUN_142cc4ec0(tstate,lVar10,&puStack_88);
                    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                    }
                    if (plVar7 == (longlong *)0x0) goto LAB_1408c6e48;
                    plVar12 = (longlong *)FUN_142cc1540(plVar6,plVar7);
                    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                    }
                    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    if (plVar12 == (longlong *)0x0) goto LAB_1408c6e96;
                    if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
                       (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
                      (**(code **)(plStack_e8[1] + 0x30))();
                    }
                    plVar6 = (longlong *)FUN_142cd7b20(tstate,plStackX_18,classes_const_211_get);
                    puVar21 = classes_const_1874_h;
                    plStack_e8 = plVar12;
                    if (plVar6 == (longlong *)0x0) {
LAB_1408c6df7:
                      plVar9 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      uVar22 = 0x2205;
                      goto LAB_1408c6191;
                    }
                    *(undefined4 *)(plVar3 + 5) = 0x2205;
                    puStack_78 = puVar21;
                    plStack_70 = plVar8;
                    plVar9 = (longlong *)FUN_142cc4ec0(tstate,plVar6,&puStack_78);
                    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                    }
                    if (plVar9 == (longlong *)0x0) goto LAB_1408c6df7;
                    plVar6 = (longlong *)Nuitka_helper_142ce5200(plVar9);
                    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                    }
                    if (plVar6 == (longlong *)0x0) goto LAB_1408c6df7;
                    plVar9 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_228_max);
                    puVar21 = classes_const_1793_1_0;
                    if ((plVar9 == (longlong *)0x0) || (lVar10 = *plVar9, lVar10 == 0))
                    goto LAB_1408c6e7b;
                    plVar9 = (longlong *)Nuitka_helper_142ce5200(plVar8);
                    if (plVar9 == (longlong *)0x0) {
LAB_1408c6e15:
                      plStackX_20 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                      }
                      uVar22 = 0x2205;
                      plVar9 = plStackX_20;
                      goto LAB_1408c6191;
                    }
                    *(undefined4 *)(plVar3 + 5) = 0x2205;
                    puStack_68 = puVar21;
                    plStack_60 = plVar9;
                    plVar7 = (longlong *)FUN_142cc4ec0(tstate,lVar10,&puStack_68);
                    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                    }
                    if (plVar7 == (longlong *)0x0) goto LAB_1408c6e15;
                    plVar8 = (longlong *)FUN_142cc1540(plVar6,plVar7);
                    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                    }
                    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    if (plVar8 == (longlong *)0x0) goto LAB_1408c6df7;
                    if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
                       (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
                      (**(code **)(plStack_e0[1] + 0x30))();
                    }
                    plVar6 = (longlong *)FUN_142cd8f90(tstate,0);
                    if (((plStack_1b0 != (longlong *)0x0) && (-1 < (int)*plStack_1b0)) &&
                       (*plStack_1b0 = *plStack_1b0 + -1, *plStack_1b0 == 0)) {
                      (**(code **)(plStack_1b0[1] + 0x30))(plStack_1b0);
                    }
                    plVar19 = (longlong *)FUN_140009850(tstate,plVar19);
                    plStack_1b0 = plVar6;
                    plStack_e0 = plVar8;
                    if (plVar19 == (longlong *)0x0) {
                      plVar9 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      uVar22 = 0x2207;
                      goto LAB_1408c6191;
                    }
                    plVar7 = (longlong *)0x0;
LAB_1408c41f0:
                    if (*(code **)(plVar19[1] + 0xe0) != (code *)0x0) {
                      plVar13 = (longlong *)(**(code **)(plVar19[1] + 0xe0))(plVar19);
                      uVar22 = (undefined4)((ulonglong)in_stack_fffffffffffffd58 >> 0x20);
                      if (plVar13 == (longlong *)0x0) goto LAB_1408c4628;
                      if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                        (**(code **)(plVar7[1] + 0x30))(plVar7,plVar7);
                      }
                      plVar7 = (longlong *)FUN_1400099f0(plVar13);
                      if (plVar7 == (longlong *)0x0) {
                        plVar9 = *(longlong **)(tstate + 0x70);
                        plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2207);
                        *(undefined8 *)(tstate + 0x70) = 0;
                      }
                      else {
                        uVar18 = CONCAT44(uVar22,2);
                        plVar14 = (longlong *)FUN_140009d90(tstate,&plStackX_20,plVar7,0,uVar18);
                        if (plVar14 == (longlong *)0x0) {
                          plVar14 = (longlong *)0x0;
LAB_1408c6386:
                          plVar15 = (longlong *)0x0;
LAB_1408c6389:
                          plVar9 = plStackX_20;
                          plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2207);
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
                          if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
                             (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                            (**(code **)(plVar14[1] + 0x30))(plVar14);
                          }
                          if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
                             (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                            (**(code **)(plVar15[1] + 0x30))(plVar15);
                          }
                        }
                        else {
                          in_stack_fffffffffffffd58 = CONCAT44((int)((ulonglong)uVar18 >> 0x20),2);
                          plVar15 = (longlong *)
                                    FUN_140009d90(tstate,&plStackX_20,plVar7,1,
                                                  in_stack_fffffffffffffd58);
                          if (plVar15 == (longlong *)0x0) goto LAB_1408c6386;
                          cVar4 = FUN_140009c30(tstate,&plStackX_20,plVar7);
                          if (cVar4 == '\0') goto LAB_1408c6389;
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
                          iVar5 = (int)*plVar14 + 1;
                          if (iVar5 != 0) {
                            *(int *)plVar14 = iVar5;
                          }
                          if (((plStack_198 != (longlong *)0x0) && (-1 < (int)*plStack_198)) &&
                             (*plStack_198 = *plStack_198 + -1, *plStack_198 == 0)) {
                            (**(code **)(plStack_198[1] + 0x30))();
                          }
                          if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                            (**(code **)(plVar14[1] + 0x30))(plVar14);
                          }
                          iVar5 = (int)*plVar15 + 1;
                          if (iVar5 != 0) {
                            *(int *)plVar15 = iVar5;
                          }
                          if (((plStack_190 != (longlong *)0x0) && (-1 < (int)*plStack_190)) &&
                             (*plStack_190 = *plStack_190 + -1, *plStack_190 == 0)) {
                            (**(code **)(plStack_190[1] + 0x30))();
                          }
                          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                            (**(code **)(plVar15[1] + 0x30))(plVar15);
                          }
                          plVar9 = plStackX_18;
                          plStack_198 = plVar14;
                          plStack_190 = plVar15;
                          if (plVar6 == (longlong *)0x0) {
                            FUN_142cd4900(tstate,&plStackX_20,classes_const_1875_na_tela);
                            FUN_1400048d0(tstate,plStackX_20);
                            plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2208);
                            plVar9 = plStackX_20;
                          }
                          else if (plStackX_18 == (longlong *)0x0) {
                            FUN_142cd4900(tstate,&plStackX_20,classes_const_1876_caixa);
                            FUN_1400048d0(tstate,plStackX_20);
                            plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2208);
                            plVar9 = plStackX_20;
                          }
                          else {
                            plVar7 = (longlong *)
                                     FUN_142cd7b20(tstate,plStackX_18,classes_const_211_get);
                            if (plVar7 == (longlong *)0x0) {
LAB_1408c62b2:
                              plVar9 = *(longlong **)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                              plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2208);
                            }
                            else {
                              *(undefined4 *)(plVar3 + 5) = 0x2208;
                              plVar16 = (longlong *)
                                        FUN_142ccd7d0(tstate,plVar7,
                                                                                                            
                                                  classes_const_1877___type____T____items_____x___0__
                                                  );
                              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))();
                              }
                              if (plVar16 == (longlong *)0x0) goto LAB_1408c62b2;
                              plVar7 = (longlong *)Nuitka_helper_142ce5200();
                              if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0))
                              {
                                (**(code **)(plVar16[1] + 0x30))();
                              }
                              if (plVar7 == (longlong *)0x0) goto LAB_1408c62b2;
                              plVar14 = (longlong *)Nuitka_helper_142cc0520(plVar14,plVar12);
                              if (plVar14 == (longlong *)0x0) {
                                plStackX_20 = *(longlong **)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                                }
                                plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2208);
                                plVar9 = plStackX_20;
                              }
                              else {
                                lVar10 = FUN_142cbe7f0(plVar7,plVar14);
                                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                                }
                                if ((-1 < (int)*plVar14) &&
                                   (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                  (**(code **)(plVar14[1] + 0x30))(plVar14);
                                }
                                if (lVar10 == 0) {
                                  plVar9 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2208);
                                }
                                else {
                                  plVar7 = (longlong *)FUN_142cd9440(tstate,2);
                                  plVar7[3] = lVar10;
                                  plVar9 = (longlong *)
                                           FUN_142cd7b20(tstate,plVar9,classes_const_211_get);
                                  if (plVar9 != (longlong *)0x0) {
                                    *(undefined4 *)(plVar3 + 5) = 0x2209;
                                    plVar14 = (longlong *)
                                              FUN_142ccd7d0(tstate,plVar9,
                                                                                                                        
                                                  classes_const_1879___type____T____items_____y___0__
                                                  );
                                    if ((-1 < (int)*plVar9) &&
                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                    }
                                    if (plVar14 == (longlong *)0x0) goto LAB_1408c61e6;
                                    plVar9 = (longlong *)Nuitka_helper_142ce5200(plVar14);
                                    if ((-1 < (int)*plVar14) &&
                                       (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                      (**(code **)(plVar14[1] + 0x30))(plVar14);
                                    }
                                    if (plVar9 == (longlong *)0x0) goto LAB_1408c61e6;
                                    plVar14 = (longlong *)Nuitka_helper_142cc0520(plVar15,plVar8);
                                    if (plVar14 == (longlong *)0x0) {
                                      plStackX_20 = *(longlong **)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                      if ((-1 < (int)*plVar9) &&
                                         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                                      }
                                      goto LAB_1408c61f7;
                                    }
                                    lVar10 = FUN_142cbe7f0(plVar9,plVar14);
                                    if ((-1 < (int)*plVar9) &&
                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                    }
                                    if ((-1 < (int)*plVar14) &&
                                       (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                      (**(code **)(plVar14[1] + 0x30))(plVar14);
                                    }
                                    if (lVar10 == 0) goto LAB_1408c61e6;
                                    plVar7[4] = lVar10;
                                    FUN_142cd71a0(plVar6,plVar7);
                                    if ((((*(ulonglong *)(tstate + 0x18) & 6) == 0) ||
                                        (iVar5 = Py_MakePendingCalls(), -1 < iVar5)) ||
                                       (plVar9 = *(longlong **)(tstate + 0x70),
                                       plVar9 == (longlong *)0x0)) goto LAB_1408c4588;
                                    goto LAB_1408c45e8;
                                  }
LAB_1408c61e6:
                                  plStackX_20 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408c61f7:
                                  plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2209);
                                  plVar9 = plStackX_20;
                                  if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0))
                                  {
                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                    plVar9 = plStackX_20;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      goto LAB_1408c6455;
                    }
                    Nuitka_helper_142ce5050(&UNK_142d0adb0,plVar19);
LAB_1408c4628:
                    plVar9 = *(longlong **)(tstate + 0x70);
                    if (plVar9 != (longlong *)0x0) {
                      cVar4 = FUN_140008d40(tstate,plVar9,*(undefined8 *)PyExc_StopIteration_exref);
                      if (cVar4 == '\0') {
                        plVar9 = *(longlong **)(tstate + 0x70);
                        *(undefined8 *)(tstate + 0x70) = 0;
                        plStackX_20 = (longlong *)0x0;
                        plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2207);
                        plVar13 = plVar7;
                        if (plVar7 != (longlong *)0x0) {
LAB_1408c6455:
                          plStackX_20 = (longlong *)0x0;
                          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                            (**(code **)(plVar13[1] + 0x30))(plVar13);
                          }
                        }
                        if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                          (**(code **)(plVar19[1] + 0x30))(plVar19);
                        }
                        uVar22 = plStackX_18._0_4_;
                        goto LAB_1408c6191;
                      }
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                      }
                    }
                    if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                      (**(code **)(plVar19[1] + 0x30))(plVar19);
                    }
                    if (plStack_178 == (longlong *)0x0) {
                      FUN_142cd4900(tstate,&plStackX_20,classes_const_1847_respostas);
                      FUN_1400048d0(tstate,plStackX_20);
                      uVar22 = 0x220b;
                      plVar9 = plStackX_20;
                      goto LAB_1408c6191;
                    }
                    plVar9 = (longlong *)FUN_142cbe350(plStack_178,1);
                    if ((-1 < (int)*plStack_178) &&
                       (*plStack_178 = *plStack_178 + -1, *plStack_178 == 0)) {
                      (**(code **)(plStack_178[1] + 0x30))(plStack_178);
                    }
                    uVar18 = FUN_1400776a0(classes_const_257_print);
                    puVar21 = classes_const_1881__s__geetest_ordem__tocando__s___resposta__d_de__d;
                    *(undefined4 *)(plVar3 + 5) = 0x220d;
                    lVar10 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
                    plStack_178 = plVar9;
                    if (lVar10 == 0) {
                      plVar9 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      uVar22 = 0x220d;
                      goto LAB_1408c6191;
                    }
                    plVar19 = (longlong *)FUN_142cd9440(tstate,4);
                    plVar19[3] = lVar10;
                    if (plVar6 == (longlong *)0x0) {
                      FUN_142cd4880(tstate,&plStackX_20,classes_const_1875_na_tela);
                      FUN_1400048d0(tstate,plStackX_20);
                      plVar9 = plStackX_20;
LAB_1408c6d22:
                      uVar22 = 0x220d;
                      if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                        plStackX_20 = plVar9;
                        (**(code **)(plVar19[1] + 0x30))(plVar19);
                        plVar9 = plStackX_20;
                      }
                      goto LAB_1408c6191;
                    }
                    plVar7 = (longlong *)FUN_140009850(tstate,plVar6);
                    if (plVar7 == (longlong *)0x0) {
                      plVar9 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      goto LAB_1408c6d22;
                    }
                    plVar13 = (longlong *)FUN_142cd8f90(tstate,0);
                    plVar12 = (longlong *)(**(code **)(plVar7[1] + 0xe0))();
                    plVar8 = (longlong *)0x0;
                    if (plVar12 == (longlong *)0x0) {
                      plVar14 = (longlong *)0x0;
                      plVar15 = (longlong *)0x0;
                    }
                    else {
                      plStackX_18 = (longlong *)0x0;
                      plVar16 = plVar8;
                      plVar23 = (longlong *)0x0;
                      do {
                        uVar22 = (undefined4)((ulonglong)in_stack_fffffffffffffd58 >> 0x20);
                        plVar8 = plVar12;
                        if (((plStackX_18 != (longlong *)0x0) && (-1 < (int)*plStackX_18)) &&
                           (*plStackX_18 = *plStackX_18 + -1, *plStackX_18 == 0)) {
                          plVar8 = plStackX_18 + 1;
                          plStackX_18 = plVar12;
                          (**(code **)(*plVar8 + 0x30))();
                          plVar8 = plStackX_18;
                        }
                        plStackX_18 = plVar8;
                        plVar15 = (longlong *)FUN_1400099f0(plVar12);
                        if (plVar15 == (longlong *)0x0) {
                          plVar6 = *(longlong **)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          plVar8 = plVar16;
                          plVar14 = plVar23;
                          goto LAB_1408c6c84;
                        }
                        uVar27 = CONCAT44(uVar22,2);
                        plVar8 = (longlong *)FUN_140009d90(tstate,&plStackX_20,plVar15,0,uVar27);
                        if (plVar8 == (longlong *)0x0) {
                          plVar8 = (longlong *)0x0;
LAB_1408c650d:
                          plVar24 = (longlong *)0x0;
LAB_1408c6510:
                          plVar6 = plStackX_20;
                          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                            (**(code **)(plVar15[1] + 0x30))(plVar15);
                          }
                          if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                             (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                          }
                          plVar8 = plVar16;
                          plVar14 = plVar23;
                          if (((plVar24 != (longlong *)0x0) && (-1 < (int)*plVar24)) &&
                             (*plVar24 = *plVar24 + -1, *plVar24 == 0)) {
                            (**(code **)(plVar24[1] + 0x30))(plVar24);
                          }
                          goto LAB_1408c6c84;
                        }
                        in_stack_fffffffffffffd58 = CONCAT44((int)((ulonglong)uVar27 >> 0x20),2);
                        plVar14 = (longlong *)
                                  FUN_140009d90(tstate,&plStackX_20,plVar15,1,
                                                in_stack_fffffffffffffd58);
                        if (plVar14 == (longlong *)0x0) goto LAB_1408c650d;
                        cVar4 = FUN_140009c30(tstate,&plStackX_20,plVar15);
                        plVar24 = plVar14;
                        if (cVar4 == '\0') goto LAB_1408c6510;
                        if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                          (**(code **)(plVar15[1] + 0x30))(plVar15);
                        }
                        iVar5 = (int)*plVar8 + 1;
                        if (iVar5 != 0) {
                          *(int *)plVar8 = iVar5;
                        }
                        if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
                           (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                          (**(code **)(plVar16[1] + 0x30))();
                        }
                        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                          (**(code **)(plVar8[1] + 0x30))(plVar8);
                        }
                        iVar5 = (int)*plVar14 + 1;
                        if (iVar5 != 0) {
                          *(int *)plVar14 = iVar5;
                        }
                        if (((plVar23 != (longlong *)0x0) && (-1 < (int)*plVar23)) &&
                           (*plVar23 = *plVar23 + -1, *plVar23 == 0)) {
                          (**(code **)(plVar23[1] + 0x30))();
                        }
                        if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                          (**(code **)(plVar14[1] + 0x30))(plVar14);
                        }
                        lVar10 = PyNumber_Long(plVar8);
                        if (lVar10 == 0) {
                          plVar6 = *(longlong **)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          plVar12 = plStackX_18;
                          goto LAB_1408c6c84;
                        }
                        plVar15 = (longlong *)FUN_142cd9440(tstate,2);
                        plVar15[3] = lVar10;
                        lVar10 = PyNumber_Long(plVar14);
                        if (lVar10 == 0) {
                          plStackX_20 = *(longlong **)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          plVar12 = plStackX_18;
                          plVar6 = plStackX_20;
                          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                            (**(code **)(plVar15[1] + 0x30))(plVar15);
                            plVar12 = plStackX_18;
                            plVar6 = plStackX_20;
                          }
                          goto LAB_1408c6c84;
                        }
                        plVar15[4] = lVar10;
                        cVar4 = FUN_142cd71a0(plVar13,plVar15);
                        if ((cVar4 == '\0') || (cVar4 = FUN_140008af0(tstate), cVar4 == '\0')) {
                          plVar6 = *(longlong **)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          plVar12 = plStackX_18;
                          goto LAB_1408c6c84;
                        }
                        plVar12 = (longlong *)(**(code **)(plVar7[1] + 0xe0))(plVar7);
                        plVar16 = plVar8;
                        plVar23 = plVar14;
                        plVar15 = plStackX_18;
                      } while (plVar12 != (longlong *)0x0);
                    }
                    cVar4 = FUN_140009ec0(tstate,*(undefined8 *)PyExc_StopIteration_exref);
                    if (cVar4 == '\0') {
                      plVar6 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      plVar12 = plVar15;
LAB_1408c6c84:
                      plStackX_20 = plVar6;
                      plVar9 = plStackX_20;
                      if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                        (**(code **)(plVar7[1] + 0x30))();
                      }
                      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                        (**(code **)(plVar13[1] + 0x30))();
                      }
                      if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
                         (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                        (**(code **)(plVar12[1] + 0x30))(plVar12);
                      }
                      if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                        (**(code **)(plVar8[1] + 0x30))(plVar8);
                      }
                      if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
                         (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                        (**(code **)(plVar14[1] + 0x30))(plVar14);
                      }
                      goto LAB_1408c6d22;
                    }
                    iVar5 = (int)*plVar13 + 1;
                    if (iVar5 != 0) {
                      *(int *)plVar13 = iVar5;
                    }
                    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                      (**(code **)(plVar13[1] + 0x30))(plVar13);
                    }
                    if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
                       (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                      (**(code **)(plVar15[1] + 0x30))(plVar15);
                    }
                    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                    }
                    if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
                       (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                      (**(code **)(plVar14[1] + 0x30))(plVar14);
                    }
                    plVar19[4] = (longlong)plVar13;
                    iVar5 = (int)*plVar9 + 1;
                    if (iVar5 != 0) {
                      *(int *)plVar9 = iVar5;
                    }
                    plVar19[5] = (longlong)plVar9;
                    iVar5 = (int)*plVar2 + 1;
                    if (iVar5 != 0) {
                      *(int *)plVar2 = iVar5;
                    }
                    plVar19[6] = (longlong)plVar2;
                    plVar7 = (longlong *)FUN_142cbffc0(puVar21,plVar19);
                    if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                      (**(code **)(plVar19[1] + 0x30))(plVar19);
                    }
                    if (plVar7 == (longlong *)0x0) {
                      uVar22 = 0x220d;
                      goto LAB_1408c5c12;
                    }
                    *(undefined4 *)(plVar3 + 5) = 0x220c;
                    plVar19 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar7);
                    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    if (plVar19 == (longlong *)0x0) {
                      uVar22 = 0x220c;
                      goto LAB_1408c5c12;
                    }
                    if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                      (**(code **)(plVar19[1] + 0x30))(plVar19);
                    }
                    plVar19 = (longlong *)FUN_142cc1f90(tstate,plVar6);
                    if (plVar19 != (longlong *)0x0) {
                      plVar7 = (longlong *)FUN_142cc2e30(tstate,plVar19);
                      if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                        (**(code **)(plVar19[1] + 0x30))(plVar19);
                      }
                      if (plVar7 != (longlong *)0x0) {
                        plVar19 = (longlong *)FUN_140009850(tstate,plVar7);
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (plVar19 != (longlong *)0x0) {
                          plVar7 = (longlong *)(**(code **)(plVar19[1] + 0xe0))(plVar19);
                          plVar12 = (longlong *)0x0;
                          plVar8 = plVar12;
                          if (plVar7 != (longlong *)0x0) {
LAB_1408c4b80:
                            plVar12 = plVar7;
                            uVar22 = (undefined4)((ulonglong)in_stack_fffffffffffffd58 >> 0x20);
                            if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                               (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))();
                            }
                            iVar5 = (int)*plVar12 + 1;
                            if (iVar5 != 0) {
                              *(int *)plVar12 = iVar5;
                            }
                            if (((plStack_120 != (longlong *)0x0) && (-1 < (int)*plStack_120)) &&
                               (*plStack_120 = *plStack_120 + -1, *plStack_120 == 0)) {
                              (**(code **)(plStack_120[1] + 0x30))();
                            }
                            plVar7 = (longlong *)FUN_140008da0(tstate,plVar6,plVar12);
                            plStack_120 = plVar12;
                            if (plVar7 == (longlong *)0x0) {
LAB_1408c6723:
                              plStackX_20 = *(longlong **)(tstate + 0x70);
                              uVar22 = 0x2211;
                              *(undefined8 *)(tstate + 0x70) = 0;
                              goto LAB_1408c6bff;
                            }
                            plVar8 = (longlong *)FUN_1400099f0(plVar7);
                            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                            }
                            if (plVar8 == (longlong *)0x0) goto LAB_1408c6723;
                            uVar18 = CONCAT44(uVar22,2);
                            plVar7 = (longlong *)FUN_140009d90(tstate,&plStackX_20,plVar8,0,uVar18);
                            if (plVar7 == (longlong *)0x0) {
                              plVar7 = (longlong *)0x0;
LAB_1408c66ad:
                              plVar13 = (longlong *)0x0;
LAB_1408c66b0:
                              plVar6 = plStackX_20;
                              plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2211);
                              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                (**(code **)(plVar8[1] + 0x30))(plVar8);
                              }
                              if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                                 (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                              }
                              if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
                                 (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                (**(code **)(plVar13[1] + 0x30))(plVar13);
                              }
                              uVar22 = plStackX_18._0_4_;
                              plStackX_20 = plVar6;
                              goto LAB_1408c6bff;
                            }
                            in_stack_fffffffffffffd58 = CONCAT44((int)((ulonglong)uVar18 >> 0x20),2)
                            ;
                            plVar13 = (longlong *)
                                      FUN_140009d90(tstate,&plStackX_20,plVar8,1,
                                                    in_stack_fffffffffffffd58);
                            if (plVar13 == (longlong *)0x0) goto LAB_1408c66ad;
                            cVar4 = FUN_140009c30(tstate,&plStackX_20,plVar8,2);
                            if (cVar4 == '\0') goto LAB_1408c66b0;
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                            iVar5 = (int)*plVar7 + 1;
                            if (iVar5 != 0) {
                              *(int *)plVar7 = iVar5;
                            }
                            if (((plStack_158 != (longlong *)0x0) && (-1 < (int)*plStack_158)) &&
                               (*plStack_158 = *plStack_158 + -1, *plStack_158 == 0)) {
                              (**(code **)(plStack_158[1] + 0x30))();
                            }
                            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                            }
                            iVar5 = (int)*plVar13 + 1;
                            if (iVar5 != 0) {
                              *(int *)plVar13 = iVar5;
                            }
                            if (((plStack_160 != (longlong *)0x0) && (-1 < (int)*plStack_160)) &&
                               (*plStack_160 = *plStack_160 + -1, *plStack_160 == 0)) {
                              (**(code **)(plStack_160[1] + 0x30))();
                            }
                            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                              (**(code **)(plVar13[1] + 0x30))(plVar13);
                            }
                            *(undefined4 *)(plVar3 + 5) = 0x2217;
                            plVar8 = (longlong *)
                                     FUN_142cd06a0(tstate,plVar1,classes_const_1882__geetest_aberto)
                            ;
                            plStack_160 = plVar13;
                            plStack_158 = plVar7;
                            if (plVar8 == (longlong *)0x0) {
LAB_1408c66a0:
                              uVar22 = 0x2217;
                              goto LAB_1408c6bec;
                            }
                            iVar5 = FUN_140004970(plVar8);
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                            if (iVar5 == -1) goto LAB_1408c66a0;
                            if (iVar5 == 0) {
                              uVar18 = FUN_1400776a0(classes_const_257_print);
                              puVar21 = 
                              classes_const_1883__s__geetest_ordem__o_painel_fechou___parando_de_tocar
                              ;
                              *(undefined4 *)(plVar3 + 5) = 0x2219;
                              plVar7 = (longlong *)
                                       FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
                              if (plVar7 != (longlong *)0x0) {
                                plVar8 = (longlong *)FUN_142cbff90(puVar21,plVar7);
                                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                                }
                                if (plVar8 != (longlong *)0x0) {
                                  *(undefined4 *)(plVar3 + 5) = 0x2218;
                                  plVar7 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar8);
                                  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                  {
                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                  }
                                  if (plVar7 != (longlong *)0x0) {
                                    if ((-1 < (int)*plVar7) &&
                                       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                                    }
                                    goto LAB_1408c50a3;
                                  }
                                  uVar22 = 0x2218;
                                  goto LAB_1408c6bec;
                                }
                              }
                              uVar22 = 0x2219;
                              goto LAB_1408c6bec;
                            }
                            *(undefined4 *)(plVar3 + 5) = 0x221b;
                            plStack_58 = plVar7;
                            plStack_50 = plVar13;
                            plVar8 = (longlong *)
                                     FUN_142cd07f0(tstate,plVar1,classes_const_1765__tocar_ponto);
                            if (plVar8 == (longlong *)0x0) {
                              uVar22 = 0x221b;
                              goto LAB_1408c6bec;
                            }
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                            lVar10 = FUN_140a3b210(tstate);
                            if (lVar10 == 0) {
                              FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                              uVar22 = 0x221c;
                              goto LAB_1408c6bff;
                            }
                            plVar8 = (longlong *)FUN_142cd7b20(tstate,lVar10,classes_const_77_sleep)
                            ;
                            if (plVar8 == (longlong *)0x0) {
                              uVar22 = 0x221c;
                              goto LAB_1408c6bec;
                            }
                            plVar14 = (longlong *)
                                      FUN_142cd7b20(tstate,plVar1,
                                                    classes_const_1884__PAUSA_ENTRE_TOQUES);
                            if (plVar14 == (longlong *)0x0) {
                              plStackX_20 = *(longlong **)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                (**(code **)(plVar8[1] + 0x30))(plVar8);
                              }
                              uVar22 = 0x221c;
                              goto LAB_1408c6bff;
                            }
                            *(undefined4 *)(plVar3 + 5) = 0x221c;
                            plVar15 = (longlong *)FUN_142ccfd60(tstate,plVar8,plVar14);
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                            if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                              (**(code **)(plVar14[1] + 0x30))(plVar14);
                            }
                            if (plVar15 == (longlong *)0x0) {
                              uVar22 = 0x221c;
                              goto LAB_1408c6bec;
                            }
                            if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                              (**(code **)(plVar15[1] + 0x30))(plVar15);
                            }
                            *(undefined4 *)(plVar3 + 5) = 0x2223;
                            plVar8 = (longlong *)
                                     FUN_142cd06a0(tstate,plVar1,
                                                   classes_const_1856__geetest_click_marcas);
                            if (plVar8 == (longlong *)0x0) {
                              uVar22 = 0x2223;
                              goto LAB_1408c6bec;
                            }
                            if (((plStack_138 != (longlong *)0x0) && (-1 < (int)*plStack_138)) &&
                               (*plStack_138 = *plStack_138 + -1, *plStack_138 == 0)) {
                              (**(code **)(plStack_138[1] + 0x30))(plStack_138);
                            }
                            iVar5 = FUN_142ce0750(plVar8,_DAT_142d9a260);
                            plStack_138 = plVar8;
                            if (iVar5 != -1) {
                              if (iVar5 == 1) {
                                plVar14 = (longlong *)FUN_142cbe6d0(plVar12,_DAT_142d9a268);
                                if (plVar14 == (longlong *)0x0) goto LAB_1408c65f7;
                                iVar5 = FUN_142ce2e00(plVar8,plVar14);
                                if ((-1 < (int)*plVar14) &&
                                   (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                  (**(code **)(plVar14[1] + 0x30))(plVar14);
                                }
                                if (iVar5 == -1) goto LAB_1408c65f7;
                                if (iVar5 == 1) {
                                  *(undefined4 *)(plVar3 + 5) = 0x2225;
                                  plStack_48 = plVar7;
                                  plStack_40 = plVar13;
                                  plVar7 = (longlong *)
                                           FUN_142cd07f0(tstate,plVar1,
                                                         classes_const_1765__tocar_ponto);
                                  if (plVar7 != (longlong *)0x0) {
                                    if ((-1 < (int)*plVar7) &&
                                       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                                    }
                                    lVar10 = FUN_140a3b210(tstate);
                                    if (lVar10 == 0) {
                                      FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                      uVar22 = 0x2226;
                                    }
                                    else {
                                      plVar7 = (longlong *)
                                               FUN_142cd7b20(tstate,lVar10,classes_const_77_sleep);
                                      if (plVar7 == (longlong *)0x0) {
                                        uVar22 = 0x2226;
                                        goto LAB_1408c6bec;
                                      }
                                      plVar8 = (longlong *)
                                               FUN_142cd7b20(tstate,plVar1,
                                                             classes_const_1884__PAUSA_ENTRE_TOQUES)
                                      ;
                                      if (plVar8 != (longlong *)0x0) {
                                        *(undefined4 *)(plVar3 + 5) = 0x2226;
                                        plVar13 = (longlong *)FUN_142ccfd60(tstate,plVar7,plVar8);
                                        if ((-1 < (int)*plVar7) &&
                                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                                        }
                                        if ((-1 < (int)*plVar8) &&
                                           (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                          (**(code **)(plVar8[1] + 0x30))(plVar8);
                                        }
                                        if (plVar13 != (longlong *)0x0) {
                                          if ((-1 < (int)*plVar13) &&
                                             (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                            (**(code **)(plVar13[1] + 0x30))(plVar13);
                                          }
                                          goto LAB_1408c5054;
                                        }
                                        uVar22 = 0x2226;
                                        goto LAB_1408c6bec;
                                      }
                                      plStackX_20 = *(longlong **)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                      if ((-1 < (int)*plVar7) &&
                                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                        (**(code **)(plVar7[1] + 0x30))(plVar7);
                                      }
                                      uVar22 = 0x2226;
                                    }
                                    goto LAB_1408c6bff;
                                  }
                                  uVar22 = 0x2225;
                                  goto LAB_1408c6bec;
                                }
                              }
LAB_1408c5054:
                              cVar4 = FUN_140008af0(tstate);
                              if (cVar4 == '\0') {
                                uVar22 = 0x2210;
                                goto LAB_1408c6bec;
                              }
                              plVar7 = (longlong *)(**(code **)(plVar19[1] + 0xe0))(plVar19);
                              plVar8 = plVar12;
                              if (plVar7 == (longlong *)0x0) goto LAB_1408c5085;
                              goto LAB_1408c4b80;
                            }
LAB_1408c65f7:
                            uVar22 = 0x2224;
                            goto LAB_1408c6bec;
                          }
LAB_1408c5085:
                          cVar4 = FUN_140009ec0(tstate,*(undefined8 *)PyExc_StopIteration_exref);
                          if (cVar4 == '\0') {
                            uVar22 = 0x2210;
LAB_1408c6bec:
                            plStackX_20 = *(longlong **)(tstate + 0x70);
                            *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408c6bff:
                            plVar9 = plStackX_20;
                            plStackX_20 = (longlong *)0x0;
                            if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
                               (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                              (**(code **)(plVar12[1] + 0x30))(plVar12);
                            }
                            if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                              (**(code **)(plVar19[1] + 0x30))();
                            }
                            goto LAB_1408c6191;
                          }
LAB_1408c50a3:
                          if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
                             (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                            (**(code **)(plVar12[1] + 0x30))(plVar12);
                          }
                          if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                            (**(code **)(plVar19[1] + 0x30))();
                          }
                          lVar10 = FUN_140a3b210(tstate);
                          if (lVar10 == 0) {
                            FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                            uVar22 = 0x2227;
                            plVar9 = plStackX_20;
                            goto LAB_1408c6191;
                          }
                          *(undefined4 *)(plVar3 + 5) = 0x2227;
                          plVar19 = (longlong *)
                                    FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep,
                                                  *(undefined8 *)
                                                   (classes_const_1673___type____T____items____0_4__
                                                   + 0x18));
                          if (plVar19 == (longlong *)0x0) {
                            uVar22 = 0x2227;
                            goto LAB_1408c5c12;
                          }
                          if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                            (**(code **)(plVar19[1] + 0x30))(plVar19);
                          }
                          *(undefined4 *)(plVar3 + 5) = 0x222c;
                          plVar19 = (longlong *)
                                    FUN_142cd06a0(tstate,plVar1,
                                                  classes_const_1856__geetest_click_marcas);
                          if (plVar19 == (longlong *)0x0) {
                            uVar22 = 0x222c;
                            goto LAB_1408c5c12;
                          }
                          if (((plStack_138 != (longlong *)0x0) && (-1 < (int)*plStack_138)) &&
                             (*plStack_138 = *plStack_138 + -1, *plStack_138 == 0)) {
                            (**(code **)(plStack_138[1] + 0x30))(plStack_138);
                          }
                          iVar5 = FUN_142ce0750(plVar19,_DAT_142d9a260);
                          plStack_138 = plVar19;
                          if (iVar5 != -1) {
                            if (iVar5 != 1) {
LAB_1408c5441:
                              plVar6 = (longlong *)
                                       FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
                              if (plVar6 == (longlong *)0x0) {
LAB_1408c551d:
                                plStackX_20 = *(longlong **)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408c5530:
                                plVar6 = plStackX_20;
                                plStackX_20 = (longlong *)0x0;
                                piVar25 = *(int **)(tstate + 0xf8);
                                plStackX_18 = plVar6;
                                if ((piVar25 != (int *)0x0) && (*piVar25 + 1 != 0)) {
                                  *piVar25 = *piVar25 + 1;
                                }
                                if (plVar6[5] == 0) {
                                  plVar19 = (longlong *)FUN_142cd9160(plVar3,0x2235);
                                }
                                else {
                                  plVar19 = (longlong *)FUN_140008a80(plVar6[5],plVar3,0x2235);
                                }
                                Nuitka_helper_140008ab0(plVar6,plVar19);
                                if (((plVar19 != (longlong *)0x0) && (-1 < (int)*plVar19)) &&
                                   (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                                  (**(code **)(plVar19[1] + 0x30))(plVar19);
                                }
                                FUN_14005a9a0(tstate,&plStackX_18);
                                iVar5 = FUN_140008b90(tstate,*(undefined8 *)
                                                              (*(longlong *)(tstate + 0xf8) + 8),
                                                      *(undefined8 *)PyExc_Exception_exref);
                                if (iVar5 == 0) {
                                  cVar4 = FUN_142cded30(tstate,&plStackX_20);
                                  uVar22 = 0x2234;
                                  if (cVar4 != '\0') {
                                    uVar22 = 0;
                                  }
                                  lVar10 = plStackX_20[5];
                                  if ((lVar10 != 0) && (*(longlong **)(lVar10 + 0x18) == plVar3)) {
                                    *(undefined4 *)(plVar3 + 5) = *(undefined4 *)(lVar10 + 0x24);
                                  }
                                  plVar6 = *(longlong **)(tstate + 0xf8);
                                  *(int **)(tstate + 0xf8) = piVar25;
                                  plVar9 = plStackX_20;
LAB_1408c78f6:
                                  plStackX_20 = (longlong *)0x0;
                                  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) &&
                                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                    (**(code **)(plVar6[1] + 0x30))();
                                  }
                                  goto LAB_1408c6191;
                                }
                                plVar7 = *(longlong **)(tstate + 0xf8);
                                *(int **)(tstate + 0xf8) = piVar25;
                                if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                                   (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  lVar10 = plVar7[1];
LAB_1408c5616:
                                  (**(code **)(lVar10 + 0x30))(plVar7);
                                }
                              }
                              else {
                                plVar19 = (longlong *)
                                          FUN_142cd7b20(tstate,plVar6,
                                                        classes_const_338_execute_script);
                                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                                }
                                if (plVar19 == (longlong *)0x0) goto LAB_1408c551d;
                                plVar6 = (longlong *)
                                         FUN_142cd7b20(tstate,plVar1,
                                                       classes_const_1886__JS_GEETEST_NINE_CONFIRMAR
                                                      );
                                if (plVar6 == (longlong *)0x0) {
                                  plStackX_20 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  if ((-1 < (int)*plVar19) &&
                                     (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                                    (**(code **)(plVar19[1] + 0x30))(plVar19);
                                  }
                                  goto LAB_1408c5530;
                                }
                                *(undefined4 *)(plVar3 + 5) = 0x2235;
                                plVar7 = (longlong *)FUN_142ccfd60(tstate,plVar19,plVar6);
                                if ((-1 < (int)*plVar19) &&
                                   (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                                  (**(code **)(plVar19[1] + 0x30))(plVar19);
                                }
                                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                                }
                                if (plVar7 == (longlong *)0x0) goto LAB_1408c551d;
                                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  lVar10 = plVar7[1];
                                  goto LAB_1408c5616;
                                }
                              }
                              lVar10 = FUN_140a3b210(tstate);
                              if (lVar10 == 0) {
                                FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                uVar22 = 0x223a;
                                plVar9 = plStackX_20;
                                goto LAB_1408c6191;
                              }
                              *(undefined4 *)(plVar3 + 5) = 0x223a;
                              plVar6 = (longlong *)
                                       FUN_142cd06a0(tstate,lVar10,classes_const_76_time);
                              if (plVar6 != (longlong *)0x0) {
                                plVar19 = (longlong *)FUN_142cbe6d0(plVar6,classes_const_721_6);
                                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                                }
                                if (plVar19 != (longlong *)0x0) {
                                  if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8))
                                     && (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
                                    (**(code **)(plStack_d8[1] + 0x30))();
                                  }
                                  pcStack_1a8 = _Py_NoneStruct_exref;
                                  if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                    *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                                  }
                                  if (((pcVar20 != (code *)0x0) && (-1 < *(int *)pcVar20)) &&
                                     (*(longlong *)pcVar20 = *(longlong *)pcVar20 + -1,
                                     *(longlong *)pcVar20 == 0)) {
                                    (**(code **)(*(longlong *)(pcVar20 + 8) + 0x30))();
                                  }
LAB_1408c56d7:
                                  pcVar20 = pcStack_1a8;
                                  lVar10 = FUN_140a3b210(tstate);
                                  plStack_d8 = plVar19;
                                  if (lVar10 == 0) {
                                    FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                    uVar22 = 0x223c;
                                    plVar9 = plStackX_20;
                                    goto LAB_1408c6191;
                                  }
                                  *(undefined4 *)(plVar3 + 5) = 0x223c;
                                  plVar6 = (longlong *)
                                           FUN_142cd06a0(tstate,lVar10,classes_const_76_time);
                                  if (plVar6 == (longlong *)0x0) goto LAB_1408c59cd;
                                  plVar7 = (longlong *)FUN_142ce3540(plVar6,plVar19);
                                  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0))
                                  {
                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                  }
                                  if (plVar7 == (longlong *)0x0) goto LAB_1408c59cd;
                                  iVar5 = FUN_140004970(plVar7);
                                  if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0))
                                  {
                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                  }
                                  if (iVar5 == -1) goto LAB_1408c59cd;
                                  if (iVar5 != 0) {
                                    *(undefined4 *)(plVar3 + 5) = 0x223d;
                                    plVar6 = (longlong *)
                                             FUN_142cd06a0(tstate,plVar1,
                                                           classes_const_1839__geetest_click_na_tela
                                                          );
                                    if (plVar6 == (longlong *)0x0) {
LAB_1408c6a5f:
                                      plVar9 = *(longlong **)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                      uVar22 = 0x223d;
                                      goto LAB_1408c6191;
                                    }
                                    iVar5 = FUN_140004970(plVar6);
                                    if (iVar5 == -1) {
LAB_1408c6a28:
                                      plStackX_20 = *(longlong **)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                      if ((-1 < (int)*plVar6) &&
                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                      }
                                      uVar22 = 0x223d;
                                      plVar9 = plStackX_20;
                                      goto LAB_1408c6191;
                                    }
                                    bVar26 = iVar5 != 0;
                                    if ((-1 < (int)*plVar6) &&
                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                    }
                                    if (iVar5 == 0) {
                                      *(undefined4 *)(plVar3 + 5) = 0x223d;
                                      plVar6 = (longlong *)
                                               FUN_142cd06a0(tstate,plVar1,
                                                             classes_const_1882__geetest_aberto);
                                      if (plVar6 == (longlong *)0x0) goto LAB_1408c6a5f;
                                      iVar5 = FUN_140004970(plVar6);
                                      if (iVar5 == -1) goto LAB_1408c6a28;
                                      bVar26 = iVar5 != 0;
                                      if ((-1 < (int)*plVar6) &&
                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                      }
                                    }
                                    if (bVar26) {
                                      pcStack_1a8 = _Py_NoneStruct_exref;
                                      if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                        *(int *)_Py_NoneStruct_exref =
                                             *(int *)_Py_NoneStruct_exref + 1;
                                      }
                                      pcVar17 = pcStack_1a8;
                                      if (((pcVar20 != (code *)0x0) && (-1 < *(int *)pcVar20)) &&
                                         (*(longlong *)pcVar20 = *(longlong *)pcVar20 + -1,
                                         *(longlong *)pcVar20 == 0)) {
                                        (**(code **)(*(longlong *)(pcVar20 + 8) + 0x30))();
                                      }
                                    }
                                    else {
                                      if (pcStack_1a8 == (code *)0x0) {
                                        FUN_142cd4900(tstate,&plStackX_20,
                                                      classes_const_1887_fechado_desde);
                                        FUN_1400048d0(tstate,plStackX_20);
                                        uVar22 = 0x2240;
                                        plVar9 = plStackX_20;
                                        goto LAB_1408c6191;
                                      }
                                      if (pcStack_1a8 != _Py_NoneStruct_exref) {
                                        lVar10 = FUN_140a3b210();
                                        if (lVar10 == 0) {
                                          FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                          uVar22 = 0x2242;
                                          plVar9 = plStackX_20;
                                          goto LAB_1408c6191;
                                        }
                                        *(undefined4 *)(plVar3 + 5) = 0x2242;
                                        plVar6 = (longlong *)
                                                 FUN_142cd06a0(tstate,lVar10,classes_const_76_time);
                                        if (plVar6 != (longlong *)0x0) {
                                          plVar7 = (longlong *)FUN_142cc11d0(plVar6,pcStack_1a8);
                                          if ((-1 < (int)*plVar6) &&
                                             (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                            (**(code **)(plVar6[1] + 0x30))(plVar6);
                                          }
                                          if (plVar7 != (longlong *)0x0) {
                                            iVar5 = FUN_142ce05d0(plVar7,classes_const_1792_2_0);
                                            if ((-1 < (int)*plVar7) &&
                                               (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                                            }
                                            if (iVar5 != -1) {
                                              pcVar17 = pcStack_1a8;
                                              if (iVar5 != 1) goto LAB_1408c5969;
                                              uVar18 = FUN_1400776a0(classes_const_257_print);
                                              puVar21 = 
                                              classes_const_1888__s__geetest_ordem__resolvido;
                                              *(undefined4 *)(plVar3 + 5) = 0x2243;
                                              plVar6 = (longlong *)
                                                       FUN_142cd06a0(tstate,plVar1,
                                                                     classes_const_1346__tag);
                                              if (plVar6 != (longlong *)0x0) {
                                                plVar9 = (longlong *)FUN_142cbff90(puVar21,plVar6);
                                                if ((-1 < (int)*plVar6) &&
                                                   (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                }
                                                if (plVar9 != (longlong *)0x0) {
                                                  *(undefined4 *)(plVar3 + 5) = 0x2243;
                                                  plVar6 = (longlong *)
                                                           FUN_142ccfd60(tstate,uVar18,plVar9);
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  if (plVar6 != (longlong *)0x0) {
                                                    pcVar20 = _Py_TrueStruct_exref;
                                                    if ((-1 < (int)*plVar6) &&
                                                       (*plVar6 = *plVar6 + -1,
                                                       pcVar20 = _Py_TrueStruct_exref, *plVar6 == 0)
                                                       ) {
                                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                      pcVar20 = _Py_TrueStruct_exref;
                                                    }
                                                    goto LAB_1408c5cfc;
                                                  }
                                                }
                                              }
                                              plVar9 = *(longlong **)(tstate + 0x70);
                                              *(undefined8 *)(tstate + 0x70) = 0;
                                              uVar22 = 0x2243;
                                              goto LAB_1408c6191;
                                            }
                                          }
                                        }
                                        plVar9 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        uVar22 = 0x2242;
                                        goto LAB_1408c6191;
                                      }
                                      lVar10 = FUN_140a3b210();
                                      if (lVar10 == 0) {
                                        FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                        uVar22 = 0x2241;
                                        plVar9 = plStackX_20;
                                        goto LAB_1408c6191;
                                      }
                                      *(undefined4 *)(plVar3 + 5) = 0x2241;
                                      pcVar17 = (code *)FUN_142cd06a0(tstate,lVar10,
                                                                      classes_const_76_time);
                                      if (pcVar17 == (code *)0x0) {
                                        plVar9 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        uVar22 = 0x2241;
                                        goto LAB_1408c6191;
                                      }
                                      if ((-1 < *(int *)pcStack_1a8) &&
                                         (*(longlong *)pcStack_1a8 = *(longlong *)pcStack_1a8 + -1,
                                         *(longlong *)pcStack_1a8 == 0)) {
                                        (**(code **)(*(longlong *)(pcStack_1a8 + 8) + 0x30))
                                                  (pcStack_1a8);
                                      }
                                    }
LAB_1408c5969:
                                    pcStack_1a8 = pcVar17;
                                    lVar10 = FUN_140a3b210(tstate);
                                    if (lVar10 == 0) {
                                      FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                      uVar22 = 0x2245;
                                      plVar9 = plStackX_20;
                                    }
                                    else {
                                      *(undefined4 *)(plVar3 + 5) = 0x2245;
                                      plVar6 = (longlong *)
                                               FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep,
                                                             *(undefined8 *)
                                                              (
                                                  classes_const_1551___type____T____items____0_3__ +
                                                  0x18));
                                      if (plVar6 != (longlong *)0x0) goto code_r0x0001408c59a8;
                                      plVar9 = *(longlong **)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                      uVar22 = 0x2245;
                                    }
                                    goto LAB_1408c6191;
                                  }
                                  uVar18 = FUN_1400776a0(classes_const_257_print);
                                  puVar21 = 
                                  classes_const_1889__s__geetest_ordem__respondi_e_o_captcha_ficou__resposta__d_de__d_
                                  ;
                                  *(undefined4 *)(plVar3 + 5) = 0x2247;
                                  lVar10 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
                                  if (lVar10 != 0) {
                                    plVar6 = (longlong *)FUN_142cd9440(tstate,3);
                                    plVar6[3] = lVar10;
                                    iVar5 = (int)*plVar9 + 1;
                                    if (iVar5 != 0) {
                                      *(int *)plVar9 = iVar5;
                                    }
                                    plVar6[4] = (longlong)plVar9;
                                    iVar5 = (int)*plVar2 + 1;
                                    if (iVar5 != 0) {
                                      *(int *)plVar2 = iVar5;
                                    }
                                    plVar6[5] = (longlong)plVar2;
                                    plVar9 = (longlong *)FUN_142cbffc0(puVar21,plVar6);
                                    if ((-1 < (int)*plVar6) &&
                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                    }
                                    if (plVar9 != (longlong *)0x0) {
                                      *(undefined4 *)(plVar3 + 5) = 0x2246;
                                      plVar6 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar9);
                                      if ((-1 < (int)*plVar9) &&
                                         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                                      }
                                      if (plVar6 == (longlong *)0x0) {
                                        plVar9 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        uVar22 = 0x2246;
                                        goto LAB_1408c6191;
                                      }
                                      if ((-1 < (int)*plVar6) &&
                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                      }
                                      lVar10 = FUN_140a3b210(tstate);
                                      if (lVar10 == 0) {
                                        FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                        uVar22 = 0x2248;
                                        plVar9 = plStackX_20;
                                        goto LAB_1408c6191;
                                      }
                                      *(undefined4 *)(plVar3 + 5) = 0x2248;
                                      plVar6 = (longlong *)
                                               FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep);
                                      if (plVar6 == (longlong *)0x0) {
                                        plVar9 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        uVar22 = 0x2248;
                                        goto LAB_1408c6191;
                                      }
                                      if ((-1 < (int)*plVar6) &&
                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                      }
                                      cVar4 = FUN_140008af0(tstate);
                                      if (cVar4 == '\0') {
LAB_1408c5b3d:
                                        plVar9 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        uVar22 = 0x21c5;
                                        goto LAB_1408c6191;
                                      }
LAB_1408c30a1:
                                      plVar6 = plVar2;
                                      if (plStack_178 == (longlong *)0x0) goto LAB_1408c6a81;
                                      goto LAB_1408c2ce5;
                                    }
                                  }
                                  plVar9 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  uVar22 = 0x2247;
                                  goto LAB_1408c6191;
                                }
                              }
                              plVar9 = *(longlong **)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                              uVar22 = 0x223a;
                              goto LAB_1408c6191;
                            }
                            plVar7 = (longlong *)FUN_142cc1f90(tstate,plVar6);
                            if (plVar7 != (longlong *)0x0) {
                              iVar5 = FUN_142ce3b20(plVar19,plVar7);
                              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                              }
                              if (iVar5 != -1) {
                                if (iVar5 == 1) {
                                  uVar18 = FUN_1400776a0(classes_const_257_print);
                                  puVar21 = 
                                  classes_const_1885__s__geetest_ordem__ficaram__d_marcas_para__d_figuras___nao_vou_co
                                  ;
                                  *(undefined4 *)(plVar3 + 5) = 0x2230;
                                  lVar10 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
                                  if (lVar10 == 0) {
                                    plVar9 = *(longlong **)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                    uVar22 = 0x2230;
                                    goto LAB_1408c6191;
                                  }
                                  plVar7 = (longlong *)FUN_142cd9440(tstate,3);
                                  plVar7[3] = lVar10;
                                  iVar5 = (int)*plVar19 + 1;
                                  if (iVar5 != 0) {
                                    *(int *)plVar19 = iVar5;
                                  }
                                  plVar7[4] = (longlong)plVar19;
                                  lVar10 = FUN_142cc1f90(tstate,plVar6);
                                  if (lVar10 == 0) {
                                    uVar22 = 0x2230;
                                    plStackX_20 = *(longlong **)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                    plVar9 = plStackX_20;
                                    if ((-1 < (int)*plVar7) &&
                                       (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                                      plVar9 = plStackX_20;
                                    }
                                    goto LAB_1408c6191;
                                  }
                                  plVar7[5] = lVar10;
                                  plVar6 = (longlong *)FUN_142cbffc0(puVar21,plVar7);
                                  if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0))
                                  {
                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                  }
                                  if (plVar6 == (longlong *)0x0) {
                                    uVar22 = 0x2230;
                                  }
                                  else {
                                    *(undefined4 *)(plVar3 + 5) = 0x222e;
                                    plVar9 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar6);
                                    if ((-1 < (int)*plVar6) &&
                                       (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                                    }
                                    if (plVar9 == (longlong *)0x0) {
                                      uVar22 = 0x222e;
                                    }
                                    else {
                                      if ((-1 < (int)*plVar9) &&
                                         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                                      }
                                      *(undefined4 *)(plVar3 + 5) = 0x2231;
                                      plVar6 = (longlong *)
                                               FUN_142cd06a0(tstate,plVar1,
                                                             classes_const_1862__geetest_refresh);
                                      if (plVar6 == (longlong *)0x0) {
                                        uVar22 = 0x2231;
                                      }
                                      else {
                                        if ((-1 < (int)*plVar6) &&
                                           (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                          (**(code **)(plVar6[1] + 0x30))(plVar6);
                                        }
                                        lVar10 = FUN_140a3b210(tstate);
                                        if (lVar10 == 0) {
                                          FUN_142cde870(tstate,&plStackX_20,classes_const_76_time);
                                          uVar22 = 0x2232;
                                          plVar9 = plStackX_20;
                                          goto LAB_1408c6191;
                                        }
                                        *(undefined4 *)(plVar3 + 5) = 0x2232;
                                        plVar6 = (longlong *)
                                                 FUN_142cd12f0(tstate,lVar10,classes_const_77_sleep)
                                        ;
                                        if (plVar6 != (longlong *)0x0) {
                                          if ((-1 < (int)*plVar6) &&
                                             (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                            (**(code **)(plVar6[1] + 0x30))(plVar6);
                                          }
                                          goto LAB_1408c30a1;
                                        }
                                        uVar22 = 0x2232;
                                      }
                                    }
                                  }
                                  goto LAB_1408c5c12;
                                }
                                goto LAB_1408c5441;
                              }
                            }
                          }
                          uVar22 = 0x222d;
                          goto LAB_1408c5c12;
                        }
                      }
                    }
                    uVar22 = 0x2210;
LAB_1408c5c12:
                    plVar9 = *(longlong **)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x70) = 0;
                    goto LAB_1408c6191;
                  }
                }
                plVar8 = (longlong *)0x0;
LAB_1408c6eba:
                plVar9 = plStackX_20;
                plStackX_18 = (longlong *)CONCAT44(plStackX_18._4_4_,0x2203);
                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                }
                if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                   (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                }
                if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                   (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                uVar22 = plStackX_18._0_4_;
                goto LAB_1408c6191;
              }
            }
            plVar6 = plStackX_20;
            if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
            if (((plVar19 != (longlong *)0x0) && (-1 < (int)*plVar19)) &&
               (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
              (**(code **)(plVar19[1] + 0x30))(plVar19);
            }
            if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
               (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
              (**(code **)(plVar7[1] + 0x30))(plVar7);
            }
            goto LAB_1408c708d;
          }
        }
        plVar6 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
      }
LAB_1408c708d:
      plStackX_20 = (longlong *)0x0;
      piVar25 = *(int **)(tstate + 0xf8);
      if ((piVar25 != (int *)0x0) && (*piVar25 + 1 != 0)) {
        *piVar25 = *piVar25 + 1;
      }
      plStackX_18 = plVar6;
      if (plVar6[5] == 0) {
        plVar9 = (longlong *)FUN_142cd9160(plVar3,0x21f9);
      }
      else {
        plVar9 = (longlong *)FUN_140008a80(plVar6[5],plVar3,0x21f9);
      }
      Nuitka_helper_140008ab0(plVar6,plVar9);
      if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      FUN_14005a9a0(tstate,&plStackX_18);
      iVar5 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                            *(undefined8 *)PyExc_Exception_exref);
      if (iVar5 == 0) {
        cVar4 = FUN_142cded30(tstate,&plStackX_20);
        uVar22 = 0x21f8;
        if (cVar4 != '\0') {
          uVar22 = 0;
        }
        lVar10 = plStackX_20[5];
        plVar9 = plStackX_20;
        if ((lVar10 != 0) && (*(longlong **)(lVar10 + 0x18) == plVar3)) {
          *(undefined4 *)(plVar3 + 5) = *(undefined4 *)(lVar10 + 0x24);
        }
      }
      else {
        plVar6 = *(longlong **)(tstate + 0xf8);
        iVar5 = (int)*plVar6 + 1;
        if (iVar5 != 0) {
          *(int *)plVar6 = iVar5;
        }
        uVar18 = FUN_1400776a0(classes_const_257_print);
        puVar21 = classes_const_1870__s__geetest_ordem__falhei_ao_pontuar___s;
        *(undefined4 *)(plVar3 + 5) = 0x21fb;
        lVar10 = FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
        if (lVar10 != 0) {
          plVar9 = (longlong *)FUN_142cd9440(tstate,2);
          plVar9[3] = lVar10;
          iVar5 = (int)*plVar6 + 1;
          if (iVar5 != 0) {
            *(int *)plVar6 = iVar5;
          }
          plVar9[4] = (longlong)plVar6;
          plVar19 = (longlong *)FUN_142cbffc0(puVar21,plVar9);
          if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
            (**(code **)(plVar9[1] + 0x30))(plVar9);
          }
          if (plVar19 != (longlong *)0x0) {
            *(undefined4 *)(plVar3 + 5) = 0x21fb;
            plVar9 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar19);
            if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
              (**(code **)(plVar19[1] + 0x30))(plVar19);
            }
            if (plVar9 != (longlong *)0x0) {
LAB_1408c7824:
              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              pcVar20 = _Py_FalseStruct_exref;
              if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
                *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
              }
              if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                (**(code **)(plVar6[1] + 0x30))(plVar6);
              }
              plVar3 = *(longlong **)(tstate + 0xf8);
              *(int **)(tstate + 0xf8) = piVar25;
              if (((plVar3 != (longlong *)0x0) && (-1 < (int)*plVar3)) &&
                 (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
                (**(code **)(plVar3[1] + 0x30))();
              }
              goto LAB_1408c7883;
            }
          }
        }
        plVar9 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        plStackX_20 = (longlong *)0x0;
        uVar22 = 0x21fb;
        if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, uVar22 = 0x21fb, *plVar6 == 0)) {
          (**(code **)(plVar6[1] + 0x30))(plVar6);
        }
      }
      plStackX_20 = (longlong *)0x0;
      plVar19 = *(longlong **)(tstate + 0xf8);
      *(int **)(tstate + 0xf8) = piVar25;
      if (((plVar19 == (longlong *)0x0) || ((int)*plVar19 < 0)) ||
         (*plVar19 = *plVar19 + -1, *plVar19 != 0)) goto LAB_1408c6191;
      lVar10 = plVar19[1];
LAB_1408c617f:
      (**(code **)(lVar10 + 0x30))(plVar19);
      goto LAB_1408c6191;
    }
    uVar18 = FUN_1400776a0(classes_const_257_print);
    puVar21 = classes_const_1868__s__geetest_ordem__nao_consegui_baixar_as_imagens;
    uVar22 = 0x21f5;
    *(undefined4 *)(plVar3 + 5) = 0x21f5;
    plVar6 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1346__tag);
    if (plVar6 == (longlong *)0x0) {
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      goto LAB_1408c6191;
    }
    plVar9 = (longlong *)FUN_142cbff90(puVar21,plVar6);
    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
    if (plVar9 == (longlong *)0x0) {
      plVar9 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      goto LAB_1408c6191;
    }
  }
LAB_1408c5ede:
  *(undefined4 *)(plVar3 + 5) = uVar22;
  plVar6 = (longlong *)FUN_142ccfd60(tstate,uVar18,plVar9);
  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if (plVar6 == (longlong *)0x0) {
    plVar9 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    goto LAB_1408c6191;
  }
  pcVar20 = _Py_FalseStruct_exref;
  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, pcVar20 = _Py_FalseStruct_exref, *plVar6 == 0)
     ) {
    lVar10 = plVar6[1];
LAB_1408c5cf2:
    (**(code **)(lVar10 + 0x30))(plVar6);
    pcVar20 = _Py_FalseStruct_exref;
  }
LAB_1408c5cfc:
  if (*(int *)pcVar20 + 1 != 0) {
    *(int *)pcVar20 = *(int *)pcVar20 + 1;
  }
LAB_1408c7883:
  FUN_140008990(tstate);
LAB_1408c7932:
  if (((plStack_178 != (longlong *)0x0) && (-1 < (int)*plStack_178)) &&
     (*plStack_178 = *plStack_178 + -1, *plStack_178 == 0)) {
    (**(code **)(plStack_178[1] + 0x30))(plStack_178);
  }
  if (((plStack_150 != (longlong *)0x0) && (-1 < (int)*plStack_150)) &&
     (*plStack_150 = *plStack_150 + -1, *plStack_150 == 0)) {
    (**(code **)(plStack_150[1] + 0x30))();
  }
  if (((plStack_170 != (longlong *)0x0) && (-1 < (int)*plStack_170)) &&
     (*plStack_170 = *plStack_170 + -1, *plStack_170 == 0)) {
    (**(code **)(plStack_170[1] + 0x30))();
  }
  if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
     (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
    (**(code **)(plStack_d0[1] + 0x30))();
  }
  if (((plStack_148 != (longlong *)0x0) && (-1 < (int)*plStack_148)) &&
     (*plStack_148 = *plStack_148 + -1, *plStack_148 == 0)) {
    (**(code **)(plStack_148[1] + 0x30))();
  }
  if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
     (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
    (**(code **)(plStack_c8[1] + 0x30))();
  }
  if (((plStack_100 != (longlong *)0x0) && (-1 < (int)*plStack_100)) &&
     (*plStack_100 = *plStack_100 + -1, *plStack_100 == 0)) {
    (**(code **)(plStack_100[1] + 0x30))();
  }
  if (((plStack_f8 != (longlong *)0x0) && (-1 < (int)*plStack_f8)) &&
     (*plStack_f8 = *plStack_f8 + -1, *plStack_f8 == 0)) {
    (**(code **)(plStack_f8[1] + 0x30))();
  }
  if (((plStack_1a0 != (longlong *)0x0) && (-1 < (int)*plStack_1a0)) &&
     (*plStack_1a0 = *plStack_1a0 + -1, *plStack_1a0 == 0)) {
    (**(code **)(plStack_1a0[1] + 0x30))();
  }
  if (((plStack_168 != (longlong *)0x0) && (-1 < (int)*plStack_168)) &&
     (*plStack_168 = *plStack_168 + -1, *plStack_168 == 0)) {
    (**(code **)(plStack_168[1] + 0x30))();
  }
  if (((plStack_140 != (longlong *)0x0) && (-1 < (int)*plStack_140)) &&
     (*plStack_140 = *plStack_140 + -1, *plStack_140 == 0)) {
    (**(code **)(plStack_140[1] + 0x30))();
  }
  if (((plStack_118 != (longlong *)0x0) && (-1 < (int)*plStack_118)) &&
     (*plStack_118 = *plStack_118 + -1, *plStack_118 == 0)) {
    (**(code **)(plStack_118[1] + 0x30))();
  }
  if (((plStack_110 != (longlong *)0x0) && (-1 < (int)*plStack_110)) &&
     (*plStack_110 = *plStack_110 + -1, *plStack_110 == 0)) {
    (**(code **)(plStack_110[1] + 0x30))();
  }
  if (((plStack_f0 != (longlong *)0x0) && (-1 < (int)*plStack_f0)) &&
     (*plStack_f0 = *plStack_f0 + -1, *plStack_f0 == 0)) {
    (**(code **)(plStack_f0[1] + 0x30))();
  }
  if (((plStack_108 != (longlong *)0x0) && (-1 < (int)*plStack_108)) &&
     (*plStack_108 = *plStack_108 + -1, *plStack_108 == 0)) {
    (**(code **)(plStack_108[1] + 0x30))();
  }
  if (((plStack_128 != (longlong *)0x0) && (-1 < (int)*plStack_128)) &&
     (*plStack_128 = *plStack_128 + -1, *plStack_128 == 0)) {
    (**(code **)(plStack_128[1] + 0x30))();
  }
  if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
     (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
    (**(code **)(plStack_e8[1] + 0x30))();
  }
  if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
     (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
    (**(code **)(plStack_e0[1] + 0x30))();
  }
  if (((plStack_1b0 != (longlong *)0x0) && (-1 < (int)*plStack_1b0)) &&
     (*plStack_1b0 = *plStack_1b0 + -1, *plStack_1b0 == 0)) {
    (**(code **)(plStack_1b0[1] + 0x30))(plStack_1b0);
  }
  if (((plStack_198 != (longlong *)0x0) && (-1 < (int)*plStack_198)) &&
     (*plStack_198 = *plStack_198 + -1, *plStack_198 == 0)) {
    (**(code **)(plStack_198[1] + 0x30))(plStack_198);
  }
  if (((plStack_190 != (longlong *)0x0) && (-1 < (int)*plStack_190)) &&
     (*plStack_190 = *plStack_190 + -1, *plStack_190 == 0)) {
    (**(code **)(plStack_190[1] + 0x30))(plStack_190);
  }
  if (((plStack_120 != (longlong *)0x0) && (-1 < (int)*plStack_120)) &&
     (*plStack_120 = *plStack_120 + -1, *plStack_120 == 0)) {
    (**(code **)(plStack_120[1] + 0x30))();
  }
  if (((plStack_158 != (longlong *)0x0) && (-1 < (int)*plStack_158)) &&
     (*plStack_158 = *plStack_158 + -1, *plStack_158 == 0)) {
    (**(code **)(plStack_158[1] + 0x30))(plStack_158);
  }
  if (((plStack_160 != (longlong *)0x0) && (-1 < (int)*plStack_160)) &&
     (*plStack_160 = *plStack_160 + -1, *plStack_160 == 0)) {
    (**(code **)(plStack_160[1] + 0x30))(plStack_160);
  }
  if (((plStack_138 != (longlong *)0x0) && (-1 < (int)*plStack_138)) &&
     (*plStack_138 = *plStack_138 + -1, *plStack_138 == 0)) {
    (**(code **)(plStack_138[1] + 0x30))();
  }
  if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8)) &&
     (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
    (**(code **)(plStack_d8[1] + 0x30))();
  }
  if (((pcStack_1a8 != (code *)0x0) && (-1 < *(int *)pcStack_1a8)) &&
     (*(longlong *)pcStack_1a8 = *(longlong *)pcStack_1a8 + -1, *(longlong *)pcStack_1a8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_1a8 + 8) + 0x30))(pcStack_1a8);
  }
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((int)*plVar2 < 0) {
    return pcVar20;
  }
  *plVar2 = *plVar2 + -1;
  if (*plVar2 != 0) {
    return pcVar20;
  }
  (**(code **)(plVar2[1] + 0x30))(plVar2);
  return pcVar20;
}

