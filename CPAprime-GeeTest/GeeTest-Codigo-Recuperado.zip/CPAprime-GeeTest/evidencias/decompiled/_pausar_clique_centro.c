
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _pausar_clique_centro(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong lVar2;
  int *piVar3;
  longlong *plVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  longlong *plVar9;
  code *pcVar10;
  code *pcVar11;
  longlong lVar12;
  bool bVar13;
  longlong lStackX_18;
  int *piStackX_20;
  
  plVar5 = _DAT_142dea720;
  plVar1 = (longlong *)*python_pars;
  if (_DAT_142dea720 == (longlong *)0x0) {
LAB_1408b63e3:
    _DAT_142dea720 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9c20,_DAT_142f2aaf0,0x10);
  }
  else if ((1 < *_DAT_142dea720) || (_DAT_142dea720[2] != 0)) {
    if ((_DAT_142dea720 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea720 && (*_DAT_142dea720 = *_DAT_142dea720 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408b63e3;
  }
  plVar5 = _DAT_142dea720;
  Nuitka_helper_140008a00(tstate,_DAT_142dea720);
  plVar9 = (longlong *)
           FUN_142cc1aa0(tstate,plVar1,classes_const_177_clique_centro_ativo,_Py_FalseStruct_exref);
  if (plVar9 == (longlong *)0x0) {
    lVar12 = *(longlong *)(tstate + 0x70);
    plVar9 = (longlong *)0x0;
    *(undefined8 *)(tstate + 0x70) = 0;
    pcVar11 = (code *)0x2060;
  }
  else {
    cVar6 = FUN_142ce4bf0(tstate,plVar1,classes_const_177_clique_centro_ativo,_Py_FalseStruct_exref)
    ;
    if (cVar6 != '\0') {
LAB_1408b678c:
      FUN_140008990(tstate);
      iVar8 = (int)*plVar9;
      iVar7 = iVar8 + 1;
      if (iVar7 != 0) {
        *(int *)plVar9 = iVar7;
        iVar8 = iVar7;
      }
      if ((-1 < iVar8) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      if ((int)*plVar1 < 0) {
        return (undefined *)plVar9;
      }
      *plVar1 = *plVar1 + -1;
      if (*plVar1 != 0) {
        return (undefined *)plVar9;
      }
      (**(code **)(plVar1[1] + 0x30))(plVar1);
      return (undefined *)plVar9;
    }
    lVar12 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    piStackX_20 = *(int **)(tstate + 0xf8);
    lStackX_18 = 0;
    if ((piStackX_20 != (int *)0x0) && (*piStackX_20 + 1 != 0)) {
      *piStackX_20 = *piStackX_20 + 1;
    }
    piVar3 = *(int **)(lVar12 + 0x28);
    pcVar11 = (code *)FUN_142cd9160(plVar5,0x2062);
    if (piVar3 != (int *)0x0) {
      *(int **)(pcVar11 + 0x10) = piVar3;
      if (*piVar3 + 1 != 0) {
        *piVar3 = *piVar3 + 1;
      }
    }
    plVar4 = *(longlong **)(lVar12 + 0x28);
    pcVar10 = (code *)0x0;
    if (((pcVar11 != _Py_NoneStruct_exref) && (pcVar10 = pcVar11, pcVar11 != (code *)0x0)) &&
       (*(int *)pcVar11 + 1 != 0)) {
      *(int *)pcVar11 = *(int *)pcVar11 + 1;
    }
    *(code **)(lVar12 + 0x28) = pcVar10;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
       (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
      (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
    }
    plVar4 = *(longlong **)(tstate + 0xf8);
    *(longlong *)(tstate + 0xf8) = lVar12;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    if (iVar7 != 0) {
      plVar5 = *(longlong **)(tstate + 0xf8);
      *(int **)(tstate + 0xf8) = piStackX_20;
      if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
         (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))();
      }
      goto LAB_1408b678c;
    }
    cVar6 = FUN_142cded30(tstate,&lStackX_18);
    lVar12 = lStackX_18;
    pcVar11 = (code *)0x2061;
    if (cVar6 != '\0') {
      pcVar11 = (code *)0x0;
    }
    lVar2 = *(longlong *)(lStackX_18 + 0x28);
    if ((lVar2 != 0) && (*(longlong **)(lVar2 + 0x18) == plVar5)) {
      *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar2 + 0x24);
    }
    plVar4 = *(longlong **)(tstate + 0xf8);
    lStackX_18 = 0;
    *(int **)(tstate + 0xf8) = piStackX_20;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
  }
  pcVar10 = (code *)0x0;
  piVar3 = *(int **)(lVar12 + 0x28);
  lStackX_18 = lVar12;
  if (piVar3 == (int *)0x0) {
    pcVar11 = (code *)FUN_142cd9160(plVar5,pcVar11);
    bVar13 = pcVar11 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar3 + 6) == plVar5) goto LAB_1408b66aa;
    pcVar11 = (code *)FUN_142cd9160(plVar5,pcVar11);
    *(int **)(pcVar11 + 0x10) = piVar3;
    if (*piVar3 + 1 != 0) {
      *piVar3 = *piVar3 + 1;
    }
    bVar13 = pcVar11 == _Py_NoneStruct_exref;
  }
  plVar4 = *(longlong **)(lStackX_18 + 0x28);
  if (((!bVar13) && (pcVar10 = pcVar11, pcVar11 != (code *)0x0)) && (*(int *)pcVar11 + 1 != 0)) {
    *(int *)pcVar11 = *(int *)pcVar11 + 1;
  }
  *(code **)(lStackX_18 + 0x28) = pcVar10;
  if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)
     ) {
    (**(code **)(plVar4[1] + 0x30))();
  }
  if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
     (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
    (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
  }
LAB_1408b66aa:
  FUN_142cdb370(plVar5,&UNK_142d0ae3c,plVar1,plVar9);
  plVar4 = _DAT_142dea720;
  if (plVar5 == _DAT_142dea720) {
    if ((-1 < (int)*_DAT_142dea720) && (*_DAT_142dea720 = *_DAT_142dea720 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    _DAT_142dea720 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar12 = lStackX_18;
  lStackX_18 = 0;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  lStackX_18 = lVar12;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

