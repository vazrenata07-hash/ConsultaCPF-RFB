
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _grad(undefined *tstate,undefined *self,undefined **python_pars)

{
  int *piVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  code *pcVar8;
  code *pcVar9;
  undefined *puVar10;
  int iVar11;
  undefined8 uVar12;
  longlong *plVar13;
  bool bVar14;
  undefined1 auStack_118 [32];
  longlong *plStack_f8;
  longlong *plStack_f0;
  undefined8 uStack_e8;
  longlong lStack_d8;
  longlong *plStack_d0;
  longlong *plStack_c8;
  longlong lStack_c0;
  longlong *plStack_b8;
  undefined *puStack_b0;
  longlong *plStack_a8;
  undefined *puStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_88;
  undefined *puStack_80;
  int *piStack_78;
  longlong *plStack_70;
  undefined *puStack_68;
  longlong *plStack_60;
  undefined *puStack_58;
  int *piStack_50;
  ulonglong uStack_48;
  
  plVar2 = _DAT_142dea750;
  uStack_48 = _DAT_142d9a1c0 ^ (ulonglong)auStack_118;
  plVar4 = (longlong *)*python_pars;
  plVar7 = (longlong *)0x0;
  plStack_90 = (longlong *)0x0;
  plStack_d0 = (longlong *)0x0;
  lStack_d8 = 0;
  plStack_c8 = plVar4;
  puStack_a0 = self;
  if (_DAT_142dea750 == (longlong *)0x0) {
LAB_1408bf804:
    _DAT_142dea750 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9ba0,_DAT_142f2aaf0,0x28);
  }
  else if ((1 < *_DAT_142dea750) || (_DAT_142dea750[2] != 0)) {
    if ((_DAT_142dea750 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea750 && (*_DAT_142dea750 = *_DAT_142dea750 + -1, *plVar2 == 0)))) {
      (**(code **)(plVar2[1] + 0x30))(plVar2);
    }
    goto LAB_1408bf804;
  }
  plVar2 = _DAT_142dea750;
  Nuitka_helper_140008a00(tstate,_DAT_142dea750);
  puVar10 = classes_const_1820___type____T____items____3__3__;
  piVar1 = _DAT_142d9a260;
  lVar6 = *(longlong *)(*(longlong *)(self + 0xe0) + 0x10);
  if (lVar6 == 0) {
    FUN_142cd4880(tstate,&lStack_d8,classes_const_1786__cv2);
    FUN_1400048d0(tstate,lStack_d8);
    uVar12 = 0x2141;
    plVar13 = (longlong *)0x0;
  }
  else {
    uVar12 = 0x2141;
    *(undefined4 *)(plVar2 + 5) = 0x2141;
    piStack_78 = piVar1;
    puStack_80 = puVar10;
    plStack_88 = plVar4;
    plVar3 = (longlong *)FUN_142cd0950(tstate,lVar6,classes_const_1819_GaussianBlur,&plStack_88);
    if (plVar3 == (longlong *)0x0) {
      lStack_d8 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      plVar13 = plVar7;
    }
    else {
      plVar7 = plVar3;
      plStack_b8 = plVar3;
      if (*(longlong *)(*(longlong *)(self + 0xe0) + 0x10) == 0) {
        FUN_142cd4880(tstate,&lStack_d8,classes_const_1786__cv2);
        FUN_1400048d0(tstate,lStack_d8);
        uVar12 = 0x2142;
        plVar13 = plStack_d0;
      }
      else {
        plVar4 = (longlong *)
                 FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(self + 0xe0) + 0x10),
                               classes_const_1821_Sobel);
        if (plVar4 == (longlong *)0x0) {
          lStack_d8 = *(longlong *)(tstate + 0x70);
          uVar12 = 0x2142;
          *(undefined8 *)(tstate + 0x70) = 0;
          plVar13 = plStack_d0;
          plVar4 = plStack_c8;
        }
        else {
          plVar5 = (longlong *)FUN_142cd9440(tstate,4);
          iVar11 = (int)*plVar3 + 1;
          if (iVar11 != 0) {
            *(int *)plVar3 = iVar11;
          }
          plVar5[3] = (longlong)plVar3;
          if (*(longlong *)(*(longlong *)(puStack_a0 + 0xe0) + 0x10) == 0) {
            FUN_142cd4880(tstate,&lStack_d8,classes_const_1786__cv2);
            FUN_1400048d0(tstate,lStack_d8);
          }
          else {
            lVar6 = FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(puStack_a0 + 0xe0) + 0x10),
                                  classes_const_1822_CV_64F);
            if (lVar6 != 0) {
              plVar5[4] = lVar6;
              piVar1 = _DAT_142d9a268;
              if (*_DAT_142d9a268 + 1 != 0) {
                *_DAT_142d9a268 = *_DAT_142d9a268 + 1;
              }
              plVar5[5] = (longlong)piVar1;
              piVar1 = _DAT_142d9a260;
              if (*_DAT_142d9a260 + 1 != 0) {
                *_DAT_142d9a260 = *_DAT_142d9a260 + 1;
              }
              plVar5[6] = (longlong)piVar1;
              plVar7 = (longlong *)
                       FUN_142cd3be0(tstate,
                                     classes_const_1823___type____D____keys_____ksize_____values____3__
                                    );
              uVar12 = 0x2142;
              *(undefined4 *)(plVar2 + 5) = 0x2142;
              plStack_98 = (longlong *)FUN_140001330(tstate,plVar4,plVar5,plVar7);
              if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                (**(code **)(plVar4[1] + 0x30))(plVar4);
              }
              if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                (**(code **)(plVar5[1] + 0x30))(plVar5);
              }
              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                (**(code **)(plVar7[1] + 0x30))(plVar7);
              }
              puVar10 = puStack_a0;
              if (plStack_98 == (longlong *)0x0) {
LAB_1408bfeb5:
                lStack_d8 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                plVar7 = plStack_b8;
                plVar13 = plStack_d0;
                plVar4 = plStack_c8;
                goto LAB_1408bfed1;
              }
              plStack_90 = plStack_98;
              if (*(longlong *)(*(longlong *)(puStack_a0 + 0xe0) + 0x10) == 0) {
                FUN_142cd4880(tstate,&lStack_d8,classes_const_1786__cv2);
                FUN_1400048d0(tstate,lStack_d8);
                uVar12 = 0x2143;
                plVar7 = plStack_b8;
                plVar13 = plStack_d0;
                plVar4 = plStack_c8;
                goto LAB_1408bfed1;
              }
              plVar4 = (longlong *)
                       FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(puStack_a0 + 0xe0) + 0x10),
                                     classes_const_1821_Sobel);
              if (plVar4 == (longlong *)0x0) {
                uVar12 = 0x2143;
                goto LAB_1408bfeb5;
              }
              plVar5 = (longlong *)FUN_142cd9440(tstate,4);
              iVar11 = (int)*plVar3 + 1;
              if (iVar11 != 0) {
                *(int *)plVar3 = iVar11;
              }
              plVar5[3] = (longlong)plVar3;
              if (*(longlong *)(*(longlong *)(puVar10 + 0xe0) + 0x10) == 0) {
                FUN_142cd4880(tstate,&lStack_d8,classes_const_1786__cv2);
                FUN_1400048d0(tstate,lStack_d8);
              }
              else {
                lVar6 = FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(puVar10 + 0xe0) + 0x10),
                                      classes_const_1822_CV_64F);
                if (lVar6 != 0) {
                  plVar5[4] = lVar6;
                  piVar1 = _DAT_142d9a260;
                  if (*_DAT_142d9a260 + 1 != 0) {
                    *_DAT_142d9a260 = *_DAT_142d9a260 + 1;
                  }
                  plVar5[5] = (longlong)piVar1;
                  piVar1 = _DAT_142d9a268;
                  if (*_DAT_142d9a268 + 1 != 0) {
                    *_DAT_142d9a268 = *_DAT_142d9a268 + 1;
                  }
                  plVar5[6] = (longlong)piVar1;
                  plVar7 = (longlong *)
                           FUN_142cd3be0(tstate,
                                         classes_const_1823___type____D____keys_____ksize_____values____3__
                                        );
                  uVar12 = 0x2143;
                  *(undefined4 *)(plVar2 + 5) = 0x2143;
                  plStack_a8 = (longlong *)FUN_140001330(tstate,plVar4,plVar5,plVar7);
                  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                    (**(code **)(plVar4[1] + 0x30))(plVar4);
                  }
                  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                    (**(code **)(plVar5[1] + 0x30))(plVar5);
                  }
                  if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                  }
                  puVar10 = puStack_a0;
                  plVar13 = plStack_a8;
                  if (plStack_a8 == (longlong *)0x0) goto LAB_1408bfeb5;
                  plStack_d0 = plStack_a8;
                  if (*(longlong *)(*(longlong *)(puStack_a0 + 0xe0) + 0x10) == 0) {
LAB_1408bfc6e:
                    FUN_142cd4880(tstate,&lStack_d8,classes_const_1786__cv2);
                    FUN_1400048d0(tstate,lStack_d8);
                  }
                  else {
                    plVar4 = (longlong *)
                             FUN_142cd7b20(tstate,*(longlong *)
                                                   (*(longlong *)(puStack_a0 + 0xe0) + 0x10),
                                           classes_const_1824_addWeighted);
                    if (plVar4 != (longlong *)0x0) {
                      lVar6 = *(longlong *)(*(longlong *)(puVar10 + 0xe0) + 0x10);
                      if (lVar6 != 0) {
                        uVar12 = 0x2144;
                        *(undefined4 *)(plVar2 + 5) = 0x2144;
                        plVar7 = (longlong *)
                                 FUN_142cd12f0(tstate,lVar6,classes_const_1825_convertScaleAbs,
                                               plStack_98);
                        puVar10 = classes_const_213_0_5;
                        if (plVar7 == (longlong *)0x0) {
                          lStack_d8 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
                          if (((int)*plVar4 < 0) || (*plVar4 = *plVar4 + -1, *plVar4 != 0))
                          goto LAB_1408bfc8f;
                          (**(code **)(plVar4[1] + 0x30))(plVar4);
                          plVar7 = plStack_b8;
                          plVar4 = plStack_c8;
                        }
                        else {
                          lVar6 = *(longlong *)(*(longlong *)(puStack_a0 + 0xe0) + 0x10);
                          if (lVar6 == 0) {
                            if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                              (**(code **)(plVar4[1] + 0x30))(plVar4);
                            }
                            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                            }
                            FUN_142cd4880(tstate,&lStack_d8,classes_const_1786__cv2);
                            FUN_1400048d0(tstate,lStack_d8);
                            uVar12 = 0x2145;
                            plVar7 = plStack_b8;
                            plVar4 = plStack_c8;
                          }
                          else {
                            *(undefined4 *)(plVar2 + 5) = 0x2145;
                            puStack_b0 = puVar10;
                            plVar5 = (longlong *)
                                     FUN_142cd12f0(tstate,lVar6,classes_const_1825_convertScaleAbs,
                                                   plVar13);
                            puVar10 = classes_const_213_0_5;
                            if (plVar5 != (longlong *)0x0) {
                              puStack_68 = puStack_b0;
                              piStack_50 = _DAT_142d9a260;
                              *(undefined4 *)(plVar2 + 5) = 0x2144;
                              puStack_58 = puVar10;
                              plStack_70 = plVar7;
                              plStack_60 = plVar5;
                              lStack_c0 = FUN_142cc7b00(tstate,plVar4,&plStack_70);
                              if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                                (**(code **)(plVar4[1] + 0x30))(plVar4);
                              }
                              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                              }
                              if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                                (**(code **)(plVar5[1] + 0x30))(plVar5);
                              }
                              if (lStack_c0 != 0) {
                                FUN_140008990(tstate);
                                if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
                                  (**(code **)(plVar3[1] + 0x30))(plVar3);
                                }
                                if ((-1 < (int)*plStack_98) &&
                                   (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
                                  (**(code **)(plStack_90[1] + 0x30))();
                                }
                                if ((-1 < (int)*plStack_a8) &&
                                   (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
                                  (**(code **)(plStack_d0[1] + 0x30))();
                                }
                                if ((-1 < (int)*plStack_c8) &&
                                   (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
                                  (**(code **)(plStack_c8[1] + 0x30))();
                                }
                                goto LAB_1408c00e2;
                              }
                              goto LAB_1408bfeb5;
                            }
                            lStack_d8 = *(longlong *)(tstate + 0x70);
                            *(undefined8 *)(tstate + 0x70) = 0;
                            if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                              (**(code **)(plVar4[1] + 0x30))(plVar4);
                            }
                            if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))(plVar7);
                            }
                            uVar12 = 0x2145;
                            plVar7 = plStack_b8;
                            plVar13 = plStack_d0;
                            plVar4 = plStack_c8;
                          }
                        }
                        goto LAB_1408bfed1;
                      }
                      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                        (**(code **)(plVar4[1] + 0x30))(plVar4);
                      }
                      goto LAB_1408bfc6e;
                    }
                    lStack_d8 = *(longlong *)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x70) = 0;
                  }
LAB_1408bfc8f:
                  uVar12 = 0x2144;
                  plVar7 = plStack_b8;
                  plVar4 = plStack_c8;
                  goto LAB_1408bfed1;
                }
                lStack_d8 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
              }
              uVar12 = 0x2143;
              if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                (**(code **)(plVar4[1] + 0x30))(plVar4);
              }
              plVar7 = plStack_b8;
              plVar13 = plStack_d0;
              plVar4 = plStack_c8;
              if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, plVar7 = plVar3, *plVar5 == 0)) {
                (**(code **)(plVar5[1] + 0x30))(plVar5);
                plVar7 = plStack_b8;
                plVar13 = plStack_d0;
                plVar4 = plStack_c8;
              }
              goto LAB_1408bfed1;
            }
            lStack_d8 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
          }
          uVar12 = 0x2142;
          if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
            (**(code **)(plVar4[1] + 0x30))(plVar4);
          }
          plVar13 = plStack_d0;
          plVar4 = plStack_c8;
          if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
            (**(code **)(plVar5[1] + 0x30))(plVar5);
            plVar13 = plStack_d0;
            plVar4 = plStack_c8;
          }
        }
      }
    }
  }
LAB_1408bfed1:
  piVar1 = *(int **)(lStack_d8 + 0x28);
  if (piVar1 == (int *)0x0) {
    pcVar8 = (code *)FUN_142cd9160(plVar2,uVar12);
    bVar14 = pcVar8 == _Py_NoneStruct_exref;
LAB_1408bff1b:
    plVar3 = *(longlong **)(lStack_d8 + 0x28);
    if (bVar14) {
      pcVar9 = (code *)0x0;
    }
    else {
      pcVar9 = pcVar8;
      if ((pcVar8 != (code *)0x0) && (*(int *)pcVar8 + 1 != 0)) {
        *(int *)pcVar8 = *(int *)pcVar8 + 1;
      }
    }
    *(code **)(lStack_d8 + 0x28) = pcVar9;
    if (((plVar3 != (longlong *)0x0) && (-1 < (int)*plVar3)) &&
       (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
      (**(code **)(plVar3[1] + 0x30))();
    }
    if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
       (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
      (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
    }
  }
  else if (*(longlong **)(piVar1 + 6) != plVar2) {
    pcVar8 = (code *)FUN_142cd9160(plVar2,uVar12);
    *(int **)(pcVar8 + 0x10) = piVar1;
    if (*piVar1 + 1 != 0) {
      *piVar1 = *piVar1 + 1;
    }
    bVar14 = pcVar8 == _Py_NoneStruct_exref;
    goto LAB_1408bff1b;
  }
  plVar5 = plStack_90;
  uStack_e8 = *(undefined8 *)(puStack_a0 + 0xe0);
  plStack_f8 = plStack_90;
  plStack_f0 = plVar13;
  FUN_142cdb370(plVar2,&UNK_142d0c288,plVar4,plVar7);
  plVar3 = _DAT_142dea750;
  if (plVar2 == _DAT_142dea750) {
    if ((-1 < (int)*_DAT_142dea750) && (*_DAT_142dea750 = *_DAT_142dea750 + -1, *plVar3 == 0)) {
      (**(code **)(plVar3[1] + 0x30))();
    }
    _DAT_142dea750 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar6 = lStack_d8;
  lStack_d8 = 0;
  if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)
     ) {
    (**(code **)(plVar7[1] + 0x30))(plVar7);
  }
  if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)
     ) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  lStack_d8 = lVar6;
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))(plVar4);
  }
  plVar4 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStack_d8;
  if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)
     ) {
    (**(code **)(plVar4[1] + 0x30))();
  }
LAB_1408c00e2:
  puVar10 = (undefined *)FUN_142cfc380(uStack_48 ^ (ulonglong)auStack_118);
  return puVar10;
}

