
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _resolver_geetest_slider(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  int *piVar3;
  longlong lVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  code *pcVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  code *pcVar14;
  undefined *puVar15;
  undefined8 uVar16;
  longlong *plVar17;
  bool bVar18;
  longlong lStackX_18;
  longlong *plStackX_20;
  longlong *plStack_58;
  longlong *plStack_50;
  
  plVar17 = _DAT_142d9a260;
  plVar1 = (longlong *)*python_pars;
  plVar10 = (longlong *)python_pars[1];
  plStack_58 = (longlong *)0x0;
  lStackX_18 = 0;
  plStack_50 = (longlong *)0x0;
  iVar7 = (int)*_DAT_142d9a260 + 1;
  if (iVar7 != 0) {
    *(int *)_DAT_142d9a260 = iVar7;
  }
  plVar5 = _DAT_142dea7b0;
  plStackX_20 = plVar10;
  if (_DAT_142dea7b0 != (longlong *)0x0) {
    if ((*_DAT_142dea7b0 < 2) && (_DAT_142dea7b0[2] == 0)) goto LAB_1408d0afd;
    if ((_DAT_142dea7b0 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7b0 && (*_DAT_142dea7b0 = *_DAT_142dea7b0 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
  }
  _DAT_142dea7b0 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9d48,_DAT_142f2aaf0,0x30);
LAB_1408d0afd:
  plVar5 = _DAT_142dea7b0;
  Nuitka_helper_140008a00(tstate,_DAT_142dea7b0);
  uVar16 = 0x2390;
LAB_1408d0b10:
  pcVar8 = (code *)FUN_142ce3260(plVar17,plVar10);
  plVar9 = plVar17;
  if (pcVar8 != (code *)0x0) {
    if (pcVar8 == _Py_TrueStruct_exref) {
LAB_1408d0b30:
      iVar7 = 1;
    }
    else if ((pcVar8 == _Py_FalseStruct_exref) || (pcVar8 == _Py_NoneStruct_exref)) {
      iVar7 = 0;
    }
    else {
      lVar12 = *(longlong *)(pcVar8 + 8);
      if ((*(longlong *)(lVar12 + 0x60) == 0) ||
         (pcVar14 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48), pcVar14 == (code *)0x0)) {
        if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
           (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar14 == (code *)0x0)) {
          if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
             (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x68), pcVar14 == (code *)0x0))
          goto LAB_1408d0b30;
          lVar12 = (*pcVar14)(pcVar8);
        }
        else {
          lVar12 = (*pcVar14)(pcVar8);
        }
      }
      else {
        iVar7 = (*pcVar14)(pcVar8);
        lVar12 = (longlong)iVar7;
      }
      if (lVar12 < 1) {
        iVar7 = -(uint)(lVar12 != 0);
      }
      else {
        iVar7 = 1;
      }
    }
    if ((-1 < *(int *)pcVar8) &&
       (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
      (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
    }
    if (iVar7 == -1) goto LAB_1408d14f7;
    if (iVar7 == 0) {
      FUN_140008990(tstate);
      pcVar8 = _Py_FalseStruct_exref;
      if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
        *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
      }
      goto LAB_1408d1afa;
    }
    plVar9 = (longlong *)FUN_142cbe350(plVar17,1);
    if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
       (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
      (**(code **)(plVar17[1] + 0x30))(plVar17);
    }
    plVar17 = plVar9;
    if (plVar1 == (longlong *)0x0) {
      FUN_142cd4900(tstate,&lStackX_18,classes_const_403_self);
      FUN_1400048d0(tstate,lStackX_18);
      lVar12 = lStackX_18;
LAB_1408d1840:
      piVar2 = *(int **)(tstate + 0xf8);
      lStackX_18 = 0;
      if ((piVar2 != (int *)0x0) && (*piVar2 + 1 != 0)) {
        *piVar2 = *piVar2 + 1;
      }
      piVar3 = *(int **)(lVar12 + 0x28);
      pcVar8 = (code *)FUN_142cd9160(plVar5,0x238c);
      if (piVar3 != (int *)0x0) {
        *(int **)(pcVar8 + 0x10) = piVar3;
        if (*piVar3 + 1 != 0) {
          *piVar3 = *piVar3 + 1;
        }
      }
      plVar10 = *(longlong **)(lVar12 + 0x28);
      if (pcVar8 == _Py_NoneStruct_exref) {
        pcVar14 = (code *)0x0;
      }
      else {
        pcVar14 = pcVar8;
        if ((pcVar8 != (code *)0x0) && (*(int *)pcVar8 + 1 != 0)) {
          *(int *)pcVar8 = *(int *)pcVar8 + 1;
        }
      }
      *(code **)(lVar12 + 0x28) = pcVar14;
      if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
         (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))();
      }
      if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
         (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
        (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
      }
      plVar10 = *(longlong **)(tstate + 0xf8);
      *(longlong *)(tstate + 0xf8) = lVar12;
      if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
         (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))();
      }
      iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                            *(undefined8 *)PyExc_Exception_exref);
      if (iVar7 == 0) {
        cVar6 = FUN_142cded30(tstate,&lStackX_18);
        uVar16 = 0x238b;
        if (cVar6 != '\0') {
          uVar16 = 0;
        }
        lVar4 = *(longlong *)(lStackX_18 + 0x28);
        lVar12 = lStackX_18;
        if ((lVar4 != 0) && (*(longlong **)(lVar4 + 0x18) == plVar5)) {
          *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar4 + 0x24);
        }
      }
      else {
        plVar10 = *(longlong **)(tstate + 0xf8);
        iVar7 = (int)*plVar10 + 1;
        if (iVar7 != 0) {
          *(int *)plVar10 = iVar7;
        }
        plVar11 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
        if ((plVar11 == (longlong *)0x0) || (lVar12 = *plVar11, lVar12 == 0)) goto LAB_1408d1a58;
        plVar11 = (longlong *)
                  FUN_142cbff90(classes_const_1952__geetest__o_script_nao_rodou___s,plVar10);
        uVar16 = 0x238e;
        if (plVar11 != (longlong *)0x0) {
          *(undefined4 *)(plVar5 + 5) = 0x238e;
          plVar13 = (longlong *)FUN_142ccfd60(tstate,lVar12,plVar11);
          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
            (**(code **)(plVar11[1] + 0x30))();
          }
          if (plVar13 != (longlong *)0x0) {
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
            }
            pcVar8 = _Py_FalseStruct_exref;
            if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
              *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
            }
            if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
              (**(code **)(plVar10[1] + 0x30))(plVar10);
            }
            plVar10 = *(longlong **)(tstate + 0xf8);
            *(int **)(tstate + 0xf8) = piVar2;
            if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
               (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
              (**(code **)(plVar10[1] + 0x30))();
            }
LAB_1408d1a43:
            FUN_140008990(tstate);
            plVar10 = plStackX_20;
LAB_1408d1afa:
            if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
               (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
              (**(code **)(plVar17[1] + 0x30))(plVar17);
            }
            if (((plStack_50 != (longlong *)0x0) && (-1 < (int)*plStack_50)) &&
               (*plStack_50 = *plStack_50 + -1, *plStack_50 == 0)) {
              (**(code **)(plStack_50[1] + 0x30))();
            }
            if (((plStack_58 != (longlong *)0x0) && (-1 < (int)*plStack_58)) &&
               (*plStack_58 = *plStack_58 + -1, *plStack_58 == 0)) {
              (**(code **)(plStack_58[1] + 0x30))();
            }
            if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
              (**(code **)(plVar1[1] + 0x30))();
            }
            if ((int)*plVar10 < 0) {
              return pcVar8;
            }
            *plVar10 = *plVar10 + -1;
            if (*plVar10 != 0) {
              return pcVar8;
            }
            (**(code **)(plVar10[1] + 0x30))(plVar10);
            return pcVar8;
          }
        }
        lVar12 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        lStackX_18 = 0;
        if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
          (**(code **)(plVar10[1] + 0x30))(plVar10);
        }
      }
      plVar17 = *(longlong **)(tstate + 0xf8);
      lStackX_18 = 0;
      *(int **)(tstate + 0xf8) = piVar2;
      plVar10 = plStackX_20;
      if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
         (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
        (**(code **)(plVar17[1] + 0x30))();
        plVar10 = plStackX_20;
      }
    }
    else {
      plVar10 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
      if (plVar10 == (longlong *)0x0) {
LAB_1408d1812:
        lVar12 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        goto LAB_1408d1840;
      }
      plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar10,classes_const_338_execute_script);
      if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))(plVar10);
      }
      if (plVar11 == (longlong *)0x0) goto LAB_1408d1812;
      plVar10 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1951__JS_GEETEST_SLIDER);
      if (plVar10 == (longlong *)0x0) {
        lStackX_18 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        lVar12 = lStackX_18;
        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
          (**(code **)(plVar11[1] + 0x30))(plVar11);
          lVar12 = lStackX_18;
        }
        goto LAB_1408d1840;
      }
      *(undefined4 *)(plVar5 + 5) = 0x238c;
      pcVar8 = (code *)FUN_142ccfd60(tstate,plVar11,plVar10);
      if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
        (**(code **)(plVar11[1] + 0x30))(plVar11);
      }
      if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))(plVar10);
      }
      if (pcVar8 == (code *)0x0) goto LAB_1408d1812;
      if (pcVar8 != _Py_TrueStruct_exref) {
        if ((pcVar8 != _Py_FalseStruct_exref) && (pcVar8 != _Py_NoneStruct_exref)) {
          lVar12 = *(longlong *)(pcVar8 + 8);
          if ((*(longlong *)(lVar12 + 0x60) == 0) ||
             (pcVar14 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48), pcVar14 == (code *)0x0)) {
            if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
               (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar14 == (code *)0x0)) {
              if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
                 (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x68), pcVar14 == (code *)0x0))
              goto LAB_1408d0d61;
              lVar12 = (*pcVar14)(pcVar8);
            }
            else {
              lVar12 = (*pcVar14)(pcVar8);
            }
          }
          else {
            iVar7 = (*pcVar14)(pcVar8);
            lVar12 = (longlong)iVar7;
          }
          if (0 < lVar12) goto LAB_1408d0d61;
          if (lVar12 != 0) {
            lStackX_18 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            lVar12 = lStackX_18;
            if ((-1 < *(int *)pcVar8) &&
               (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
              (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
              lVar12 = lStackX_18;
            }
            goto LAB_1408d1840;
          }
        }
        if ((-1 < *(int *)pcVar8) &&
           (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
          (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
        }
        pcVar8 = (code *)classes_const_102_;
        if (*(int *)classes_const_102_ + 1 != 0) {
          *(int *)classes_const_102_ = *(int *)classes_const_102_ + 1;
        }
      }
LAB_1408d0d61:
      plVar11 = (longlong *)FUN_142cc2ce0(pcVar8);
      if ((-1 < *(int *)pcVar8) &&
         (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
        (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
      }
      if (plVar11 == (longlong *)0x0) goto LAB_1408d1812;
      if (((plStack_50 != (longlong *)0x0) && (-1 < (int)*plStack_50)) &&
         (*plStack_50 = *plStack_50 + -1, *plStack_50 == 0)) {
        (**(code **)(plStack_50[1] + 0x30))();
      }
      plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar11,classes_const_1434_startswith);
      plVar10 = plStackX_20;
      plStack_50 = plVar11;
      if (plVar13 == (longlong *)0x0) goto LAB_1408d14fd;
      *(undefined4 *)(plVar5 + 5) = 0x2390;
      pcVar8 = (code *)FUN_142cccf70(tstate,plVar13,
                                     classes_const_1953___type____T____items_____ok____);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      plVar10 = plStackX_20;
      if (pcVar8 == (code *)0x0) goto LAB_1408d14fd;
      if (pcVar8 == _Py_TrueStruct_exref) {
LAB_1408d0e07:
        bVar18 = true;
      }
      else {
        if ((pcVar8 != _Py_FalseStruct_exref) && (pcVar8 != _Py_NoneStruct_exref)) {
          lVar12 = *(longlong *)(pcVar8 + 8);
          if ((*(longlong *)(lVar12 + 0x60) == 0) ||
             (pcVar14 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48), pcVar14 == (code *)0x0)) {
            if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
               (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar14 == (code *)0x0)) {
              if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
                 (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x68), pcVar14 == (code *)0x0))
              goto LAB_1408d0e07;
              lVar12 = (*pcVar14)(pcVar8);
            }
            else {
              lVar12 = (*pcVar14)(pcVar8);
            }
          }
          else {
            iVar7 = (*pcVar14)(pcVar8);
            lVar12 = (longlong)iVar7;
          }
          if (0 < lVar12) {
            bVar18 = true;
            goto LAB_1408d0e81;
          }
          if (lVar12 != 0) {
            lStackX_18 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            plVar10 = plStackX_20;
            lVar12 = lStackX_18;
            if ((-1 < *(int *)pcVar8) &&
               (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
              (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
              plVar10 = plStackX_20;
              lVar12 = lStackX_18;
            }
            goto LAB_1408d150d;
          }
        }
        bVar18 = false;
      }
LAB_1408d0e81:
      if ((-1 < *(int *)pcVar8) &&
         (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
        (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
      }
      if (!bVar18) {
        plVar10 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
        puVar15 = classes_const_1957__geetest__nao_arrastei___s___d_de__d_;
        if ((plVar10 == (longlong *)0x0) || (lVar12 = *plVar10, lVar12 == 0)) goto LAB_1408d1a58;
        plVar10 = (longlong *)FUN_142cd9440(tstate,3);
        iVar7 = (int)*plVar11 + 1;
        if (iVar7 != 0) {
          *(int *)plVar11 = iVar7;
        }
        plVar10[3] = (longlong)plVar11;
        iVar7 = (int)*plVar9 + 1;
        if (iVar7 != 0) {
          *(int *)plVar9 = iVar7;
        }
        plVar10[4] = (longlong)plVar9;
        iVar7 = (int)*plStackX_20 + 1;
        if (iVar7 != 0) {
          *(int *)plStackX_20 = iVar7;
        }
        plVar10[5] = (longlong)plStackX_20;
        plVar13 = (longlong *)FUN_142cbffc0(puVar15,plVar10);
        if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
          (**(code **)(plVar10[1] + 0x30))(plVar10);
        }
        if (plVar13 == (longlong *)0x0) {
          uVar16 = 0x239c;
          plVar10 = plStackX_20;
        }
        else {
          *(undefined4 *)(plVar5 + 5) = 0x239b;
          plVar10 = (longlong *)FUN_142ccfd60(tstate,lVar12,plVar13);
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          if (plVar10 == (longlong *)0x0) {
            uVar16 = 0x239b;
            plVar10 = plStackX_20;
          }
          else {
            if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
              (**(code **)(plVar10[1] + 0x30))(plVar10);
            }
            iVar7 = PySequence_Contains(classes_const_1958___type____T____items_____sem_captcha____sem_botao___
                                        ,plVar11);
            pcVar8 = _Py_FalseStruct_exref;
            if (iVar7 != -1) {
              if (iVar7 == 1) {
                if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
                  *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
                }
                goto LAB_1408d1a43;
              }
              goto LAB_1408d13d4;
            }
            uVar16 = 0x239d;
            plVar10 = plStackX_20;
          }
        }
        goto LAB_1408d14fd;
      }
      lVar12 = FUN_140a3b210(tstate);
      if (lVar12 != 0) {
        *(undefined4 *)(plVar5 + 5) = 0x2392;
        plVar10 = (longlong *)FUN_142cd06a0(tstate,lVar12,classes_const_76_time);
        if (plVar10 != (longlong *)0x0) {
          plVar13 = (longlong *)FUN_142cbe6d0(plVar10,classes_const_1029_4);
          if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
            (**(code **)(plVar10[1] + 0x30))(plVar10);
          }
          if (plVar13 != (longlong *)0x0) {
            if (((plStack_58 != (longlong *)0x0) && (-1 < (int)*plStack_58)) &&
               (*plStack_58 = *plStack_58 + -1, *plStack_58 == 0)) {
              (**(code **)(plStack_58[1] + 0x30))();
            }
            do {
              lVar12 = FUN_140a3b210(tstate);
              plStack_58 = plVar13;
              if (lVar12 == 0) {
                FUN_142cde870(tstate,&lStackX_18,classes_const_76_time);
                uVar16 = 0x2393;
                plVar10 = plStackX_20;
                lVar12 = lStackX_18;
                goto LAB_1408d150d;
              }
              *(undefined4 *)(plVar5 + 5) = 0x2393;
              plVar10 = (longlong *)FUN_142cd06a0(tstate,lVar12,classes_const_76_time);
              if (plVar10 == (longlong *)0x0) goto LAB_1408d11cb;
              pcVar8 = (code *)FUN_142ce3540(plVar10,plVar13);
              if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                (**(code **)(plVar10[1] + 0x30))(plVar10);
              }
              if (pcVar8 == (code *)0x0) goto LAB_1408d11cb;
              if (pcVar8 == _Py_TrueStruct_exref) {
LAB_1408d0f90:
                iVar7 = 1;
              }
              else if ((pcVar8 == _Py_FalseStruct_exref) || (pcVar8 == _Py_NoneStruct_exref)) {
                iVar7 = 0;
              }
              else {
                lVar12 = *(longlong *)(pcVar8 + 8);
                if ((*(longlong *)(lVar12 + 0x60) == 0) ||
                   (pcVar14 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48),
                   pcVar14 == (code *)0x0)) {
                  if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
                     (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar14 == (code *)0x0)) {
                    if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
                       (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x68), pcVar14 == (code *)0x0))
                    goto LAB_1408d0f90;
                    lVar12 = (*pcVar14)(pcVar8);
                  }
                  else {
                    lVar12 = (*pcVar14)(pcVar8);
                  }
                }
                else {
                  iVar7 = (*pcVar14)(pcVar8);
                  lVar12 = (longlong)iVar7;
                }
                if (lVar12 < 1) {
                  iVar7 = -(uint)(lVar12 != 0);
                }
                else {
                  iVar7 = 1;
                }
              }
              if ((-1 < *(int *)pcVar8) &&
                 (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
              }
              if (iVar7 == -1) goto LAB_1408d11cb;
              if (iVar7 == 0) goto LAB_1408d11de;
              *(undefined4 *)(plVar5 + 5) = 0x2394;
              pcVar8 = (code *)FUN_142cd06a0(tstate,plVar1,classes_const_1948__geetest_na_tela);
              if (pcVar8 == (code *)0x0) {
LAB_1408d16d3:
                uVar16 = 0x2394;
                plVar10 = plStackX_20;
                goto LAB_1408d14fd;
              }
              if (pcVar8 == _Py_TrueStruct_exref) {
LAB_1408d1061:
                iVar7 = 1;
              }
              else if ((pcVar8 == _Py_FalseStruct_exref) || (pcVar8 == _Py_NoneStruct_exref)) {
                iVar7 = 0;
              }
              else {
                lVar12 = *(longlong *)(pcVar8 + 8);
                if ((*(longlong *)(lVar12 + 0x60) == 0) ||
                   (pcVar14 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48),
                   pcVar14 == (code *)0x0)) {
                  if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
                     (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar14 == (code *)0x0)) {
                    if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
                       (pcVar14 = (code *)**(undefined8 **)(lVar12 + 0x68), pcVar14 == (code *)0x0))
                    goto LAB_1408d1061;
                    lVar12 = (*pcVar14)(pcVar8);
                  }
                  else {
                    lVar12 = (*pcVar14)(pcVar8);
                  }
                }
                else {
                  iVar7 = (*pcVar14)(pcVar8);
                  lVar12 = (longlong)iVar7;
                }
                if (lVar12 < 1) {
                  iVar7 = -(uint)(lVar12 != 0);
                }
                else {
                  iVar7 = 1;
                }
              }
              if ((-1 < *(int *)pcVar8) &&
                 (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
              }
              if (iVar7 == -1) goto LAB_1408d16d3;
              if (iVar7 == 0) {
                plVar10 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
                puVar15 = classes_const_1954__geetest__slider_resolvido___s_px_;
                if ((plVar10 == (longlong *)0x0) || (lVar12 = *plVar10, lVar12 == 0))
                goto LAB_1408d1a58;
                plVar10 = (longlong *)
                          FUN_140008da0(tstate,plVar11,
                                        classes_const_1955___type_________items____3__None__None__);
                if (plVar10 == (longlong *)0x0) {
                  uVar16 = 0x2395;
                  plVar10 = plStackX_20;
                  goto LAB_1408d14fd;
                }
                plVar11 = (longlong *)FUN_142cbff90(puVar15,plVar10);
                if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                  (**(code **)(plVar10[1] + 0x30))(plVar10);
                }
                uVar16 = 0x2395;
                plVar10 = plStackX_20;
                if (plVar11 == (longlong *)0x0) goto LAB_1408d14fd;
                *(undefined4 *)(plVar5 + 5) = 0x2395;
                plVar13 = (longlong *)FUN_142ccfd60(tstate,lVar12,plVar11);
                if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                  (**(code **)(plVar11[1] + 0x30))(plVar11);
                }
                plVar10 = plStackX_20;
                if (plVar13 == (longlong *)0x0) goto LAB_1408d14fd;
                if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                }
                pcVar8 = _Py_TrueStruct_exref;
                if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
                  *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
                }
                goto LAB_1408d1a43;
              }
              lVar12 = FUN_140a3b210(tstate);
              if (lVar12 == 0) {
                FUN_142cde870(tstate,&lStackX_18,classes_const_76_time);
                uVar16 = 0x2397;
                plVar10 = plStackX_20;
                lVar12 = lStackX_18;
                goto LAB_1408d150d;
              }
              *(undefined4 *)(plVar5 + 5) = 0x2397;
              plVar10 = (longlong *)
                        FUN_142cd12f0(tstate,lVar12,classes_const_77_sleep,
                                      *(undefined8 *)
                                       (classes_const_1551___type____T____items____0_3__ + 0x18));
              if (plVar10 == (longlong *)0x0) {
                uVar16 = 0x2397;
                plVar10 = plStackX_20;
                goto LAB_1408d14fd;
              }
              if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                (**(code **)(plVar10[1] + 0x30))(plVar10);
              }
              if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                  (iVar7 = Py_MakePendingCalls(), iVar7 < 0)) && (*(longlong *)(tstate + 0x70) != 0)
                 ) goto LAB_1408d11cb;
              if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                PyEval_SaveThread();
                PyEval_AcquireThread(tstate);
              }
              if (*(longlong *)(tstate + 0x90) != 0) {
                plVar10 = *(longlong **)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x90) = 0;
                uVar16 = FUN_142cd9e70(tstate);
                *(undefined8 *)(tstate + 0x70) = uVar16;
                if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
                   (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                  (**(code **)(plVar10[1] + 0x30))(plVar10);
                }
LAB_1408d11cb:
                uVar16 = 0x2393;
                plVar10 = plStackX_20;
                goto LAB_1408d14fd;
              }
            } while( true );
          }
        }
        uVar16 = 0x2392;
        plVar10 = plStackX_20;
        goto LAB_1408d14fd;
      }
      FUN_142cde870(tstate,&lStackX_18,classes_const_76_time);
      uVar16 = 0x2392;
      plVar10 = plStackX_20;
      lVar12 = lStackX_18;
    }
    goto LAB_1408d150d;
  }
  goto LAB_1408d14f7;
LAB_1408d11de:
  plVar10 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
  puVar15 = classes_const_1956__geetest__arrastei_e_o_captcha_ficou___d_de__d_;
  if ((plVar10 == (longlong *)0x0) || (lVar12 = *plVar10, lVar12 == 0)) {
LAB_1408d1a58:
    PyErr_PrintEx(0);
    Py_Exit(1);
    pcVar8 = (code *)swi(3);
    puVar15 = (undefined *)(*pcVar8)();
    return puVar15;
  }
  plVar10 = (longlong *)FUN_142cd9440(tstate,2);
  iVar7 = (int)*plVar9 + 1;
  if (iVar7 != 0) {
    *(int *)plVar9 = iVar7;
  }
  plVar10[3] = (longlong)plVar9;
  iVar7 = (int)*plStackX_20 + 1;
  if (iVar7 != 0) {
    *(int *)plStackX_20 = iVar7;
  }
  plVar10[4] = (longlong)plStackX_20;
  plVar11 = (longlong *)FUN_142cbffc0(puVar15,plVar10);
  if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))(plVar10);
  }
  if (plVar11 == (longlong *)0x0) {
    uVar16 = 0x2399;
    plVar10 = plStackX_20;
    goto LAB_1408d14fd;
  }
  *(undefined4 *)(plVar5 + 5) = 0x2398;
  plVar10 = (longlong *)FUN_142ccfd60(tstate,lVar12,plVar11);
  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
    (**(code **)(plVar11[1] + 0x30))(plVar11);
  }
  if (plVar10 == (longlong *)0x0) {
    uVar16 = 0x2398;
    plVar10 = plStackX_20;
    goto LAB_1408d14fd;
  }
  if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))(plVar10);
  }
LAB_1408d13d4:
  plVar10 = plStackX_20;
  iVar7 = FUN_142ce2990(plVar9,plStackX_20);
  if (iVar7 == -1) {
    uVar16 = 0x239f;
    goto LAB_1408d14fd;
  }
  if (iVar7 == 1) {
    *(undefined4 *)(plVar5 + 5) = 0x23a0;
    plVar11 = (longlong *)FUN_142cd06a0(tstate,plVar1,classes_const_1862__geetest_refresh);
    if (plVar11 == (longlong *)0x0) {
      uVar16 = 0x23a0;
      goto LAB_1408d14fd;
    }
    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
    lVar12 = FUN_140a3b210(tstate);
    if (lVar12 == 0) {
      FUN_142cde870(tstate,&lStackX_18,classes_const_76_time);
      uVar16 = 0x23a1;
      lVar12 = lStackX_18;
      goto LAB_1408d150d;
    }
    *(undefined4 *)(plVar5 + 5) = 0x23a1;
    plVar11 = (longlong *)
              FUN_142cd12f0(tstate,lVar12,classes_const_77_sleep,
                            *(undefined8 *)(classes_const_1890___type____T____items____1_5__ + 0x18)
                           );
    if (plVar11 == (longlong *)0x0) {
      uVar16 = 0x23a1;
      goto LAB_1408d14fd;
    }
    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
  }
  if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) && (iVar7 = Py_MakePendingCalls(), iVar7 < 0)) &&
     (*(longlong *)(tstate + 0x70) != 0)) goto LAB_1408d14f7;
  if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
    PyEval_SaveThread();
    PyEval_AcquireThread(tstate);
  }
  if (*(longlong *)(tstate + 0x90) != 0) goto code_r0x0001408d14c2;
  goto LAB_1408d0b10;
code_r0x0001408d14c2:
  plVar17 = *(longlong **)(tstate + 0x70);
  *(undefined8 *)(tstate + 0x90) = 0;
  uVar16 = FUN_142cd9e70(tstate);
  *(undefined8 *)(tstate + 0x70) = uVar16;
  if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
     (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
    (**(code **)(plVar17[1] + 0x30))(plVar17);
  }
LAB_1408d14f7:
  uVar16 = 0x2389;
LAB_1408d14fd:
  lVar12 = *(longlong *)(tstate + 0x70);
  *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408d150d:
  lStackX_18 = lVar12;
  piVar2 = *(int **)(lStackX_18 + 0x28);
  if (piVar2 == (int *)0x0) {
    pcVar8 = (code *)FUN_142cd9160(plVar5,uVar16);
    bVar18 = pcVar8 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar2 + 6) == plVar5) goto LAB_1408d1bfa;
    pcVar8 = (code *)FUN_142cd9160(plVar5,uVar16);
    *(int **)(pcVar8 + 0x10) = piVar2;
    if (*piVar2 + 1 != 0) {
      *piVar2 = *piVar2 + 1;
    }
    bVar18 = pcVar8 == _Py_NoneStruct_exref;
  }
  plVar17 = *(longlong **)(lStackX_18 + 0x28);
  if (bVar18) {
    pcVar14 = (code *)0x0;
  }
  else {
    pcVar14 = pcVar8;
    if ((pcVar8 != (code *)0x0) && (*(int *)pcVar8 + 1 != 0)) {
      *(int *)pcVar8 = *(int *)pcVar8 + 1;
    }
  }
  *(code **)(lStackX_18 + 0x28) = pcVar14;
  if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
     (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
    (**(code **)(plVar17[1] + 0x30))();
  }
  if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
     (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
    (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
  }
LAB_1408d1bfa:
  FUN_142cdb370(plVar5,&UNK_142d0b550,plVar1,plVar10,plVar9,plStack_50,0,plStack_58);
  plVar17 = _DAT_142dea7b0;
  if (plVar5 == _DAT_142dea7b0) {
    if ((-1 < (int)*_DAT_142dea7b0) && (*_DAT_142dea7b0 = *_DAT_142dea7b0 + -1, *plVar17 == 0)) {
      (**(code **)(plVar17[1] + 0x30))();
    }
    _DAT_142dea7b0 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar12 = lStackX_18;
  lStackX_18 = 0;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if (((plStack_50 != (longlong *)0x0) && (-1 < (int)*plStack_50)) &&
     (*plStack_50 = *plStack_50 + -1, *plStack_50 == 0)) {
    (**(code **)(plStack_50[1] + 0x30))(plStack_50);
  }
  if (((plStack_58 != (longlong *)0x0) && (-1 < (int)*plStack_58)) &&
     (*plStack_58 = *plStack_58 + -1, *plStack_58 == 0)) {
    (**(code **)(plStack_58[1] + 0x30))();
  }
  lStackX_18 = lVar12;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))(plVar10);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

