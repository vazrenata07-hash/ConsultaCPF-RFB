
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _geetest_nine_marcar(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int *piVar5;
  longlong lVar6;
  int *piVar7;
  int iVar8;
  longlong *plVar9;
  longlong *plVar10;
  code *pcVar11;
  code *pcVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong *plVar18;
  longlong lVar19;
  undefined8 uVar20;
  undefined *puVar21;
  code *pcVar22;
  undefined8 uVar23;
  char cVar24;
  bool bVar25;
  undefined8 uStackX_18;
  longlong lStackX_20;
  longlong *plStack_c8;
  longlong *plStack_b8;
  longlong *plStack_b0;
  longlong *plStack_a8;
  code *pcStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_88;
  longlong *plStack_80;
  longlong *plStack_48;
  longlong *plStack_40;
  
  plVar9 = _DAT_142dea730;
  plVar1 = (longlong *)python_pars[1];
  plVar2 = (longlong *)*python_pars;
  plVar3 = (longlong *)python_pars[2];
  plVar4 = (longlong *)python_pars[3];
  lStackX_20 = 0;
  plStack_80 = (longlong *)0x0;
  plStack_b0 = (longlong *)0x0;
  pcStack_a0 = (code *)0x0;
  plStack_b8 = (longlong *)0x0;
  plStack_a8 = (longlong *)0x0;
  plStack_98 = (longlong *)0x0;
  plStack_90 = (longlong *)0x0;
  plStack_88 = (longlong *)0x0;
  plStack_c8 = _DAT_142dea730;
  if (_DAT_142dea730 == (longlong *)0x0) {
LAB_1408b6cb2:
    plStack_c8 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9b88,_DAT_142f2aaf0,0x60);
  }
  else if ((1 < *_DAT_142dea730) || (_DAT_142dea730[2] != 0)) {
    if ((_DAT_142dea730 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea730 && (*_DAT_142dea730 = *_DAT_142dea730 + -1, *plVar9 == 0)))) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    goto LAB_1408b6cb2;
  }
  _DAT_142dea730 = plStack_c8;
  Nuitka_helper_140008a00(tstate,plStack_c8);
  plVar9 = (longlong *)FUN_142cd7b20(tstate,plVar2,classes_const_170_driver);
  if (plVar9 == (longlong *)0x0) {
LAB_1408b6d09:
    lVar19 = *(longlong *)(tstate + 0x70);
    uStackX_18 = 0x207a;
    *(undefined8 *)(tstate + 0x70) = 0;
  }
  else {
    iVar8 = FUN_140004970(plVar9);
    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    pcVar22 = _Py_FalseStruct_exref;
    if (iVar8 == -1) goto LAB_1408b6d09;
    if (iVar8 == 0) {
      plStack_b8 = (longlong *)0x0;
      if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
        *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
        plStack_b8 = (longlong *)0x0;
      }
LAB_1408b80b7:
      plVar9 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
      *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
      *(undefined4 *)(plVar9 + 10) = 0xfffffffe;
      plVar10 = (longlong *)plVar9[2];
      if (((plVar10 != (longlong *)0x0) && (plVar9[2] = 0, -1 < (int)*plVar10)) &&
         (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))();
      }
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      plVar9[0xc] = 0;
      if (plStack_80 != (longlong *)0x0) {
LAB_1408b89fa:
        if ((-1 < (int)*plStack_80) && (*plStack_80 = *plStack_80 + -1, *plStack_80 == 0)) {
          (**(code **)(plStack_80[1] + 0x30))();
        }
      }
      if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
         (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
        (**(code **)(plStack_b0[1] + 0x30))(plStack_b0);
      }
      if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
         (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0)) {
        (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))(pcStack_a0);
      }
      if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
         (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
        (**(code **)(plStack_b8[1] + 0x30))(plStack_b8);
      }
      if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
         (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
        (**(code **)(plStack_a8[1] + 0x30))(plStack_a8);
      }
      if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
         (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
        (**(code **)(plStack_98[1] + 0x30))();
      }
      if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
         (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
        (**(code **)(plStack_90[1] + 0x30))();
      }
      if (((plStack_88 != (longlong *)0x0) && (-1 < (int)*plStack_88)) &&
         (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
        (**(code **)(plStack_88[1] + 0x30))();
      }
      if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
        (**(code **)(plVar2[1] + 0x30))();
      }
      if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
        (**(code **)(plVar1[1] + 0x30))();
      }
      if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
        (**(code **)(plVar3[1] + 0x30))();
      }
      if ((int)*plVar4 < 0) {
        return pcVar22;
      }
      *plVar4 = *plVar4 + -1;
      if (*plVar4 != 0) {
        return pcVar22;
      }
      (**(code **)(plVar4[1] + 0x30))(plVar4);
      return pcVar22;
    }
    plVar9 = (longlong *)PySet_New(plVar1);
    if (plVar9 == (longlong *)0x0) {
      lVar19 = *(longlong *)(tstate + 0x70);
      uStackX_18 = 0x207c;
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      plStack_b0 = _DAT_142d9a260;
      iVar8 = (int)*_DAT_142d9a260 + 1;
      if (iVar8 != 0) {
        *(int *)_DAT_142d9a260 = iVar8;
      }
      do {
        pcVar22 = pcStack_a0;
        plVar10 = (longlong *)FUN_142ce3260(plStack_b0,plVar4);
        plStack_80 = plVar9;
        if (plVar10 == (longlong *)0x0) {
LAB_1408b8256:
          lVar19 = *(longlong *)(tstate + 0x70);
LAB_1408b825a:
          uStackX_18 = 0x207e;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        iVar8 = FUN_140004970(plVar10);
        if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
          (**(code **)(plVar10[1] + 0x30))(plVar10);
        }
        if (iVar8 == -1) goto LAB_1408b8256;
        if (iVar8 == 0) {
          uVar20 = FUN_1400776a0(classes_const_257_print);
          puVar21 = 
          classes_const_1768__s__geetest_3x3__nao_consegui_fixar_a_selecao__queria__s__ficou__;
          if (plVar2 == (longlong *)0x0) {
            FUN_142cd4900(tstate,&lStackX_20,classes_const_403_self);
            FUN_1400048d0(tstate,lStackX_20);
            uStackX_18 = 0x20ac;
            lVar19 = lStackX_20;
            goto LAB_1408b8856;
          }
          uStackX_18 = 0x20ac;
          *(undefined4 *)(plStack_c8 + 5) = 0x20ac;
          lVar19 = FUN_142cd06a0(tstate,plVar2,classes_const_1346__tag);
          if (lVar19 == 0) {
            lVar19 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            goto LAB_1408b8856;
          }
          plVar10 = (longlong *)FUN_142cd9440(tstate,3);
          plVar10[3] = lVar19;
          uVar23 = FUN_1400776a0(classes_const_1170_sorted);
          *(undefined4 *)(plStack_c8 + 5) = 0x20ac;
          lVar19 = FUN_142ccfd60(tstate,uVar23,plVar9);
          if (lVar19 == 0) {
            lStackX_20 = *(longlong *)(tstate + 0x70);
LAB_1408b8916:
            *(undefined8 *)(tstate + 0x70) = 0;
          }
          else {
            plVar10[4] = lVar19;
            uVar23 = FUN_1400776a0(classes_const_1170_sorted);
            if (plStack_b8 != (longlong *)0x0) {
              *(undefined4 *)(plStack_c8 + 5) = 0x20ac;
              lVar19 = FUN_142ccfd60(tstate,uVar23);
              if (lVar19 == 0) {
                lStackX_20 = *(longlong *)(tstate + 0x70);
                goto LAB_1408b8916;
              }
              plVar10[5] = lVar19;
              plVar9 = (longlong *)FUN_142cbffc0(puVar21,plVar10);
              if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                (**(code **)(plVar10[1] + 0x30))(plVar10);
              }
              if (plVar9 != (longlong *)0x0) {
                uStackX_18 = 0x20ab;
                *(undefined4 *)(plStack_c8 + 5) = 0x20ab;
                plVar10 = (longlong *)FUN_142ccfd60(tstate,uVar20,plVar9);
                if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                }
                if (plVar10 != (longlong *)0x0) {
                  if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                  }
                  FUN_140008990(tstate);
                  pcVar22 = _Py_FalseStruct_exref;
                  if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
                    *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
                  }
                  goto LAB_1408b89fa;
                }
              }
              lVar19 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              goto LAB_1408b8856;
            }
            FUN_142cd4900(tstate,&lStackX_20,classes_const_1759_atual);
            FUN_1400048d0(tstate,lStackX_20);
          }
          lVar19 = lStackX_20;
          if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
            (**(code **)(plVar10[1] + 0x30))(plVar10);
            lVar19 = lStackX_20;
          }
          goto LAB_1408b8856;
        }
        if (plStack_b0 == (longlong *)0x0) {
          FUN_142cd4900(tstate,&lStackX_20,classes_const_1754_passada);
          FUN_1400048d0(tstate,lStackX_20);
          uStackX_18 = 0x207f;
          lVar19 = lStackX_20;
          goto LAB_1408b8856;
        }
        plVar10 = (longlong *)FUN_142cbe350(plStack_b0,1);
        if ((-1 < (int)*plStack_b0) && (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
          (**(code **)(plStack_b0[1] + 0x30))(plStack_b0);
        }
        plStack_b0 = plVar10;
        if (plVar2 == (longlong *)0x0) {
          FUN_142cd4900(tstate,&lStackX_20,classes_const_403_self);
          FUN_1400048d0(tstate,lStackX_20);
          lVar19 = lStackX_20;
LAB_1408b6f37:
          piVar7 = *(int **)(tstate + 0xf8);
          lStackX_20 = 0;
          if ((piVar7 != (int *)0x0) && (*piVar7 + 1 != 0)) {
            *piVar7 = *piVar7 + 1;
          }
          piVar5 = *(int **)(lVar19 + 0x28);
          if (piVar5 == (int *)0x0) {
            pcVar11 = (code *)FUN_142cd9160(plStack_c8,0x2081);
            plVar13 = *(longlong **)(lVar19 + 0x28);
            if (pcVar11 == _Py_NoneStruct_exref) {
              pcVar12 = (code *)0x0;
            }
            else {
              pcVar12 = pcVar11;
              if ((pcVar11 != (code *)0x0) && (*(int *)pcVar11 + 1 != 0)) {
                *(int *)pcVar11 = *(int *)pcVar11 + 1;
              }
            }
            *(code **)(lVar19 + 0x28) = pcVar12;
            if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
               (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))();
            }
            if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
               (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
              (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
            }
          }
          else {
            pcVar11 = (code *)FUN_142cd9160(plStack_c8,0x2081);
            *(int **)(pcVar11 + 0x10) = piVar5;
            if (*piVar5 + 1 != 0) {
              *piVar5 = *piVar5 + 1;
            }
            plVar13 = *(longlong **)(lVar19 + 0x28);
            if (pcVar11 == _Py_NoneStruct_exref) {
              pcVar12 = (code *)0x0;
            }
            else {
              pcVar12 = pcVar11;
              if ((pcVar11 != (code *)0x0) && (*(int *)pcVar11 + 1 != 0)) {
                *(int *)pcVar11 = *(int *)pcVar11 + 1;
              }
            }
            *(code **)(lVar19 + 0x28) = pcVar12;
            if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
               (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))();
            }
            if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
               (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
              (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
            }
          }
          plVar13 = *(longlong **)(tstate + 0xf8);
          *(longlong *)(tstate + 0xf8) = lVar19;
          if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
             (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))();
          }
          iVar8 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                                *(undefined8 *)PyExc_Exception_exref);
          if (iVar8 == 0) {
            cVar24 = FUN_142cded30(tstate,&lStackX_20);
            lVar19 = lStackX_20;
            uStackX_18 = 0x2080;
            if (cVar24 != '\0') {
              uStackX_18 = 0;
            }
            lVar6 = *(longlong *)(lStackX_20 + 0x28);
            if ((lVar6 != 0) && (*(longlong **)(lVar6 + 0x18) == plStack_c8)) {
              *(undefined4 *)(plStack_c8 + 5) = *(undefined4 *)(lVar6 + 0x24);
            }
            lStackX_20 = 0;
            plVar9 = *(longlong **)(tstate + 0xf8);
            *(int **)(tstate + 0xf8) = piVar7;
            if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
               (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
              (**(code **)(plVar9[1] + 0x30))();
            }
            goto LAB_1408b8856;
          }
          pcStack_a0 = _Py_NoneStruct_exref;
          if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
            *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
          }
          if (((pcVar22 != (code *)0x0) && (-1 < *(int *)pcVar22)) &&
             (*(longlong *)pcVar22 = *(longlong *)pcVar22 + -1, *(longlong *)pcVar22 == 0)) {
            (**(code **)(*(longlong *)(pcVar22 + 8) + 0x30))();
          }
          plVar13 = *(longlong **)(tstate + 0xf8);
          *(int **)(tstate + 0xf8) = piVar7;
          pcVar11 = pcStack_a0;
          if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
             (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))();
          }
        }
        else {
          plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar2,classes_const_170_driver);
          if (plVar13 == (longlong *)0x0) {
LAB_1408b6f2b:
            lVar19 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            goto LAB_1408b6f37;
          }
          plVar16 = (longlong *)FUN_142cd7b20(tstate,plVar13,classes_const_338_execute_script);
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          if (plVar16 == (longlong *)0x0) goto LAB_1408b6f2b;
          plVar13 = (longlong *)
                    FUN_142cd7b20(tstate,plVar2,classes_const_1755__JS_GEETEST_NINE_MARCADAS);
          if (plVar13 == (longlong *)0x0) {
            lVar19 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
              lStackX_20 = lVar19;
              (**(code **)(plVar16[1] + 0x30))(plVar16);
              lVar19 = lStackX_20;
            }
            goto LAB_1408b6f37;
          }
          *(undefined4 *)(plStack_c8 + 5) = 0x2081;
          pcVar11 = (code *)FUN_142ccfd60(tstate,plVar16,plVar13);
          if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
            (**(code **)(plVar16[1] + 0x30))(plVar16);
          }
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          if (pcVar11 == (code *)0x0) goto LAB_1408b6f2b;
          if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
             (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0))
          {
            (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))();
          }
        }
        pcStack_a0 = pcVar11;
        iVar8 = PyObject_IsInstance(pcStack_a0,PyList_Type_exref);
        if (iVar8 == -1) {
LAB_1408b8795:
          lVar19 = *(longlong *)(tstate + 0x70);
          uStackX_18 = 0x2084;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        pcVar22 = _Py_FalseStruct_exref;
        if (iVar8 != 0) {
          pcVar22 = _Py_TrueStruct_exref;
        }
        iVar8 = FUN_140004970(pcVar22);
        if (iVar8 == -1) goto LAB_1408b8795;
        cVar24 = iVar8 == 0;
        if (iVar8 != 0) {
          plVar13 = (longlong *)FUN_142cc1f90(tstate,pcStack_a0);
          if (plVar13 == (longlong *)0x0) goto LAB_1408b8795;
          cVar24 = Nuitka_helper_142ce2960(plVar13,9);
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
        }
        if (cVar24 != '\0') {
          cVar24 = Nuitka_helper_142ce0f60(plVar10,1);
          if (cVar24 == '\0') {
            uVar20 = FUN_1400776a0(classes_const_257_print);
            puVar21 = classes_const_1757__s__geetest_3x3__nao_consegui_ler_o_que_esta_marcado;
            if (plVar2 == (longlong *)0x0) {
              FUN_142cd4900(tstate,&lStackX_20,classes_const_403_self);
              FUN_1400048d0(tstate,lStackX_20);
              uStackX_18 = 0x208b;
              lVar19 = lStackX_20;
              goto LAB_1408b8856;
            }
            uStackX_18 = 0x208b;
            *(undefined4 *)(plStack_c8 + 5) = 0x208b;
            plVar9 = (longlong *)FUN_142cd06a0(tstate,plVar2,classes_const_1346__tag);
            if (plVar9 != (longlong *)0x0) {
              plVar10 = (longlong *)FUN_142cbff90(puVar21,plVar9);
              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              if (plVar10 != (longlong *)0x0) {
                *(undefined4 *)(plStack_c8 + 5) = 0x208b;
                plVar9 = (longlong *)FUN_142ccfd60(tstate,uVar20,plVar10);
                if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                  (**(code **)(plVar10[1] + 0x30))(plVar10);
                }
                if (plVar9 != (longlong *)0x0) {
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  pcVar22 = _Py_FalseStruct_exref;
                  if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
                    *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
                  }
                  goto LAB_1408b80b7;
                }
              }
            }
          }
          else {
            uVar20 = FUN_1400776a0(classes_const_257_print);
            puVar21 = classes_const_1756__s__geetest_3x3__a_grade_fechou_durante_a_marcacao;
            if (plVar2 == (longlong *)0x0) {
              FUN_142cd4900(tstate,&lStackX_20,classes_const_403_self);
              FUN_1400048d0(tstate,lStackX_20);
              uStackX_18 = 0x2089;
              lVar19 = lStackX_20;
              goto LAB_1408b8856;
            }
            uStackX_18 = 0x2089;
            *(undefined4 *)(plStack_c8 + 5) = 0x2089;
            plVar9 = (longlong *)FUN_142cd06a0(tstate,plVar2,classes_const_1346__tag);
            if (plVar9 != (longlong *)0x0) {
              plVar10 = (longlong *)FUN_142cbff90(puVar21,plVar9);
              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              if (plVar10 != (longlong *)0x0) {
                *(undefined4 *)(plStack_c8 + 5) = 0x2089;
                plVar9 = (longlong *)FUN_142ccfd60(tstate,uVar20,plVar10);
                if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                  (**(code **)(plVar10[1] + 0x30))(plVar10);
                }
                if (plVar9 != (longlong *)0x0) {
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  pcVar22 = _Py_TrueStruct_exref;
                  if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
                    *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
                  }
                  goto LAB_1408b80b7;
                }
              }
            }
          }
          lVar19 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        plVar13 = (longlong *)PySet_New(0);
        if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
           (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
          (**(code **)(plStack_b8[1] + 0x30))(plStack_b8);
        }
        plVar14 = (longlong *)FUN_140009960(classes_const_1758___type_________items____0__9__1__);
        plVar15 = (longlong *)(**(code **)(plVar14[1] + 0xe0))(plVar14);
        plVar16 = (longlong *)0x0;
        while (plVar17 = plVar15, plStack_b8 = plVar13, plVar17 != (longlong *)0x0) {
          if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
             (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
            (**(code **)(plVar16[1] + 0x30))();
          }
          iVar8 = (int)*plVar17 + 1;
          if (iVar8 != 0) {
            *(int *)plVar17 = iVar8;
          }
          if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
             (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
            (**(code **)(plStack_a8[1] + 0x30))();
          }
          plVar16 = (longlong *)FUN_140008da0(tstate,pcStack_a0,plVar17);
          plStack_a8 = plVar17;
          if (plVar16 == (longlong *)0x0) {
            uStackX_18 = 0x208f;
            goto LAB_1408b7deb;
          }
          iVar8 = FUN_140004970(plVar16);
          if (iVar8 == -1) {
            lStackX_20 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            lVar19 = lStackX_20;
            if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
              (**(code **)(plVar16[1] + 0x30))(plVar16);
              lVar19 = lStackX_20;
            }
            uStackX_18 = 0x208f;
            goto LAB_1408b7df7;
          }
          if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
            (**(code **)(plVar16[1] + 0x30))(plVar16);
          }
          if (iVar8 != 0) {
            if (plVar13 == (longlong *)0x0) {
              FUN_142cd4900(tstate,&lStackX_20,classes_const_1759_atual);
              FUN_1400048d0(tstate,lStackX_20);
              uStackX_18 = 0x2090;
              lVar19 = lStackX_20;
              goto LAB_1408b7df7;
            }
            *(undefined4 *)(plStack_c8 + 5) = 0x2090;
            plVar16 = (longlong *)FUN_142cd12f0(tstate,plVar13,classes_const_71_add,plVar17);
            if (plVar16 == (longlong *)0x0) {
              uStackX_18 = 0x2090;
              goto LAB_1408b7deb;
            }
            if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
              (**(code **)(plVar16[1] + 0x30))(plVar16);
            }
          }
          if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
              (iVar8 = Py_MakePendingCalls(), iVar8 < 0)) &&
             (lVar19 = *(longlong *)(tstate + 0x70), lVar19 != 0)) {
LAB_1408b7da4:
            uStackX_18 = 0x208e;
            goto LAB_1408b7def;
          }
          if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
            PyEval_SaveThread();
            PyEval_AcquireThread(tstate);
          }
          if (*(longlong *)(tstate + 0x90) != 0) {
            plVar9 = *(longlong **)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x90) = 0;
            lVar19 = FUN_142cd9e70(tstate);
            *(longlong *)(tstate + 0x70) = lVar19;
            if ((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) {
              *plVar9 = *plVar9 + -1;
              if (*plVar9 == 0) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              lVar19 = *(longlong *)(tstate + 0x70);
            }
            goto LAB_1408b7da4;
          }
          plVar15 = (longlong *)(**(code **)(plVar14[1] + 0xe0))(plVar14);
          plVar16 = plVar17;
        }
        plVar15 = *(longlong **)(tstate + 0x70);
        if (plVar15 != (longlong *)0x0) {
          plVar17 = plVar15;
          if ((*(uint *)((longlong *)plVar15[1] + 0x15) & 0x40000000) != 0) {
            plVar17 = (longlong *)plVar15[1];
          }
          if ((plVar17 != *(longlong **)PyExc_StopIteration_exref) &&
             (((-1 < *(int *)(plVar17[1] + 0xa8) || ((*(uint *)(plVar17 + 0x15) & 0x40000000) == 0))
              || (cVar24 = Nuitka_helper_142cdd950(), cVar24 != '\x01')))) {
            uStackX_18 = 0x208e;
            plVar17 = plVar16;
LAB_1408b7deb:
            lVar19 = *(longlong *)(tstate + 0x70);
LAB_1408b7def:
            *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408b7df7:
            lStackX_20 = 0;
            if (((plVar17 != (longlong *)0x0) && (-1 < (int)*plVar17)) &&
               (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
              (**(code **)(plVar17[1] + 0x30))(plVar17);
            }
            if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
              (**(code **)(plVar14[1] + 0x30))(plVar14);
            }
            goto LAB_1408b8856;
          }
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
            (**(code **)(plVar15[1] + 0x30))(plVar15);
          }
        }
        if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
           (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
          (**(code **)(plVar16[1] + 0x30))(plVar16);
        }
        if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
          (**(code **)(plVar14[1] + 0x30))(plVar14);
        }
        if (plVar13 == (longlong *)0x0) {
          FUN_142cd4900(tstate,&lStackX_20,classes_const_1759_atual);
          FUN_1400048d0(tstate,lStackX_20);
          uStackX_18 = 0x2091;
          lVar19 = lStackX_20;
          goto LAB_1408b8856;
        }
        iVar8 = FUN_142cdf5a0(plVar13,plVar9);
        if (iVar8 == -1) {
          lVar19 = *(longlong *)(tstate + 0x70);
          uStackX_18 = 0x2091;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        if (iVar8 == 1) {
          cVar24 = Nuitka_helper_142ce0f60(plVar10,2);
          if (cVar24 != '\0') {
            uVar20 = FUN_1400776a0(classes_const_257_print);
            puVar21 = 
            classes_const_1761__s__geetest_3x3__precisei_de__d_passadas_para_fixar_a_selecao;
            if (plVar2 == (longlong *)0x0) {
              FUN_142cd4900(tstate,&lStackX_20,classes_const_403_self);
              FUN_1400048d0(tstate,lStackX_20);
              uStackX_18 = 0x2098;
              lVar19 = lStackX_20;
            }
            else {
              uStackX_18 = 0x2098;
              *(undefined4 *)(plStack_c8 + 5) = 0x2098;
              lVar19 = FUN_142cd06a0(tstate,plVar2,classes_const_1346__tag);
              if (lVar19 == 0) {
                lVar19 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
              }
              else {
                plVar9 = (longlong *)FUN_142cd9440(tstate,2);
                plVar9[3] = lVar19;
                iVar8 = (int)*plVar10 + 1;
                if (iVar8 != 0) {
                  *(int *)plVar10 = iVar8;
                }
                plVar9[4] = (longlong)plVar10;
                plVar10 = (longlong *)FUN_142cbffc0(puVar21,plVar9);
                if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                }
                if (plVar10 != (longlong *)0x0) {
                  uStackX_18 = 0x2097;
                  *(undefined4 *)(plStack_c8 + 5) = 0x2097;
                  plVar9 = (longlong *)FUN_142ccfd60(tstate,uVar20,plVar10);
                  if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                    (**(code **)(plVar10[1] + 0x30))(plVar10);
                  }
                  if (plVar9 != (longlong *)0x0) {
                    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                    }
                    goto LAB_1408b850a;
                  }
                }
                lVar19 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
              }
            }
            goto LAB_1408b8856;
          }
LAB_1408b850a:
          pcVar22 = _Py_TrueStruct_exref;
          if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
            *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
          }
          goto LAB_1408b80b7;
        }
        plVar16 = (longlong *)FUN_142cc11d0(plVar9,plVar13);
        if (plVar16 == (longlong *)0x0) {
          lVar19 = *(longlong *)(tstate + 0x70);
          uStackX_18 = 0x209e;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
           (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
          (**(code **)(plStack_98[1] + 0x30))();
        }
        plVar13 = (longlong *)FUN_142cc11d0(plVar13,plVar9);
        plStack_98 = plVar16;
        if (plVar13 == (longlong *)0x0) {
          lVar19 = *(longlong *)(tstate + 0x70);
          uStackX_18 = 0x209f;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
           (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
          (**(code **)(plStack_90[1] + 0x30))(plStack_90);
        }
        plStack_90 = plVar13;
        if (plVar1 == (longlong *)0x0) {
          FUN_142cd4880(tstate,&lStackX_20,classes_const_1762_alvos);
          FUN_1400048d0(tstate,lStackX_20);
          lVar19 = lStackX_20;
LAB_1408b8368:
          uStackX_18 = 0x20a0;
          goto LAB_1408b8856;
        }
        plVar15 = (longlong *)FUN_140009850(tstate,plVar1);
        if (plVar15 == (longlong *)0x0) {
          lVar19 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          uStackX_18 = 0x20a0;
          goto LAB_1408b8856;
        }
        plVar17 = (longlong *)FUN_142cd8f90(tstate,0);
        plVar14 = (longlong *)0x0;
        while (*(code **)(plVar15[1] + 0xe0) != (code *)0x0) {
          plVar18 = (longlong *)(**(code **)(plVar15[1] + 0xe0))(plVar15);
          if (plVar18 == (longlong *)0x0) goto LAB_1408b7694;
          if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
             (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))();
          }
          iVar8 = (int)*plVar18 + 1;
          if (iVar8 != 0) {
            *(int *)plVar18 = iVar8;
          }
          if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
             (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))();
          }
          iVar8 = PySequence_Contains(plVar16,plVar18);
          plVar14 = plVar18;
          if ((iVar8 == -1) ||
             ((iVar8 == 1 && (cVar24 = FUN_142cd7140(plVar17,plVar18), cVar24 == '\0'))))
          goto LAB_1408b75b2;
          if (((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
             ((iVar8 = Py_MakePendingCalls(), iVar8 < 0 &&
              (lVar19 = *(longlong *)(tstate + 0x70), lVar19 != 0)))) goto LAB_1408b75b6;
          if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
            PyEval_SaveThread();
            PyEval_AcquireThread(tstate);
          }
          if (*(longlong *)(tstate + 0x90) != 0) {
            plVar9 = *(longlong **)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x90) = 0;
            lVar19 = FUN_142cd9e70(tstate);
            *(longlong *)(tstate + 0x70) = lVar19;
            if ((plVar9 == (longlong *)0x0) || ((int)*plVar9 < 0)) goto LAB_1408b75b6;
            *plVar9 = *plVar9 + -1;
            if (*plVar9 == 0) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
            goto LAB_1408b75b2;
          }
        }
        Nuitka_helper_142ce5050(&UNK_142d0adb0,plVar15);
LAB_1408b7694:
        plVar16 = *(longlong **)(tstate + 0x70);
        if (plVar16 != (longlong *)0x0) {
          plVar18 = plVar16;
          if ((*(uint *)((longlong *)plVar16[1] + 0x15) & 0x40000000) != 0) {
            plVar18 = (longlong *)plVar16[1];
          }
          if ((plVar18 != *(longlong **)PyExc_StopIteration_exref) &&
             (((-1 < *(int *)(plVar18[1] + 0xa8) || ((*(uint *)(plVar18 + 0x15) & 0x40000000) == 0))
              || (cVar24 = Nuitka_helper_142cdd950(), cVar24 != '\x01')))) {
LAB_1408b75b2:
            lVar19 = *(longlong *)(tstate + 0x70);
LAB_1408b75b6:
            *(undefined8 *)(tstate + 0x70) = 0;
            lStackX_20 = 0;
            if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
              (**(code **)(plVar15[1] + 0x30))(plVar15);
            }
            if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
              (**(code **)(plVar17[1] + 0x30))(plVar17);
            }
            if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
               (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
              (**(code **)(plVar14[1] + 0x30))(plVar14);
            }
            lStackX_20 = 0;
            if (((plVar14 == (longlong *)0x0) || ((int)*plVar14 < 0)) ||
               (*plVar14 = *plVar14 + -1, *plVar14 != 0)) goto LAB_1408b8368;
            (**(code **)(plVar14[1] + 0x30))(plVar14);
            uStackX_18 = 0x20a0;
            goto LAB_1408b8856;
          }
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
            (**(code **)(plVar16[1] + 0x30))(plVar16);
          }
        }
        iVar8 = (int)*plVar17 + 1;
        if (iVar8 != 0) {
          *(int *)plVar17 = iVar8;
        }
        if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))(plVar15);
        }
        if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
          (**(code **)(plVar17[1] + 0x30))(plVar17);
        }
        if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
           (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
          (**(code **)(plVar14[1] + 0x30))(plVar14);
        }
        if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
           (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
          (**(code **)(plVar14[1] + 0x30))(plVar14);
        }
        plVar16 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_1170_sorted);
        if ((plVar16 == (longlong *)0x0) || (lVar19 = *plVar16, lVar19 == 0)) {
          PyErr_PrintEx(0);
          Py_Exit(1);
          pcVar22 = (code *)swi(3);
          puVar21 = (undefined *)(*pcVar22)();
          return puVar21;
        }
        *(undefined4 *)(plStack_c8 + 5) = 0x20a0;
        plVar13 = (longlong *)FUN_142ccfd60(tstate,lVar19,plVar13);
        if (plVar13 == (longlong *)0x0) {
          lStackX_20 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
            (**(code **)(plVar17[1] + 0x30))(plVar17);
          }
          uStackX_18 = 0x20a0;
          lVar19 = lStackX_20;
          goto LAB_1408b8856;
        }
        plVar16 = (longlong *)FUN_142cbe7f0(plVar17,plVar13);
        if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
          (**(code **)(plVar17[1] + 0x30))(plVar17);
        }
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if (plVar16 == (longlong *)0x0) {
          lVar19 = *(longlong *)(tstate + 0x70);
          uStackX_18 = 0x20a0;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        if (((plStack_88 != (longlong *)0x0) && (-1 < (int)*plStack_88)) &&
           (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
          (**(code **)(plStack_88[1] + 0x30))();
        }
        plVar13 = (longlong *)FUN_140009850(tstate,plVar16);
        plStack_88 = plVar16;
        if (plVar13 == (longlong *)0x0) {
          lVar19 = *(longlong *)(tstate + 0x70);
          uStackX_18 = 0x20a1;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        plVar16 = (longlong *)0x0;
LAB_1408b7850:
        if (*(code **)(plVar13[1] + 0xe0) != (code *)0x0) {
          plVar15 = (longlong *)(**(code **)(plVar13[1] + 0xe0))(plVar13);
          if (plVar15 == (longlong *)0x0) goto LAB_1408b7b63;
          if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
             (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
            (**(code **)(plVar16[1] + 0x30))(plVar16,plVar16);
          }
          iVar8 = (int)*plVar15 + 1;
          if (iVar8 != 0) {
            *(int *)plVar15 = iVar8;
          }
          if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
             (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
            (**(code **)(plStack_a8[1] + 0x30))();
          }
          plVar16 = plVar15;
          plStack_a8 = plVar15;
          if (plVar2 == (longlong *)0x0) {
            FUN_142cd4900(tstate,&lStackX_20,classes_const_403_self);
            FUN_1400048d0(tstate,lStackX_20);
            uStackX_18 = 0x20a5;
            lVar19 = lStackX_20;
            goto LAB_1408b81bb;
          }
          *(undefined4 *)(plStack_c8 + 5) = 0x20a5;
          plVar14 = (longlong *)
                    FUN_142cd06a0(tstate,plVar2,classes_const_1763__geetest_nine_na_tela);
          if (plVar14 == (longlong *)0x0) {
LAB_1408b8144:
            lVar19 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            uStackX_18 = 0x20a5;
            goto LAB_1408b81bb;
          }
          iVar8 = FUN_140004970(plVar14);
          if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))(plVar14);
          }
          if (iVar8 == -1) goto LAB_1408b8144;
          if (iVar8 != 0) {
            plVar14 = (longlong *)FUN_142cd7b20(tstate,plVar2,classes_const_1765__tocar_ponto);
            if (plVar14 == (longlong *)0x0) {
              lVar19 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              uStackX_18 = 0x20a8;
            }
            else {
              plVar17 = (longlong *)FUN_140008da0(tstate,plVar3,plVar15);
              if (plVar17 == (longlong *)0x0) {
                lStackX_20 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                  (**(code **)(plVar14[1] + 0x30))(plVar14);
                }
                uStackX_18 = 0x20a8;
                lVar19 = lStackX_20;
              }
              else {
                plVar18 = (longlong *)FUN_140008da0(tstate,plVar17,classes_const_309_x);
                if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
                  (**(code **)(plVar17[1] + 0x30))(plVar17);
                }
                if (plVar18 == (longlong *)0x0) {
                  lStackX_20 = *(longlong *)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                    (**(code **)(plVar14[1] + 0x30))(plVar14);
                  }
                  uStackX_18 = 0x20a8;
                  lVar19 = lStackX_20;
                }
                else {
                  plVar15 = (longlong *)FUN_140008da0(tstate,plVar3,plVar15);
                  if (plVar15 == (longlong *)0x0) {
LAB_1408b7e95:
                    lStackX_20 = *(longlong *)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x70) = 0;
                    if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                      (**(code **)(plVar14[1] + 0x30))(plVar14);
                    }
                    if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                      (**(code **)(plVar18[1] + 0x30))(plVar18);
                    }
                    uStackX_18 = 0x20a8;
                    lVar19 = lStackX_20;
                  }
                  else {
                    plVar17 = (longlong *)FUN_140008da0(tstate,plVar15,classes_const_310_y);
                    if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                      (**(code **)(plVar15[1] + 0x30))(plVar15);
                    }
                    if (plVar17 == (longlong *)0x0) goto LAB_1408b7e95;
                    *(undefined4 *)(plStack_c8 + 5) = 0x20a8;
                    plStack_48 = plVar18;
                    plStack_40 = plVar17;
                    plVar15 = (longlong *)FUN_142cc4ec0(tstate,plVar14,&plStack_48);
                    if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                      (**(code **)(plVar14[1] + 0x30))(plVar14);
                    }
                    if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                      (**(code **)(plVar18[1] + 0x30))(plVar18);
                    }
                    if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
                      (**(code **)(plVar17[1] + 0x30))(plVar17);
                    }
                    if (plVar15 == (longlong *)0x0) {
                      uStackX_18 = 0x20a8;
                      goto LAB_1408b800c;
                    }
                    if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                      (**(code **)(plVar15[1] + 0x30))(plVar15);
                    }
                    lVar19 = FUN_140a3b210(tstate);
                    if (lVar19 == 0) {
                      FUN_142cde870(tstate,&lStackX_20,classes_const_76_time);
                      uStackX_18 = 0x20a9;
                      lVar19 = lStackX_20;
                    }
                    else {
                      *(undefined4 *)(plStack_c8 + 5) = 0x20a9;
                      plVar15 = (longlong *)
                                FUN_142cd12f0(tstate,lVar19,classes_const_77_sleep,
                                              *(undefined8 *)
                                               (classes_const_1766___type____T____items____0_28__ +
                                               0x18));
                      if (plVar15 != (longlong *)0x0) {
                        if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                          (**(code **)(plVar15[1] + 0x30))(plVar15);
                        }
                        if ((((*(ulonglong *)(tstate + 0x18) & 6) == 0) ||
                            (iVar8 = Py_MakePendingCalls(), -1 < iVar8)) ||
                           (lVar19 = *(longlong *)(tstate + 0x70), lVar19 == 0)) goto LAB_1408b7ad5;
                        goto LAB_1408b7b38;
                      }
                      lVar19 = *(longlong *)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      uStackX_18 = 0x20a9;
                    }
                  }
                }
              }
            }
            goto LAB_1408b81bb;
          }
          uVar20 = FUN_1400776a0(classes_const_257_print);
          puVar21 = classes_const_1764__s__geetest_3x3__a_grade_fechou___parando_de_tocar;
          uStackX_18 = 0x20a6;
          *(undefined4 *)(plStack_c8 + 5) = 0x20a6;
          plVar9 = (longlong *)FUN_142cd06a0(tstate,plVar2,classes_const_1346__tag);
          if (plVar9 == (longlong *)0x0) {
            lVar19 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            goto LAB_1408b81bb;
          }
          plVar10 = (longlong *)FUN_142cbff90(puVar21,plVar9);
          if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
            (**(code **)(plVar9[1] + 0x30))(plVar9);
          }
          if (plVar10 != (longlong *)0x0) {
            *(undefined4 *)(plStack_c8 + 5) = 0x20a6;
            plVar9 = (longlong *)FUN_142ccfd60(tstate,uVar20,plVar10);
            if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
              (**(code **)(plVar10[1] + 0x30))(plVar10);
            }
            if (plVar9 != (longlong *)0x0) {
              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              pcVar22 = _Py_TrueStruct_exref;
              if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
                *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
              }
              if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                (**(code **)(plVar15[1] + 0x30))(plVar15);
              }
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              goto LAB_1408b80b7;
            }
          }
LAB_1408b800c:
          lVar19 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b81bb;
        }
        Nuitka_helper_142ce5050(&UNK_142d0adb0,plVar13);
LAB_1408b7b63:
        plVar15 = *(longlong **)(tstate + 0x70);
        if (plVar15 != (longlong *)0x0) {
          plVar14 = plVar15;
          if ((*(uint *)((longlong *)plVar15[1] + 0x15) & 0x40000000) != 0) {
            plVar14 = (longlong *)plVar15[1];
          }
          if ((plVar14 != *(longlong **)PyExc_StopIteration_exref) &&
             (((-1 < *(int *)(plVar14[1] + 0xa8) || ((*(uint *)(plVar14 + 0x15) & 0x40000000) == 0))
              || (cVar24 = Nuitka_helper_142cdd950(), cVar24 != '\x01')))) {
            lVar19 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            uStackX_18 = 0x20a1;
            lStackX_20 = 0;
            if (plVar16 != (longlong *)0x0) {
LAB_1408b81bb:
              lStackX_20 = 0;
              if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                (**(code **)(plVar16[1] + 0x30))(plVar16);
              }
            }
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
            }
            goto LAB_1408b8856;
          }
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
            (**(code **)(plVar15[1] + 0x30))(plVar15);
          }
        }
        if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
           (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
          (**(code **)(plVar16[1] + 0x30))(plVar16);
        }
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        lVar19 = FUN_140a3b210(tstate);
        if (lVar19 == 0) {
          FUN_142cde870(tstate,&lStackX_20,classes_const_76_time);
          uStackX_18 = 0x20aa;
          lVar19 = lStackX_20;
          goto LAB_1408b8856;
        }
        *(undefined4 *)(plStack_c8 + 5) = 0x20aa;
        plVar13 = (longlong *)
                  FUN_142cd12f0(tstate,lVar19,classes_const_77_sleep,
                                *(undefined8 *)
                                 (classes_const_1767___type____T____items____0_35__ + 0x18));
        if (plVar13 == (longlong *)0x0) {
          lVar19 = *(longlong *)(tstate + 0x70);
          uStackX_18 = 0x20aa;
          *(undefined8 *)(tstate + 0x70) = 0;
          goto LAB_1408b8856;
        }
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
            (iVar8 = Py_MakePendingCalls(), iVar8 < 0)) &&
           (lVar19 = *(longlong *)(tstate + 0x70), lVar19 != 0)) goto LAB_1408b825a;
        if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
          PyEval_SaveThread();
          PyEval_AcquireThread(tstate);
        }
        if (*(longlong *)(tstate + 0x90) != 0) {
          plVar9 = *(longlong **)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x90) = 0;
          lVar19 = FUN_142cd9e70(tstate);
          *(longlong *)(tstate + 0x70) = lVar19;
          if ((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) {
            *plVar9 = *plVar9 + -1;
            if (*plVar9 == 0) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
            goto LAB_1408b8256;
          }
          goto LAB_1408b825a;
        }
      } while (plVar10 != (longlong *)0x0);
      FUN_142cd4900(tstate,&lStackX_20,classes_const_1754_passada);
      FUN_1400048d0(tstate,lStackX_20);
      uStackX_18 = 0x207e;
      lVar19 = lStackX_20;
    }
  }
LAB_1408b8856:
  lStackX_20 = lVar19;
  piVar7 = *(int **)(lStackX_20 + 0x28);
  if (piVar7 == (int *)0x0) {
    pcVar22 = (code *)FUN_142cd9160(plStack_c8,uStackX_18);
    bVar25 = pcVar22 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar7 + 6) == plStack_c8) goto LAB_1408b8baa;
    pcVar22 = (code *)FUN_142cd9160(plStack_c8,uStackX_18);
    *(int **)(pcVar22 + 0x10) = piVar7;
    if (*piVar7 + 1 != 0) {
      *piVar7 = *piVar7 + 1;
    }
    bVar25 = pcVar22 == _Py_NoneStruct_exref;
  }
  plVar9 = *(longlong **)(lStackX_20 + 0x28);
  if (bVar25) {
    pcVar11 = (code *)0x0;
  }
  else {
    pcVar11 = pcVar22;
    if ((pcVar22 != (code *)0x0) && (*(int *)pcVar22 + 1 != 0)) {
      *(int *)pcVar22 = *(int *)pcVar22 + 1;
    }
  }
  *(code **)(lStackX_20 + 0x28) = pcVar11;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if (((pcVar22 != (code *)0x0) && (-1 < *(int *)pcVar22)) &&
     (*(longlong *)pcVar22 = *(longlong *)pcVar22 + -1, *(longlong *)pcVar22 == 0)) {
    (**(code **)(*(longlong *)(pcVar22 + 8) + 0x30))(pcVar22);
  }
LAB_1408b8baa:
  FUN_142cdb370(plStack_c8,&UNK_142d0b518,plVar2,plVar1,plVar3,plVar4,plStack_80,plStack_b0,
                pcStack_a0,plStack_b8,plStack_a8,plStack_98,plStack_90,plStack_88);
  plVar9 = _DAT_142dea730;
  if (plStack_c8 == _DAT_142dea730) {
    if ((-1 < (int)*_DAT_142dea730) && (*_DAT_142dea730 = *_DAT_142dea730 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))();
    }
    _DAT_142dea730 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar19 = lStackX_20;
  lStackX_20 = 0;
  if (((plStack_80 != (longlong *)0x0) && (-1 < (int)*plStack_80)) &&
     (*plStack_80 = *plStack_80 + -1, *plStack_80 == 0)) {
    (**(code **)(plStack_80[1] + 0x30))();
  }
  if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
     (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
    (**(code **)(plStack_b0[1] + 0x30))();
  }
  if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
     (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))(pcStack_a0);
  }
  if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
     (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
    (**(code **)(plStack_b8[1] + 0x30))(plStack_b8);
  }
  if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
     (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
    (**(code **)(plStack_a8[1] + 0x30))(plStack_a8);
  }
  if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
     (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
    (**(code **)(plStack_98[1] + 0x30))();
  }
  if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
     (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
    (**(code **)(plStack_90[1] + 0x30))();
  }
  if (((plStack_88 != (longlong *)0x0) && (-1 < (int)*plStack_88)) &&
     (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
    (**(code **)(plStack_88[1] + 0x30))();
  }
  lStackX_20 = lVar19;
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))(plVar2);
  }
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
    (**(code **)(plVar3[1] + 0x30))();
  }
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))();
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_20;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
LAB_1408b7ad5:
  if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
    PyEval_SaveThread();
    PyEval_AcquireThread(tstate);
  }
  if (*(longlong *)(tstate + 0x90) != 0) {
    plVar9 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x90) = 0;
    lVar19 = FUN_142cd9e70(tstate);
    *(longlong *)(tstate + 0x70) = lVar19;
    if ((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) {
      *plVar9 = *plVar9 + -1;
      if (*plVar9 == 0) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      lVar19 = *(longlong *)(tstate + 0x70);
    }
LAB_1408b7b38:
    *(undefined8 *)(tstate + 0x70) = 0;
    uStackX_18 = 0x20a1;
    goto LAB_1408b81bb;
  }
  goto LAB_1408b7850;
}

