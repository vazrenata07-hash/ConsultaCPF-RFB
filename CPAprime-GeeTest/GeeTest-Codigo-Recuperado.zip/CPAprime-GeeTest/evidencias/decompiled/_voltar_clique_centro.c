
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _voltar_clique_centro(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  int *piVar4;
  int *piVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  char cVar9;
  int iVar10;
  code *pcVar11;
  code *pcVar12;
  undefined8 uVar13;
  bool bVar14;
  longlong alStackX_18 [2];
  
  plVar8 = _DAT_142dea728;
  plVar1 = (longlong *)*python_pars;
  plVar2 = (longlong *)python_pars[1];
  if (_DAT_142dea728 == (longlong *)0x0) {
LAB_1408b6838:
    _DAT_142dea728 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9e08,_DAT_142f2aaf0,0x10);
  }
  else if ((1 < *_DAT_142dea728) || (_DAT_142dea728[2] != 0)) {
    if ((_DAT_142dea728 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea728 && (*_DAT_142dea728 = *_DAT_142dea728 + -1, *plVar8 == 0)))) {
      (**(code **)(plVar8[1] + 0x30))(plVar8);
    }
    goto LAB_1408b6838;
  }
  plVar8 = _DAT_142dea728;
  Nuitka_helper_140008a00(tstate,_DAT_142dea728);
  cVar9 = FUN_142ce4bf0(tstate,plVar1,classes_const_177_clique_centro_ativo,plVar2);
  if (cVar9 != '\0') {
LAB_1408b6ba6:
    FUN_140008990(tstate);
    pcVar11 = _Py_NoneStruct_exref;
    if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
      *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
    }
    if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
      (**(code **)(plVar1[1] + 0x30))(plVar1);
    }
    if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
      (**(code **)(plVar2[1] + 0x30))(plVar2);
    }
    return pcVar11;
  }
  lVar3 = *(longlong *)(tstate + 0x70);
  *(undefined8 *)(tstate + 0x70) = 0;
  piVar4 = *(int **)(tstate + 0xf8);
  alStackX_18[0] = 0;
  if ((piVar4 != (int *)0x0) && (*piVar4 + 1 != 0)) {
    *piVar4 = *piVar4 + 1;
  }
  piVar5 = *(int **)(lVar3 + 0x28);
  pcVar11 = (code *)FUN_142cd9160(plVar8,0x206a);
  if (piVar5 != (int *)0x0) {
    *(int **)(pcVar11 + 0x10) = piVar5;
    if (*piVar5 + 1 != 0) {
      *piVar5 = *piVar5 + 1;
    }
  }
  plVar6 = *(longlong **)(lVar3 + 0x28);
  if (pcVar11 == _Py_NoneStruct_exref) {
    pcVar12 = (code *)0x0;
  }
  else {
    pcVar12 = pcVar11;
    if ((pcVar11 != (code *)0x0) && (*(int *)pcVar11 + 1 != 0)) {
      *(int *)pcVar11 = *(int *)pcVar11 + 1;
    }
  }
  *(code **)(lVar3 + 0x28) = pcVar12;
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))();
  }
  if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
     (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
    (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
  }
  plVar6 = *(longlong **)(tstate + 0xf8);
  *(longlong *)(tstate + 0xf8) = lVar3;
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))();
  }
  iVar10 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                         *(undefined8 *)PyExc_Exception_exref);
  if (iVar10 != 0) {
    plVar8 = *(longlong **)(tstate + 0xf8);
    *(int **)(tstate + 0xf8) = piVar4;
    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    goto LAB_1408b6ba6;
  }
  cVar9 = FUN_142cded30(tstate,alStackX_18);
  lVar3 = alStackX_18[0];
  uVar13 = 0x2069;
  if (cVar9 != '\0') {
    uVar13 = 0;
  }
  lVar7 = *(longlong *)(alStackX_18[0] + 0x28);
  if ((lVar7 != 0) && (*(longlong **)(lVar7 + 0x18) == plVar8)) {
    *(undefined4 *)(plVar8 + 5) = *(undefined4 *)(lVar7 + 0x24);
  }
  alStackX_18[0] = 0;
  plVar6 = *(longlong **)(tstate + 0xf8);
  *(int **)(tstate + 0xf8) = piVar4;
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))();
  }
  piVar4 = *(int **)(lVar3 + 0x28);
  alStackX_18[0] = lVar3;
  if (piVar4 == (int *)0x0) {
    pcVar11 = (code *)FUN_142cd9160(plVar8,uVar13);
    bVar14 = pcVar11 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar4 + 6) == plVar8) goto LAB_1408b6a9e;
    pcVar11 = (code *)FUN_142cd9160(plVar8,uVar13);
    *(int **)(pcVar11 + 0x10) = piVar4;
    if (*piVar4 + 1 != 0) {
      *piVar4 = *piVar4 + 1;
    }
    bVar14 = pcVar11 == _Py_NoneStruct_exref;
  }
  plVar6 = *(longlong **)(alStackX_18[0] + 0x28);
  if (bVar14) {
    pcVar12 = (code *)0x0;
  }
  else {
    pcVar12 = pcVar11;
    if ((pcVar11 != (code *)0x0) && (*(int *)pcVar11 + 1 != 0)) {
      *(int *)pcVar11 = *(int *)pcVar11 + 1;
    }
  }
  *(code **)(alStackX_18[0] + 0x28) = pcVar12;
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))();
  }
  if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
     (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
    (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
  }
LAB_1408b6a9e:
  FUN_142cdb370(plVar8,&UNK_142d0ae3c,plVar1,plVar2);
  plVar6 = _DAT_142dea728;
  if (plVar8 == _DAT_142dea728) {
    if ((-1 < (int)*_DAT_142dea728) && (*_DAT_142dea728 = *_DAT_142dea728 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))();
    }
    _DAT_142dea728 = (longlong *)0x0;
  }
  plVar8 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar8 + 10) = 0xfffffffe;
  plVar6 = (longlong *)plVar8[2];
  if (((plVar6 != (longlong *)0x0) && (plVar8[2] = 0, -1 < (int)*plVar6)) &&
     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
    (**(code **)(plVar6[1] + 0x30))();
  }
  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
    (**(code **)(plVar8[1] + 0x30))(plVar8);
  }
  plVar8[0xc] = 0;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))(plVar2);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = alStackX_18[0];
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

