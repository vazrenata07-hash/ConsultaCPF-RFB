
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _dhash_celula(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong *plVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined8 uVar14;
  undefined *puVar15;
  code *pcVar16;
  code *pcVar17;
  longlong lVar18;
  longlong *plVar19;
  undefined8 uVar20;
  bool bVar21;
  longlong lStackX_18;
  longlong *plStackX_20;
  longlong *plStack_b8;
  longlong *plStack_a8;
  longlong *plStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_68;
  longlong *plStack_60;
  longlong *plStack_58;
  longlong *plStack_50;
  undefined *puStack_48;
  
  plVar6 = _DAT_142dea788;
  plVar1 = (longlong *)*python_pars;
  plVar10 = (longlong *)0x0;
  plVar19 = (longlong *)0x0;
  plVar2 = (longlong *)python_pars[1];
  lStackX_18 = 0;
  plStack_a0 = (longlong *)0x0;
  plStack_a8 = (longlong *)0x0;
  plStack_98 = (longlong *)0x0;
  plStackX_20 = (longlong *)0x0;
  plStack_b8 = _DAT_142dea788;
  if (_DAT_142dea788 == (longlong *)0x0) {
LAB_1408c9288:
    plStack_b8 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9af0,_DAT_142f2aaf0,0x40);
  }
  else if ((1 < *_DAT_142dea788) || (_DAT_142dea788[2] != 0)) {
    if ((_DAT_142dea788 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea788 && (*_DAT_142dea788 = *_DAT_142dea788 + -1, *plVar6 == 0)))) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
    goto LAB_1408c9288;
  }
  _DAT_142dea788 = plStack_b8;
  Nuitka_helper_140008a00(tstate,plStack_b8);
  uVar14 = _DAT_142f2aae8;
  puVar15 = classes_const_1774_numpy;
  plVar6 = _DAT_142d9a260;
  pcVar16 = _Py_NoneStruct_exref;
  uVar20 = 0x229f;
  *(undefined4 *)(plStack_b8 + 5) = 0x229f;
  plStack_90 = (longlong *)FUN_142cd5880(tstate,puVar15,uVar14,pcVar16,pcVar16,plVar6);
  uVar14 = _DAT_142f2aae8;
  puVar15 = classes_const_1775_cv2;
  plVar6 = _DAT_142d9a260;
  pcVar16 = _Py_NoneStruct_exref;
  if (plStack_90 == (longlong *)0x0) {
    lVar18 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    plStack_90 = (longlong *)0x0;
    plVar19 = plVar10;
  }
  else {
    uVar20 = 0x22a0;
    *(undefined4 *)(plStack_b8 + 5) = 0x22a0;
    plVar6 = (longlong *)FUN_142cd5880(tstate,puVar15,uVar14,pcVar16,pcVar16,plVar6);
    if (plVar6 == (longlong *)0x0) {
      lVar18 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      plVar10 = (longlong *)0x0;
    }
    else {
      plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_1827_cvtColor);
      plStack_a0 = plVar6;
      if (plVar7 == (longlong *)0x0) {
        lVar18 = *(longlong *)(tstate + 0x70);
        uVar20 = 0x22a1;
        *(undefined8 *)(tstate + 0x70) = 0;
        plVar10 = (longlong *)0x0;
      }
      else {
        plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_1833_COLOR_BGR2GRAY);
        if (plVar8 == (longlong *)0x0) {
          lStackX_18 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
            (**(code **)(plVar7[1] + 0x30))(plVar7);
          }
          uVar20 = 0x22a1;
          plVar19 = plVar10;
          lVar18 = lStackX_18;
        }
        else {
          uVar20 = 0x22a1;
          *(undefined4 *)(plStack_b8 + 5) = 0x22a1;
          plStack_60 = plVar2;
          plStack_58 = plVar8;
          plVar9 = (longlong *)FUN_142cc4ec0(tstate,plVar7,&plStack_60);
          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
            (**(code **)(plVar7[1] + 0x30))(plVar7);
          }
          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
            (**(code **)(plVar8[1] + 0x30))(plVar8);
          }
          if (plVar9 == (longlong *)0x0) {
            lVar18 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            plVar10 = (longlong *)0x0;
          }
          else {
            plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_1787_resize);
            puVar15 = classes_const_1903___type____T____items____9__8__;
            plStack_a8 = plVar9;
            if (plVar7 == (longlong *)0x0) {
              lVar18 = *(longlong *)(tstate + 0x70);
              uVar20 = 0x22a2;
              *(undefined8 *)(tstate + 0x70) = 0;
              plVar10 = (longlong *)0x0;
            }
            else {
              plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_1904_INTER_AREA);
              if (plVar8 == (longlong *)0x0) {
                lStackX_18 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                }
                uVar20 = 0x22a2;
                plVar10 = (longlong *)0x0;
                lVar18 = lStackX_18;
              }
              else {
                uVar20 = 0x22a2;
                puStack_48 = puVar15;
                *(undefined4 *)(plStack_b8 + 5) = 0x22a2;
                plStack_68 = plVar8;
                plStack_50 = plVar9;
                plStack_a8 = (longlong *)
                             FUN_142cc5940(tstate,plVar7,&plStack_50,&plStack_68,
                                           classes_const_1905___type____T____items_____interpolation___
                                          );
                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                }
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                if (plStack_a8 == (longlong *)0x0) {
                  lVar18 = *(longlong *)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  plVar19 = plVar10;
                  plStack_a8 = plVar9;
                }
                else {
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  plVar10 = (longlong *)
                            FUN_140008da0(tstate,plStack_a8,
                                          classes_const_1906___type____T____items______type_________items____None__None__None_
                                         );
                  if (plVar10 == (longlong *)0x0) {
LAB_1408c9587:
                    lVar18 = *(longlong *)(tstate + 0x70);
                    uVar20 = 0x22a3;
                    *(undefined8 *)(tstate + 0x70) = 0;
                    plVar10 = (longlong *)0x0;
                  }
                  else {
                    plVar7 = (longlong *)
                             FUN_140008da0(tstate,plStack_a8,
                                           classes_const_1907___type____T____items______type_________items____None__None__None_
                                          );
                    if (plVar7 == (longlong *)0x0) {
                      lStackX_18 = *(longlong *)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                        (**(code **)(plVar10[1] + 0x30))(plVar10);
                      }
                      uVar20 = 0x22a3;
                      plVar10 = (longlong *)0x0;
                      lVar18 = lStackX_18;
                    }
                    else {
                      plVar8 = (longlong *)FUN_142ce1980(plVar10,plVar7);
                      if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                        (**(code **)(plVar10[1] + 0x30))(plVar10);
                      }
                      if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                        (**(code **)(plVar7[1] + 0x30))(plVar7);
                      }
                      plVar10 = _DAT_142d9a260;
                      if (plVar8 == (longlong *)0x0) goto LAB_1408c9587;
                      iVar5 = (int)*_DAT_142d9a260 + 1;
                      if (iVar5 != 0) {
                        *(int *)_DAT_142d9a260 = iVar5;
                      }
                      uVar20 = 0x22a5;
                      *(undefined4 *)(plStack_b8 + 5) = 0x22a5;
                      plVar7 = (longlong *)FUN_142cd06a0(tstate,plVar8,classes_const_1908_flatten);
                      plVar19 = plVar10;
                      plStack_98 = plVar8;
                      if (plVar7 != (longlong *)0x0) {
                        plVar9 = (longlong *)FUN_140009850(tstate,plVar7);
                        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                        }
                        if (plVar9 != (longlong *)0x0) {
                          plVar7 = (longlong *)0x0;
                          do {
                            if (*(code **)(plVar9[1] + 0xe0) == (code *)0x0) {
                              Nuitka_helper_142ce5050(&UNK_142d0adb0,plVar9);
LAB_1408c991d:
                              plVar10 = *(longlong **)(tstate + 0x70);
                              if (plVar10 != (longlong *)0x0) {
                                plVar11 = (longlong *)plVar10[1];
                                if ((*(uint *)((longlong *)plVar10[1] + 0x15) & 0x40000000) == 0) {
                                  plVar11 = plVar10;
                                }
                                if ((plVar11 != *(longlong **)PyExc_StopIteration_exref) &&
                                   (((-1 < *(int *)(plVar11[1] + 0xa8) ||
                                     ((*(uint *)(plVar11 + 0x15) & 0x40000000) == 0)) ||
                                    (cVar4 = Nuitka_helper_142cdd950(), cVar4 != '\x01')))) {
                                  lVar18 = *(longlong *)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  lStackX_18 = 0;
                                  plVar10 = plStackX_20;
                                  if (plVar7 != (longlong *)0x0) goto LAB_1408c9985;
                                  goto LAB_1408c999e;
                                }
                                *(undefined8 *)(tstate + 0x70) = 0;
                                if ((-1 < (int)*plVar10) &&
                                   (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                                  (**(code **)(plVar10[1] + 0x30))(plVar10);
                                }
                              }
                              if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                                 (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                              }
                              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                              }
                              if (plVar19 == (longlong *)0x0) {
                                FUN_142cd4900(tstate,&lStackX_18,classes_const_587_v);
                                FUN_1400048d0(tstate,lStackX_18);
                                uVar20 = 0x22a7;
                                plVar10 = plStackX_20;
                                lVar18 = lStackX_18;
                              }
                              else {
                                puVar15 = (undefined *)
                                          FUN_142cbff90(classes_const_1909__016x,plVar19);
                                if (puVar15 != (undefined *)0x0) {
                                  FUN_140008990(tstate);
                                  if ((-1 < (int)*plStack_90) &&
                                     (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
                                    (**(code **)(plStack_90[1] + 0x30))();
                                  }
                                  if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0))
                                  {
                                    (**(code **)(plVar6[1] + 0x30))();
                                  }
                                  if ((-1 < (int)*plStack_a8) &&
                                     (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
                                    (**(code **)(plStack_a8[1] + 0x30))();
                                  }
                                  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                  {
                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                  }
                                  if ((-1 < (int)*plVar19) &&
                                     (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                                    (**(code **)(plVar19[1] + 0x30))(plVar19);
                                  }
                                  if (((plStackX_20 != (longlong *)0x0) && (-1 < (int)*plStackX_20))
                                     && (*plStackX_20 = *plStackX_20 + -1, *plStackX_20 == 0)) {
                                    (**(code **)(plStackX_20[1] + 0x30))();
                                  }
                                  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0))
                                  {
                                    (**(code **)(plVar1[1] + 0x30))();
                                  }
                                  if ((int)*plVar2 < 0) {
                                    return puVar15;
                                  }
                                  *plVar2 = *plVar2 + -1;
                                  if (*plVar2 != 0) {
                                    return puVar15;
                                  }
                                  (**(code **)(plVar2[1] + 0x30))();
                                  return puVar15;
                                }
                                lVar18 = *(longlong *)(tstate + 0x70);
                                uVar20 = 0x22a7;
                                *(undefined8 *)(tstate + 0x70) = 0;
                                plVar10 = plStackX_20;
                              }
                              goto LAB_1408c9a7d;
                            }
                            plVar10 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
                            plVar11 = plStackX_20;
                            if (plVar10 == (longlong *)0x0) goto LAB_1408c991d;
                            if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) &&
                               (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                              (**(code **)(plVar7[1] + 0x30))();
                            }
                            iVar5 = (int)*plVar10 + 1;
                            if (iVar5 != 0) {
                              *(int *)plVar10 = iVar5;
                            }
                            plStackX_20 = plVar10;
                            if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                               (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))();
                            }
                            plVar7 = plVar10;
                            if (plVar19 == (longlong *)0x0) {
                              FUN_142cd4900(tstate,&lStackX_18,classes_const_587_v);
                              FUN_1400048d0(tstate,lStackX_18);
                              uVar20 = 0x22a6;
                              lVar18 = lStackX_18;
                              goto LAB_1408c9985;
                            }
                            plVar11 = (longlong *)FUN_142cbf700(plVar19,_DAT_142d9a268);
                            if (plVar11 == (longlong *)0x0) {
                              lVar18 = *(longlong *)(tstate + 0x70);
                              uVar20 = 0x22a6;
                              *(undefined8 *)(tstate + 0x70) = 0;
                              goto LAB_1408c9985;
                            }
                            plVar12 = (longlong *)PyNumber_Long();
                            if (plVar12 == (longlong *)0x0) {
                              lStackX_18 = *(longlong *)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0))
                              {
                                (**(code **)(plVar11[1] + 0x30))();
                              }
                              uVar20 = 0x22a6;
                              lVar18 = lStackX_18;
                              goto LAB_1408c9985;
                            }
                            plVar13 = (longlong *)FUN_142cbee60(plVar11,plVar12);
                            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                            }
                            if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                              (**(code **)(plVar12[1] + 0x30))(plVar12);
                            }
                            if (plVar13 == (longlong *)0x0) {
                              lVar18 = *(longlong *)(tstate + 0x70);
                              uVar20 = 0x22a6;
                              *(undefined8 *)(tstate + 0x70) = 0;
                              goto LAB_1408c9985;
                            }
                            if ((-1 < (int)*plVar19) && (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
                              (**(code **)(plVar19[1] + 0x30))();
                            }
                            plVar19 = plVar13;
                            if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                                (iVar5 = Py_MakePendingCalls(), iVar5 < 0)) &&
                               (*(longlong *)(tstate + 0x70) != 0)) goto LAB_1408c9845;
                            if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                              PyEval_SaveThread();
                              PyEval_AcquireThread(tstate);
                            }
                          } while (*(longlong *)(tstate + 0x90) == 0);
                          plVar6 = *(longlong **)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x90) = 0;
                          uVar14 = FUN_142cd9e70();
                          *(undefined8 *)(tstate + 0x70) = uVar14;
                          if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) &&
                             (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                            (**(code **)(plVar6[1] + 0x30))();
                          }
LAB_1408c9845:
                          lVar18 = *(longlong *)(tstate + 0x70);
                          *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408c9985:
                          lStackX_18 = 0;
                          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                            (**(code **)(plVar7[1] + 0x30))(plVar7);
                          }
LAB_1408c999e:
                          if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                            (**(code **)(plVar9[1] + 0x30))(plVar9);
                          }
                          goto LAB_1408c9a7d;
                        }
                      }
                      lVar18 = *(longlong *)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      plVar10 = plStackX_20;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
LAB_1408c9a7d:
  lStackX_18 = lVar18;
  piVar3 = *(int **)(lStackX_18 + 0x28);
  if (piVar3 == (int *)0x0) {
    pcVar16 = (code *)FUN_142cd9160(plStack_b8,uVar20);
    bVar21 = pcVar16 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar3 + 6) == plStack_b8) goto LAB_1408c9b1d;
    pcVar16 = (code *)FUN_142cd9160(plStack_b8,uVar20);
    *(int **)(pcVar16 + 0x10) = piVar3;
    if (*piVar3 + 1 != 0) {
      *piVar3 = *piVar3 + 1;
    }
    bVar21 = pcVar16 == _Py_NoneStruct_exref;
  }
  plVar6 = *(longlong **)(lStackX_18 + 0x28);
  if (bVar21) {
    pcVar17 = (code *)0x0;
  }
  else {
    pcVar17 = pcVar16;
    if ((pcVar16 != (code *)0x0) && (*(int *)pcVar16 + 1 != 0)) {
      *(int *)pcVar16 = *(int *)pcVar16 + 1;
    }
  }
  *(code **)(lStackX_18 + 0x28) = pcVar17;
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))();
  }
  if (((pcVar16 != (code *)0x0) && (-1 < *(int *)pcVar16)) &&
     (*(longlong *)pcVar16 = *(longlong *)pcVar16 + -1, *(longlong *)pcVar16 == 0)) {
    (**(code **)(*(longlong *)(pcVar16 + 8) + 0x30))(pcVar16);
  }
LAB_1408c9b1d:
  FUN_142cdb370(plStack_b8,&UNK_142d0ae40,plVar1,plVar2,plStack_90,plStack_a0,plStack_a8,plStack_98,
                plVar19,plVar10);
  plVar6 = _DAT_142dea788;
  if (plStack_b8 == _DAT_142dea788) {
    if ((-1 < (int)*_DAT_142dea788) && (*_DAT_142dea788 = *_DAT_142dea788 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))();
    }
    _DAT_142dea788 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar18 = lStackX_18;
  lStackX_18 = 0;
  if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
     (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
    (**(code **)(plStack_90[1] + 0x30))(plStack_90);
  }
  if (((plStack_a0 != (longlong *)0x0) && (-1 < (int)*plStack_a0)) &&
     (*plStack_a0 = *plStack_a0 + -1, *plStack_a0 == 0)) {
    (**(code **)(plStack_a0[1] + 0x30))();
  }
  if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
     (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
    (**(code **)(plStack_a8[1] + 0x30))();
  }
  if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
     (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
    (**(code **)(plStack_98[1] + 0x30))();
  }
  if (((plVar19 != (longlong *)0x0) && (-1 < (int)*plVar19)) &&
     (*plVar19 = *plVar19 + -1, *plVar19 == 0)) {
    (**(code **)(plVar19[1] + 0x30))(plVar19);
  }
  if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))(plVar10);
  }
  lStackX_18 = lVar18;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))(plVar2);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

