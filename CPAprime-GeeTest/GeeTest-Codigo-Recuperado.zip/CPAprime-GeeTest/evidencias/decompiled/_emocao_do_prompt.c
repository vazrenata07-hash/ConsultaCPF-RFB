
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _emocao_do_prompt(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  longlong lVar3;
  int *piVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  code *pcVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  code *pcVar14;
  longlong *plVar15;
  code *pcVar16;
  undefined8 uVar17;
  bool bVar18;
  longlong lStackX_18;
  longlong *plStackX_20;
  
  plVar5 = _DAT_142dea790;
  plVar15 = (longlong *)0x0;
  plVar1 = (longlong *)*python_pars;
  plVar10 = (longlong *)python_pars[1];
  lStackX_18 = 0;
  plStackX_20 = plVar10;
  if (_DAT_142dea790 == (longlong *)0x0) {
LAB_1408c9df9:
    _DAT_142dea790 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9b18,_DAT_142f2aaf0,0x20);
  }
  else if ((1 < *_DAT_142dea790) || (_DAT_142dea790[2] != 0)) {
    if ((_DAT_142dea790 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea790 && (*_DAT_142dea790 = *_DAT_142dea790 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408c9df9;
  }
  plVar5 = _DAT_142dea790;
  Nuitka_helper_140008a00(tstate,_DAT_142dea790);
  uVar17 = 0x22b2;
  *(undefined4 *)(plVar5 + 5) = 0x22b2;
  pcVar8 = (code *)FUN_142cd06a0(tstate,plVar1,classes_const_1911__tabela_emocao);
  plVar11 = plVar15;
  if (pcVar8 == (code *)0x0) {
    lVar9 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    goto LAB_1408ca41f;
  }
  if (pcVar8 != _Py_TrueStruct_exref) {
    if ((pcVar8 != _Py_FalseStruct_exref) && (pcVar8 != _Py_NoneStruct_exref)) {
      lVar9 = *(longlong *)(pcVar8 + 8);
      if ((*(longlong *)(lVar9 + 0x60) == 0) ||
         (pcVar16 = *(code **)(*(longlong *)(lVar9 + 0x60) + 0x48), pcVar16 == (code *)0x0)) {
        if ((*(undefined8 **)(lVar9 + 0x70) == (undefined8 *)0x0) ||
           (pcVar16 = (code *)**(undefined8 **)(lVar9 + 0x70), pcVar16 == (code *)0x0)) {
          if ((*(undefined8 **)(lVar9 + 0x68) == (undefined8 *)0x0) ||
             (pcVar16 = (code *)**(undefined8 **)(lVar9 + 0x68), pcVar16 == (code *)0x0))
          goto LAB_1408c9efd;
          lVar9 = (*pcVar16)(pcVar8);
        }
        else {
          lVar9 = (*pcVar16)(pcVar8);
        }
      }
      else {
        iVar7 = (*pcVar16)(pcVar8);
        lVar9 = (longlong)iVar7;
      }
      if (0 < lVar9) goto LAB_1408c9efd;
      if (lVar9 != 0) {
        lVar9 = *(longlong *)(tstate + 0x70);
        uVar17 = 0x22b3;
        *(undefined8 *)(tstate + 0x70) = 0;
        goto LAB_1408ca41f;
      }
    }
    pcVar16 = _Py_NoneStruct_exref;
    if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
      *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
    }
    goto LAB_1408ca180;
  }
LAB_1408c9efd:
  lVar9 = FUN_140a39450(tstate);
  if (lVar9 == 0) {
    FUN_142cde870(tstate,&lStackX_18,classes_const_827_base64);
LAB_1408ca04e:
    lVar9 = lStackX_18;
    piVar4 = *(int **)(tstate + 0xf8);
    lStackX_18 = 0;
    if ((piVar4 != (int *)0x0) && (*piVar4 + 1 != 0)) {
      *piVar4 = *piVar4 + 1;
    }
    piVar2 = *(int **)(lVar9 + 0x28);
    pcVar16 = (code *)FUN_142cd9160(plVar5,0x22b6);
    if (piVar2 != (int *)0x0) {
      *(int **)(pcVar16 + 0x10) = piVar2;
      if (*piVar2 + 1 != 0) {
        *piVar2 = *piVar2 + 1;
      }
    }
    plVar10 = *(longlong **)(lVar9 + 0x28);
    if (pcVar16 == _Py_NoneStruct_exref) {
      pcVar14 = (code *)0x0;
    }
    else {
      pcVar14 = pcVar16;
      if ((pcVar16 != (code *)0x0) && (*(int *)pcVar16 + 1 != 0)) {
        *(int *)pcVar16 = *(int *)pcVar16 + 1;
      }
    }
    *(code **)(lVar9 + 0x28) = pcVar14;
    if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
       (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
      (**(code **)(plVar10[1] + 0x30))();
    }
    if (((pcVar16 != (code *)0x0) && (-1 < *(int *)pcVar16)) &&
       (*(longlong *)pcVar16 = *(longlong *)pcVar16 + -1, *(longlong *)pcVar16 == 0)) {
      (**(code **)(*(longlong *)(pcVar16 + 8) + 0x30))(pcVar16);
    }
    plVar10 = *(longlong **)(tstate + 0xf8);
    *(longlong *)(tstate + 0xf8) = lVar9;
    if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
       (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
      (**(code **)(plVar10[1] + 0x30))();
    }
    iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    pcVar16 = _Py_NoneStruct_exref;
    if (iVar7 != 0) {
      if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
        *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
      }
      plVar5 = *(longlong **)(tstate + 0xf8);
      *(int **)(tstate + 0xf8) = piVar4;
      plVar10 = plStackX_20;
      plVar11 = plVar15;
      if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
         (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))();
        plVar10 = plStackX_20;
        plVar11 = (longlong *)0x0;
      }
LAB_1408ca180:
      FUN_140008990(tstate);
      if ((-1 < *(int *)pcVar8) &&
         (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
        (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
      }
      if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
         (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
        (**(code **)(plVar11[1] + 0x30))(plVar11);
      }
      if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
        (**(code **)(plVar1[1] + 0x30))();
      }
      if ((int)*plVar10 < 0) {
        return pcVar16;
      }
      *plVar10 = *plVar10 + -1;
      if (*plVar10 != 0) {
        return pcVar16;
      }
      (**(code **)(plVar10[1] + 0x30))(plVar10);
      return pcVar16;
    }
    cVar6 = FUN_142cded30(tstate,&lStackX_18);
    lVar9 = lStackX_18;
    uVar17 = 0x22b5;
    if (cVar6 != '\0') {
      uVar17 = 0;
    }
    lVar3 = *(longlong *)(lStackX_18 + 0x28);
    if ((lVar3 != 0) && (*(longlong **)(lVar3 + 0x18) == plVar5)) {
      *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar3 + 0x24);
    }
    lStackX_18 = 0;
    plVar10 = *(longlong **)(tstate + 0xf8);
    *(int **)(tstate + 0xf8) = piVar4;
    plVar11 = plVar15;
    if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
       (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
      (**(code **)(plVar10[1] + 0x30))();
    }
  }
  else {
    plVar10 = (longlong *)FUN_142cd7b20(tstate,lVar9,classes_const_828_b64decode);
    if (plVar10 == (longlong *)0x0) {
LAB_1408ca042:
      lStackX_18 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      goto LAB_1408ca04e;
    }
    plVar11 = (longlong *)FUN_142cd7b20(tstate,plStackX_20,classes_const_529_split);
    if (plVar11 == (longlong *)0x0) {
LAB_1408c9f58:
      lStackX_18 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))(plVar10);
      }
      goto LAB_1408ca04e;
    }
    *(undefined4 *)(plVar5 + 5) = 0x22b6;
    plVar12 = (longlong *)
              FUN_142ccd7d0(tstate,plVar11,classes_const_1845___type____T____items_________1__);
    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
    if (plVar12 == (longlong *)0x0) goto LAB_1408c9f58;
    plVar13 = (longlong *)FUN_140008f40(tstate,plVar12,_DAT_142d9a268,1);
    if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
      (**(code **)(plVar12[1] + 0x30))(plVar12);
    }
    if (plVar13 == (longlong *)0x0) goto LAB_1408c9f58;
    *(undefined4 *)(plVar5 + 5) = 0x22b6;
    plVar11 = (longlong *)FUN_142ccfd60(tstate,plVar10,plVar13);
    if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
      (**(code **)(plVar10[1] + 0x30))(plVar10);
    }
    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    if (plVar11 == (longlong *)0x0) goto LAB_1408ca042;
    plVar10 = (longlong *)FUN_140008da0(tstate,pcVar8,classes_const_1897_prompts);
    if (plVar10 == (longlong *)0x0) {
LAB_1408ca40f:
      uVar17 = 0x22b9;
      lVar9 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      plVar15 = (longlong *)FUN_142cd7b20(tstate,plVar10,classes_const_211_get);
      if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))(plVar10);
      }
      if (plVar15 == (longlong *)0x0) goto LAB_1408ca40f;
      lVar9 = FUN_140a39ef0(tstate);
      if (lVar9 == 0) {
        FUN_142cde870(tstate,&lStackX_18,classes_const_820_hashlib);
        if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))(plVar15);
        }
        uVar17 = 0x22b9;
        lVar9 = lStackX_18;
      }
      else {
        uVar17 = 0x22b9;
        *(undefined4 *)(plVar5 + 5) = 0x22b9;
        plVar10 = (longlong *)FUN_142cd12f0(tstate,lVar9,classes_const_821_md5,plVar11);
        if (plVar10 == (longlong *)0x0) {
          lStackX_18 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          lVar9 = lStackX_18;
          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
            (**(code **)(plVar15[1] + 0x30))(plVar15);
            lVar9 = lStackX_18;
          }
        }
        else {
          *(undefined4 *)(plVar5 + 5) = 0x22b9;
          plVar12 = (longlong *)FUN_142cd06a0(tstate,plVar10,classes_const_823_hexdigest);
          if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
            (**(code **)(plVar10[1] + 0x30))(plVar10);
          }
          if (plVar12 != (longlong *)0x0) {
            *(undefined4 *)(plVar5 + 5) = 0x22b9;
            pcVar16 = (code *)FUN_142ccfd60(tstate,plVar15,plVar12);
            if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
              (**(code **)(plVar15[1] + 0x30))(plVar15);
            }
            if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
              (**(code **)(plVar12[1] + 0x30))(plVar12);
            }
            plVar10 = plStackX_20;
            if (pcVar16 != (code *)0x0) goto LAB_1408ca180;
            goto LAB_1408ca40f;
          }
          lStackX_18 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          lVar9 = lStackX_18;
          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
            (**(code **)(plVar15[1] + 0x30))(plVar15);
            lVar9 = lStackX_18;
          }
        }
      }
    }
  }
LAB_1408ca41f:
  lStackX_18 = lVar9;
  piVar4 = *(int **)(lStackX_18 + 0x28);
  if (piVar4 == (int *)0x0) {
    pcVar16 = (code *)FUN_142cd9160(plVar5,uVar17);
    bVar18 = pcVar16 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar4 + 6) == plVar5) goto LAB_1408ca4bf;
    pcVar16 = (code *)FUN_142cd9160(plVar5,uVar17);
    *(int **)(pcVar16 + 0x10) = piVar4;
    if (*piVar4 + 1 != 0) {
      *piVar4 = *piVar4 + 1;
    }
    bVar18 = pcVar16 == _Py_NoneStruct_exref;
  }
  plVar10 = *(longlong **)(lStackX_18 + 0x28);
  if (bVar18) {
    pcVar14 = (code *)0x0;
  }
  else {
    pcVar14 = pcVar16;
    if ((pcVar16 != (code *)0x0) && (*(int *)pcVar16 + 1 != 0)) {
      *(int *)pcVar16 = *(int *)pcVar16 + 1;
    }
  }
  *(code **)(lStackX_18 + 0x28) = pcVar14;
  if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))();
  }
  if (((pcVar16 != (code *)0x0) && (-1 < *(int *)pcVar16)) &&
     (*(longlong *)pcVar16 = *(longlong *)pcVar16 + -1, *(longlong *)pcVar16 == 0)) {
    (**(code **)(*(longlong *)(pcVar16 + 8) + 0x30))(pcVar16);
  }
LAB_1408ca4bf:
  plVar15 = plStackX_20;
  FUN_142cdb370(plVar5,&UNK_142d0b528,plVar1,plStackX_20,pcVar8,plVar11);
  plVar10 = _DAT_142dea790;
  if (plVar5 == _DAT_142dea790) {
    if ((-1 < (int)*_DAT_142dea790) && (*_DAT_142dea790 = *_DAT_142dea790 + -1, *plVar10 == 0)) {
      (**(code **)(plVar10[1] + 0x30))();
    }
    _DAT_142dea790 = (longlong *)0x0;
  }
  plVar10 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar10 + 10) = 0xfffffffe;
  plVar5 = (longlong *)plVar10[2];
  if (((plVar5 != (longlong *)0x0) && (plVar10[2] = 0, -1 < (int)*plVar5)) &&
     (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))();
  }
  if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))(plVar10);
  }
  lVar9 = lStackX_18;
  plVar10[0xc] = 0;
  lStackX_18 = 0;
  if (((pcVar8 != (code *)0x0) && (-1 < *(int *)pcVar8)) &&
     (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
    (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
  }
  if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
     (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
    (**(code **)(plVar11[1] + 0x30))(plVar11);
  }
  lStackX_18 = lVar9;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
    (**(code **)(plVar15[1] + 0x30))(plVar15);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

