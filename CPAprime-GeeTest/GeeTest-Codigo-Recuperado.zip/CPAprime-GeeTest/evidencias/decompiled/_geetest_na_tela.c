
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _geetest_na_tela(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  longlong lVar3;
  int *piVar4;
  code *pcVar5;
  char cVar6;
  int iVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  code *pcVar11;
  code *pcVar12;
  code *pcVar13;
  code *pcVar14;
  undefined8 uVar15;
  bool bVar16;
  code *apcStackX_18 [2];
  
  pcVar5 = _DAT_142dea6e8;
  plVar1 = (longlong *)*python_pars;
  if (_DAT_142dea6e8 == (code *)0x0) {
LAB_1408ae7b4:
    _DAT_142dea6e8 = (code *)FUN_142cd81e0(tstate,_DAT_142de9b80,_DAT_142f2aaf0,8);
  }
  else if ((1 < *(longlong *)_DAT_142dea6e8) || (*(longlong *)(_DAT_142dea6e8 + 0x10) != 0)) {
    if ((_DAT_142dea6e8 != (code *)0x0) &&
       ((-1 < *(int *)_DAT_142dea6e8 &&
        (*(longlong *)_DAT_142dea6e8 = *(longlong *)_DAT_142dea6e8 + -1, *(longlong *)pcVar5 == 0)))
       ) {
      (**(code **)(*(longlong *)(pcVar5 + 8) + 0x30))(pcVar5);
    }
    goto LAB_1408ae7b4;
  }
  pcVar5 = _DAT_142dea6e8;
  Nuitka_helper_140008a00(tstate,_DAT_142dea6e8);
  plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
  if (plVar8 == (longlong *)0x0) {
LAB_1408ae813:
    pcVar13 = *(code **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    uVar15 = 0x1ea6;
  }
  else {
    iVar7 = FUN_140004970(plVar8);
    if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))(plVar8);
    }
    if (iVar7 == -1) goto LAB_1408ae813;
    pcVar13 = _Py_FalseStruct_exref;
    if (iVar7 == 0) {
LAB_1408aec84:
      if (*(int *)pcVar13 + 1 != 0) {
        *(int *)pcVar13 = *(int *)pcVar13 + 1;
      }
      goto LAB_1408aec8d;
    }
    plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_170_driver);
    if (plVar8 == (longlong *)0x0) {
LAB_1408ae965:
      pcVar13 = *(code **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      plVar9 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_338_execute_script);
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
      }
      if (plVar9 == (longlong *)0x0) goto LAB_1408ae965;
      plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1716__JS_GEETEST_PRESENTE);
      if (plVar8 != (longlong *)0x0) {
        *(undefined4 *)(pcVar5 + 0x28) = 0x1ea9;
        plVar10 = (longlong *)FUN_142ccfd60(tstate,plVar9,plVar8);
        if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
          (**(code **)(plVar9[1] + 0x30))(plVar9);
        }
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if (plVar10 != (longlong *)0x0) {
          iVar7 = FUN_140004970(plVar10);
          if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
            (**(code **)(plVar10[1] + 0x30))(plVar10);
          }
          if (iVar7 != -1) {
            pcVar13 = _Py_FalseStruct_exref;
            if (iVar7 != 0) {
              pcVar13 = _Py_TrueStruct_exref;
            }
            goto LAB_1408aec84;
          }
        }
        goto LAB_1408ae965;
      }
      apcStackX_18[0] = *(code **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      pcVar13 = apcStackX_18[0];
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
        pcVar13 = apcStackX_18[0];
      }
    }
    pcVar14 = (code *)0x0;
    piVar4 = *(int **)(tstate + 0xf8);
    if ((piVar4 != (int *)0x0) && (*piVar4 + 1 != 0)) {
      *piVar4 = *piVar4 + 1;
    }
    piVar2 = *(int **)(pcVar13 + 0x28);
    apcStackX_18[0] = pcVar14;
    pcVar11 = (code *)FUN_142cd9160(pcVar5,0x1ea9);
    if (piVar2 != (int *)0x0) {
      *(int **)(pcVar11 + 0x10) = piVar2;
      if (*piVar2 + 1 != 0) {
        *piVar2 = *piVar2 + 1;
      }
    }
    plVar8 = *(longlong **)(pcVar13 + 0x28);
    pcVar12 = pcVar14;
    if (((pcVar11 != _Py_NoneStruct_exref) && (pcVar12 = pcVar11, pcVar11 != (code *)0x0)) &&
       (*(int *)pcVar11 + 1 != 0)) {
      *(int *)pcVar11 = *(int *)pcVar11 + 1;
    }
    *(code **)(pcVar13 + 0x28) = pcVar12;
    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
       (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
      (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
    }
    plVar8 = *(longlong **)(tstate + 0xf8);
    *(code **)(tstate + 0xf8) = pcVar13;
    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    pcVar13 = _Py_FalseStruct_exref;
    if (iVar7 != 0) {
      if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
        *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
      }
      plVar8 = *(longlong **)(tstate + 0xf8);
      *(int **)(tstate + 0xf8) = piVar4;
      if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))();
      }
LAB_1408aec8d:
      FUN_140008990(tstate);
      if ((int)*plVar1 < 0) {
        return pcVar13;
      }
      *plVar1 = *plVar1 + -1;
      if (*plVar1 != 0) {
        return pcVar13;
      }
      (**(code **)(plVar1[1] + 0x30))(plVar1);
      return pcVar13;
    }
    cVar6 = FUN_142cded30(tstate,apcStackX_18);
    pcVar13 = apcStackX_18[0];
    uVar15 = 0x1ea8;
    if (cVar6 != '\0') {
      uVar15 = 0;
    }
    lVar3 = *(longlong *)(apcStackX_18[0] + 0x28);
    if ((lVar3 != 0) && (*(code **)(lVar3 + 0x18) == pcVar5)) {
      *(undefined4 *)(pcVar5 + 0x28) = *(undefined4 *)(lVar3 + 0x24);
    }
    plVar8 = *(longlong **)(tstate + 0xf8);
    *(int **)(tstate + 0xf8) = piVar4;
    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      apcStackX_18[0] = pcVar14;
      (**(code **)(plVar8[1] + 0x30))();
    }
  }
  pcVar14 = (code *)0x0;
  piVar4 = *(int **)(pcVar13 + 0x28);
  apcStackX_18[0] = pcVar13;
  if (piVar4 == (int *)0x0) {
    pcVar13 = (code *)FUN_142cd9160(pcVar5,uVar15);
    bVar16 = pcVar13 == _Py_NoneStruct_exref;
  }
  else {
    if (*(code **)(piVar4 + 6) == pcVar5) goto LAB_1408aebae;
    pcVar13 = (code *)FUN_142cd9160(pcVar5,uVar15);
    *(int **)(pcVar13 + 0x10) = piVar4;
    if (*piVar4 + 1 != 0) {
      *piVar4 = *piVar4 + 1;
    }
    bVar16 = pcVar13 == _Py_NoneStruct_exref;
  }
  plVar8 = *(longlong **)(apcStackX_18[0] + 0x28);
  pcVar11 = pcVar14;
  if (((!bVar16) && (pcVar11 = pcVar13, pcVar13 != (code *)0x0)) && (*(int *)pcVar13 + 1 != 0)) {
    *(int *)pcVar13 = *(int *)pcVar13 + 1;
  }
  *(code **)(apcStackX_18[0] + 0x28) = pcVar11;
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))();
  }
  if (((pcVar13 != (code *)0x0) && (-1 < *(int *)pcVar13)) &&
     (*(longlong *)pcVar13 = *(longlong *)pcVar13 + -1, *(longlong *)pcVar13 == 0)) {
    (**(code **)(*(longlong *)(pcVar13 + 8) + 0x30))(pcVar13);
  }
LAB_1408aebae:
  FUN_142cdb370(pcVar5,&UNK_142d0ae4c,plVar1);
  pcVar13 = _DAT_142dea6e8;
  pcVar11 = _DAT_142dea6e8;
  if (((pcVar5 == _DAT_142dea6e8) && (pcVar11 = pcVar14, -1 < *(int *)_DAT_142dea6e8)) &&
     (*(longlong *)_DAT_142dea6e8 = *(longlong *)_DAT_142dea6e8 + -1, *(longlong *)pcVar13 == 0)) {
    (**(code **)(*(longlong *)(pcVar13 + 8) + 0x30))();
  }
  _DAT_142dea6e8 = pcVar11;
  plVar8 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar8 + 10) = 0xfffffffe;
  plVar9 = (longlong *)plVar8[2];
  if (((plVar9 != (longlong *)0x0) && (plVar8[2] = 0, -1 < (int)*plVar9)) &&
     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))();
  }
  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
    (**(code **)(plVar8[1] + 0x30))(plVar8);
  }
  plVar8[0xc] = 0;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(code **)(tstate + 0x70) = apcStackX_18[0];
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

