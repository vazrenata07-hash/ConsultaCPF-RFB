
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * iniciar_clique_centro(undefined *tstate,undefined *self,undefined **python_pars)

{
  int *piVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  longlong *plVar5;
  code *pcVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  code *pcVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  bool bVar15;
  longlong lStackX_18;
  longlong *plStackX_20;
  longlong *plStack_50;
  code *pcStack_48;
  
  plVar5 = (longlong *)FUN_142cdadd0(*python_pars);
  plVar2 = _DAT_142dea8c8;
  plVar13 = (longlong *)0x0;
  lStackX_18 = 0;
  plVar12 = (longlong *)0x0;
  plVar14 = (longlong *)0x0;
  bVar15 = false;
  if (_DAT_142dea8c8 == (longlong *)0x0) {
LAB_1408f5e5a:
    _DAT_142dea8c8 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9fe0,_DAT_142f2aaf0,0x18);
  }
  else if ((1 < *_DAT_142dea8c8) || (_DAT_142dea8c8[2] != 0)) {
    if ((_DAT_142dea8c8 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea8c8 && (*_DAT_142dea8c8 = *_DAT_142dea8c8 + -1, *plVar2 == 0)))) {
      (**(code **)(plVar2[1] + 0x30))(plVar2);
    }
    goto LAB_1408f5e5a;
  }
  plVar2 = _DAT_142dea8c8;
  Nuitka_helper_140008a00(tstate,_DAT_142dea8c8);
  pcVar6 = (code *)FUN_142cc1aa0(tstate,plVar5[2],classes_const_2168__thread_clique_centro_ligada,
                                 _Py_FalseStruct_exref);
  if (pcVar6 == (code *)0x0) {
    uVar11 = 0x293f;
    plVar12 = plVar13;
LAB_1408f6108:
    lStackX_18 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    plVar14 = plVar13;
  }
  else {
    if (pcVar6 == _Py_TrueStruct_exref) {
LAB_1408f5ec8:
      bVar15 = true;
LAB_1408f5f7b:
      if ((-1 < *(int *)pcVar6) &&
         (*(longlong *)pcVar6 = *(longlong *)pcVar6 + -1, *(longlong *)pcVar6 == 0)) {
        (**(code **)(*(longlong *)(pcVar6 + 8) + 0x30))(pcVar6);
      }
      pcVar6 = _Py_NoneStruct_exref;
      if (bVar15) {
        if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
          *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
        }
        FUN_140008990(tstate);
LAB_1408f633b:
        if ((int)*plVar5 < 0) {
          return pcVar6;
        }
        *plVar5 = *plVar5 + -1;
        if (*plVar5 != 0) {
          return pcVar6;
        }
        (**(code **)(plVar5[1] + 0x30))(plVar5);
        return pcVar6;
      }
      cVar3 = FUN_142ce4bf0(tstate,plVar5[2],classes_const_2168__thread_clique_centro_ligada,
                            _Py_TrueStruct_exref);
      if (cVar3 == '\0') {
        uVar11 = 0x2941;
        plVar13 = plVar14;
      }
      else {
        iVar4 = (int)*plVar5 + 1;
        if (iVar4 != 0) {
          *(int *)plVar5 = iVar4;
        }
        plStackX_20 = plVar5;
        plVar12 = (longlong *)
                  FUN_142cdb550(FUN_1408f6370,classes_const_1659_worker,
                                classes_const_2169_Navegacao_iniciar_clique_centro__locals__worker,
                                _DAT_142dea180,0,0,0,_DAT_142f2aaf0,0,&plStackX_20,1);
        lVar7 = FUN_140a3b100(tstate);
        if (lVar7 == 0) {
          FUN_142cde870(tstate,&lStackX_18,classes_const_181_threading);
          uVar11 = 0x295a;
          plVar14 = plVar13;
          goto LAB_1408f6118;
        }
        plVar8 = (longlong *)FUN_142cd7b20(tstate,lVar7,classes_const_397_Thread);
        pcVar6 = _Py_TrueStruct_exref;
        uVar11 = 0x295a;
        if (plVar8 != (longlong *)0x0) {
          *(undefined4 *)(plVar2 + 5) = 0x295a;
          pcStack_48 = pcVar6;
          plStack_50 = plVar12;
          plVar9 = (longlong *)
                   FUN_142cccd20(tstate,plVar8,&plStack_50,
                                 classes_const_398___type____T____items_____target____daemon___);
          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
            (**(code **)(plVar8[1] + 0x30))(plVar8);
          }
          plVar13 = plVar14;
          if (plVar9 != (longlong *)0x0) {
            uVar11 = 0x295b;
            *(undefined4 *)(plVar2 + 5) = 0x295b;
            plVar14 = (longlong *)FUN_142cd06a0(tstate,plVar9,classes_const_399_start);
            plVar13 = plVar9;
            if (plVar14 != (longlong *)0x0) {
              if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                (**(code **)(plVar14[1] + 0x30))(plVar14);
              }
              FUN_140008990(tstate);
              pcVar6 = _Py_NoneStruct_exref;
              if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
              }
              if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
                 (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                (**(code **)(plVar12[1] + 0x30))(plVar12);
              }
              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              goto LAB_1408f633b;
            }
          }
        }
      }
      goto LAB_1408f6108;
    }
    if ((pcVar6 == _Py_FalseStruct_exref) || (pcVar6 == _Py_NoneStruct_exref)) goto LAB_1408f5f7b;
    lVar7 = *(longlong *)(pcVar6 + 8);
    if ((*(longlong *)(lVar7 + 0x60) == 0) ||
       (pcVar10 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar10 == (code *)0x0)) {
      if ((*(undefined8 **)(lVar7 + 0x70) == (undefined8 *)0x0) ||
         (pcVar10 = (code *)**(undefined8 **)(lVar7 + 0x70), pcVar10 == (code *)0x0)) {
        if ((*(undefined8 **)(lVar7 + 0x68) == (undefined8 *)0x0) ||
           (pcVar10 = (code *)**(undefined8 **)(lVar7 + 0x68), pcVar10 == (code *)0x0))
        goto LAB_1408f5ec8;
        lVar7 = (*pcVar10)(pcVar6);
      }
      else {
        lVar7 = (*pcVar10)(pcVar6);
      }
    }
    else {
      iVar4 = (*pcVar10)(pcVar6);
      lVar7 = (longlong)iVar4;
    }
    if (0 < lVar7) {
      bVar15 = true;
      goto LAB_1408f5f7b;
    }
    if (lVar7 == 0) goto LAB_1408f5f7b;
    lStackX_18 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < *(int *)pcVar6) &&
       (*(longlong *)pcVar6 = *(longlong *)pcVar6 + -1, *(longlong *)pcVar6 == 0)) {
      (**(code **)(*(longlong *)(pcVar6 + 8) + 0x30))(pcVar6);
    }
    uVar11 = 0x293f;
    plVar12 = plVar13;
  }
LAB_1408f6118:
  pcVar6 = (code *)0x0;
  piVar1 = *(int **)(lStackX_18 + 0x28);
  if (piVar1 == (int *)0x0) {
    pcVar10 = (code *)FUN_142cd9160(plVar2,uVar11);
    bVar15 = pcVar10 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar1 + 6) == plVar2) goto LAB_1408f61c1;
    pcVar10 = (code *)FUN_142cd9160(plVar2,uVar11);
    *(int **)(pcVar10 + 0x10) = piVar1;
    if (*piVar1 + 1 != 0) {
      *piVar1 = *piVar1 + 1;
    }
    bVar15 = pcVar10 == _Py_NoneStruct_exref;
  }
  plVar13 = *(longlong **)(lStackX_18 + 0x28);
  if (((!bVar15) && (pcVar6 = pcVar10, pcVar10 != (code *)0x0)) && (*(int *)pcVar10 + 1 != 0)) {
    *(int *)pcVar10 = *(int *)pcVar10 + 1;
  }
  *(code **)(lStackX_18 + 0x28) = pcVar6;
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))();
  }
  if (((pcVar10 != (code *)0x0) && (-1 < *(int *)pcVar10)) &&
     (*(longlong *)pcVar10 = *(longlong *)pcVar10 + -1, *(longlong *)pcVar10 == 0)) {
    (**(code **)(*(longlong *)(pcVar10 + 8) + 0x30))(pcVar10);
  }
LAB_1408f61c1:
  FUN_142cdb370(plVar2,&UNK_142d0c6f8,plVar5,plVar12,plVar14);
  plVar13 = _DAT_142dea8c8;
  if (plVar2 == _DAT_142dea8c8) {
    if ((-1 < (int)*_DAT_142dea8c8) && (*_DAT_142dea8c8 = *_DAT_142dea8c8 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))();
    }
    _DAT_142dea8c8 = (longlong *)0x0;
  }
  plVar2 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar2 + 10) = 0xfffffffe;
  plVar13 = (longlong *)plVar2[2];
  if (((plVar13 != (longlong *)0x0) && (plVar2[2] = 0, -1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))();
  }
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))(plVar2);
  }
  lVar7 = lStackX_18;
  plVar2[0xc] = 0;
  lStackX_18 = 0;
  if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
     (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
    (**(code **)(plVar12[1] + 0x30))(plVar12);
  }
  if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
     (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
    (**(code **)(plVar14[1] + 0x30))(plVar14);
  }
  lStackX_18 = lVar7;
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  plVar2 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar2 != (longlong *)0x0) && (-1 < (int)*plVar2)) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)
     ) {
    (**(code **)(plVar2[1] + 0x30))();
  }
  return (undefined *)0x0;
}

