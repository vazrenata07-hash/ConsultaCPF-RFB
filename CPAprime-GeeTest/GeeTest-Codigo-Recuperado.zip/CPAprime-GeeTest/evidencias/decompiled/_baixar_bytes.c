
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _baixar_bytes(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  longlong lVar4;
  int *piVar5;
  char cVar6;
  int iVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined *puVar13;
  code *pcVar14;
  code *pcVar15;
  bool bVar16;
  longlong lStackX_18;
  longlong *plStackX_20;
  
  plVar3 = _DAT_142dea768;
  plVar1 = (longlong *)*python_pars;
  plVar10 = (longlong *)python_pars[1];
  lStackX_18 = 0;
  plStackX_20 = plVar10;
  if (_DAT_142dea768 == (longlong *)0x0) {
LAB_1408c25d2:
    _DAT_142dea768 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9988,_DAT_142f2aaf0,0x18);
  }
  else if ((1 < *_DAT_142dea768) || (_DAT_142dea768[2] != 0)) {
    if ((_DAT_142dea768 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea768 && (*_DAT_142dea768 = *_DAT_142dea768 + -1, *plVar3 == 0)))) {
      (**(code **)(plVar3[1] + 0x30))(plVar3);
    }
    goto LAB_1408c25d2;
  }
  plVar3 = _DAT_142dea768;
  Nuitka_helper_140008a00(tstate,_DAT_142dea768);
  pcVar15 = (code *)0x21b1;
  *(undefined4 *)(plVar3 + 5) = 0x21b1;
  plVar8 = (longlong *)FUN_142cd12f0(tstate,plVar1,classes_const_1844__baixar_data_url,plVar10);
  if (plVar8 == (longlong *)0x0) {
    lVar9 = *(longlong *)(tstate + 0x70);
    plVar8 = (longlong *)0x0;
    *(undefined8 *)(tstate + 0x70) = 0;
  }
  else {
    iVar7 = FUN_140004970(plVar8);
    if ((iVar7 == -1) ||
       ((iVar7 != 0 && (iVar7 = PySequence_Contains(plVar8,classes_const_225__), iVar7 == -1)))) {
      lVar9 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      pcVar15 = (code *)0x21b2;
    }
    else {
      puVar13 = classes_const_830___bytes_hex______;
      if (iVar7 == 0) {
        if (*(int *)classes_const_830___bytes_hex______ + 1 != 0) {
          *(int *)classes_const_830___bytes_hex______ =
               *(int *)classes_const_830___bytes_hex______ + 1;
        }
        goto LAB_1408c293c;
      }
      lVar9 = FUN_140a39450(tstate);
      if (lVar9 == 0) {
        FUN_142cde870(tstate,&lStackX_18,classes_const_827_base64);
      }
      else {
        plVar10 = (longlong *)FUN_142cd7b20(tstate,lVar9,classes_const_828_b64decode);
        if (plVar10 == (longlong *)0x0) {
LAB_1408c27f6:
          lStackX_18 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
        }
        else {
          plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_529_split);
          if (plVar11 != (longlong *)0x0) {
            *(undefined4 *)(plVar3 + 5) = 0x21b5;
            plVar12 = (longlong *)
                      FUN_142ccd7d0(tstate,plVar11,
                                    classes_const_1845___type____T____items_________1__);
            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
              (**(code **)(plVar11[1] + 0x30))(plVar11);
            }
            if (plVar12 != (longlong *)0x0) {
              plVar11 = (longlong *)FUN_140008f40(tstate,plVar12,_DAT_142d9a268,1);
              if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                (**(code **)(plVar12[1] + 0x30))(plVar12);
              }
              if (plVar11 != (longlong *)0x0) {
                *(undefined4 *)(plVar3 + 5) = 0x21b5;
                puVar13 = (undefined *)FUN_142ccfd60(tstate,plVar10,plVar11);
                if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                  (**(code **)(plVar10[1] + 0x30))(plVar10);
                }
                if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                  (**(code **)(plVar11[1] + 0x30))(plVar11);
                }
                plVar10 = plStackX_20;
                if (puVar13 != (undefined *)0x0) goto LAB_1408c293c;
                goto LAB_1408c27f6;
              }
            }
          }
          lStackX_18 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
            (**(code **)(plVar10[1] + 0x30))(plVar10);
          }
        }
      }
      lVar9 = lStackX_18;
      piVar5 = *(int **)(tstate + 0xf8);
      lStackX_18 = 0;
      if ((piVar5 != (int *)0x0) && (*piVar5 + 1 != 0)) {
        *piVar5 = *piVar5 + 1;
      }
      piVar2 = *(int **)(lVar9 + 0x28);
      pcVar15 = (code *)FUN_142cd9160(plVar3,0x21b5);
      if (piVar2 != (int *)0x0) {
        *(int **)(pcVar15 + 0x10) = piVar2;
        if (*piVar2 + 1 != 0) {
          *piVar2 = *piVar2 + 1;
        }
      }
      plVar10 = *(longlong **)(lVar9 + 0x28);
      pcVar14 = (code *)0x0;
      if (((pcVar15 != _Py_NoneStruct_exref) && (pcVar14 = pcVar15, pcVar15 != (code *)0x0)) &&
         (*(int *)pcVar15 + 1 != 0)) {
        *(int *)pcVar15 = *(int *)pcVar15 + 1;
      }
      *(code **)(lVar9 + 0x28) = pcVar14;
      if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
         (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))();
      }
      if (((pcVar15 != (code *)0x0) && (-1 < *(int *)pcVar15)) &&
         (*(longlong *)pcVar15 = *(longlong *)pcVar15 + -1, *(longlong *)pcVar15 == 0)) {
        (**(code **)(*(longlong *)(pcVar15 + 8) + 0x30))(pcVar15);
      }
      plVar10 = *(longlong **)(tstate + 0xf8);
      *(longlong *)(tstate + 0xf8) = lVar9;
      if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
         (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))();
      }
      iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                            *(undefined8 *)PyExc_Exception_exref);
      puVar13 = classes_const_830___bytes_hex______;
      if (iVar7 != 0) {
        if (*(int *)classes_const_830___bytes_hex______ + 1 != 0) {
          *(int *)classes_const_830___bytes_hex______ =
               *(int *)classes_const_830___bytes_hex______ + 1;
        }
        plVar3 = *(longlong **)(tstate + 0xf8);
        *(int **)(tstate + 0xf8) = piVar5;
        plVar10 = plStackX_20;
        if (((plVar3 != (longlong *)0x0) && (-1 < (int)*plVar3)) &&
           (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
          (**(code **)(plVar3[1] + 0x30))();
          plVar10 = plStackX_20;
        }
LAB_1408c293c:
        FUN_140008990(tstate);
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
          (**(code **)(plVar1[1] + 0x30))(plVar1);
        }
        if ((int)*plVar10 < 0) {
          return puVar13;
        }
        *plVar10 = *plVar10 + -1;
        if (*plVar10 != 0) {
          return puVar13;
        }
        (**(code **)(plVar10[1] + 0x30))(plVar10);
        return puVar13;
      }
      cVar6 = FUN_142cded30(tstate,&lStackX_18);
      lVar9 = lStackX_18;
      pcVar15 = (code *)0x21b4;
      if (cVar6 != '\0') {
        pcVar15 = (code *)0x0;
      }
      lVar4 = *(longlong *)(lStackX_18 + 0x28);
      if ((lVar4 != 0) && (*(longlong **)(lVar4 + 0x18) == plVar3)) {
        *(undefined4 *)(plVar3 + 5) = *(undefined4 *)(lVar4 + 0x24);
      }
      plVar10 = *(longlong **)(tstate + 0xf8);
      lStackX_18 = 0;
      *(int **)(tstate + 0xf8) = piVar5;
      if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
         (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
        (**(code **)(plVar10[1] + 0x30))();
      }
    }
  }
  pcVar14 = (code *)0x0;
  piVar5 = *(int **)(lVar9 + 0x28);
  lStackX_18 = lVar9;
  if (piVar5 == (int *)0x0) {
    pcVar15 = (code *)FUN_142cd9160(plVar3,pcVar15);
    bVar16 = pcVar15 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar5 + 6) == plVar3) goto LAB_1408c2aa9;
    pcVar15 = (code *)FUN_142cd9160(plVar3,pcVar15);
    *(int **)(pcVar15 + 0x10) = piVar5;
    if (*piVar5 + 1 != 0) {
      *piVar5 = *piVar5 + 1;
    }
    bVar16 = pcVar15 == _Py_NoneStruct_exref;
  }
  plVar10 = *(longlong **)(lStackX_18 + 0x28);
  if (((!bVar16) && (pcVar14 = pcVar15, pcVar15 != (code *)0x0)) && (*(int *)pcVar15 + 1 != 0)) {
    *(int *)pcVar15 = *(int *)pcVar15 + 1;
  }
  *(code **)(lStackX_18 + 0x28) = pcVar14;
  if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))();
  }
  if (((pcVar15 != (code *)0x0) && (-1 < *(int *)pcVar15)) &&
     (*(longlong *)pcVar15 = *(longlong *)pcVar15 + -1, *(longlong *)pcVar15 == 0)) {
    (**(code **)(*(longlong *)(pcVar15 + 8) + 0x30))(pcVar15);
  }
LAB_1408c2aa9:
  plVar11 = plStackX_20;
  FUN_142cdb370(plVar3,&UNK_142d0b25c,plVar1,plStackX_20,plVar8);
  plVar10 = _DAT_142dea768;
  if (plVar3 == _DAT_142dea768) {
    if ((-1 < (int)*_DAT_142dea768) && (*_DAT_142dea768 = *_DAT_142dea768 + -1, *plVar10 == 0)) {
      (**(code **)(plVar10[1] + 0x30))();
    }
    _DAT_142dea768 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar9 = lStackX_18;
  lStackX_18 = 0;
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))(plVar8);
  }
  lStackX_18 = lVar9;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
    (**(code **)(plVar11[1] + 0x30))(plVar11);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

