
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _tabela_emocao(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  int *piVar2;
  int *piVar3;
  longlong lVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  longlong *plVar8;
  undefined *puVar9;
  longlong *plVar10;
  longlong *plVar11;
  code *pcVar12;
  undefined8 uVar13;
  code *pcVar14;
  longlong lVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  bool bVar18;
  longlong lStackX_18;
  longlong *plStackX_20;
  
  plVar5 = _DAT_142dea780;
  plVar10 = (longlong *)0x0;
  plVar1 = (longlong *)*python_pars;
  plStackX_20 = (longlong *)0x0;
  if (_DAT_142dea780 == (longlong *)0x0) {
LAB_1408c8a95:
    _DAT_142dea780 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9d98,_DAT_142f2aaf0,0x18);
  }
  else if ((1 < *_DAT_142dea780) || (_DAT_142dea780[2] != 0)) {
    if ((_DAT_142dea780 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea780 && (*_DAT_142dea780 = *_DAT_142dea780 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408c8a95;
  }
  plVar5 = _DAT_142dea780;
  Nuitka_helper_140008a00(tstate,_DAT_142dea780);
  plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar1,classes_const_1894__TABELA_EMOCAO_LIDA);
  if (plVar8 == (longlong *)0x0) {
    lVar15 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    uVar16 = 0x228c;
  }
  else {
    iVar7 = FUN_140004970(plVar8);
    if (iVar7 == -1) {
      lStackX_18 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
      }
      uVar16 = 0x228c;
      lVar15 = lStackX_18;
    }
    else {
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
      }
      if (iVar7 == 0) {
        cVar6 = FUN_142ce4bf0(tstate,plVar1,classes_const_1894__TABELA_EMOCAO_LIDA,
                              _Py_TrueStruct_exref);
        uVar13 = _DAT_142f2aae8;
        puVar9 = classes_const_1896_geetest_emocao;
        uVar16 = _DAT_142d9a260;
        pcVar14 = _Py_NoneStruct_exref;
        if (cVar6 == '\0') {
          lVar15 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          uVar16 = 0x228e;
          plVar10 = (longlong *)0x0;
        }
        else {
          uVar17 = 0x2290;
          *(undefined4 *)(plVar5 + 5) = 0x2290;
          plVar10 = (longlong *)FUN_142cd5880(tstate,puVar9,uVar13,pcVar14,pcVar14,uVar16);
          puVar9 = classes_const_1897_prompts;
          if (plVar10 == (longlong *)0x0) {
LAB_1408c8d04:
            lVar15 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408c8d0c:
            piVar3 = *(int **)(tstate + 0xf8);
            lStackX_18 = 0;
            if ((piVar3 != (int *)0x0) && (*piVar3 + 1 != 0)) {
              *piVar3 = *piVar3 + 1;
            }
            piVar2 = *(int **)(lVar15 + 0x28);
            pcVar14 = (code *)FUN_142cd9160(plVar5,uVar17);
            if (piVar2 != (int *)0x0) {
              *(int **)(pcVar14 + 0x10) = piVar2;
              if (*piVar2 + 1 != 0) {
                *piVar2 = *piVar2 + 1;
              }
            }
            plVar10 = *(longlong **)(lVar15 + 0x28);
            if (pcVar14 == _Py_NoneStruct_exref) {
              pcVar12 = (code *)0x0;
            }
            else {
              pcVar12 = pcVar14;
              if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
                *(int *)pcVar14 = *(int *)pcVar14 + 1;
              }
            }
            *(code **)(lVar15 + 0x28) = pcVar12;
            if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
               (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
              (**(code **)(plVar10[1] + 0x30))();
            }
            if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
               (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
              (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
            }
            plVar10 = *(longlong **)(tstate + 0xf8);
            *(longlong *)(tstate + 0xf8) = lVar15;
            if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
               (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
              (**(code **)(plVar10[1] + 0x30))();
            }
            iVar7 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                                  *(undefined8 *)PyExc_Exception_exref);
            if (iVar7 == 0) {
              cVar6 = FUN_142cded30(tstate,&lStackX_18);
              uVar16 = 0x228f;
              if (cVar6 != '\0') {
                uVar16 = 0;
              }
              lVar4 = *(longlong *)(lStackX_18 + 0x28);
              lVar15 = lStackX_18;
              if ((lVar4 != 0) && (*(longlong **)(lVar4 + 0x18) == plVar5)) {
                *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar4 + 0x24);
              }
            }
            else {
              plVar10 = *(longlong **)(tstate + 0xf8);
              iVar7 = (int)*plVar10 + 1;
              if (iVar7 != 0) {
                *(int *)plVar10 = iVar7;
              }
              uVar13 = FUN_1400776a0(classes_const_257_print);
              plVar8 = (longlong *)
                       FUN_142cbff90(classes_const_1901__geetest_3x3_emocao__tabela_indisponivel___s____esta_variante_nao
                                     ,plVar10);
              if (plVar8 == (longlong *)0x0) {
                uVar16 = 0x2294;
              }
              else {
                uVar16 = 0x2293;
                *(undefined4 *)(plVar5 + 5) = 0x2293;
                plVar11 = (longlong *)FUN_142ccfd60(tstate,uVar13,plVar8);
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                if (plVar11 != (longlong *)0x0) {
                  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                    (**(code **)(plVar11[1] + 0x30))(plVar11);
                  }
                  cVar6 = FUN_142ce4bf0(tstate,plVar1,classes_const_1895__TABELA_EMOCAO,
                                        _Py_NoneStruct_exref);
                  if (cVar6 != '\0') {
                    if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                      (**(code **)(plVar10[1] + 0x30))(plVar10);
                    }
                    plVar8 = *(longlong **)(tstate + 0xf8);
                    *(int **)(tstate + 0xf8) = piVar3;
                    plVar10 = plStackX_20;
                    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                      (**(code **)(plVar8[1] + 0x30))();
                      plVar10 = plStackX_20;
                    }
                    goto LAB_1408c8f19;
                  }
                  uVar16 = 0x2295;
                }
              }
              lVar15 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              if ((-1 < (int)*plVar10) && (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                (**(code **)(plVar10[1] + 0x30))(plVar10);
              }
            }
            plVar8 = *(longlong **)(tstate + 0xf8);
            lStackX_18 = 0;
            *(int **)(tstate + 0xf8) = piVar3;
            plVar10 = plStackX_20;
            if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
               (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))();
              plVar10 = plStackX_20;
            }
          }
          else {
            plStackX_20 = plVar10;
            plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar10,classes_const_1898_PROMPTS);
            if (plVar8 == (longlong *)0x0) {
LAB_1408c8cfb:
              uVar17 = 0x2291;
              goto LAB_1408c8d04;
            }
            plVar11 = (longlong *)_PyDict_NewPresized(2);
            PyDict_SetItem(plVar11,puVar9,plVar8);
            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))(plVar8);
            }
            puVar9 = classes_const_1899_celulas;
            plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar10,classes_const_1900_CELULAS);
            if (plVar8 == (longlong *)0x0) {
              lStackX_18 = *(longlong *)(tstate + 0x70);
              uVar17 = 0x2291;
              *(undefined8 *)(tstate + 0x70) = 0;
              lVar15 = lStackX_18;
              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                (**(code **)(plVar11[1] + 0x30))(plVar11);
                lVar15 = lStackX_18;
              }
              goto LAB_1408c8d0c;
            }
            PyDict_SetItem(plVar11,puVar9,plVar8);
            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))(plVar8);
            }
            cVar6 = FUN_142ce4bf0(tstate,plVar1,classes_const_1895__TABELA_EMOCAO,plVar11);
            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
              (**(code **)(plVar11[1] + 0x30))(plVar11);
            }
            if (cVar6 == '\0') goto LAB_1408c8cfb;
LAB_1408c8f19:
            puVar9 = (undefined *)FUN_142cd7b20(tstate,plVar1,classes_const_1895__TABELA_EMOCAO);
            if (puVar9 != (undefined *)0x0) {
LAB_1408c9157:
              plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
              *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
              *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
              plVar8 = (longlong *)plVar5[2];
              if (((plVar8 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar8)) &&
                 (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))();
              }
              if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                (**(code **)(plVar5[1] + 0x30))(plVar5);
              }
              plVar5[0xc] = 0;
              if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
                 (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
                (**(code **)(plVar10[1] + 0x30))(plVar10);
              }
              if ((int)*plVar1 < 0) {
                return puVar9;
              }
              *plVar1 = *plVar1 + -1;
              if (*plVar1 != 0) {
                return puVar9;
              }
              (**(code **)(plVar1[1] + 0x30))(plVar1);
              return puVar9;
            }
            lVar15 = *(longlong *)(tstate + 0x70);
            uVar16 = 0x2296;
            *(undefined8 *)(tstate + 0x70) = 0;
          }
        }
      }
      else {
        puVar9 = (undefined *)FUN_142cd7b20(tstate,plVar1,classes_const_1895__TABELA_EMOCAO);
        if (puVar9 != (undefined *)0x0) goto LAB_1408c9157;
        lVar15 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        uVar16 = 0x228d;
        plVar10 = (longlong *)0x0;
      }
    }
  }
  lStackX_18 = lVar15;
  piVar3 = *(int **)(lStackX_18 + 0x28);
  if (piVar3 == (int *)0x0) {
    pcVar14 = (code *)FUN_142cd9160(plVar5,uVar16);
    bVar18 = pcVar14 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar3 + 6) == plVar5) goto LAB_1408c905e;
    pcVar14 = (code *)FUN_142cd9160(plVar5,uVar16);
    *(int **)(pcVar14 + 0x10) = piVar3;
    if (*piVar3 + 1 != 0) {
      *piVar3 = *piVar3 + 1;
    }
    bVar18 = pcVar14 == _Py_NoneStruct_exref;
  }
  plVar8 = *(longlong **)(lStackX_18 + 0x28);
  if (bVar18) {
    pcVar12 = (code *)0x0;
  }
  else {
    pcVar12 = pcVar14;
    if ((pcVar14 != (code *)0x0) && (*(int *)pcVar14 + 1 != 0)) {
      *(int *)pcVar14 = *(int *)pcVar14 + 1;
    }
  }
  *(code **)(lStackX_18 + 0x28) = pcVar12;
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))();
  }
  if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
     (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
    (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
  }
LAB_1408c905e:
  FUN_142cdb370(plVar5,&UNK_142d0b25c,plVar1,plVar10,0);
  plVar8 = _DAT_142dea780;
  if (plVar5 == _DAT_142dea780) {
    if ((-1 < (int)*_DAT_142dea780) && (*_DAT_142dea780 = *_DAT_142dea780 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    _DAT_142dea780 = (longlong *)0x0;
  }
  plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
  plVar8 = (longlong *)plVar5[2];
  if (((plVar8 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar8)) &&
     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
    (**(code **)(plVar8[1] + 0x30))();
  }
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  lVar15 = lStackX_18;
  plVar5[0xc] = 0;
  lStackX_18 = 0;
  if (((plVar10 != (longlong *)0x0) && (-1 < (int)*plVar10)) &&
     (*plVar10 = *plVar10 + -1, *plVar10 == 0)) {
    (**(code **)(plVar10[1] + 0x30))(plVar10);
  }
  lStackX_18 = lVar15;
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_18;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

