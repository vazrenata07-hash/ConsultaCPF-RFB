
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _nine_emocao_alvos(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  int *piVar4;
  int *piVar5;
  undefined *puVar6;
  undefined8 uVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  code *pcVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong *plVar18;
  code *pcVar19;
  longlong *plVar20;
  code *pcVar21;
  longlong lVar22;
  code *pcVar23;
  undefined8 uVar24;
  code *pcVar25;
  bool bVar26;
  undefined4 uStackX_18;
  longlong *plStackX_20;
  longlong *plStack_110;
  code *pcStack_108;
  code *pcStack_f8;
  code *pcStack_f0;
  longlong *plStack_e0;
  longlong *plStack_d8;
  longlong *plStack_d0;
  longlong *plStack_c8;
  longlong *plStack_c0;
  longlong *plStack_b8;
  longlong *plStack_b0;
  longlong *plStack_a8;
  longlong *plStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_88;
  longlong *plStack_58;
  longlong *plStack_50;
  longlong *plStack_48;
  longlong *plStack_40;
  
  plVar13 = _DAT_142dea798;
  plVar1 = (longlong *)python_pars[1];
  pcVar21 = (code *)0x0;
  plVar2 = (longlong *)*python_pars;
  pcVar25 = (code *)0x0;
  plVar3 = (longlong *)python_pars[2];
  plStackX_20 = (longlong *)0x0;
  plStack_c8 = (longlong *)0x0;
  plStack_c0 = (longlong *)0x0;
  plStack_b8 = (longlong *)0x0;
  plStack_b0 = (longlong *)0x0;
  plStack_a8 = (longlong *)0x0;
  pcStack_f8 = (code *)0x0;
  plStack_a0 = (longlong *)0x0;
  plStack_98 = (longlong *)0x0;
  plStack_90 = (longlong *)0x0;
  plStack_88 = (longlong *)0x0;
  pcStack_f0 = (code *)0x0;
  pcStack_108 = (code *)0x0;
  plStack_e0 = (longlong *)0x0;
  plStack_d8 = (longlong *)0x0;
  plStack_d0 = (longlong *)0x0;
  plStack_110 = _DAT_142dea798;
  if (_DAT_142dea798 == (longlong *)0x0) {
LAB_1408ca6bb:
    plStack_110 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9c08,_DAT_142f2aaf0,0x98);
  }
  else if ((1 < *_DAT_142dea798) || (_DAT_142dea798[2] != 0)) {
    if ((_DAT_142dea798 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea798 && (*_DAT_142dea798 = *_DAT_142dea798 + -1, *plVar13 == 0)))) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    goto LAB_1408ca6bb;
  }
  _DAT_142dea798 = plStack_110;
  Nuitka_helper_140008a00(tstate,plStack_110);
  uStackX_18 = 0x22c1;
  *(undefined4 *)(plStack_110 + 5) = 0x22c1;
  pcVar11 = (code *)FUN_142cd06a0(tstate,plVar2,classes_const_1911__tabela_emocao);
  if (pcVar11 == (code *)0x0) {
    plVar13 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    pcVar11 = pcVar21;
    pcStack_108 = pcVar21;
    goto LAB_1408cbe2b;
  }
  if (pcVar11 != _Py_TrueStruct_exref) {
    if ((pcVar11 != _Py_FalseStruct_exref) && (pcVar11 != _Py_NoneStruct_exref)) {
      lVar12 = *(longlong *)(pcVar11 + 8);
      if ((*(longlong *)(lVar12 + 0x60) == 0) ||
         (pcVar23 = *(code **)(*(longlong *)(lVar12 + 0x60) + 0x48), pcVar23 == (code *)0x0)) {
        if ((*(undefined8 **)(lVar12 + 0x70) == (undefined8 *)0x0) ||
           (pcVar23 = (code *)**(undefined8 **)(lVar12 + 0x70), pcVar23 == (code *)0x0)) {
          if ((*(undefined8 **)(lVar12 + 0x68) == (undefined8 *)0x0) ||
             (pcVar23 = (code *)**(undefined8 **)(lVar12 + 0x68), pcVar23 == (code *)0x0))
          goto LAB_1408ca7e5;
          lVar12 = (*pcVar23)(pcVar11);
        }
        else {
          lVar12 = (*pcVar23)(pcVar11);
        }
      }
      else {
        iVar9 = (*pcVar23)(pcVar11);
        lVar12 = (longlong)iVar9;
      }
      if (0 < lVar12) goto LAB_1408ca7e5;
      if (lVar12 != 0) {
        plVar13 = *(longlong **)(tstate + 0x70);
        uStackX_18 = 0x22c2;
        *(undefined8 *)(tstate + 0x70) = 0;
        pcStack_108 = pcVar25;
        goto LAB_1408cbe2b;
      }
    }
    pcVar23 = _Py_NoneStruct_exref;
    pcVar19 = pcVar21;
    pcStack_108 = pcVar21;
    if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
      *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
      pcVar21 = (code *)0x0;
      pcVar19 = (code *)0x0;
      pcStack_108 = pcVar25;
    }
    goto LAB_1408cac53;
  }
LAB_1408ca7e5:
  uVar7 = _DAT_142f2aae8;
  puVar6 = classes_const_1774_numpy;
  uVar24 = _DAT_142d9a260;
  pcVar23 = _Py_NoneStruct_exref;
  uStackX_18 = 0x22c4;
  *(undefined4 *)(plStack_110 + 5) = 0x22c4;
  plVar13 = (longlong *)FUN_142cd5880(tstate,puVar6,uVar7,pcVar23,pcVar23,uVar24);
  uVar7 = _DAT_142f2aae8;
  puVar6 = classes_const_1775_cv2;
  uVar24 = _DAT_142d9a260;
  pcVar23 = _Py_NoneStruct_exref;
  if (plVar13 == (longlong *)0x0) {
    plVar13 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    pcStack_108 = pcVar21;
  }
  else {
    *(undefined4 *)(plStack_110 + 5) = 0x22c5;
    plVar14 = (longlong *)FUN_142cd5880(tstate,puVar6,uVar7,pcVar23,pcVar23,uVar24);
    plStack_c8 = plVar13;
    if (plVar14 == (longlong *)0x0) {
      plVar13 = *(longlong **)(tstate + 0x70);
      uStackX_18 = 0x22c5;
      *(undefined8 *)(tstate + 0x70) = 0;
      pcStack_108 = pcVar25;
    }
    else {
      *(undefined4 *)(plStack_110 + 5) = 0x22c7;
      plVar15 = (longlong *)FUN_142cd12f0(tstate,plVar2,classes_const_1913__emocao_do_prompt,plVar1)
      ;
      plStack_c0 = plVar14;
      if (plVar15 == (longlong *)0x0) {
        plVar13 = *(longlong **)(tstate + 0x70);
        uStackX_18 = 0x22c7;
        *(undefined8 *)(tstate + 0x70) = 0;
      }
      else {
        iVar9 = FUN_140004970(plVar15);
        pcVar23 = _Py_NoneStruct_exref;
        plStack_b8 = plVar15;
        if (iVar9 == -1) {
          plVar13 = *(longlong **)(tstate + 0x70);
          uStackX_18 = 0x22c8;
          *(undefined8 *)(tstate + 0x70) = 0;
        }
        else {
          if (iVar9 == 0) {
            pcStack_108 = (code *)0x0;
            pcVar21 = pcStack_108;
            pcVar19 = pcStack_108;
            if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
              *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
            }
            goto LAB_1408cac53;
          }
          lVar12 = FUN_140a39450(tstate);
          if (lVar12 == 0) {
            FUN_142cde870(tstate,&plStackX_20,classes_const_827_base64);
          }
          else {
            plVar16 = (longlong *)FUN_142cd7b20(tstate,lVar12,classes_const_828_b64decode);
            if (plVar16 == (longlong *)0x0) {
LAB_1408caa92:
              plStackX_20 = *(longlong **)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
            }
            else {
              plVar17 = (longlong *)FUN_142cd7b20(tstate,plVar3,classes_const_529_split);
              if (plVar17 != (longlong *)0x0) {
                *(undefined4 *)(plStack_110 + 5) = 0x22cb;
                plVar18 = (longlong *)
                          FUN_142ccd7d0(tstate,plVar17,
                                        classes_const_1845___type____T____items_________1__);
                if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
                  (**(code **)(plVar17[1] + 0x30))(plVar17);
                }
                if (plVar18 != (longlong *)0x0) {
                  plVar17 = (longlong *)FUN_140008f40(tstate,plVar18,_DAT_142d9a268,1);
                  if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                  }
                  if (plVar17 != (longlong *)0x0) {
                    *(undefined4 *)(plStack_110 + 5) = 0x22cb;
                    plVar18 = (longlong *)FUN_142ccfd60(tstate,plVar16,plVar17);
                    if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                      (**(code **)(plVar16[1] + 0x30))(plVar16);
                    }
                    if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
                      (**(code **)(plVar17[1] + 0x30))(plVar17);
                    }
                    if (plVar18 == (longlong *)0x0) goto LAB_1408caa92;
                    plVar16 = (longlong *)FUN_140008da0(tstate,pcVar11,classes_const_1899_celulas);
                    plStack_b0 = plVar18;
                    if (plVar16 == (longlong *)0x0) {
LAB_1408caf41:
                      uStackX_18 = 0x22ce;
                    }
                    else {
                      plVar17 = (longlong *)FUN_142cd7b20(tstate,plVar16,classes_const_211_get);
                      if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                        (**(code **)(plVar16[1] + 0x30))(plVar16);
                      }
                      if (plVar17 == (longlong *)0x0) goto LAB_1408caf41;
                      *(undefined4 *)(plStack_110 + 5) = 0x22ce;
                      plVar15 = (longlong *)FUN_142ccfd60(tstate,plVar17,plVar15);
                      if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
                        (**(code **)(plVar17[1] + 0x30))(plVar17);
                      }
                      if (plVar15 == (longlong *)0x0) {
                        uStackX_18 = 0x22ce;
                      }
                      else {
                        iVar9 = FUN_140004970(plVar15);
                        pcVar23 = _Py_NoneStruct_exref;
                        plStack_a8 = plVar15;
                        if (iVar9 != -1) {
                          if (iVar9 == 0) {
                            pcStack_108 = (code *)0x0;
                            pcVar21 = pcStack_108;
                            pcVar19 = pcStack_108;
                            if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                              *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                            }
                            goto LAB_1408cac53;
                          }
                          plVar16 = (longlong *)
                                    FUN_142cd7b20(tstate,plVar14,classes_const_1781_imdecode);
                          if (plVar16 == (longlong *)0x0) {
                            uStackX_18 = 0x22d2;
                            goto LAB_1408caf47;
                          }
                          plVar17 = (longlong *)
                                    FUN_142cd7b20(tstate,plVar13,classes_const_1782_frombuffer);
                          if (plVar17 == (longlong *)0x0) {
                            plStackX_20 = *(longlong **)(tstate + 0x70);
                            *(undefined8 *)(tstate + 0x70) = 0;
                            if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                              (**(code **)(plVar16[1] + 0x30))(plVar16);
                            }
LAB_1408cb089:
                            uStackX_18 = 0x22d2;
                            plVar13 = plStackX_20;
                          }
                          else {
                            plVar13 = (longlong *)
                                      FUN_142cd7b20(tstate,plVar13,classes_const_1783_uint8);
                            if (plVar13 == (longlong *)0x0) {
                              plStackX_20 = *(longlong **)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                              if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0))
                              {
                                (**(code **)(plVar16[1] + 0x30))(plVar16);
                              }
                              if (((int)*plVar17 < 0) || (*plVar17 = *plVar17 + -1, *plVar17 != 0))
                              goto LAB_1408cb089;
                              (**(code **)(plVar17[1] + 0x30))(plVar17);
                              uStackX_18 = 0x22d2;
                              plVar13 = plStackX_20;
                            }
                            else {
                              *(undefined4 *)(plStack_110 + 5) = 0x22d2;
                              plStack_58 = plVar18;
                              plStack_50 = plVar13;
                              plVar18 = (longlong *)FUN_142cc4ec0(tstate,plVar17,&plStack_58);
                              if ((-1 < (int)*plVar17) && (*plVar17 = *plVar17 + -1, *plVar17 == 0))
                              {
                                (**(code **)(plVar17[1] + 0x30))(plVar17);
                              }
                              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0))
                              {
                                (**(code **)(plVar13[1] + 0x30))(plVar13);
                              }
                              uStackX_18 = 0x22d2;
                              if (plVar18 == (longlong *)0x0) {
                                plStackX_20 = *(longlong **)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                                plVar13 = plStackX_20;
                                if ((-1 < (int)*plVar16) &&
                                   (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                                  (**(code **)(plVar16[1] + 0x30))(plVar16);
                                  plVar13 = plStackX_20;
                                }
                              }
                              else {
                                plVar13 = (longlong *)
                                          FUN_142cd7b20(tstate,plVar14,
                                                        classes_const_1914_IMREAD_COLOR);
                                if (plVar13 == (longlong *)0x0) {
                                  plStackX_20 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  if ((-1 < (int)*plVar16) &&
                                     (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                                    (**(code **)(plVar16[1] + 0x30))(plVar16);
                                  }
                                  plVar13 = plStackX_20;
                                  if ((-1 < (int)*plVar18) &&
                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                    uStackX_18 = 0x22d2;
                                    plVar13 = plStackX_20;
                                  }
                                }
                                else {
                                  uStackX_18 = 0x22d2;
                                  *(undefined4 *)(plStack_110 + 5) = 0x22d2;
                                  plStack_48 = plVar18;
                                  plStack_40 = plVar13;
                                  pcVar19 = (code *)FUN_142cc4ec0(tstate,plVar16,&plStack_48);
                                  if ((-1 < (int)*plVar16) &&
                                     (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                                    (**(code **)(plVar16[1] + 0x30))(plVar16);
                                  }
                                  if ((-1 < (int)*plVar18) &&
                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                  }
                                  if ((-1 < (int)*plVar13) &&
                                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                                  }
                                  pcVar23 = _Py_NoneStruct_exref;
                                  if (pcVar19 == (code *)0x0) {
                                    plVar13 = *(longlong **)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                  }
                                  else {
                                    if (pcVar19 == _Py_NoneStruct_exref) {
                                      pcStack_108 = (code *)0x0;
                                      pcVar21 = pcStack_108;
                                      if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                        *(int *)_Py_NoneStruct_exref =
                                             *(int *)_Py_NoneStruct_exref + 1;
                                      }
                                      goto LAB_1408cac53;
                                    }
                                    plVar13 = (longlong *)
                                              FUN_142cd7b20(tstate,pcVar19,classes_const_1795_shape)
                                    ;
                                    pcStack_f8 = pcVar19;
                                    if (plVar13 == (longlong *)0x0) {
LAB_1408cb2b9:
                                      plVar13 = *(longlong **)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                    }
                                    else {
                                      plVar14 = (longlong *)
                                                FUN_140008da0(tstate,plVar13,
                                                                                                                            
                                                  classes_const_1915___type_________items____None__2__None__
                                                  );
                                      if ((-1 < (int)*plVar13) &&
                                         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                        (**(code **)(plVar13[1] + 0x30))(plVar13);
                                      }
                                      if (plVar14 == (longlong *)0x0) goto LAB_1408cb2b9;
                                      plVar16 = (longlong *)FUN_1400099f0(plVar14);
                                      if ((-1 < (int)*plVar14) &&
                                         (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                        (**(code **)(plVar14[1] + 0x30))(plVar14);
                                      }
                                      if (plVar16 == (longlong *)0x0) goto LAB_1408cb2b9;
                                      plVar13 = (longlong *)0x0;
                                      plVar17 = (longlong *)0x0;
                                      plVar14 = (longlong *)
                                                (**(code **)(plVar16[1] + 0xe0))(plVar16);
                                      if (plVar14 == (longlong *)0x0) {
                                        plVar20 = *(longlong **)(tstate + 0x70);
                                        if ((plVar20 == (longlong *)0x0) ||
                                           (lVar12 = plVar20[1], lVar12 == 0)) {
LAB_1408cb3cc:
                                          uVar24 = 0;
                                          plVar14 = plVar13;
                                          goto LAB_1408cb3cf;
                                        }
                                        lVar22 = *(longlong *)(lVar12 + 8);
                                        if ((*(uint *)(*(longlong *)(lVar12 + 8) + 0xa8) &
                                            0x40000000) == 0) {
                                          lVar22 = lVar12;
                                        }
                                        if (lVar22 == *(longlong *)PyExc_StopIteration_exref) {
LAB_1408cb3b2:
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          if (((plVar20 != (longlong *)0x0) && (-1 < (int)*plVar20))
                                             && (*plVar20 = *plVar20 + -1, *plVar20 == 0)) {
                                            (**(code **)(plVar20[1] + 0x30))();
                                          }
                                          goto LAB_1408cb3cc;
                                        }
                                        plVar14 = plVar13;
                                        if ((*(int *)(*(longlong *)(lVar22 + 8) + 0xa8) < 0) &&
                                           (plVar14 = (longlong *)0x0,
                                           (*(uint *)(lVar22 + 0xa8) & 0x40000000) != 0)) {
                                          cVar8 = Nuitka_helper_142cdd950(lVar22);
                                          plVar20 = *(longlong **)(tstate + 0x70);
                                          if (cVar8 == '\x01') goto LAB_1408cb3b2;
                                        }
LAB_1408cb3a2:
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        plVar18 = plVar13;
                                      }
                                      else {
                                        plVar18 = (longlong *)
                                                  (**(code **)(plVar16[1] + 0xe0))(plVar16);
                                        if (plVar18 != (longlong *)0x0) {
                                          plVar13 = (longlong *)
                                                    (**(code **)(plVar16[1] + 0xe0))(plVar16);
                                          if (plVar13 != (longlong *)0x0) {
                                            if ((-1 < (int)*plVar13) &&
                                               (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                              (**(code **)(plVar13[1] + 0x30))(plVar13);
                                            }
                                            plVar13 = (longlong *)
                                                      PyUnicode_FromFormat(&UNK_142d0b0e8,2);
                                            plStackX_20 = (longlong *)
                                                          FUN_142ccfd60(tstate,*(undefined8 *)
                                                                                                                                                                
                                                  PyExc_ValueError_exref,plVar13);
                                            plVar20 = plStackX_20;
                                            if ((-1 < (int)*plVar13) &&
                                               (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                              (**(code **)(plVar13[1] + 0x30))(plVar13);
                                              plVar20 = plStackX_20;
                                            }
                                            goto LAB_1408cbdbc;
                                          }
                                          if ((*(longlong *)(tstate + 0x70) != 0) &&
                                             (lVar12 = *(longlong *)
                                                        (*(longlong *)(tstate + 0x70) + 8),
                                             lVar12 != 0)) {
                                            lVar22 = *(longlong *)(lVar12 + 8);
                                            if ((*(uint *)(*(longlong *)(lVar12 + 8) + 0xa8) &
                                                0x40000000) == 0) {
                                              lVar22 = lVar12;
                                            }
                                            if (lVar22 != *(longlong *)PyExc_StopIteration_exref) {
                                              if ((*(int *)(*(longlong *)(lVar22 + 8) + 0xa8) < 0)
                                                 && ((*(uint *)(lVar22 + 0xa8) & 0x40000000) != 0))
                                              {
                                                cVar8 = Nuitka_helper_142cdd950
                                                                  (lVar22,*(longlong *)
                                                                           PyExc_StopIteration_exref
                                                                  );
                                                plVar20 = *(longlong **)(tstate + 0x70);
                                                *(undefined8 *)(tstate + 0x70) = 0;
                                                if (cVar8 == '\x01') {
                                                  if (plVar20 == (longlong *)0x0)
                                                  goto LAB_1408cb571;
                                                  goto LAB_1408cb560;
                                                }
                                              }
                                              else {
                                                plVar20 = *(longlong **)(tstate + 0x70);
                                                *(undefined8 *)(tstate + 0x70) = 0;
                                              }
                                              goto LAB_1408cbdbc;
                                            }
                                            plVar20 = *(longlong **)(tstate + 0x70);
                                            *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408cb560:
                                            if ((-1 < (int)*plVar20) &&
                                               (*plVar20 = *plVar20 + -1, *plVar20 == 0)) {
                                              (**(code **)(plVar20[1] + 0x30))();
                                            }
                                          }
LAB_1408cb571:
                                          if ((-1 < (int)*plVar16) &&
                                             (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                                            (**(code **)(plVar16[1] + 0x30))(plVar16);
                                          }
                                          iVar10 = (int)*plVar14;
                                          iVar9 = iVar10 + 1;
                                          if (iVar9 != 0) {
                                            *(int *)plVar14 = iVar9;
                                            iVar10 = iVar9;
                                          }
                                          if ((-1 < iVar10) &&
                                             (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                            (**(code **)(plVar14[1] + 0x30))(plVar14);
                                          }
                                          iVar10 = (int)*plVar18;
                                          iVar9 = iVar10 + 1;
                                          if (iVar9 != 0) {
                                            *(int *)plVar18 = iVar9;
                                            iVar10 = iVar9;
                                          }
                                          if ((-1 < iVar10) &&
                                             (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                            (**(code **)(plVar18[1] + 0x30))(plVar18);
                                          }
                                          plVar16 = (longlong *)
                                                    FUN_142cbf590(plVar14,classes_const_1376_3);
                                          plStack_a0 = plVar14;
                                          plStack_98 = plVar18;
                                          if (plVar16 == (longlong *)0x0) {
                                            plVar13 = *(longlong **)(tstate + 0x70);
                                            uStackX_18 = 0x22d6;
                                            pcStack_108 = (code *)0x0;
                                            *(undefined8 *)(tstate + 0x70) = 0;
                                          }
                                          else {
                                            plVar13 = (longlong *)
                                                      FUN_142cbf590(plVar18,classes_const_1376_3);
                                            plStack_90 = plVar16;
                                            plStack_58 = plVar13;
                                            if (plVar13 == (longlong *)0x0) {
                                              plVar13 = *(longlong **)(tstate + 0x70);
                                              uStackX_18 = 0x22d7;
                                              pcStack_108 = (code *)0x0;
                                              *(undefined8 *)(tstate + 0x70) = 0;
                                            }
                                            else {
                                              pcStack_f0 = (code *)FUN_142cd8f90(tstate,0);
                                              plVar14 = (longlong *)
                                                        FUN_140009960(
                                                  classes_const_1758___type_________items____0__9__1__
                                                  );
                                              pcVar21 = (code *)(**(code **)(plVar14[1] + 0xe0))
                                                                          (plVar14);
                                              plStack_88 = plVar13;
                                              if (pcVar21 != (code *)0x0) {
                                                uStackX_18 = 0x22dd;
                                                do {
                                                  if (((pcStack_108 != (code *)0x0) &&
                                                      (-1 < *(int *)pcStack_108)) &&
                                                     (*(longlong *)pcStack_108 =
                                                           *(longlong *)pcStack_108 + -1,
                                                     *(longlong *)pcStack_108 == 0)) {
                                                    (**(code **)(*(longlong *)(pcStack_108 + 8) +
                                                                0x30))(pcStack_108);
                                                  }
                                                  if (*(int *)pcVar21 + 1 != 0) {
                                                    *(int *)pcVar21 = *(int *)pcVar21 + 1;
                                                  }
                                                  if (((pcStack_108 != (code *)0x0) &&
                                                      (-1 < *(int *)pcStack_108)) &&
                                                     (*(longlong *)pcStack_108 =
                                                           *(longlong *)pcStack_108 + -1,
                                                     *(longlong *)pcStack_108 == 0)) {
                                                    (**(code **)(*(longlong *)(pcStack_108 + 8) +
                                                                0x30))();
                                                  }
                                                  plVar13 = (longlong *)
                                                            FUN_142cbf590(pcVar21,
                                                  classes_const_1376_3);
                                                  pcStack_108 = pcVar21;
                                                  if (plVar13 == (longlong *)0x0) {
                                                    uStackX_18 = 0x22da;
                                                    goto LAB_1408cbc74;
                                                  }
                                                  if (((plStack_e0 != (longlong *)0x0) &&
                                                      (-1 < (int)*plStack_e0)) &&
                                                     (*plStack_e0 = *plStack_e0 + -1,
                                                     *plStack_e0 == 0)) {
                                                    (**(code **)(plStack_e0[1] + 0x30))(plStack_e0);
                                                  }
                                                  plVar17 = (longlong *)
                                                            FUN_142cbfdc0(pcVar21,
                                                  classes_const_1376_3);
                                                  plStack_e0 = plVar13;
                                                  if (plVar17 == (longlong *)0x0) {
                                                    uStackX_18 = 0x22db;
                                                    goto LAB_1408cbc74;
                                                  }
                                                  if (((plStack_d8 != (longlong *)0x0) &&
                                                      (-1 < (int)*plStack_d8)) &&
                                                     (*plStack_d8 = *plStack_d8 + -1,
                                                     *plStack_d8 == 0)) {
                                                    (**(code **)(plStack_d8[1] + 0x30))(plStack_d8);
                                                  }
                                                  plVar18 = (longlong *)
                                                            Nuitka_helper_142cc0520(plVar13,plVar16)
                                                  ;
                                                  plStack_d8 = plVar17;
                                                  if (plVar18 == (longlong *)0x0) {
LAB_1408cbaeb:
                                                    uStackX_18 = 0x22dc;
                                                    goto LAB_1408cbc74;
                                                  }
                                                  plVar13 = (longlong *)
                                                            FUN_142cbe6d0(plVar13,_DAT_142d9a268);
                                                  if (plVar13 == (longlong *)0x0) {
LAB_1408cbb66:
                                                    plStackX_20 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    if ((-1 < (int)*plVar18) &&
                                                       (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                      (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                    }
                                                    uStackX_18 = 0x22dc;
                                                    plVar13 = plStackX_20;
                                                    goto LAB_1408cbc84;
                                                  }
                                                  plVar20 = (longlong *)
                                                            Nuitka_helper_142cc0520(plVar13,plVar16)
                                                  ;
                                                  if ((-1 < (int)*plVar13) &&
                                                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                                                  }
                                                  if (plVar20 == (longlong *)0x0)
                                                  goto LAB_1408cbb66;
                                                  lVar12 = FUN_142cdd880(tstate,plVar18,plVar20,
                                                                         _Py_NoneStruct_exref);
                                                  if ((-1 < (int)*plVar18) &&
                                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                  }
                                                  if ((-1 < (int)*plVar20) &&
                                                     (*plVar20 = *plVar20 + -1, *plVar20 == 0)) {
                                                    (**(code **)(plVar20[1] + 0x30))(plVar20);
                                                  }
                                                  plVar18 = (longlong *)FUN_142cd9440(tstate,2);
                                                  plVar13 = plStack_58;
                                                  plVar18[3] = lVar12;
                                                  plVar20 = (longlong *)
                                                            Nuitka_helper_142cc0520
                                                                      (plVar17,plStack_58);
                                                  if (plVar20 == (longlong *)0x0) {
                                                    plStackX_20 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408cbb3a:
                                                    uStackX_18 = 0x22dc;
                                                    plVar13 = plStackX_20;
                                                    if ((-1 < (int)*plVar18) &&
                                                       (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                      (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                      plVar13 = plStackX_20;
                                                    }
                                                    goto LAB_1408cbc84;
                                                  }
                                                  plVar17 = (longlong *)
                                                            FUN_142cbe6d0(plVar17,_DAT_142d9a268);
                                                  if (plVar17 == (longlong *)0x0) {
LAB_1408cbaf6:
                                                    plStackX_20 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    if ((-1 < (int)*plVar20) &&
                                                       (*plVar20 = *plVar20 + -1, *plVar20 == 0)) {
                                                      (**(code **)(plVar20[1] + 0x30))(plVar20);
                                                    }
                                                    goto LAB_1408cbb3a;
                                                  }
                                                  plVar13 = (longlong *)
                                                            Nuitka_helper_142cc0520(plVar17,plVar13)
                                                  ;
                                                  if ((-1 < (int)*plVar17) &&
                                                     (*plVar17 = *plVar17 + -1, *plVar17 == 0)) {
                                                    (**(code **)(plVar17[1] + 0x30))(plVar17);
                                                  }
                                                  if (plVar13 == (longlong *)0x0)
                                                  goto LAB_1408cbaf6;
                                                  lVar12 = FUN_142cdd880(tstate,plVar20,plVar13,
                                                                         _Py_NoneStruct_exref);
                                                  if ((-1 < (int)*plVar20) &&
                                                     (*plVar20 = *plVar20 + -1, *plVar20 == 0)) {
                                                    (**(code **)(plVar20[1] + 0x30))(plVar20);
                                                  }
                                                  if ((-1 < (int)*plVar13) &&
                                                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                                                  }
                                                  plVar18[4] = lVar12;
                                                  plVar13 = (longlong *)
                                                            FUN_140008da0(tstate,pcVar19,plVar18);
                                                  if ((-1 < (int)*plVar18) &&
                                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                  }
                                                  if (plVar13 == (longlong *)0x0)
                                                  goto LAB_1408cbaeb;
                                                  if (((plStack_d0 != (longlong *)0x0) &&
                                                      (-1 < (int)*plStack_d0)) &&
                                                     (*plStack_d0 = *plStack_d0 + -1,
                                                     *plStack_d0 == 0)) {
                                                    (**(code **)(plStack_d0[1] + 0x30))();
                                                  }
                                                  plStack_d0 = plVar13;
                                                  if (plVar2 == (longlong *)0x0) {
                                                    FUN_142cd4900(tstate,&plStackX_20,
                                                                  classes_const_403_self);
                                                    FUN_1400048d0(tstate,plStackX_20);
                                                    plVar13 = plStackX_20;
                                                    goto LAB_1408cbc84;
                                                  }
                                                  *(undefined4 *)(plStack_110 + 5) = 0x22dd;
                                                  plVar13 = (longlong *)
                                                            FUN_142cd12f0(tstate,plVar2,
                                                                                                                                                    
                                                  classes_const_1918__dhash_celula,plVar13);
                                                  if (plVar13 == (longlong *)0x0) {
LAB_1408cbaac:
                                                    plVar13 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    goto LAB_1408cbc84;
                                                  }
                                                  iVar9 = PySequence_Contains(plVar15,plVar13);
                                                  if ((-1 < (int)*plVar13) &&
                                                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                                                  }
                                                  if (iVar9 == -1) goto LAB_1408cbaac;
                                                  if (iVar9 == 1) {
                                                    if (pcStack_f0 == (code *)0x0) {
                                                      FUN_142cd4900(tstate,&plStackX_20,
                                                                    classes_const_1762_alvos);
                                                      FUN_1400048d0(tstate,plStackX_20);
                                                      uStackX_18 = 0x22de;
                                                      plVar13 = plStackX_20;
                                                      goto LAB_1408cbc84;
                                                    }
                                                    FUN_142cd7140(pcStack_f0,pcVar21);
                                                  }
                                                  if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                                                      (iVar9 = Py_MakePendingCalls(), iVar9 < 0)) &&
                                                     (plVar13 = *(longlong **)(tstate + 0x70),
                                                     plVar13 != (longlong *)0x0)) {
LAB_1408cba99:
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    uStackX_18 = 0x22d9;
                                                    goto LAB_1408cbc84;
                                                  }
                                                  if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                                                    PyEval_SaveThread();
                                                    PyEval_AcquireThread(tstate);
                                                  }
                                                  if (*(longlong *)(tstate + 0x90) != 0) {
                                                    plVar15 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x90) = 0;
                                                    plVar13 = (longlong *)FUN_142cd9e70(tstate);
                                                    *(longlong **)(tstate + 0x70) = plVar13;
                                                    if ((plVar15 != (longlong *)0x0) &&
                                                       (-1 < (int)*plVar15)) {
                                                      *plVar15 = *plVar15 + -1;
                                                      if (*plVar15 == 0) {
                                                        (**(code **)(plVar15[1] + 0x30))(plVar15);
                                                      }
                                                      plVar13 = *(longlong **)(tstate + 0x70);
                                                    }
                                                    goto LAB_1408cba99;
                                                  }
                                                  pcVar21 = (code *)(**(code **)(plVar14[1] + 0xe0))
                                                                              (plVar14);
                                                } while (pcVar21 != (code *)0x0);
                                              }
                                              plVar13 = *(longlong **)(tstate + 0x70);
                                              if (plVar13 != (longlong *)0x0) {
                                                cVar8 = FUN_140008d40(tstate,plVar13,
                                                                      *(undefined8 *)
                                                                       PyExc_StopIteration_exref);
                                                if (cVar8 == '\0') {
                                                  uStackX_18 = 0x22d9;
LAB_1408cbc74:
                                                  plVar13 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408cbc84:
                                                  plStackX_20 = (longlong *)0x0;
                                                  if (((pcStack_108 != (code *)0x0) &&
                                                      (-1 < *(int *)pcStack_108)) &&
                                                     (*(longlong *)pcStack_108 =
                                                           *(longlong *)pcStack_108 + -1,
                                                     *(longlong *)pcStack_108 == 0)) {
                                                    (**(code **)(*(longlong *)(pcStack_108 + 8) +
                                                                0x30))(pcStack_108);
                                                  }
                                                  if ((-1 < (int)*plVar14) &&
                                                     (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                                    (**(code **)(plVar14[1] + 0x30))();
                                                  }
                                                  goto LAB_1408cbe2b;
                                                }
                                                *(undefined8 *)(tstate + 0x70) = 0;
                                                if ((-1 < (int)*plVar13) &&
                                                   (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                                                }
                                              }
                                              if (((pcStack_108 != (code *)0x0) &&
                                                  (-1 < *(int *)pcStack_108)) &&
                                                 (*(longlong *)pcStack_108 =
                                                       *(longlong *)pcStack_108 + -1,
                                                 *(longlong *)pcStack_108 == 0)) {
                                                (**(code **)(*(longlong *)(pcStack_108 + 8) + 0x30))
                                                          (pcStack_108);
                                              }
                                              if ((-1 < (int)*plVar14) &&
                                                 (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                                (**(code **)(plVar14[1] + 0x30))(plVar14);
                                              }
                                              if (pcStack_f0 == (code *)0x0) {
                                                FUN_142cd4900(tstate,&plStackX_20,
                                                              classes_const_1762_alvos);
                                                FUN_1400048d0(tstate,plStackX_20);
                                                uStackX_18 = 0x22df;
                                                plVar13 = plStackX_20;
                                              }
                                              else {
                                                plVar13 = (longlong *)
                                                          FUN_142cc1f90(tstate,pcStack_f0);
                                                if (plVar13 != (longlong *)0x0) {
                                                  cVar8 = Nuitka_helper_142ce3660(plVar13,3);
                                                  if ((-1 < (int)*plVar13) &&
                                                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                                                  }
                                                  pcVar23 = _Py_NoneStruct_exref;
                                                  pcVar21 = pcStack_f0;
                                                  if (cVar8 == '\0') {
                                                    pcVar23 = pcStack_f0;
                                                    if (*(int *)pcStack_f0 + 1 != 0) {
                                                      *(int *)pcStack_f0 = *(int *)pcStack_f0 + 1;
                                                    }
                                                  }
                                                  else if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                                    *(int *)_Py_NoneStruct_exref =
                                                         *(int *)_Py_NoneStruct_exref + 1;
                                                  }
                                                  goto LAB_1408cac53;
                                                }
                                                plVar13 = *(longlong **)(tstate + 0x70);
                                                uStackX_18 = 0x22df;
                                                *(undefined8 *)(tstate + 0x70) = 0;
                                              }
                                            }
                                          }
                                          goto LAB_1408cbe2b;
                                        }
                                        plVar20 = *(longlong **)(tstate + 0x70);
                                        if ((plVar20 != (longlong *)0x0) &&
                                           (lVar12 = plVar20[1], lVar12 != 0)) {
                                          lVar22 = *(longlong *)(lVar12 + 8);
                                          if ((*(uint *)(*(longlong *)(lVar12 + 8) + 0xa8) &
                                              0x40000000) == 0) {
                                            lVar22 = lVar12;
                                          }
                                          if (lVar22 != *(longlong *)PyExc_StopIteration_exref) {
                                            if ((-1 < *(int *)(*(longlong *)(lVar22 + 8) + 0xa8)) ||
                                               ((*(uint *)(lVar22 + 0xa8) & 0x40000000) == 0))
                                            goto LAB_1408cb3a2;
                                            cVar8 = Nuitka_helper_142cdd950(lVar22);
                                            plVar20 = *(longlong **)(tstate + 0x70);
                                            if (cVar8 != '\x01') {
                                              *(undefined8 *)(tstate + 0x70) = 0;
                                              plVar18 = plVar17;
                                              goto LAB_1408cbdbc;
                                            }
                                          }
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          if (((plVar20 != (longlong *)0x0) && (-1 < (int)*plVar20))
                                             && (*plVar20 = *plVar20 + -1, *plVar20 == 0)) {
                                            (**(code **)(plVar20[1] + 0x30))();
                                          }
                                        }
                                        uVar24 = 1;
LAB_1408cb3cf:
                                        plVar13 = (longlong *)
                                                  PyUnicode_FromFormat(&UNK_142d0b0b0,2,uVar24);
                                        plStackX_20 = (longlong *)
                                                      FUN_142ccfd60(tstate,*(undefined8 *)
                                                                            PyExc_ValueError_exref,
                                                                    plVar13);
                                        plVar18 = plVar17;
                                        plVar20 = plStackX_20;
                                        if ((-1 < (int)*plVar13) &&
                                           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                          (**(code **)(plVar13[1] + 0x30))(plVar13);
                                          plVar20 = plStackX_20;
                                        }
                                      }
LAB_1408cbdbc:
                                      plStackX_20 = plVar20;
                                      plVar13 = plStackX_20;
                                      if ((-1 < (int)*plVar16) &&
                                         (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                                        (**(code **)(plVar16[1] + 0x30))(plVar16);
                                      }
                                      if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
                                         (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                                        (**(code **)(plVar14[1] + 0x30))(plVar14);
                                      }
                                      if (((plVar18 != (longlong *)0x0) && (-1 < (int)*plVar18)) &&
                                         (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                        (**(code **)(plVar18[1] + 0x30))(plVar18);
                                      }
                                    }
                                    uStackX_18 = 0x22d5;
                                  }
                                }
                              }
                            }
                          }
                          goto LAB_1408cbe2b;
                        }
                        uStackX_18 = 0x22cf;
                      }
                    }
LAB_1408caf47:
                    plVar13 = *(longlong **)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x70) = 0;
                    goto LAB_1408cbe2b;
                  }
                }
              }
              plStackX_20 = *(longlong **)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                (**(code **)(plVar16[1] + 0x30))(plVar16);
              }
            }
          }
          plVar13 = plStackX_20;
          piVar5 = *(int **)(tstate + 0xf8);
          plStackX_20 = (longlong *)0x0;
          if ((piVar5 != (int *)0x0) && (*piVar5 + 1 != 0)) {
            *piVar5 = *piVar5 + 1;
          }
          piVar4 = (int *)plVar13[5];
          if (piVar4 == (int *)0x0) {
            pcVar21 = (code *)FUN_142cd9160(plStack_110,0x22cb);
            plVar14 = (longlong *)plVar13[5];
            if (pcVar21 == _Py_NoneStruct_exref) {
              pcVar25 = (code *)0x0;
            }
            else {
              pcVar25 = pcVar21;
              if ((pcVar21 != (code *)0x0) && (*(int *)pcVar21 + 1 != 0)) {
                *(int *)pcVar21 = *(int *)pcVar21 + 1;
              }
            }
            plVar13[5] = (longlong)pcVar25;
            if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
               (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
              (**(code **)(plVar14[1] + 0x30))();
            }
            if (((pcVar21 != (code *)0x0) && (-1 < *(int *)pcVar21)) &&
               (*(longlong *)pcVar21 = *(longlong *)pcVar21 + -1, *(longlong *)pcVar21 == 0)) {
              (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))(pcVar21);
            }
          }
          else {
            pcVar21 = (code *)FUN_142cd9160(plStack_110,0x22cb);
            *(int **)(pcVar21 + 0x10) = piVar4;
            if (*piVar4 + 1 != 0) {
              *piVar4 = *piVar4 + 1;
            }
            plVar14 = (longlong *)plVar13[5];
            if (pcVar21 == _Py_NoneStruct_exref) {
              pcVar25 = (code *)0x0;
            }
            else {
              pcVar25 = pcVar21;
              if ((pcVar21 != (code *)0x0) && (*(int *)pcVar21 + 1 != 0)) {
                *(int *)pcVar21 = *(int *)pcVar21 + 1;
              }
            }
            plVar13[5] = (longlong)pcVar25;
            if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
               (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
              (**(code **)(plVar14[1] + 0x30))();
            }
            if (((pcVar21 != (code *)0x0) && (-1 < *(int *)pcVar21)) &&
               (*(longlong *)pcVar21 = *(longlong *)pcVar21 + -1, *(longlong *)pcVar21 == 0)) {
              (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))(pcVar21);
            }
          }
          plVar14 = *(longlong **)(tstate + 0xf8);
          *(longlong **)(tstate + 0xf8) = plVar13;
          if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
             (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))();
          }
          iVar9 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                                *(undefined8 *)PyExc_Exception_exref);
          pcVar23 = _Py_NoneStruct_exref;
          if (iVar9 != 0) {
            if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
              *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
            }
            plVar13 = *(longlong **)(tstate + 0xf8);
            *(int **)(tstate + 0xf8) = piVar5;
            pcVar21 = pcStack_108;
            pcVar19 = pcStack_108;
            if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
               (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))();
            }
LAB_1408cac53:
            plVar13 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
            *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
            *(undefined4 *)(plVar13 + 10) = 0xfffffffe;
            plVar14 = (longlong *)plVar13[2];
            if (((plVar14 != (longlong *)0x0) && (plVar13[2] = 0, -1 < (int)*plVar14)) &&
               (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
              (**(code **)(plVar14[1] + 0x30))();
            }
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
            }
            plVar13[0xc] = 0;
            if ((-1 < *(int *)pcVar11) &&
               (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
              (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
            }
            if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
               (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
              (**(code **)(plStack_c8[1] + 0x30))();
            }
            if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
               (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
              (**(code **)(plStack_c0[1] + 0x30))();
            }
            if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
               (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
              (**(code **)(plStack_b8[1] + 0x30))();
            }
            if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
               (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
              (**(code **)(plStack_b0[1] + 0x30))();
            }
            if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
               (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
              (**(code **)(plStack_a8[1] + 0x30))();
            }
            if (((pcVar19 != (code *)0x0) && (-1 < *(int *)pcVar19)) &&
               (*(longlong *)pcVar19 = *(longlong *)pcVar19 + -1, *(longlong *)pcVar19 == 0)) {
              (**(code **)(*(longlong *)(pcVar19 + 8) + 0x30))(pcVar19);
            }
            if (((plStack_a0 != (longlong *)0x0) && (-1 < (int)*plStack_a0)) &&
               (*plStack_a0 = *plStack_a0 + -1, *plStack_a0 == 0)) {
              (**(code **)(plStack_a0[1] + 0x30))();
            }
            if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
               (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
              (**(code **)(plStack_98[1] + 0x30))();
            }
            if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
               (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
              (**(code **)(plStack_90[1] + 0x30))();
            }
            if (((plStack_88 != (longlong *)0x0) && (-1 < (int)*plStack_88)) &&
               (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
              (**(code **)(plStack_88[1] + 0x30))();
            }
            if (((pcVar21 != (code *)0x0) && (-1 < *(int *)pcVar21)) &&
               (*(longlong *)pcVar21 = *(longlong *)pcVar21 + -1, *(longlong *)pcVar21 == 0)) {
              (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))(pcVar21);
            }
            if (((pcStack_108 != (code *)0x0) && (-1 < *(int *)pcStack_108)) &&
               (*(longlong *)pcStack_108 = *(longlong *)pcStack_108 + -1,
               *(longlong *)pcStack_108 == 0)) {
              (**(code **)(*(longlong *)(pcStack_108 + 8) + 0x30))(pcStack_108);
            }
            if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
               (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
              (**(code **)(plStack_e0[1] + 0x30))();
            }
            if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8)) &&
               (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
              (**(code **)(plStack_d8[1] + 0x30))();
            }
            if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
               (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
              (**(code **)(plStack_d0[1] + 0x30))();
            }
            if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
              (**(code **)(plVar2[1] + 0x30))();
            }
            if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
              (**(code **)(plVar1[1] + 0x30))();
            }
            if ((int)*plVar3 < 0) {
              return pcVar23;
            }
            *plVar3 = *plVar3 + -1;
            if (*plVar3 != 0) {
              return pcVar23;
            }
            (**(code **)(plVar3[1] + 0x30))();
            return pcVar23;
          }
          cVar8 = FUN_142cded30(tstate,&plStackX_20);
          plVar13 = plStackX_20;
          uStackX_18 = 0x22ca;
          if (cVar8 != '\0') {
            uStackX_18 = 0;
          }
          lVar12 = plStackX_20[5];
          if ((lVar12 != 0) && (*(longlong **)(lVar12 + 0x18) == plStack_110)) {
            *(undefined4 *)(plStack_110 + 5) = *(undefined4 *)(lVar12 + 0x24);
          }
          plStackX_20 = (longlong *)0x0;
          plVar14 = *(longlong **)(tstate + 0xf8);
          *(int **)(tstate + 0xf8) = piVar5;
          if (((plVar14 != (longlong *)0x0) && (-1 < (int)*plVar14)) &&
             (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))();
          }
        }
      }
    }
  }
LAB_1408cbe2b:
  plStackX_20 = plVar13;
  piVar5 = (int *)plStackX_20[5];
  if (piVar5 == (int *)0x0) {
    pcVar21 = (code *)FUN_142cd9160(plStack_110,uStackX_18);
    bVar26 = pcVar21 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar5 + 6) == plStack_110) goto LAB_1408cbed1;
    pcVar21 = (code *)FUN_142cd9160(plStack_110,uStackX_18);
    *(int **)(pcVar21 + 0x10) = piVar5;
    if (*piVar5 + 1 != 0) {
      *piVar5 = *piVar5 + 1;
    }
    bVar26 = pcVar21 == _Py_NoneStruct_exref;
  }
  plVar13 = (longlong *)plStackX_20[5];
  if (bVar26) {
    pcVar25 = (code *)0x0;
  }
  else {
    pcVar25 = pcVar21;
    if ((pcVar21 != (code *)0x0) && (*(int *)pcVar21 + 1 != 0)) {
      *(int *)pcVar21 = *(int *)pcVar21 + 1;
    }
  }
  plStackX_20[5] = (longlong)pcVar25;
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))();
  }
  if (((pcVar21 != (code *)0x0) && (-1 < *(int *)pcVar21)) &&
     (*(longlong *)pcVar21 = *(longlong *)pcVar21 + -1, *(longlong *)pcVar21 == 0)) {
    (**(code **)(*(longlong *)(pcVar21 + 8) + 0x30))(pcVar21);
  }
LAB_1408cbed1:
  FUN_142cdb370(plStack_110,&UNK_142d0b330,plVar2,plVar1,plVar3,pcVar11,plStack_c8,plStack_c0,
                plStack_b8,plStack_b0,plStack_a8,pcStack_f8,plStack_a0,plStack_98,plStack_90,
                plStack_88,pcStack_f0,pcStack_108,plStack_e0,plStack_d8,plStack_d0);
  plVar13 = _DAT_142dea798;
  if (plStack_110 == _DAT_142dea798) {
    if ((-1 < (int)*_DAT_142dea798) && (*_DAT_142dea798 = *_DAT_142dea798 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))();
    }
    _DAT_142dea798 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  plVar13 = plStackX_20;
  plStackX_20 = (longlong *)0x0;
  if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
     (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
    (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
  }
  if (((plStack_c8 != (longlong *)0x0) && (-1 < (int)*plStack_c8)) &&
     (*plStack_c8 = *plStack_c8 + -1, *plStack_c8 == 0)) {
    (**(code **)(plStack_c8[1] + 0x30))();
  }
  if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
     (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
    (**(code **)(plStack_c0[1] + 0x30))();
  }
  if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
     (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
    (**(code **)(plStack_b8[1] + 0x30))();
  }
  if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
     (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
    (**(code **)(plStack_b0[1] + 0x30))();
  }
  if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
     (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
    (**(code **)(plStack_a8[1] + 0x30))();
  }
  if (((pcStack_f8 != (code *)0x0) && (-1 < *(int *)pcStack_f8)) &&
     (*(longlong *)pcStack_f8 = *(longlong *)pcStack_f8 + -1, *(longlong *)pcStack_f8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_f8 + 8) + 0x30))(pcStack_f8);
  }
  if (((plStack_a0 != (longlong *)0x0) && (-1 < (int)*plStack_a0)) &&
     (*plStack_a0 = *plStack_a0 + -1, *plStack_a0 == 0)) {
    (**(code **)(plStack_a0[1] + 0x30))();
  }
  if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
     (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
    (**(code **)(plStack_98[1] + 0x30))();
  }
  if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
     (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
    (**(code **)(plStack_90[1] + 0x30))();
  }
  if (((plStack_88 != (longlong *)0x0) && (-1 < (int)*plStack_88)) &&
     (*plStack_88 = *plStack_88 + -1, *plStack_88 == 0)) {
    (**(code **)(plStack_88[1] + 0x30))();
  }
  if (((pcStack_f0 != (code *)0x0) && (-1 < *(int *)pcStack_f0)) &&
     (*(longlong *)pcStack_f0 = *(longlong *)pcStack_f0 + -1, *(longlong *)pcStack_f0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_f0 + 8) + 0x30))(pcStack_f0);
  }
  if (((pcStack_108 != (code *)0x0) && (-1 < *(int *)pcStack_108)) &&
     (*(longlong *)pcStack_108 = *(longlong *)pcStack_108 + -1, *(longlong *)pcStack_108 == 0)) {
    (**(code **)(*(longlong *)(pcStack_108 + 8) + 0x30))(pcStack_108);
  }
  if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
     (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
    (**(code **)(plStack_e0[1] + 0x30))();
  }
  if (((plStack_d8 != (longlong *)0x0) && (-1 < (int)*plStack_d8)) &&
     (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
    (**(code **)(plStack_d8[1] + 0x30))();
  }
  if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
     (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
    (**(code **)(plStack_d0[1] + 0x30))();
  }
  plStackX_20 = plVar13;
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))();
  }
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
    (**(code **)(plVar3[1] + 0x30))();
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong **)(tstate + 0x70) = plStackX_20;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

