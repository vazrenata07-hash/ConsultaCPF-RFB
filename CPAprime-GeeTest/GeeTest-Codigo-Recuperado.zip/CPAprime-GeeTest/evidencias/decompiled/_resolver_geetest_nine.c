
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _resolver_geetest_nine(undefined *tstate,undefined *self,undefined **python_pars)

{
  char cVar1;
  int iVar2;
  code *pcVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  code *pcVar8;
  code *pcVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *plVar13;
  undefined *puVar14;
  code *pcVar15;
  int *piVar16;
  undefined4 uVar17;
  bool bVar18;
  undefined1 auStack_1e8 [32];
  longlong *plStack_1c8;
  longlong *plStack_1c0;
  longlong *plStack_1b8;
  longlong *plStack_1b0;
  undefined8 uStack_1a8;
  longlong *plStack_1a0;
  code *pcStack_198;
  longlong *plStack_190;
  longlong *plStack_188;
  code *pcStack_180;
  code *pcStack_178;
  longlong *plStack_170;
  longlong *plStack_168;
  code *pcStack_160;
  longlong *plStack_158;
  longlong *plStack_150;
  code *pcStack_148;
  longlong lStack_130;
  longlong *plStack_128;
  code *pcStack_120;
  longlong *plStack_118;
  longlong *plStack_110;
  longlong *plStack_108;
  longlong *plStack_100;
  code *pcStack_f8;
  longlong *plStack_f0;
  longlong *plStack_e8;
  longlong *plStack_e0;
  longlong *plStack_d8;
  longlong *plStack_d0;
  code *pcStack_c8;
  longlong *plStack_c0;
  longlong *plStack_b8;
  code *pcStack_b0;
  longlong *plStack_a8;
  code *pcStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  code *pcStack_88;
  longlong *plStack_80;
  code *pcStack_78;
  code *pcStack_70;
  longlong *plStack_68;
  code *pcStack_60;
  longlong *plStack_58;
  code *pcStack_50;
  ulonglong uStack_48;
  
  plVar4 = _DAT_142d9a260;
  uStack_48 = _DAT_142d9a1c0 ^ (ulonglong)auStack_1e8;
  pcVar9 = (code *)0x0;
  plVar13 = (longlong *)*python_pars;
  plStack_d8 = (longlong *)python_pars[1];
  lStack_130 = 0;
  plStack_d0 = (longlong *)0x0;
  plStack_e0 = (longlong *)0x0;
  pcStack_c8 = (code *)0x0;
  plStack_c0 = (longlong *)0x0;
  plStack_b8 = (longlong *)0x0;
  pcStack_b0 = (code *)0x0;
  pcStack_f8 = (code *)0x0;
  plStack_e8 = (longlong *)0x0;
  plStack_a8 = (longlong *)0x0;
  pcStack_a0 = (code *)0x0;
  plStack_98 = (longlong *)0x0;
  plStack_90 = (longlong *)0x0;
  pcStack_120 = (code *)0x0;
  plStack_108 = _DAT_142d9a260;
  plStack_f0 = _DAT_142d9a260;
  iVar2 = (int)*_DAT_142d9a260 + 1;
  if (iVar2 != 0) {
    *(int *)_DAT_142d9a260 = iVar2;
    plStack_108 = _DAT_142d9a260;
  }
  plStack_100 = plStack_108;
  iVar2 = (int)*plStack_108 + 1;
  if (iVar2 != 0) {
    _DAT_142d9a260 = plStack_108;
    *(int *)plStack_108 = iVar2;
    plStack_108 = _DAT_142d9a260;
  }
  iVar2 = (int)*plStack_108 + 1;
  _DAT_142d9a260 = plStack_108;
  if (iVar2 != 0) {
    *(int *)plStack_108 = iVar2;
  }
  plVar11 = _DAT_142dea7a0;
  plStack_118 = _DAT_142dea7a0;
  plStack_128 = plVar13;
  if (_DAT_142dea7a0 == (longlong *)0x0) {
LAB_1408cc30d:
    _DAT_142dea7a0 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9d40,_DAT_142f2aaf0,0x98);
  }
  else if ((1 < *_DAT_142dea7a0) || (_DAT_142dea7a0[2] != 0)) {
    if ((_DAT_142dea7a0 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea7a0 && (*_DAT_142dea7a0 = *_DAT_142dea7a0 + -1, *plVar11 == 0)))) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
    goto LAB_1408cc30d;
  }
  plVar11 = _DAT_142dea7a0;
  plVar5 = plStack_d8;
  plStack_118 = _DAT_142dea7a0;
  Nuitka_helper_140008a00(tstate,_DAT_142dea7a0);
LAB_1408cc350:
  uVar17 = 0x22f4;
  pcVar3 = (code *)FUN_142ce3260(plVar4,plVar5);
  if (pcVar3 == (code *)0x0) goto LAB_1408cf718;
  if (pcVar3 == _Py_TrueStruct_exref) {
LAB_1408cc370:
    iVar2 = 1;
  }
  else if ((pcVar3 == _Py_FalseStruct_exref) || (pcVar3 == _Py_NoneStruct_exref)) {
    iVar2 = 0;
  }
  else {
    lVar7 = *(longlong *)(pcVar3 + 8);
    if ((*(longlong *)(lVar7 + 0x60) == 0) ||
       (pcVar8 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar8 == (code *)0x0)) {
      if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
          (pcVar8 = (code *)**(longlong **)(lVar7 + 0x70), pcVar8 == (code *)0x0)) &&
         ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
          (pcVar8 = (code *)**(longlong **)(lVar7 + 0x68), pcVar8 == (code *)0x0))))
      goto LAB_1408cc370;
      lVar7 = (*pcVar8)(pcVar3);
    }
    else {
      iVar2 = (*pcVar8)(pcVar3);
      lVar7 = (longlong)iVar2;
    }
    if (lVar7 < 1) {
      iVar2 = -(uint)(lVar7 != 0);
    }
    else {
      iVar2 = 1;
    }
  }
  if ((-1 < *(int *)pcVar3) &&
     (*(longlong *)pcVar3 = *(longlong *)pcVar3 + -1, *(longlong *)pcVar3 == 0)) {
    (**(code **)(*(longlong *)(pcVar3 + 8) + 0x30))(pcVar3);
  }
  if (iVar2 == -1) goto LAB_1408cf718;
  if (iVar2 == 0) {
    FUN_140008990(tstate);
    if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
      *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
    }
LAB_1408cf52f:
    if (((plStack_f0 != (longlong *)0x0) && (-1 < (int)*plStack_f0)) &&
       (*plStack_f0 = *plStack_f0 + -1, *plStack_f0 == 0)) {
      (**(code **)(plStack_f0[1] + 0x30))();
    }
    if (((plStack_100 != (longlong *)0x0) && (-1 < (int)*plStack_100)) &&
       (*plStack_100 = *plStack_100 + -1, *plStack_100 == 0)) {
      (**(code **)(plStack_100[1] + 0x30))();
    }
    if (((plStack_108 != (longlong *)0x0) && (-1 < (int)*plStack_108)) &&
       (*plStack_108 = *plStack_108 + -1, *plStack_108 == 0)) {
      (**(code **)(plStack_108[1] + 0x30))();
    }
    if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
       (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
      (**(code **)(plStack_d0[1] + 0x30))();
    }
    if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
       (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
      (**(code **)(plStack_e0[1] + 0x30))();
    }
    if (((pcStack_c8 != (code *)0x0) && (-1 < *(int *)pcStack_c8)) &&
       (*(longlong *)pcStack_c8 = *(longlong *)pcStack_c8 + -1, *(longlong *)pcStack_c8 == 0)) {
      (**(code **)(*(longlong *)(pcStack_c8 + 8) + 0x30))();
    }
    if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
       (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
      (**(code **)(plStack_c0[1] + 0x30))();
    }
    if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
       (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
      (**(code **)(plStack_b8[1] + 0x30))();
    }
    if (((pcStack_b0 != (code *)0x0) && (-1 < *(int *)pcStack_b0)) &&
       (*(longlong *)pcStack_b0 = *(longlong *)pcStack_b0 + -1, *(longlong *)pcStack_b0 == 0)) {
      (**(code **)(*(longlong *)(pcStack_b0 + 8) + 0x30))();
    }
    if (((pcStack_f8 != (code *)0x0) && (-1 < *(int *)pcStack_f8)) &&
       (*(longlong *)pcStack_f8 = *(longlong *)pcStack_f8 + -1, *(longlong *)pcStack_f8 == 0)) {
      (**(code **)(*(longlong *)(pcStack_f8 + 8) + 0x30))();
    }
    if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
       (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
      (**(code **)(plStack_e8[1] + 0x30))();
    }
    if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
       (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
      (**(code **)(plStack_a8[1] + 0x30))();
    }
    if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
       (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0)) {
      (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))();
    }
    if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
       (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
      (**(code **)(plStack_98[1] + 0x30))();
    }
    if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
       (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
      (**(code **)(plStack_90[1] + 0x30))();
    }
    if (((pcVar9 != (code *)0x0) && (-1 < *(int *)pcVar9)) &&
       (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
      (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
    }
    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    if ((-1 < (int)*plStack_d8) && (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
      (**(code **)(plStack_d8[1] + 0x30))(plStack_d8);
    }
    goto LAB_1408cfac4;
  }
  if (plVar13 == (longlong *)0x0) {
    FUN_142cd4900(tstate,&lStack_130,classes_const_403_self);
    FUN_1400048d0(tstate,lStack_130);
LAB_1408cf1fa:
    lVar7 = lStack_130;
    lStack_130 = 0;
    piVar16 = *(int **)(tstate + 0xf8);
    if ((piVar16 != (int *)0x0) && (*piVar16 + 1 != 0)) {
      *piVar16 = *piVar16 + 1;
    }
    if (*(longlong *)(lVar7 + 0x28) == 0) {
      pcVar9 = (code *)FUN_142cd9160(plVar11,0x22f0);
    }
    else {
      pcVar9 = (code *)FUN_140008a80(*(longlong *)(lVar7 + 0x28),plVar11,0x22f0);
    }
    plVar4 = *(longlong **)(lVar7 + 0x28);
    if (pcVar9 == _Py_NoneStruct_exref) {
      pcVar3 = (code *)0x0;
    }
    else {
      pcVar3 = pcVar9;
      if ((pcVar9 != (code *)0x0) && (*(int *)pcVar9 + 1 != 0)) {
        *(int *)pcVar9 = *(int *)pcVar9 + 1;
      }
    }
    *(code **)(lVar7 + 0x28) = pcVar3;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    if (((pcVar9 != (code *)0x0) && (-1 < *(int *)pcVar9)) &&
       (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
      (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
    }
    plVar4 = *(longlong **)(tstate + 0xf8);
    *(longlong *)(tstate + 0xf8) = lVar7;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    iVar2 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    if (iVar2 == 0) {
      cVar1 = FUN_142cded30(tstate,&lStack_130);
      uVar17 = 0x22ef;
      if (cVar1 != '\0') {
        uVar17 = 0;
      }
      lVar10 = *(longlong *)(lStack_130 + 0x28);
      lVar7 = lStack_130;
      if ((lVar10 != 0) && (*(longlong **)(lVar10 + 0x18) == plVar11)) {
        *(undefined4 *)(plVar11 + 5) = *(undefined4 *)(lVar10 + 0x24);
      }
    }
    else {
      plVar4 = *(longlong **)(tstate + 0xf8);
      iVar2 = (int)*plVar4 + 1;
      if (iVar2 != 0) {
        *(int *)plVar4 = iVar2;
      }
      uVar12 = FUN_1400776a0(classes_const_257_print);
      puVar14 = classes_const_1921__s__geetest_3x3__o_script_nao_rodou___s;
      if (plVar13 == (longlong *)0x0) {
        FUN_142cd4900(tstate,&lStack_130,classes_const_403_self);
        FUN_1400048d0(tstate,lStack_130);
        lVar7 = lStack_130;
        uVar17 = 0x22f2;
      }
      else {
        plStack_110 = (longlong *)CONCAT44(plStack_110._4_4_,0x22f2);
        *(undefined4 *)(plStack_118 + 5) = 0x22f2;
        lVar7 = FUN_142cd06a0(tstate,plVar13,classes_const_1346__tag);
        plVar11 = plStack_118;
        if (lVar7 != 0) {
          plVar13 = (longlong *)FUN_142cd9440(tstate,2);
          plVar13[3] = lVar7;
          iVar2 = (int)*plVar4 + 1;
          if (iVar2 != 0) {
            *(int *)plVar4 = iVar2;
          }
          plVar13[4] = (longlong)plVar4;
          plVar5 = (longlong *)FUN_142cbffc0(puVar14,plVar13);
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          plVar11 = plStack_118;
          if (plVar5 != (longlong *)0x0) {
            *(undefined4 *)(plStack_118 + 5) = 0x22f2;
            plVar13 = (longlong *)FUN_142ccfd60(tstate,uVar12,plVar5);
            if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
              (**(code **)(plVar5[1] + 0x30))(plVar5);
            }
            if (plVar13 != (longlong *)0x0) {
LAB_1408cf434:
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
                *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
              }
              if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                (**(code **)(plVar4[1] + 0x30))(plVar4);
              }
              plVar4 = *(longlong **)(tstate + 0xf8);
              *(int **)(tstate + 0xf8) = piVar16;
              plVar13 = plStack_128;
              pcVar9 = pcStack_120;
              if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
                 (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                (**(code **)(plVar4[1] + 0x30))();
                plVar13 = plStack_128;
                pcVar9 = pcStack_120;
              }
LAB_1408cf49b:
              FUN_140008990(tstate);
              goto LAB_1408cf52f;
            }
          }
        }
        lVar7 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        plVar13 = plStack_128;
        uVar17 = plStack_110._0_4_;
      }
      lStack_130 = 0;
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
    }
    lStack_130 = 0;
    plVar4 = *(longlong **)(tstate + 0xf8);
    *(int **)(tstate + 0xf8) = piVar16;
    pcVar9 = pcStack_120;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
      pcVar9 = pcStack_120;
    }
    goto LAB_1408cf72e;
  }
  plVar4 = (longlong *)FUN_142cd7b20(tstate,plVar13,classes_const_170_driver);
  if (plVar4 == (longlong *)0x0) {
LAB_1408cf1cc:
    lStack_130 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    goto LAB_1408cf1fa;
  }
  plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar4,classes_const_338_execute_script);
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))(plVar4);
  }
  if (plVar5 == (longlong *)0x0) goto LAB_1408cf1cc;
  plVar4 = (longlong *)FUN_142cd7b20(tstate,plVar13,classes_const_1920__JS_GEETEST_NINE_URLS);
  if (plVar4 == (longlong *)0x0) {
    lStack_130 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408cf1fa;
  }
  *(undefined4 *)(plVar11 + 5) = 0x22f0;
  plVar6 = (longlong *)FUN_142ccfd60(tstate,plVar5,plVar4);
  plStack_110 = plVar6;
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))(plVar4);
  }
  if (plVar6 == (longlong *)0x0) goto LAB_1408cf1cc;
  plVar4 = plVar6;
  if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
     (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
    plVar4 = plStack_d0 + 1;
    plStack_d0 = plVar6;
    (**(code **)(*plVar4 + 0x30))();
    plVar4 = plStack_d0;
  }
  plStack_d0 = plVar4;
  iVar2 = PyObject_IsInstance(plVar6,PyDict_Type_exref);
  pcVar9 = pcStack_120;
  if (iVar2 == -1) goto LAB_1408cf71e;
  pcVar9 = _Py_FalseStruct_exref;
  if (iVar2 != 0) {
    pcVar9 = _Py_TrueStruct_exref;
  }
  if (pcVar9 != _Py_TrueStruct_exref) {
    if ((pcVar9 != _Py_FalseStruct_exref) && (pcVar9 != _Py_NoneStruct_exref)) {
      lVar7 = *(longlong *)(pcVar9 + 8);
      if ((*(longlong *)(lVar7 + 0x60) == 0) ||
         (pcVar3 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar3 == (code *)0x0)) {
        if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
            (pcVar3 = (code *)**(longlong **)(lVar7 + 0x70), pcVar3 == (code *)0x0)) &&
           ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
            (pcVar3 = (code *)**(longlong **)(lVar7 + 0x68), pcVar3 == (code *)0x0))))
        goto LAB_1408cc69f;
        lVar7 = (*pcVar3)(pcVar9);
      }
      else {
        iVar2 = (*pcVar3)(pcVar9);
        lVar7 = (longlong)iVar2;
      }
      if (0 < lVar7) goto LAB_1408cc69f;
      pcVar9 = pcStack_120;
      if (lVar7 != 0) goto LAB_1408cf71e;
    }
LAB_1408cc59c:
    plVar4 = plStack_e0;
    plVar13 = plStack_108;
    puVar14 = classes_const_102_;
    plStack_e0 = (longlong *)classes_const_102_;
    if (*(int *)classes_const_102_ + 1 != 0) {
      *(int *)classes_const_102_ = *(int *)classes_const_102_ + 1;
    }
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4,plVar4);
    }
    iVar2 = PyObject_IsInstance(plVar6,PyDict_Type_exref);
    if (iVar2 == -1) {
      uVar17 = 0x22f6;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      goto LAB_1408cf71e;
    }
    plVar4 = (longlong *)puVar14;
    plVar5 = plStack_118;
    if (iVar2 != 0) {
      plVar4 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_211_get);
      plVar11 = plStack_118;
      if (plVar4 == (longlong *)0x0) {
        uVar17 = 0x22f7;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
      }
      else {
        *(undefined4 *)(plStack_118 + 5) = 0x22f7;
        plVar5 = (longlong *)
                 FUN_142ccd7d0(tstate,plVar4,classes_const_1851___type____T____items_____erro_______
                              );
        if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
          (**(code **)(plVar4[1] + 0x30))(plVar4);
        }
        if (plVar5 != (longlong *)0x0) {
          plVar4 = (longlong *)FUN_142cc2ce0(plVar5);
          if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
            (**(code **)(plVar5[1] + 0x30))(plVar5);
          }
          if (plVar4 != (longlong *)0x0) {
            plVar5 = plVar11;
            plStack_e0 = plVar4;
            if ((-1 < *(int *)puVar14) &&
               (*(longlong *)puVar14 = *(longlong *)puVar14 + -1, *(longlong *)puVar14 == 0)) {
              (**(code **)(*(longlong *)(puVar14 + 8) + 0x30))(puVar14);
            }
            goto LAB_1408cde51;
          }
        }
        uVar17 = 0x22f7;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
      }
      goto LAB_1408cf71e;
    }
LAB_1408cde51:
    iVar2 = PySequence_Contains(classes_const_1922___type____T____items_____sem_pergunta____sem_grade____sem_sprite_
                                ,plVar4);
    plVar4 = plStack_108;
    if (iVar2 == -1) {
      uVar17 = 0x22fc;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      goto LAB_1408cf71e;
    }
    if (iVar2 != 1) {
LAB_1408cf050:
      uVar12 = FUN_1400776a0(classes_const_257_print);
      puVar14 = classes_const_1923__s__geetest_3x3__nao_consegui_ler_a_grade___s;
      uVar17 = 0x2301;
      *(undefined4 *)(plVar5 + 5) = 0x2301;
      lVar7 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      if (lVar7 == 0) goto LAB_1408cf71e;
      plVar13 = (longlong *)FUN_142cd9440(tstate,2);
      plVar13[3] = lVar7;
      iVar2 = (int)*plStack_e0 + 1;
      if (iVar2 != 0) {
        *(int *)plStack_e0 = iVar2;
      }
      plVar13[4] = (longlong)plStack_e0;
      plVar4 = (longlong *)FUN_142cbffc0(puVar14,plVar13);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      if (plVar4 == (longlong *)0x0) goto LAB_1408cf71e;
      *(undefined4 *)(plVar5 + 5) = 0x2301;
LAB_1408cf100:
      plVar5 = (longlong *)FUN_142ccfd60(tstate,uVar12,plVar4);
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      if (plVar5 == (longlong *)0x0) goto LAB_1408cf71e;
LAB_1408cf13c:
      pcVar15 = _Py_FalseStruct_exref;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      if ((-1 < (int)*plVar5) &&
         (*plVar5 = *plVar5 + -1, pcVar15 = _Py_FalseStruct_exref, *plVar5 == 0)) {
        lVar7 = plVar5[1];
LAB_1408cf14e:
        (**(code **)(lVar7 + 0x30))(plVar5);
        pcVar15 = _Py_FalseStruct_exref;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
      }
LAB_1408cf160:
      if (*(int *)pcVar15 + 1 != 0) {
        *(int *)pcVar15 = *(int *)pcVar15 + 1;
        FUN_140008990(tstate);
        goto LAB_1408cf52f;
      }
      goto LAB_1408cf49b;
    }
    if (plStack_108 == (longlong *)0x0) {
      FUN_142cd4900(tstate,&lStack_130,classes_const_1853_esperas);
      FUN_1400048d0(tstate,lStack_130);
      uVar17 = 0x22fd;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      lVar7 = lStack_130;
    }
    else {
      plVar11 = (longlong *)FUN_142cbe350(plStack_108,1);
      plStack_108 = plVar11;
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
      cVar1 = Nuitka_helper_142ce1a90(plVar11,6);
      if (cVar1 == '\0') goto LAB_1408cf050;
      lVar7 = FUN_140a3b210(tstate);
      plVar11 = plStack_118;
      if (lVar7 != 0) {
        *(undefined4 *)(plStack_118 + 5) = 0x22ff;
        plVar4 = (longlong *)
                 FUN_142cd12f0(tstate,lVar7,classes_const_77_sleep,
                               *(undefined8 *)
                                (classes_const_1854___type____T____items____1_0__ + 0x18));
        pcVar9 = pcStack_120;
        plVar13 = plStack_128;
        if (plVar4 == (longlong *)0x0) {
          uVar17 = 0x22ff;
          goto LAB_1408cf71e;
        }
        if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
          (**(code **)(plVar4[1] + 0x30))(plVar4);
          plVar13 = plStack_128;
          pcVar9 = pcStack_120;
        }
        goto LAB_1408cdf22;
      }
      FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
      uVar17 = 0x22ff;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      lVar7 = lStack_130;
    }
    goto LAB_1408cf72e;
  }
LAB_1408cc69f:
  plVar4 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_211_get);
  pcVar9 = pcStack_120;
  if (plVar4 == (longlong *)0x0) goto LAB_1408cf71e;
  *(undefined4 *)(plVar11 + 5) = 0x22f4;
  plVar5 = (longlong *)
           FUN_142cccf70(tstate,plVar4,classes_const_1850___type____T____items_____ok___);
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))(plVar4);
  }
  pcVar9 = pcStack_120;
  if (plVar5 == (longlong *)0x0) goto LAB_1408cf71e;
  iVar2 = FUN_140004970(plVar5);
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  plVar4 = plStack_108;
  pcVar9 = pcStack_120;
  if (iVar2 == -1) goto LAB_1408cf71e;
  if (iVar2 == 0) goto LAB_1408cc59c;
  plStack_108 = _DAT_142d9a260;
  iVar2 = (int)*_DAT_142d9a260 + 1;
  if (iVar2 != 0) {
    *(int *)_DAT_142d9a260 = iVar2;
  }
  if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)
     ) {
    (**(code **)(plVar4[1] + 0x30))();
  }
  plVar4 = (longlong *)FUN_142cd7b20(tstate,plVar13,classes_const_1844__baixar_data_url);
  if (plVar4 == (longlong *)0x0) {
    uVar17 = 0x2305;
    pcVar9 = pcStack_120;
    plVar11 = plStack_118;
    goto LAB_1408cf71e;
  }
  plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_211_get);
  plVar11 = plStack_118;
  if (plVar5 == (longlong *)0x0) {
    lStack_130 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    uVar17 = 0x2305;
    pcVar9 = pcStack_120;
    plVar11 = plStack_118;
    lVar7 = lStack_130;
    goto LAB_1408cf72e;
  }
  *(undefined4 *)(plStack_118 + 5) = 0x2305;
  plVar13 = (longlong *)
            FUN_142ccd7d0(tstate,plVar5,classes_const_1924___type____T____items_____icone_______);
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  if (plVar13 == (longlong *)0x0) {
    lStack_130 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    uVar17 = 0x2305;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    lVar7 = lStack_130;
    goto LAB_1408cf72e;
  }
  *(undefined4 *)(plVar11 + 5) = 0x2305;
  pcVar3 = (code *)FUN_142ccfd60(tstate,plVar4,plVar13);
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))(plVar4);
  }
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  if (pcVar3 == (code *)0x0) {
    uVar17 = 0x2305;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    goto LAB_1408cf71e;
  }
  pcVar9 = pcVar3;
  if (((pcStack_c8 != (code *)0x0) && (-1 < *(int *)pcStack_c8)) &&
     (*(longlong *)pcStack_c8 = *(longlong *)pcStack_c8 + -1, *(longlong *)pcStack_c8 == 0)) {
    pcVar9 = pcStack_c8 + 8;
    pcStack_c8 = pcVar3;
    (**(code **)(*(longlong *)pcVar9 + 0x30))();
    pcVar9 = pcStack_c8;
  }
  pcStack_c8 = pcVar9;
  plVar13 = plStack_128;
  plVar4 = (longlong *)FUN_142cd7b20(tstate,plStack_128,classes_const_1844__baixar_data_url);
  if (plVar4 == (longlong *)0x0) {
    uVar17 = 0x2306;
    pcVar9 = pcStack_120;
    goto LAB_1408cf71e;
  }
  plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_211_get);
  if (plVar5 == (longlong *)0x0) {
    lStack_130 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    uVar17 = 0x2306;
    pcVar9 = pcStack_120;
    lVar7 = lStack_130;
    goto LAB_1408cf72e;
  }
  *(undefined4 *)(plVar11 + 5) = 0x2306;
  plVar13 = (longlong *)
            FUN_142ccd7d0(tstate,plVar5,classes_const_1925___type____T____items_____sprite_______);
  if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  if (plVar13 == (longlong *)0x0) {
    lStack_130 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    uVar17 = 0x2306;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    lVar7 = lStack_130;
    goto LAB_1408cf72e;
  }
  *(undefined4 *)(plVar11 + 5) = 0x2306;
  plVar5 = (longlong *)FUN_142ccfd60(tstate,plVar4,plVar13);
  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
    (**(code **)(plVar4[1] + 0x30))(plVar4);
  }
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  if (plVar5 == (longlong *)0x0) {
    uVar17 = 0x2306;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    plVar11 = plStack_118;
    goto LAB_1408cf71e;
  }
  plVar13 = plVar5;
  if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
     (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
    plVar13 = plStack_c0 + 1;
    plStack_c0 = plVar5;
    (**(code **)(*plVar13 + 0x30))();
    plVar13 = plStack_c0;
  }
  plStack_c0 = plVar13;
  if (pcVar3 != _Py_TrueStruct_exref) {
    if ((pcVar3 != _Py_FalseStruct_exref) && (pcVar3 != _Py_NoneStruct_exref)) {
      lVar7 = *(longlong *)(pcVar3 + 8);
      if ((*(longlong *)(lVar7 + 0x60) == 0) ||
         (pcVar9 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar9 == (code *)0x0)) {
        if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
            (pcVar9 = (code *)**(longlong **)(lVar7 + 0x70), pcVar9 == (code *)0x0)) &&
           ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
            (pcVar9 = (code *)**(longlong **)(lVar7 + 0x68), pcVar9 == (code *)0x0))))
        goto LAB_1408cc999;
        lVar7 = (*pcVar9)(pcVar3);
      }
      else {
        iVar2 = (*pcVar9)(pcVar3);
        lVar7 = (longlong)iVar2;
      }
      if (0 < lVar7) goto LAB_1408cc999;
      if (lVar7 == 0) goto LAB_1408ced28;
      goto LAB_1408cdf3e;
    }
LAB_1408ced28:
    iVar2 = FUN_140004970(pcVar3);
    if (iVar2 == -1) {
      uVar17 = 0x2308;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
    }
    else {
      plStack_b8 = (longlong *)classes_const_1927_sprite;
      if (iVar2 == 0) {
        plStack_b8 = (longlong *)classes_const_1926_icone;
      }
      iVar2 = (int)*plStack_b8 + 1;
      if (iVar2 != 0) {
        *(int *)plStack_b8 = iVar2;
      }
      uVar12 = FUN_1400776a0(classes_const_257_print);
      plVar11 = plStack_118;
      puVar14 = classes_const_1928__s__geetest_3x3__nao_consegui_baixar_o__s_do_desafio;
      uVar17 = 0x230a;
      *(undefined4 *)(plStack_118 + 5) = 0x230a;
      lVar7 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      if (lVar7 != 0) {
        plVar13 = (longlong *)FUN_142cd9440(tstate,2);
        plVar13[3] = lVar7;
        iVar2 = (int)*plStack_b8 + 1;
        if (iVar2 != 0) {
          *(int *)plStack_b8 = iVar2;
        }
        plVar13[4] = (longlong)plStack_b8;
        plVar4 = (longlong *)FUN_142cbffc0(puVar14,plVar13);
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
        if (plVar4 != (longlong *)0x0) {
          uVar17 = 0x2309;
          *(undefined4 *)(plVar11 + 5) = 0x2309;
          plVar5 = (longlong *)FUN_142ccfd60(tstate,uVar12,plVar4);
          if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
            (**(code **)(plVar4[1] + 0x30))(plVar4);
          }
          plVar13 = plStack_128;
          pcVar9 = pcStack_120;
          if (plVar5 != (longlong *)0x0) goto LAB_1408cf13c;
        }
      }
    }
    goto LAB_1408cf71e;
  }
LAB_1408cc999:
  iVar2 = FUN_140004970(plVar5);
  if (iVar2 == -1) {
LAB_1408cdf3e:
    uVar17 = 0x2307;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    plVar11 = plStack_118;
    goto LAB_1408cf71e;
  }
  if (iVar2 == 0) goto LAB_1408ced28;
  plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar6,classes_const_211_get);
  plVar11 = plStack_118;
  if (plVar13 == (longlong *)0x0) {
    uVar17 = 0x230c;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    goto LAB_1408cf71e;
  }
  *(undefined4 *)(plStack_118 + 5) = 0x230c;
  pcVar8 = (code *)FUN_142cccf70(tstate,plVar13,classes_const_1929___type____T____items_____cels___)
  ;
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  if (pcVar8 == (code *)0x0) {
    uVar17 = 0x230c;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    goto LAB_1408cf71e;
  }
  if (pcVar8 != _Py_TrueStruct_exref) {
    if ((pcVar8 != _Py_FalseStruct_exref) && (pcVar8 != _Py_NoneStruct_exref)) {
      lVar7 = *(longlong *)(pcVar8 + 8);
      if ((*(longlong *)(lVar7 + 0x60) == 0) ||
         (pcVar9 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar9 == (code *)0x0)) {
        if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
            (pcVar9 = (code *)**(longlong **)(lVar7 + 0x70), pcVar9 == (code *)0x0)) &&
           ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
            (pcVar9 = (code *)**(longlong **)(lVar7 + 0x68), pcVar9 == (code *)0x0))))
        goto LAB_1408ccaaa;
        lVar7 = (*pcVar9)(pcVar8);
      }
      else {
        iVar2 = (*pcVar9)(pcVar8);
        lVar7 = (longlong)iVar2;
      }
      if (0 < lVar7) goto LAB_1408ccaaa;
      if (lVar7 != 0) {
        lStack_130 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        if ((-1 < *(int *)pcVar8) &&
           (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
          (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
        }
        uVar17 = 0x230c;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
        lVar7 = lStack_130;
        goto LAB_1408cf72e;
      }
    }
    if ((-1 < *(int *)pcVar8) &&
       (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
      (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
    }
    pcVar8 = (code *)FUN_142cd8f90(tstate,0);
  }
LAB_1408ccaaa:
  pcVar9 = pcVar8;
  if (((pcStack_b0 != (code *)0x0) && (-1 < *(int *)pcStack_b0)) &&
     (*(longlong *)pcStack_b0 = *(longlong *)pcStack_b0 + -1, *(longlong *)pcStack_b0 == 0)) {
    pcVar9 = pcStack_b0 + 8;
    pcStack_b0 = pcVar8;
    (**(code **)(*(longlong *)pcVar9 + 0x30))();
    pcVar9 = pcStack_b0;
  }
  pcStack_b0 = pcVar9;
  plVar13 = (longlong *)FUN_142cc1f90(tstate,pcVar8);
  if (plVar13 == (longlong *)0x0) {
    uVar17 = 0x230d;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    goto LAB_1408cf71e;
  }
  cVar1 = Nuitka_helper_142ce3660(plVar13,9);
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  pcVar15 = _Py_FalseStruct_exref;
  plVar13 = plStack_128;
  pcVar9 = pcStack_120;
  if (cVar1 != '\0') goto LAB_1408cf160;
  *(undefined4 *)(plVar11 + 5) = 0x2314;
  pcVar9 = (code *)FUN_142cd12f0(tstate,plStack_128,classes_const_1913__emocao_do_prompt,pcVar3);
  if (pcVar9 == (code *)0x0) {
    uVar17 = 0x2314;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    goto LAB_1408cf71e;
  }
  if (pcVar9 == _Py_TrueStruct_exref) {
LAB_1408ccb40:
    bVar18 = true;
  }
  else {
    if ((pcVar9 != _Py_FalseStruct_exref) && (pcVar9 != _Py_NoneStruct_exref)) {
      lVar7 = *(longlong *)(pcVar9 + 8);
      if ((*(longlong *)(lVar7 + 0x60) == 0) ||
         (pcVar15 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar15 == (code *)0x0)) {
        if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
            (pcVar15 = (code *)**(longlong **)(lVar7 + 0x70), pcVar15 == (code *)0x0)) &&
           ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
            (pcVar15 = (code *)**(longlong **)(lVar7 + 0x68), pcVar15 == (code *)0x0))))
        goto LAB_1408ccb40;
        lVar7 = (*pcVar15)(pcVar9);
      }
      else {
        iVar2 = (*pcVar15)(pcVar9);
        lVar7 = (longlong)iVar2;
      }
      if (0 < lVar7) {
        bVar18 = true;
        goto LAB_1408ccbb3;
      }
      if (lVar7 != 0) {
        lStack_130 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        if ((-1 < *(int *)pcVar9) &&
           (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
          (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
        }
        uVar17 = 0x2314;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
        lVar7 = lStack_130;
        goto LAB_1408cf72e;
      }
    }
    bVar18 = false;
  }
LAB_1408ccbb3:
  if ((-1 < *(int *)pcVar9) &&
     (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
    (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
  }
  plVar13 = plStack_128;
  if (!bVar18) {
    plVar13 = (longlong *)FUN_142cd7b20(tstate,plStack_128,classes_const_170_driver);
    if (plVar13 == (longlong *)0x0) {
LAB_1408cea63:
      lStack_130 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      plVar4 = (longlong *)FUN_142cd7b20(tstate,plVar13,classes_const_338_execute_script);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      if (plVar4 == (longlong *)0x0) goto LAB_1408cea63;
      plVar13 = (longlong *)
                FUN_142cd7b20(tstate,plStack_128,classes_const_1935__JS_GEETEST_NINE_NOTAS);
      if (plVar13 != (longlong *)0x0) {
        *(undefined4 *)(plVar11 + 5) = 0x2325;
        plStack_68 = plVar13;
        pcStack_60 = pcVar3;
        plStack_58 = plVar5;
        pcStack_50 = pcVar8;
        plVar5 = (longlong *)FUN_142cc6c80(tstate,plVar4,&plStack_68);
        if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
          (**(code **)(plVar4[1] + 0x30))(plVar4);
        }
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if (plVar5 == (longlong *)0x0) goto LAB_1408cea63;
        plVar13 = plVar5;
        if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
           (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
          plVar13 = plStack_a8 + 1;
          plStack_a8 = plVar5;
          (**(code **)(*plVar13 + 0x30))();
          plVar13 = plStack_a8;
        }
        plStack_a8 = plVar13;
        iVar2 = PyObject_IsInstance(plVar5,PyDict_Type_exref);
        if (iVar2 != -1) {
          pcVar9 = _Py_FalseStruct_exref;
          if (iVar2 != 0) {
            pcVar9 = _Py_TrueStruct_exref;
          }
          iVar2 = FUN_140004970(pcVar9);
          if (iVar2 != -1) {
            if (iVar2 == 0) {
              iVar2 = 0;
LAB_1408cd161:
              if (iVar2 == 0) {
                uVar12 = FUN_1400776a0(classes_const_257_print);
                puVar14 = classes_const_1936__s__geetest_3x3__falhei_ao_pontuar___s;
                *(undefined4 *)(plStack_118 + 5) = 0x232c;
                lVar7 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
                uVar17 = 0x232c;
                plVar13 = plStack_128;
                pcVar9 = pcStack_120;
                plVar11 = plStack_118;
                if (lVar7 == 0) goto LAB_1408cf71e;
                plVar6 = (longlong *)FUN_142cd9440(tstate,2);
                plVar6[3] = lVar7;
                iVar2 = PyObject_IsInstance(plVar5,PyDict_Type_exref);
                if (iVar2 == -1) {
                  lStack_130 = *(longlong *)(tstate + 0x70);
                }
                else {
                  if (iVar2 == 0) {
                    iVar2 = (int)*plVar5 + 1;
                    if (iVar2 != 0) {
                      *(int *)plVar5 = iVar2;
                    }
LAB_1408ce9c3:
                    plVar6[4] = (longlong)plVar5;
                    plVar4 = (longlong *)FUN_142cbffc0(puVar14,plVar6);
                    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                      (**(code **)(plVar6[1] + 0x30))(plVar6);
                    }
                    plVar13 = plStack_128;
                    pcVar9 = pcStack_120;
                    plVar11 = plStack_118;
                    if (plVar4 == (longlong *)0x0) goto LAB_1408cf71e;
                    uVar17 = 0x232b;
                    *(undefined4 *)(plStack_118 + 5) = 0x232b;
                    goto LAB_1408cf100;
                  }
                  plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar5,classes_const_211_get);
                  if (plVar13 != (longlong *)0x0) {
                    *(undefined4 *)(plStack_118 + 5) = 0x232c;
                    plVar5 = (longlong *)
                             FUN_142ccd7d0(tstate,plVar13,
                                           classes_const_1851___type____T____items_____erro_______);
                    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                      (**(code **)(plVar13[1] + 0x30))(plVar13);
                    }
                    if (plVar5 != (longlong *)0x0) goto LAB_1408ce9c3;
                  }
                  lStack_130 = *(longlong *)(tstate + 0x70);
                }
                *(undefined8 *)(tstate + 0x70) = 0;
                plVar13 = plStack_128;
                pcVar9 = pcStack_120;
                plVar11 = plStack_118;
                lVar7 = lStack_130;
                if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                  (**(code **)(plVar6[1] + 0x30))(plVar6);
                  plVar13 = plStack_128;
                  pcVar9 = pcStack_120;
                  plVar11 = plStack_118;
                  lVar7 = lStack_130;
                }
                goto LAB_1408cf72e;
              }
              plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar5,classes_const_211_get);
              if (plVar13 != (longlong *)0x0) {
                *(undefined4 *)(plVar11 + 5) = 0x232e;
                plVar4 = (longlong *)
                         FUN_142ccd7d0(tstate,plVar13,
                                       classes_const_1937___type____T____items_____margem_____float_special___0___
                                      );
                if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                }
                if (plVar4 != (longlong *)0x0) {
                  plVar13 = (longlong *)Nuitka_helper_142ce5200(plVar4);
                  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                    (**(code **)(plVar4[1] + 0x30))(plVar4);
                  }
                  if (plVar13 != (longlong *)0x0) {
                    if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
                       (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
                      plVar4 = plStack_e8 + 1;
                      plStack_e8 = plVar13;
                      (**(code **)(*plVar4 + 0x30))();
                      plVar13 = plStack_e8;
                    }
                    plStack_e8 = plVar13;
                    plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar5,classes_const_211_get);
                    if (plVar13 != (longlong *)0x0) {
                      *(undefined4 *)(plVar11 + 5) = 0x232f;
                      pcVar9 = (code *)FUN_142cccf70(tstate,plVar13,
                                                                                                          
                                                  classes_const_1938___type____T____items_____alvos___
                                                  );
                      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                        (**(code **)(plVar13[1] + 0x30))(plVar13);
                      }
                      if (pcVar9 != (code *)0x0) {
                        iVar2 = FUN_140004970(pcVar9);
                        pcVar3 = pcStack_f8;
                        if (iVar2 != -1) {
                          if (iVar2 != 1) {
                            if ((-1 < *(int *)pcVar9) &&
                               (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1,
                               *(longlong *)pcVar9 == 0)) {
                              (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
                            }
                            pcVar9 = (code *)FUN_142cd8f90(tstate,0);
                          }
                          plVar13 = plStack_128;
                          pcStack_f8 = pcVar9;
                          if (((pcVar3 != (code *)0x0) && (-1 < *(int *)pcVar3)) &&
                             (*(longlong *)pcVar3 = *(longlong *)pcVar3 + -1,
                             *(longlong *)pcVar3 == 0)) {
                            (**(code **)(*(longlong *)(pcVar3 + 8) + 0x30))(pcVar3);
                            plVar13 = plStack_128;
                          }
                          goto LAB_1408cce4e;
                        }
                        lStack_130 = *(longlong *)(tstate + 0x70);
                        *(undefined8 *)(tstate + 0x70) = 0;
                        if ((-1 < *(int *)pcVar9) &&
                           (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0
                           )) {
                          (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
                        }
                        uVar17 = 0x232f;
                        plVar13 = plStack_128;
                        pcVar9 = pcStack_120;
                        lVar7 = lStack_130;
                        goto LAB_1408cf72e;
                      }
                    }
                    uVar17 = 0x232f;
                    plVar13 = plStack_128;
                    pcVar9 = pcStack_120;
                    goto LAB_1408cf71e;
                  }
                }
              }
              uVar17 = 0x232e;
              plVar13 = plStack_128;
              pcVar9 = pcStack_120;
            }
            else {
              plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar5,classes_const_211_get);
              if (plVar13 != (longlong *)0x0) {
                *(undefined4 *)(plVar11 + 5) = 0x232a;
                plVar4 = (longlong *)
                         FUN_142cccf70(tstate,plVar13,
                                       classes_const_1850___type____T____items_____ok___);
                if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                }
                if (plVar4 != (longlong *)0x0) {
                  iVar2 = FUN_140004970(plVar4);
                  if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                    (**(code **)(plVar4[1] + 0x30))(plVar4);
                  }
                  if (iVar2 != -1) goto LAB_1408cd161;
                }
              }
              uVar17 = 0x232a;
              plVar13 = plStack_128;
              pcVar9 = pcStack_120;
            }
            goto LAB_1408cf71e;
          }
        }
        uVar17 = 0x232a;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
        goto LAB_1408cf71e;
      }
      lStack_130 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
    }
    lVar7 = lStack_130;
    lStack_130 = 0;
    piVar16 = *(int **)(tstate + 0xf8);
    if ((piVar16 != (int *)0x0) && (*piVar16 + 1 != 0)) {
      *piVar16 = *piVar16 + 1;
    }
    if (*(longlong *)(lVar7 + 0x28) == 0) {
      pcVar9 = (code *)FUN_142cd9160(plVar11,0x2325);
    }
    else {
      pcVar9 = (code *)FUN_140008a80(*(longlong *)(lVar7 + 0x28),plVar11,0x2325);
    }
    plVar13 = *(longlong **)(lVar7 + 0x28);
    if (pcVar9 == _Py_NoneStruct_exref) {
      pcVar3 = (code *)0x0;
    }
    else {
      pcVar3 = pcVar9;
      if ((pcVar9 != (code *)0x0) && (*(int *)pcVar9 + 1 != 0)) {
        *(int *)pcVar9 = *(int *)pcVar9 + 1;
      }
    }
    *(code **)(lVar7 + 0x28) = pcVar3;
    if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
       (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))();
    }
    if (((pcVar9 != (code *)0x0) && (-1 < *(int *)pcVar9)) &&
       (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
      (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
    }
    plVar13 = *(longlong **)(tstate + 0xf8);
    *(longlong *)(tstate + 0xf8) = lVar7;
    if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
       (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))();
    }
    iVar2 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    if (iVar2 == 0) {
      cVar1 = FUN_142cded30(tstate,&lStack_130);
      uVar17 = 0x2324;
      if (cVar1 != '\0') {
        uVar17 = 0;
      }
      lVar10 = *(longlong *)(lStack_130 + 0x28);
      lVar7 = lStack_130;
      if ((lVar10 != 0) && (*(longlong **)(lVar10 + 0x18) == plVar11)) {
        *(undefined4 *)(plVar11 + 5) = *(undefined4 *)(lVar10 + 0x24);
      }
    }
    else {
      plVar4 = *(longlong **)(tstate + 0xf8);
      iVar2 = (int)*plVar4 + 1;
      if (iVar2 != 0) {
        *(int *)plVar4 = iVar2;
      }
      uVar12 = FUN_1400776a0(classes_const_257_print);
      puVar14 = classes_const_1936__s__geetest_3x3__falhei_ao_pontuar___s;
      *(undefined4 *)(plVar11 + 5) = 9000;
      plStack_110 = (longlong *)CONCAT44(plStack_110._4_4_,9000);
      lVar7 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
      if (lVar7 != 0) {
        plVar13 = (longlong *)FUN_142cd9440(tstate,2);
        plVar13[3] = lVar7;
        iVar2 = (int)*plVar4 + 1;
        if (iVar2 != 0) {
          *(int *)plVar4 = iVar2;
        }
        plVar13[4] = (longlong)plVar4;
        plVar11 = (longlong *)FUN_142cbffc0(puVar14,plVar13);
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if (plVar11 != (longlong *)0x0) {
          *(undefined4 *)(plStack_118 + 5) = 9000;
          plVar13 = (longlong *)FUN_142ccfd60(tstate,uVar12,plVar11);
          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
            (**(code **)(plVar11[1] + 0x30))(plVar11);
          }
          if (plVar13 != (longlong *)0x0) goto LAB_1408cf434;
        }
      }
      lVar7 = *(longlong *)(tstate + 0x70);
      uVar17 = plStack_110._0_4_;
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
    }
    lStack_130 = 0;
    plVar4 = *(longlong **)(tstate + 0xf8);
    *(int **)(tstate + 0xf8) = piVar16;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    plVar11 = plStack_118;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
    }
    goto LAB_1408cf72e;
  }
  *(undefined4 *)(plVar11 + 5) = 0x2315;
  pcStack_88 = pcVar3;
  plStack_80 = plVar5;
  pcVar9 = (code *)FUN_142cd07f0(tstate,plStack_128,classes_const_1930__nine_emocao_alvos,
                                 &pcStack_88);
  pcVar3 = pcStack_f8;
  if (pcVar9 == (code *)0x0) {
    uVar17 = 0x2315;
    pcVar9 = pcStack_120;
    plVar11 = plStack_118;
    goto LAB_1408cf71e;
  }
  pcVar15 = pcVar9;
  if (((pcStack_f8 != (code *)0x0) && (-1 < *(int *)pcStack_f8)) &&
     (*(longlong *)pcStack_f8 = *(longlong *)pcStack_f8 + -1, *(longlong *)pcStack_f8 == 0)) {
    pcVar15 = pcStack_f8 + 8;
    pcStack_f8 = pcVar9;
    (**(code **)(*(longlong *)pcVar15 + 0x30))(pcVar3);
    pcVar15 = pcStack_f8;
  }
  pcStack_f8 = pcVar15;
  plVar5 = plStack_e8;
  plVar4 = plStack_100;
  if (pcVar9 != _Py_NoneStruct_exref) {
    plStack_e8 = (longlong *)classes_const_1934_9_999;
    if (*(int *)classes_const_1934_9_999 + 1 != 0) {
      *(int *)classes_const_1934_9_999 = *(int *)classes_const_1934_9_999 + 1;
    }
    plVar11 = plStack_118;
    if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
       (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5,plVar5);
      plVar11 = plStack_118;
    }
LAB_1408cce4e:
    plVar4 = (longlong *)FUN_142cc1f90(tstate,pcVar9);
    if (plVar4 == (longlong *)0x0) {
      uVar17 = 0x2330;
      pcVar9 = pcStack_120;
      goto LAB_1408cf71e;
    }
    cVar1 = Nuitka_helper_142ce3660(plVar4,3);
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    pcVar15 = _Py_FalseStruct_exref;
    pcVar9 = pcStack_120;
    if (cVar1 != '\0') goto LAB_1408cf160;
    plVar4 = (longlong *)FUN_142cd7b20(tstate,plStack_110,classes_const_211_get);
    if (plVar4 == (longlong *)0x0) {
LAB_1408ce81c:
      uVar17 = 0x2338;
      pcVar9 = pcStack_120;
      goto LAB_1408cf71e;
    }
    *(undefined4 *)(plVar11 + 5) = 0x2338;
    pcVar9 = (code *)FUN_142ccd7d0(tstate,plVar4,
                                   classes_const_1925___type____T____items_____sprite_______);
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    if (pcVar9 == (code *)0x0) goto LAB_1408ce81c;
    pcVar3 = pcVar9;
    if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
       (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0)) {
      pcVar3 = pcStack_a0 + 8;
      pcStack_a0 = pcVar9;
      (**(code **)(*(longlong *)pcVar3 + 0x30))();
      pcVar3 = pcStack_a0;
    }
    pcStack_a0 = pcVar3;
    plVar5 = (longlong *)
             FUN_142cc1aa0(tstate,plVar13,classes_const_1939__sprite_visto,classes_const_102_);
    plVar4 = plStack_98;
    if (plVar5 == (longlong *)0x0) {
      uVar17 = 0x2339;
      pcVar9 = pcStack_120;
      goto LAB_1408cf71e;
    }
    plVar6 = plVar5;
    if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
       (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
      plVar6 = plStack_98 + 1;
      plStack_98 = plVar5;
      (**(code **)(*plVar6 + 0x30))(plVar4);
      plVar6 = plStack_98;
    }
    plStack_98 = plVar6;
    if (pcVar9 == _Py_TrueStruct_exref) {
LAB_1408cd53b:
      iVar2 = FUN_142cdf5a0(pcVar9,plVar5);
      plVar4 = plStack_100;
      if (iVar2 == -1) {
LAB_1408ce170:
        uVar17 = 0x233a;
        pcVar9 = pcStack_120;
        goto LAB_1408cf71e;
      }
      if (iVar2 == 1) {
        if (plStack_100 == (longlong *)0x0) {
          FUN_142cd4900(tstate,&lStack_130,classes_const_1931_descartes);
          FUN_1400048d0(tstate,lStack_130);
          uVar17 = 0x233b;
          pcVar9 = pcStack_120;
          lVar7 = lStack_130;
          goto LAB_1408cf72e;
        }
        cVar1 = Nuitka_helper_142ce2960(plStack_100,3);
        if (cVar1 != '\0') {
          plVar13 = (longlong *)FUN_142cbe350(plVar4,1);
          if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
            (**(code **)(plVar4[1] + 0x30))(plVar4);
          }
          plVar4 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
          puVar14 = 
          classes_const_1940__s__geetest_3x3__a_casa_repetiu_o_mesmo_desafio___pedindo_outro__;
          if ((plVar4 == (longlong *)0x0) || (lVar7 = *plVar4, lVar7 == 0)) goto LAB_1408ce7bc;
          *(undefined4 *)(plStack_118 + 5) = 0x233e;
          plStack_100 = plVar13;
          lVar10 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
          if (lVar10 == 0) {
            uVar17 = 0x233e;
            plVar13 = plStack_128;
            pcVar9 = pcStack_120;
            plVar11 = plStack_118;
          }
          else {
            plVar4 = (longlong *)FUN_142cd9440(tstate,2);
            plVar4[3] = lVar10;
            iVar2 = (int)*plVar13 + 1;
            if (iVar2 != 0) {
              *(int *)plVar13 = iVar2;
            }
            plVar4[4] = (longlong)plVar13;
            plVar13 = (longlong *)FUN_142cbffc0(puVar14,plVar4);
            if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
              (**(code **)(plVar4[1] + 0x30))(plVar4);
            }
            plVar11 = plStack_118;
            if (plVar13 == (longlong *)0x0) {
              uVar17 = 0x233e;
              plVar13 = plStack_128;
              pcVar9 = pcStack_120;
            }
            else {
              *(undefined4 *)(plStack_118 + 5) = 0x233d;
              plVar4 = (longlong *)FUN_142ccfd60(tstate,lVar7,plVar13);
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              if (plVar4 == (longlong *)0x0) {
                uVar17 = 0x233d;
                plVar13 = plStack_128;
                pcVar9 = pcStack_120;
              }
              else {
                if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                  (**(code **)(plVar4[1] + 0x30))(plVar4);
                }
                plVar13 = plStack_128;
                *(undefined4 *)(plVar11 + 5) = 0x233f;
                plVar4 = (longlong *)
                         FUN_142cd06a0(tstate,plStack_128,classes_const_1862__geetest_refresh);
                if (plVar4 == (longlong *)0x0) {
                  uVar17 = 0x233f;
                  pcVar9 = pcStack_120;
                  goto LAB_1408cf71e;
                }
                if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                  (**(code **)(plVar4[1] + 0x30))(plVar4);
                }
                lVar7 = FUN_140a3b210(tstate);
                if (lVar7 == 0) {
                  FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
                  uVar17 = 0x2340;
                  pcVar9 = pcStack_120;
                  lVar7 = lStack_130;
                  goto LAB_1408cf72e;
                }
                *(undefined4 *)(plVar11 + 5) = 0x2340;
                plVar4 = (longlong *)
                         FUN_142cd12f0(tstate,lVar7,classes_const_77_sleep,
                                       *(undefined8 *)
                                        (classes_const_359___type____T____items____2_5__ + 0x18));
                if (plVar4 != (longlong *)0x0) goto LAB_1408ccdf6;
                uVar17 = 0x2340;
                pcVar9 = pcStack_120;
              }
            }
          }
          goto LAB_1408cf71e;
        }
      }
    }
    else if ((pcVar9 != _Py_FalseStruct_exref) && (pcVar9 != _Py_NoneStruct_exref)) {
      lVar7 = *(longlong *)(pcVar9 + 8);
      if ((*(longlong *)(lVar7 + 0x60) == 0) ||
         (pcVar3 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar3 == (code *)0x0)) {
        if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
            (pcVar3 = (code *)**(longlong **)(lVar7 + 0x70), pcVar3 == (code *)0x0)) &&
           ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
            (pcVar3 = (code *)**(longlong **)(lVar7 + 0x68), pcVar3 == (code *)0x0))))
        goto LAB_1408cd53b;
        lVar7 = (*pcVar3)(pcVar9);
      }
      else {
        iVar2 = (*pcVar3)(pcVar9);
        lVar7 = (longlong)iVar2;
      }
      if (0 < lVar7) goto LAB_1408cd53b;
      if (lVar7 == 0) goto LAB_1408cd307;
      goto LAB_1408ce170;
    }
LAB_1408cd307:
    cVar1 = FUN_142ce4bf0(tstate,plVar13,classes_const_1939__sprite_visto,pcVar9);
    plVar4 = plStack_f0;
    if (cVar1 == '\0') {
      uVar17 = 0x2342;
      pcVar9 = pcStack_120;
      goto LAB_1408cf71e;
    }
    if (plStack_f0 == (longlong *)0x0) {
      FUN_142cd4900(tstate,&lStack_130,classes_const_1847_respostas);
      FUN_1400048d0(tstate,lStack_130);
      uVar17 = 0x2344;
      pcVar9 = pcStack_120;
      lVar7 = lStack_130;
      goto LAB_1408cf72e;
    }
    plVar13 = (longlong *)FUN_142cbe350(plStack_f0,1);
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    plVar4 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
    puVar14 = classes_const_1941__s__geetest_3x3__tocando__s__margem___3f____resposta__d_de__d;
    if ((plVar4 == (longlong *)0x0) || (lVar7 = *plVar4, lVar7 == 0)) goto LAB_1408ce7bc;
    *(undefined4 *)(plStack_118 + 5) = 0x2346;
    plStack_f0 = plVar13;
    lVar10 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
    if (lVar10 == 0) {
      uVar17 = 0x2346;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
      goto LAB_1408cf71e;
    }
    plVar4 = (longlong *)FUN_142cd9440(tstate,5);
    plVar4[3] = lVar10;
    if (*(int *)pcStack_f8 + 1 != 0) {
      *(int *)pcStack_f8 = *(int *)pcStack_f8 + 1;
    }
    plVar4[4] = (longlong)pcStack_f8;
    iVar2 = (int)*plStack_e8 + 1;
    if (iVar2 != 0) {
      *(int *)plStack_e8 = iVar2;
    }
    plVar4[5] = (longlong)plStack_e8;
    iVar2 = (int)*plVar13 + 1;
    if (iVar2 != 0) {
      *(int *)plVar13 = iVar2;
    }
    plVar4[6] = (longlong)plVar13;
    iVar2 = (int)*plStack_d8 + 1;
    if (iVar2 != 0) {
      *(int *)plStack_d8 = iVar2;
    }
    plVar4[7] = (longlong)plStack_d8;
    plVar13 = (longlong *)FUN_142cbffc0(puVar14,plVar4);
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    plVar11 = plStack_118;
    if (plVar13 == (longlong *)0x0) {
      uVar17 = 0x2346;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      goto LAB_1408cf71e;
    }
    *(undefined4 *)(plStack_118 + 5) = 0x2345;
    plVar4 = (longlong *)FUN_142ccfd60(tstate,lVar7,plVar13);
    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    if (plVar4 == (longlong *)0x0) {
      uVar17 = 0x2345;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      goto LAB_1408cf71e;
    }
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    plVar13 = plStack_128;
    *(undefined4 *)(plVar11 + 5) = 0x2347;
    pcStack_78 = pcStack_f8;
    pcStack_70 = pcVar8;
    plVar4 = (longlong *)
             FUN_142cd07f0(tstate,plStack_128,classes_const_1942__geetest_nine_marcar,&pcStack_78);
    if (plVar4 == (longlong *)0x0) {
LAB_1408ce770:
      uVar17 = 0x2347;
      pcVar9 = pcStack_120;
      goto LAB_1408cf71e;
    }
    iVar2 = FUN_140004970(plVar4);
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    if (iVar2 == -1) goto LAB_1408ce770;
    if (iVar2 == 0) {
      lVar7 = FUN_140a3b210();
      if (lVar7 != 0) {
        *(undefined4 *)(plVar11 + 5) = 0x234a;
        plVar4 = (longlong *)
                 FUN_142cd12f0(tstate,lVar7,classes_const_77_sleep,
                               *(undefined8 *)
                                (classes_const_1943___type____T____items____1_2__ + 0x18));
        if (plVar4 != (longlong *)0x0) goto LAB_1408ccdf6;
        uVar17 = 0x234a;
        pcVar9 = pcStack_120;
        goto LAB_1408cf71e;
      }
      FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
      uVar17 = 0x234a;
      pcVar9 = pcStack_120;
      lVar7 = lStack_130;
      goto LAB_1408cf72e;
    }
    plVar4 = (longlong *)FUN_142cd7b20(tstate,plVar13,classes_const_170_driver);
    if (plVar4 == (longlong *)0x0) {
LAB_1408ce4da:
      lStack_130 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      plVar5 = (longlong *)FUN_142cd7b20(tstate,plVar4,classes_const_338_execute_script);
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
      if (plVar5 == (longlong *)0x0) goto LAB_1408ce4da;
      plVar4 = (longlong *)
               FUN_142cd7b20(tstate,plVar13,classes_const_1886__JS_GEETEST_NINE_CONFIRMAR);
      if (plVar4 != (longlong *)0x0) {
        *(undefined4 *)(plVar11 + 5) = 0x234d;
        plVar6 = (longlong *)FUN_142ccfd60(tstate,plVar5,plVar4);
        if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))(plVar5);
        }
        if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
          (**(code **)(plVar4[1] + 0x30))(plVar4);
        }
        plVar13 = plStack_128;
        if (plVar6 == (longlong *)0x0) goto LAB_1408ce4da;
        if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
          (**(code **)(plVar6[1] + 0x30))(plVar6);
        }
        lVar7 = FUN_140a3b210(tstate);
        if (lVar7 != 0) {
          *(undefined4 *)(plVar11 + 5) = 0x2359;
          plVar13 = (longlong *)FUN_142cd06a0(tstate,lVar7,classes_const_76_time);
          if (plVar13 != (longlong *)0x0) {
            plVar4 = (longlong *)FUN_142cbe6d0(plVar13,classes_const_721_6);
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
            }
            pcVar3 = pcStack_120;
            if (plVar4 != (longlong *)0x0) {
              plVar13 = plVar4;
              if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
                 (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
                plVar13 = plStack_90 + 1;
                plStack_90 = plVar4;
                (**(code **)(*plVar13 + 0x30))();
                plVar13 = plStack_90;
              }
              plStack_90 = plVar13;
              pcVar9 = _Py_NoneStruct_exref;
              pcStack_120 = _Py_NoneStruct_exref;
              if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
              }
              plVar13 = plStack_128;
              if (((pcVar3 != (code *)0x0) && (-1 < *(int *)pcVar3)) &&
                 (*(longlong *)pcVar3 = *(longlong *)pcVar3 + -1, *(longlong *)pcVar3 == 0)) {
                (**(code **)(*(longlong *)(pcVar3 + 8) + 0x30))();
                plVar13 = plStack_128;
              }
              do {
                lVar7 = FUN_140a3b210(tstate);
                if (lVar7 == 0) {
                  FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
                  uVar17 = 0x235b;
                  plVar13 = plStack_128;
                  lVar7 = lStack_130;
                  goto LAB_1408cf72e;
                }
                *(undefined4 *)(plVar11 + 5) = 0x235b;
                plVar5 = (longlong *)FUN_142cd06a0(tstate,lVar7,classes_const_76_time);
                pcVar3 = pcVar9;
                if (plVar5 == (longlong *)0x0) goto LAB_1408cdcc0;
                pcVar8 = (code *)FUN_142ce3540(plVar5,plVar4);
                if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                  (**(code **)(plVar5[1] + 0x30))(plVar5);
                }
                if (pcVar8 == (code *)0x0) goto LAB_1408cdcc0;
                if (pcVar8 == _Py_TrueStruct_exref) {
LAB_1408cd91c:
                  iVar2 = 1;
                }
                else if ((pcVar8 == _Py_FalseStruct_exref) || (pcVar8 == _Py_NoneStruct_exref)) {
                  iVar2 = 0;
                }
                else {
                  lVar7 = *(longlong *)(pcVar8 + 8);
                  if ((*(longlong *)(lVar7 + 0x60) == 0) ||
                     (pcVar15 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48),
                     pcVar15 == (code *)0x0)) {
                    if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
                        (pcVar15 = (code *)**(longlong **)(lVar7 + 0x70), pcVar15 == (code *)0x0))
                       && ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
                           (pcVar15 = (code *)**(longlong **)(lVar7 + 0x68), pcVar15 == (code *)0x0)
                           ))) goto LAB_1408cd91c;
                    lVar7 = (*pcVar15)(pcVar8);
                  }
                  else {
                    iVar2 = (*pcVar15)(pcVar8);
                    lVar7 = (longlong)iVar2;
                  }
                  if (lVar7 < 1) {
                    iVar2 = -(uint)(lVar7 != 0);
                  }
                  else {
                    iVar2 = 1;
                  }
                }
                if ((-1 < *(int *)pcVar8) &&
                   (*(longlong *)pcVar8 = *(longlong *)pcVar8 + -1, *(longlong *)pcVar8 == 0)) {
                  (**(code **)(*(longlong *)(pcVar8 + 8) + 0x30))(pcVar8);
                }
                if (iVar2 == -1) goto LAB_1408cdcc0;
                if (iVar2 == 0) goto LAB_1408cdccf;
                *(undefined4 *)(plVar11 + 5) = 0x235c;
                pcVar3 = (code *)FUN_142cd06a0(tstate,plVar13,
                                               classes_const_1763__geetest_nine_na_tela);
                if (pcVar3 == (code *)0x0) {
LAB_1408ce41a:
                  uVar17 = 0x235c;
                  plVar13 = plStack_128;
                  goto LAB_1408cf71e;
                }
                if (pcVar3 != _Py_TrueStruct_exref) {
                  if ((pcVar3 == _Py_FalseStruct_exref) || (pcVar3 == _Py_NoneStruct_exref)) {
LAB_1408cda56:
                    bVar18 = false;
                    goto LAB_1408cda58;
                  }
                  lVar7 = *(longlong *)(pcVar3 + 8);
                  if ((*(longlong *)(lVar7 + 0x60) == 0) ||
                     (pcVar8 = *(code **)(*(longlong *)(lVar7 + 0x60) + 0x48), pcVar8 == (code *)0x0
                     )) {
                    if (((*(longlong **)(lVar7 + 0x70) == (longlong *)0x0) ||
                        (pcVar8 = (code *)**(longlong **)(lVar7 + 0x70), pcVar8 == (code *)0x0)) &&
                       ((*(longlong **)(lVar7 + 0x68) == (longlong *)0x0 ||
                        (pcVar8 = (code *)**(longlong **)(lVar7 + 0x68), pcVar8 == (code *)0x0))))
                    goto LAB_1408cd9e5;
                    lVar7 = (*pcVar8)(pcVar3);
                  }
                  else {
                    iVar2 = (*pcVar8)(pcVar3);
                    lVar7 = (longlong)iVar2;
                  }
                  if (0 < lVar7) {
                    bVar18 = true;
                    goto LAB_1408cda58;
                  }
                  if (lVar7 == 0) goto LAB_1408cda56;
LAB_1408ce237:
                  lStack_130 = *(longlong *)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  if ((-1 < *(int *)pcVar3) &&
                     (*(longlong *)pcVar3 = *(longlong *)pcVar3 + -1, *(longlong *)pcVar3 == 0)) {
                    (**(code **)(*(longlong *)(pcVar3 + 8) + 0x30))(pcVar3);
                  }
                  uVar17 = 0x235c;
                  plVar13 = plStack_128;
                  lVar7 = lStack_130;
                  goto LAB_1408cf72e;
                }
LAB_1408cd9e5:
                bVar18 = true;
LAB_1408cda58:
                if ((-1 < *(int *)pcVar3) &&
                   (*(longlong *)pcVar3 = *(longlong *)pcVar3 + -1, *(longlong *)pcVar3 == 0)) {
                  (**(code **)(*(longlong *)(pcVar3 + 8) + 0x30))(pcVar3);
                }
                if (!bVar18) {
                  *(undefined4 *)(plVar11 + 5) = 0x235c;
                  pcVar3 = (code *)FUN_142cd06a0(tstate,plVar13,classes_const_1882__geetest_aberto);
                  if (pcVar3 == (code *)0x0) goto LAB_1408ce41a;
                  iVar2 = FUN_140004970(pcVar3);
                  if (iVar2 == -1) goto LAB_1408ce237;
                  bVar18 = iVar2 != 0;
                  if ((-1 < *(int *)pcVar3) &&
                     (*(longlong *)pcVar3 = *(longlong *)pcVar3 + -1, *(longlong *)pcVar3 == 0)) {
                    (**(code **)(*(longlong *)(pcVar3 + 8) + 0x30))(pcVar3);
                  }
                }
                pcVar3 = _Py_NoneStruct_exref;
                if (bVar18) {
                  pcStack_120 = _Py_NoneStruct_exref;
                  if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                    *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                  }
                  if (pcVar9 != (code *)0x0) goto LAB_1408cdb40;
                }
                else {
                  if (pcVar9 == (code *)0x0) {
                    FUN_142cd4900(tstate,&lStack_130,classes_const_1887_fechado_desde);
                    FUN_1400048d0(tstate,lStack_130);
                    uVar17 = 0x235f;
                    plVar13 = plStack_128;
                    lVar7 = lStack_130;
                    goto LAB_1408cf72e;
                  }
                  if (pcVar9 != _Py_NoneStruct_exref) {
                    lVar7 = FUN_140a3b210();
                    if (lVar7 == 0) {
                      FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
                      uVar17 = 0x2361;
                      plVar13 = plStack_128;
                      lVar7 = lStack_130;
                      goto LAB_1408cf72e;
                    }
                    *(undefined4 *)(plVar11 + 5) = 0x2361;
                    plVar5 = (longlong *)FUN_142cd06a0(tstate,lVar7,classes_const_76_time);
                    if (plVar5 != (longlong *)0x0) {
                      plVar6 = (longlong *)FUN_142cc11d0(plVar5,pcVar9);
                      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                        (**(code **)(plVar5[1] + 0x30))(plVar5);
                      }
                      if (plVar6 != (longlong *)0x0) {
                        iVar2 = FUN_142ce05d0(plVar6,classes_const_1792_2_0);
                        if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                          (**(code **)(plVar6[1] + 0x30))(plVar6);
                        }
                        if (iVar2 != -1) {
                          pcVar3 = pcVar9;
                          if (iVar2 != 1) goto LAB_1408cdbf7;
                          uVar12 = FUN_1400776a0(classes_const_257_print);
                          puVar14 = classes_const_1945__s__geetest_3x3__resolvido;
                          uVar17 = 0x2362;
                          *(undefined4 *)(plVar11 + 5) = 0x2362;
                          plVar4 = (longlong *)
                                   FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
                          plVar13 = plStack_128;
                          if (plVar4 == (longlong *)0x0) goto LAB_1408cf71e;
                          plVar5 = (longlong *)FUN_142cbff90(puVar14,plVar4);
                          if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                            (**(code **)(plVar4[1] + 0x30))(plVar4);
                          }
                          plVar13 = plStack_128;
                          if (plVar5 == (longlong *)0x0) goto LAB_1408cf71e;
                          *(undefined4 *)(plVar11 + 5) = 0x2362;
                          plVar4 = (longlong *)FUN_142ccfd60(tstate,uVar12,plVar5);
                          if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                            (**(code **)(plVar5[1] + 0x30))(plVar5);
                          }
                          plVar13 = plStack_128;
                          if (plVar4 == (longlong *)0x0) goto LAB_1408cf71e;
                          if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
                            (**(code **)(plVar4[1] + 0x30))(plVar4);
                          }
                          plVar13 = plStack_128;
                          cVar1 = FUN_142ce4bf0(tstate,plStack_128,classes_const_1939__sprite_visto,
                                                classes_const_102_);
                          pcVar15 = _Py_TrueStruct_exref;
                          if (cVar1 != '\0') goto LAB_1408cf160;
                          uVar17 = 0x2363;
                          goto LAB_1408cf71e;
                        }
                      }
                    }
                    uVar17 = 0x2361;
                    plVar13 = plStack_128;
                    goto LAB_1408cf71e;
                  }
                  lVar7 = FUN_140a3b210();
                  if (lVar7 == 0) {
                    FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
                    uVar17 = 0x2360;
                    plVar13 = plStack_128;
                    lVar7 = lStack_130;
                    goto LAB_1408cf72e;
                  }
                  *(undefined4 *)(plVar11 + 5) = 0x2360;
                  pcVar3 = (code *)FUN_142cd06a0(tstate,lVar7,classes_const_76_time);
                  if (pcVar3 == (code *)0x0) {
                    uVar17 = 0x2360;
                    plVar13 = plStack_128;
                    goto LAB_1408cf71e;
                  }
LAB_1408cdb40:
                  pcStack_120 = pcVar3;
                  if ((-1 < *(int *)pcVar9) &&
                     (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
                    (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))();
                  }
                }
LAB_1408cdbf7:
                lVar7 = FUN_140a3b210(tstate);
                pcVar9 = pcVar3;
                if (lVar7 == 0) {
                  FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
                  uVar17 = 0x2365;
                  plVar13 = plStack_128;
                  lVar7 = lStack_130;
                  goto LAB_1408cf72e;
                }
                *(undefined4 *)(plVar11 + 5) = 0x2365;
                plVar5 = (longlong *)
                         FUN_142cd12f0(tstate,lVar7,classes_const_77_sleep,
                                       *(undefined8 *)
                                        (classes_const_1551___type____T____items____0_3__ + 0x18));
                if (plVar5 == (longlong *)0x0) {
                  uVar17 = 0x2365;
                  plVar13 = plStack_128;
                  goto LAB_1408cf71e;
                }
                if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                  (**(code **)(plVar5[1] + 0x30))(plVar5);
                }
                if ((((*(ulonglong *)(tstate + 0x18) & 6) != 0) &&
                    (iVar2 = Py_MakePendingCalls(), iVar2 < 0)) &&
                   (*(longlong *)(tstate + 0x70) != 0)) goto LAB_1408cdcc0;
                if ((*(ulonglong *)(tstate + 0x18) & 1) != 0) {
                  PyEval_SaveThread();
                  PyEval_AcquireThread(tstate);
                }
                if (*(longlong *)(tstate + 0x90) != 0) {
                  *(undefined8 *)(tstate + 0x90) = 0;
                  plVar13 = *(longlong **)(tstate + 0x70);
                  uVar12 = FUN_142cd9e70(tstate);
                  *(undefined8 *)(tstate + 0x70) = uVar12;
                  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                  }
LAB_1408cdcc0:
                  uVar17 = 0x235b;
                  plVar13 = plStack_128;
                  pcVar9 = pcVar3;
                  goto LAB_1408cf71e;
                }
              } while( true );
            }
          }
          uVar17 = 0x2359;
          plVar13 = plStack_128;
          pcVar9 = pcStack_120;
          goto LAB_1408cf71e;
        }
        FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
        uVar17 = 0x2359;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
        lVar7 = lStack_130;
        goto LAB_1408cf72e;
      }
      lStack_130 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
    }
    lVar7 = lStack_130;
    lStack_130 = 0;
    piVar16 = *(int **)(tstate + 0xf8);
    if ((piVar16 != (int *)0x0) && (*piVar16 + 1 != 0)) {
      *piVar16 = *piVar16 + 1;
    }
    if (*(longlong *)(lVar7 + 0x28) == 0) {
      pcVar9 = (code *)FUN_142cd9160(plVar11,0x234d);
    }
    else {
      pcVar9 = (code *)FUN_140008a80(*(longlong *)(lVar7 + 0x28),plVar11,0x234d);
    }
    plVar4 = *(longlong **)(lVar7 + 0x28);
    if (pcVar9 == _Py_NoneStruct_exref) {
      pcVar3 = (code *)0x0;
    }
    else {
      pcVar3 = pcVar9;
      if ((pcVar9 != (code *)0x0) && (*(int *)pcVar9 + 1 != 0)) {
        *(int *)pcVar9 = *(int *)pcVar9 + 1;
      }
    }
    *(code **)(lVar7 + 0x28) = pcVar3;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    if (((pcVar9 != (code *)0x0) && (-1 < *(int *)pcVar9)) &&
       (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
      (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
    }
    plVar4 = *(longlong **)(tstate + 0xf8);
    *(longlong *)(tstate + 0xf8) = lVar7;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    iVar2 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                          *(undefined8 *)PyExc_Exception_exref);
    if (iVar2 != 0) {
      plVar4 = *(longlong **)(tstate + 0xf8);
      iVar2 = (int)*plVar4 + 1;
      if (iVar2 != 0) {
        *(int *)plVar4 = iVar2;
      }
      uVar12 = FUN_1400776a0(classes_const_257_print);
      puVar14 = classes_const_1944__s__geetest_3x3__falhei_ao_confirmar___s;
      plStack_110 = (longlong *)CONCAT44(plStack_110._4_4_,0x234f);
      *(undefined4 *)(plStack_118 + 5) = 0x234f;
      lVar7 = FUN_142cd06a0(tstate,plVar13,classes_const_1346__tag);
      plVar11 = plStack_118;
      if (lVar7 == 0) {
LAB_1408ce6d3:
        lVar7 = *(longlong *)(tstate + 0x70);
        uVar17 = plStack_110._0_4_;
        *(undefined8 *)(tstate + 0x70) = 0;
        if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
          (**(code **)(plVar4[1] + 0x30))(plVar4);
        }
        goto LAB_1408ce732;
      }
      plVar13 = (longlong *)FUN_142cd9440(tstate,2);
      plVar13[3] = lVar7;
      iVar2 = (int)*plVar4 + 1;
      if (iVar2 != 0) {
        *(int *)plVar4 = iVar2;
      }
      plVar13[4] = (longlong)plVar4;
      plVar5 = (longlong *)FUN_142cbffc0(puVar14,plVar13);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      plVar11 = plStack_118;
      if (plVar5 == (longlong *)0x0) goto LAB_1408ce6d3;
      *(undefined4 *)(plStack_118 + 5) = 0x234f;
      plVar13 = (longlong *)FUN_142ccfd60(tstate,uVar12,plVar5);
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
      if (plVar13 == (longlong *)0x0) goto LAB_1408ce6d3;
      goto LAB_1408cf434;
    }
    cVar1 = FUN_142cded30(tstate,&lStack_130);
    uVar17 = 0x234c;
    if (cVar1 != '\0') {
      uVar17 = 0;
    }
    lVar10 = *(longlong *)(lStack_130 + 0x28);
    lVar7 = lStack_130;
    if ((lVar10 != 0) && (*(longlong **)(lVar10 + 0x18) == plVar11)) {
      *(undefined4 *)(plVar11 + 5) = *(undefined4 *)(lVar10 + 0x24);
    }
LAB_1408ce732:
    lStack_130 = 0;
    plVar4 = *(longlong **)(tstate + 0xf8);
    *(int **)(tstate + 0xf8) = piVar16;
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) &&
       (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
    }
    goto LAB_1408cf72e;
  }
  if (plStack_100 == (longlong *)0x0) {
    FUN_142cd4900(tstate,&lStack_130,classes_const_1931_descartes);
    FUN_1400048d0(tstate,lStack_130);
    uVar17 = 0x2318;
    pcVar9 = pcStack_120;
    plVar11 = plStack_118;
    lVar7 = lStack_130;
    goto LAB_1408cf72e;
  }
  cVar1 = Nuitka_helper_142ce2960(plStack_100,3);
  if (cVar1 == '\0') {
    uVar12 = FUN_1400776a0(classes_const_257_print);
    plVar11 = plStack_118;
    puVar14 = classes_const_1933__s__geetest_3x3_emocao__desisti__nao_reconheci_3_desafios;
    uVar17 = 0x2320;
    *(undefined4 *)(plStack_118 + 5) = 0x2320;
    plVar4 = (longlong *)FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
    plVar13 = plStack_128;
    pcVar9 = pcStack_120;
    if (plVar4 != (longlong *)0x0) {
      plVar6 = (longlong *)FUN_142cbff90(puVar14,plVar4);
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      if (plVar6 != (longlong *)0x0) {
        uVar17 = 0x231f;
        *(undefined4 *)(plVar11 + 5) = 0x231f;
        plVar5 = (longlong *)FUN_142ccfd60(tstate,uVar12,plVar6);
        if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
          (**(code **)(plVar6[1] + 0x30))(plVar6);
        }
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
        if (plVar5 != (longlong *)0x0) {
          pcVar15 = _Py_FalseStruct_exref;
          if (((int)*plVar5 < 0) ||
             (*plVar5 = *plVar5 + -1, pcVar15 = _Py_FalseStruct_exref, *plVar5 != 0))
          goto LAB_1408cf160;
          lVar7 = plVar5[1];
          goto LAB_1408cf14e;
        }
      }
    }
  }
  else {
    plVar13 = (longlong *)FUN_142cbe350(plVar4,1);
    if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))(plVar4);
    }
    plVar4 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
    puVar14 = classes_const_1932__s__geetest_3x3_emocao__nao_reconheci_este_desafio___pedindo_outr;
    if ((plVar4 == (longlong *)0x0) || (lVar7 = *plVar4, lVar7 == 0)) goto LAB_1408ce7bc;
    *(undefined4 *)(plStack_118 + 5) = 0x231b;
    plStack_100 = plVar13;
    lVar10 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
    if (lVar10 == 0) {
      uVar17 = 0x231b;
      plVar13 = plStack_128;
      pcVar9 = pcStack_120;
      plVar11 = plStack_118;
    }
    else {
      plVar4 = (longlong *)FUN_142cd9440(tstate,2);
      plVar4[3] = lVar10;
      iVar2 = (int)*plVar13 + 1;
      if (iVar2 != 0) {
        *(int *)plVar13 = iVar2;
      }
      plVar4[4] = (longlong)plVar13;
      plVar13 = (longlong *)FUN_142cbffc0(puVar14,plVar4);
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
      plVar11 = plStack_118;
      if (plVar13 == (longlong *)0x0) {
        uVar17 = 0x231b;
        plVar13 = plStack_128;
        pcVar9 = pcStack_120;
      }
      else {
        *(undefined4 *)(plStack_118 + 5) = 0x231a;
        plVar4 = (longlong *)FUN_142ccfd60(tstate,lVar7,plVar13);
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if (plVar4 == (longlong *)0x0) {
          uVar17 = 0x231a;
          plVar13 = plStack_128;
          pcVar9 = pcStack_120;
        }
        else {
          if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
            (**(code **)(plVar4[1] + 0x30))(plVar4);
          }
          plVar13 = plStack_128;
          *(undefined4 *)(plVar11 + 5) = 0x231c;
          plVar4 = (longlong *)FUN_142cd06a0(tstate,plStack_128,classes_const_1862__geetest_refresh)
          ;
          if (plVar4 == (longlong *)0x0) {
            uVar17 = 0x231c;
            pcVar9 = pcStack_120;
            goto LAB_1408cf71e;
          }
          if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
            (**(code **)(plVar4[1] + 0x30))(plVar4);
          }
          lVar7 = FUN_140a3b210(tstate);
          if (lVar7 == 0) {
            FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
            uVar17 = 0x231d;
            pcVar9 = pcStack_120;
            lVar7 = lStack_130;
            goto LAB_1408cf72e;
          }
          *(undefined4 *)(plVar11 + 5) = 0x231d;
          plVar4 = (longlong *)
                   FUN_142cd12f0(tstate,lVar7,classes_const_77_sleep,
                                 *(undefined8 *)
                                  (classes_const_359___type____T____items____2_5__ + 0x18));
          if (plVar4 != (longlong *)0x0) {
LAB_1408ccdf6:
            pcVar9 = pcStack_120;
            if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
              (**(code **)(plVar4[1] + 0x30))(plVar4);
              pcVar9 = pcStack_120;
            }
            goto LAB_1408cdf22;
          }
          uVar17 = 0x231d;
          pcVar9 = pcStack_120;
        }
      }
    }
  }
LAB_1408cf71e:
  lVar7 = *(longlong *)(tstate + 0x70);
  *(undefined8 *)(tstate + 0x70) = 0;
  goto LAB_1408cf72e;
LAB_1408cdccf:
  plVar13 = (longlong *)FUN_140004a00(_DAT_142f24450,classes_const_257_print);
  plVar11 = plStack_118;
  puVar14 = classes_const_1946__s__geetest_3x3__respondi_e_o_captcha_ficou__resposta__d_de__d_;
  if ((plVar13 == (longlong *)0x0) || (lVar7 = *plVar13, lVar7 == 0)) {
LAB_1408ce7bc:
    PyErr_PrintEx(0);
    Py_Exit(1);
    pcVar9 = (code *)swi(3);
    puVar14 = (undefined *)(*pcVar9)();
    return puVar14;
  }
  *(undefined4 *)(plStack_118 + 5) = 0x2367;
  lVar10 = FUN_142cd06a0(tstate,plStack_128,classes_const_1346__tag);
  if (lVar10 != 0) {
    plVar13 = (longlong *)FUN_142cd9440(tstate,3);
    plVar13[3] = lVar10;
    iVar2 = (int)*plStack_f0 + 1;
    if (iVar2 != 0) {
      *(int *)plStack_f0 = iVar2;
    }
    plVar13[4] = (longlong)plStack_f0;
    iVar2 = (int)*plStack_d8 + 1;
    if (iVar2 != 0) {
      *(int *)plStack_d8 = iVar2;
    }
    plVar13[5] = (longlong)plStack_d8;
    plVar4 = (longlong *)FUN_142cbffc0(puVar14,plVar13);
    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    if (plVar4 != (longlong *)0x0) {
      *(undefined4 *)(plVar11 + 5) = 0x2366;
      plVar13 = (longlong *)FUN_142ccfd60(tstate,lVar7,plVar4);
      if ((-1 < (int)*plVar4) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)) {
        (**(code **)(plVar4[1] + 0x30))(plVar4);
      }
      if (plVar13 == (longlong *)0x0) {
        uVar17 = 0x2366;
        plVar13 = plStack_128;
        plVar11 = plStack_118;
      }
      else {
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        lVar7 = FUN_140a3b210(tstate);
        if (lVar7 == 0) {
          FUN_142cde870(tstate,&lStack_130,classes_const_76_time);
          uVar17 = 0x236a;
          plVar13 = plStack_128;
          plVar11 = plStack_118;
          lVar7 = lStack_130;
          goto LAB_1408cf72e;
        }
        *(undefined4 *)(plVar11 + 5) = 0x236a;
        plVar13 = (longlong *)
                  FUN_142cd12f0(tstate,lVar7,classes_const_77_sleep,
                                *(undefined8 *)
                                 (classes_const_1890___type____T____items____1_5__ + 0x18));
        if (plVar13 == (longlong *)0x0) {
          uVar17 = 0x236a;
          plVar13 = plStack_128;
        }
        else {
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          cVar1 = FUN_140008af0(tstate);
          plVar13 = plStack_128;
          if (cVar1 != '\0') {
LAB_1408cdf22:
            plVar4 = plStack_f0;
            plVar5 = plStack_d8;
            if (plStack_f0 == (longlong *)0x0) goto LAB_1408cefb6;
            goto LAB_1408cc350;
          }
LAB_1408cf718:
          uVar17 = 0x22ed;
        }
      }
      goto LAB_1408cf71e;
    }
  }
  uVar17 = 0x2367;
  plVar13 = plStack_128;
  plVar11 = plStack_118;
  goto LAB_1408cf71e;
LAB_1408cefb6:
  FUN_142cd4900(tstate,&lStack_130,classes_const_1847_respostas);
  FUN_1400048d0(tstate,lStack_130);
  uVar17 = 0x22ed;
  lVar7 = lStack_130;
LAB_1408cf72e:
  lStack_130 = lVar7;
  piVar16 = *(int **)(lStack_130 + 0x28);
  if (piVar16 == (int *)0x0) {
    pcVar3 = (code *)FUN_142cd9160(plVar11,uVar17);
    bVar18 = pcVar3 == _Py_NoneStruct_exref;
  }
  else {
    if (*(longlong **)(piVar16 + 6) == plVar11) goto LAB_1408cf7ce;
    pcVar3 = (code *)FUN_142cd9160(plVar11,uVar17);
    *(int **)(pcVar3 + 0x10) = piVar16;
    if (*piVar16 + 1 != 0) {
      *piVar16 = *piVar16 + 1;
    }
    bVar18 = pcVar3 == _Py_NoneStruct_exref;
  }
  plVar4 = *(longlong **)(lStack_130 + 0x28);
  if (bVar18) {
    pcVar8 = (code *)0x0;
  }
  else {
    pcVar8 = pcVar3;
    if ((pcVar3 != (code *)0x0) && (*(int *)pcVar3 + 1 != 0)) {
      *(int *)pcVar3 = *(int *)pcVar3 + 1;
    }
  }
  *(code **)(lStack_130 + 0x28) = pcVar8;
  if (((plVar4 != (longlong *)0x0) && (-1 < (int)*plVar4)) && (*plVar4 = *plVar4 + -1, *plVar4 == 0)
     ) {
    (**(code **)(plVar4[1] + 0x30))();
  }
  if (((pcVar3 != (code *)0x0) && (-1 < *(int *)pcVar3)) &&
     (*(longlong *)pcVar3 = *(longlong *)pcVar3 + -1, *(longlong *)pcVar3 == 0)) {
    (**(code **)(*(longlong *)(pcVar3 + 8) + 0x30))(pcVar3);
  }
LAB_1408cf7ce:
  plVar6 = plStack_f0;
  plVar5 = plStack_100;
  plStack_150 = plStack_90;
  plStack_158 = plStack_98;
  pcStack_160 = pcStack_a0;
  plStack_168 = plStack_a8;
  plStack_170 = plStack_e8;
  pcStack_178 = pcStack_f8;
  pcStack_180 = pcStack_b0;
  plStack_188 = plStack_b8;
  plStack_190 = plStack_c0;
  pcStack_198 = pcStack_c8;
  plStack_1a0 = plStack_e0;
  uStack_1a8 = 0;
  plStack_1b0 = plStack_d0;
  plStack_1b8 = plStack_108;
  plStack_1c0 = plStack_100;
  plStack_1c8 = plStack_f0;
  pcStack_148 = pcVar9;
  FUN_142cdb370(plVar11,&UNK_142d0b330,plVar13,plStack_d8);
  plVar4 = _DAT_142dea7a0;
  if (plVar11 == _DAT_142dea7a0) {
    if ((-1 < (int)*_DAT_142dea7a0) && (*_DAT_142dea7a0 = *_DAT_142dea7a0 + -1, *plVar4 == 0)) {
      (**(code **)(plVar4[1] + 0x30))();
    }
    _DAT_142dea7a0 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar7 = lStack_130;
  lStack_130 = 0;
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)
     ) {
    (**(code **)(plVar5[1] + 0x30))(plVar5);
  }
  if (((plStack_108 != (longlong *)0x0) && (-1 < (int)*plStack_108)) &&
     (*plStack_108 = *plStack_108 + -1, *plStack_108 == 0)) {
    (**(code **)(plStack_108[1] + 0x30))();
  }
  if (((plStack_d0 != (longlong *)0x0) && (-1 < (int)*plStack_d0)) &&
     (*plStack_d0 = *plStack_d0 + -1, *plStack_d0 == 0)) {
    (**(code **)(plStack_d0[1] + 0x30))();
  }
  if (((plStack_e0 != (longlong *)0x0) && (-1 < (int)*plStack_e0)) &&
     (*plStack_e0 = *plStack_e0 + -1, *plStack_e0 == 0)) {
    (**(code **)(plStack_e0[1] + 0x30))();
  }
  if (((pcStack_c8 != (code *)0x0) && (-1 < *(int *)pcStack_c8)) &&
     (*(longlong *)pcStack_c8 = *(longlong *)pcStack_c8 + -1, *(longlong *)pcStack_c8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_c8 + 8) + 0x30))();
  }
  if (((plStack_c0 != (longlong *)0x0) && (-1 < (int)*plStack_c0)) &&
     (*plStack_c0 = *plStack_c0 + -1, *plStack_c0 == 0)) {
    (**(code **)(plStack_c0[1] + 0x30))();
  }
  if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
     (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
    (**(code **)(plStack_b8[1] + 0x30))();
  }
  if (((pcStack_b0 != (code *)0x0) && (-1 < *(int *)pcStack_b0)) &&
     (*(longlong *)pcStack_b0 = *(longlong *)pcStack_b0 + -1, *(longlong *)pcStack_b0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_b0 + 8) + 0x30))();
  }
  if (((pcStack_f8 != (code *)0x0) && (-1 < *(int *)pcStack_f8)) &&
     (*(longlong *)pcStack_f8 = *(longlong *)pcStack_f8 + -1, *(longlong *)pcStack_f8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_f8 + 8) + 0x30))();
  }
  if (((plStack_e8 != (longlong *)0x0) && (-1 < (int)*plStack_e8)) &&
     (*plStack_e8 = *plStack_e8 + -1, *plStack_e8 == 0)) {
    (**(code **)(plStack_e8[1] + 0x30))();
  }
  if (((plStack_a8 != (longlong *)0x0) && (-1 < (int)*plStack_a8)) &&
     (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
    (**(code **)(plStack_a8[1] + 0x30))();
  }
  if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
     (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))();
  }
  if (((plStack_98 != (longlong *)0x0) && (-1 < (int)*plStack_98)) &&
     (*plStack_98 = *plStack_98 + -1, *plStack_98 == 0)) {
    (**(code **)(plStack_98[1] + 0x30))();
  }
  if (((plStack_90 != (longlong *)0x0) && (-1 < (int)*plStack_90)) &&
     (*plStack_90 = *plStack_90 + -1, *plStack_90 == 0)) {
    (**(code **)(plStack_90[1] + 0x30))();
  }
  if (((pcVar9 != (code *)0x0) && (-1 < *(int *)pcVar9)) &&
     (*(longlong *)pcVar9 = *(longlong *)pcVar9 + -1, *(longlong *)pcVar9 == 0)) {
    (**(code **)(*(longlong *)(pcVar9 + 8) + 0x30))(pcVar9);
  }
  lStack_130 = lVar7;
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  if ((-1 < (int)*plStack_d8) && (*plStack_d8 = *plStack_d8 + -1, *plStack_d8 == 0)) {
    (**(code **)(plStack_d8[1] + 0x30))();
  }
  plVar13 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStack_130;
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))();
  }
LAB_1408cfac4:
  puVar14 = (undefined *)FUN_142cfc380(uStack_48 ^ (ulonglong)auStack_1e8);
  return puVar14;
}

