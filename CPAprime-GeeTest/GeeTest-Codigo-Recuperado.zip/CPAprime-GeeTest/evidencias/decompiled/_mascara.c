
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _mascara(undefined *tstate,undefined *self,undefined **python_pars)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  code *pcVar11;
  code *pcVar12;
  undefined *puVar13;
  longlong lVar14;
  longlong *plVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  longlong *plVar18;
  bool bVar19;
  undefined1 auStack_178 [32];
  longlong *plStack_158;
  longlong *plStack_150;
  longlong *plStack_148;
  longlong *plStack_140;
  longlong *plStack_138;
  longlong *plStack_130;
  undefined8 uStack_128;
  undefined8 uStack_120;
  longlong *plStack_118;
  longlong *plStack_110;
  longlong *plStack_108;
  longlong *plStack_100;
  longlong *plStack_f8;
  longlong *plStack_e8;
  longlong *plStack_e0;
  undefined *puStack_d8;
  code *pcStack_d0;
  longlong *plStack_c8;
  longlong *plStack_c0;
  longlong *plStack_b8;
  longlong *plStack_b0;
  longlong *plStack_a8;
  code *pcStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  code *pcStack_88;
  longlong *plStack_80;
  longlong *plStack_78;
  longlong *plStack_70;
  longlong *plStack_68;
  undefined8 uStack_60;
  longlong *plStack_58;
  longlong *plStack_50;
  ulonglong uStack_48;
  
  plVar9 = _DAT_142dea758;
  uStack_48 = _DAT_142d9a1c0 ^ (ulonglong)auStack_178;
  plStack_a8 = (longlong *)*python_pars;
  plStack_118 = (longlong *)0x0;
  plVar18 = (longlong *)0x0;
  pcStack_a0 = (code *)0x0;
  plStack_c0 = (longlong *)0x0;
  plStack_b8 = (longlong *)0x0;
  plStack_b0 = (longlong *)0x0;
  plStack_100 = (longlong *)0x0;
  plStack_c8 = (longlong *)0x0;
  plStack_f8 = (longlong *)0x0;
  plStack_108 = _DAT_142dea758;
  puStack_d8 = self;
  if (_DAT_142dea758 == (longlong *)0x0) {
LAB_1408c01b0:
    plStack_108 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9bf0,_DAT_142f2aaf0,0x50);
  }
  else if ((1 < *_DAT_142dea758) || (_DAT_142dea758[2] != 0)) {
    if ((_DAT_142dea758 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea758 && (*_DAT_142dea758 = *_DAT_142dea758 + -1, *plVar9 == 0)))) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    goto LAB_1408c01b0;
  }
  plVar9 = plStack_108;
  _DAT_142dea758 = plStack_108;
  Nuitka_helper_140008a00(tstate,plStack_108);
  puVar13 = classes_const_1786__cv2;
  if (*(longlong *)(*(longlong *)(self + 0xe0) + 0x10) == 0) {
LAB_1408c0208:
    FUN_142cd4880(tstate,&plStack_118,puVar13);
    FUN_1400048d0(tstate,plStack_118);
LAB_1408c021f:
    uVar16 = 0x2148;
    plVar7 = (longlong *)0x0;
    plVar18 = (longlong *)0x0;
    plVar5 = plStack_118;
    goto LAB_1408c175c;
  }
  plVar5 = (longlong *)
           FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(self + 0xe0) + 0x10),
                         classes_const_1781_imdecode);
  plVar7 = (longlong *)0x0;
  if (plVar5 == (longlong *)0x0) {
    plVar5 = *(longlong **)(tstate + 0x70);
    uVar16 = 0x2148;
    *(undefined8 *)(tstate + 0x70) = 0;
    goto LAB_1408c175c;
  }
  if (*(longlong *)(*(longlong *)(self + 0xe8) + 0x10) == 0) {
    puVar13 = classes_const_1799__np;
    if ((-1 < (int)*plVar5) &&
       (*plVar5 = *plVar5 + -1, puVar13 = classes_const_1799__np, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
      puVar13 = classes_const_1799__np;
    }
    goto LAB_1408c0208;
  }
  plVar6 = (longlong *)
           FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(self + 0xe8) + 0x10),
                         classes_const_1782_frombuffer);
  if (plVar6 == (longlong *)0x0) {
    plStack_118 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
      uVar16 = 0x2148;
      plVar5 = plStack_118;
      goto LAB_1408c175c;
    }
    goto LAB_1408c021f;
  }
  if (*(longlong *)(*(longlong *)(self + 0xe8) + 0x10) == 0) {
    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    puVar13 = classes_const_1799__np;
    if ((-1 < (int)*plVar6) &&
       (*plVar6 = *plVar6 + -1, puVar13 = classes_const_1799__np, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
      puVar13 = classes_const_1799__np;
    }
    goto LAB_1408c0208;
  }
  plVar7 = (longlong *)
           FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(self + 0xe8) + 0x10),
                         classes_const_1783_uint8);
  if (plVar7 == (longlong *)0x0) {
    plStack_118 = *(longlong **)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
    uVar16 = 0x2148;
    plVar7 = (longlong *)0x0;
    plVar5 = plStack_118;
  }
  else {
    uVar16 = 0x2148;
    plStack_e8 = plStack_a8;
    *(undefined4 *)(plVar9 + 5) = 0x2148;
    plStack_e0 = plVar7;
    plVar8 = (longlong *)FUN_142cc4ec0(tstate,plVar6,&plStack_e8);
    if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
      (**(code **)(plVar6[1] + 0x30))(plVar6);
    }
    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
      (**(code **)(plVar7[1] + 0x30))(plVar7);
    }
    if (plVar8 == (longlong *)0x0) {
      plStack_118 = *(longlong **)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
LAB_1408c03f7:
      plVar7 = (longlong *)0x0;
      plVar9 = plStack_108;
      plVar5 = plStack_118;
    }
    else if (*(longlong *)(*(longlong *)(puStack_d8 + 0xe0) + 0x10) == 0) {
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
      }
      FUN_142cd4880(tstate,&plStack_118,classes_const_1786__cv2);
      FUN_1400048d0(tstate,plStack_118);
      plVar7 = (longlong *)0x0;
      plVar9 = plStack_108;
      plVar5 = plStack_118;
    }
    else {
      plVar7 = (longlong *)
               FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(puStack_d8 + 0xe0) + 0x10),
                             classes_const_1826_IMREAD_UNCHANGED);
      plVar9 = plStack_108;
      if (plVar7 == (longlong *)0x0) {
        plStack_118 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))(plVar5);
        }
        if (((int)*plVar8 < 0) || (*plVar8 = *plVar8 + -1, *plVar8 != 0)) goto LAB_1408c03f7;
        (**(code **)(plVar8[1] + 0x30))(plVar8);
        plVar7 = (longlong *)0x0;
        plVar9 = plStack_108;
        plVar5 = plStack_118;
      }
      else {
        *(undefined4 *)(plStack_108 + 5) = 0x2148;
        plStack_98 = plVar8;
        plStack_90 = plVar7;
        pcVar11 = (code *)FUN_142cc4ec0(tstate,plVar5,&plStack_98);
        pcStack_d0 = pcVar11;
        if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
          (**(code **)(plVar5[1] + 0x30))(plVar5);
        }
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
          (**(code **)(plVar7[1] + 0x30))(plVar7);
        }
        if (pcVar11 == (code *)0x0) goto LAB_1408c0540;
        if (pcVar11 == _Py_NoneStruct_exref) {
          plVar6 = plStack_f8;
          plVar7 = plStack_f8;
          if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
            *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
          }
          goto LAB_1408c1822;
        }
        pcStack_a0 = pcVar11;
        plVar18 = (longlong *)FUN_142cd7b20(tstate,pcVar11,classes_const_1795_shape);
        if (plVar18 == (longlong *)0x0) {
LAB_1408c05a3:
          uVar16 = 0x214b;
        }
        else {
          plVar7 = (longlong *)FUN_142cc1f90(tstate,plVar18);
          if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
            (**(code **)(plVar18[1] + 0x30))(plVar18);
          }
          if (plVar7 == (longlong *)0x0) goto LAB_1408c05a3;
          cVar2 = Nuitka_helper_142cdee20(plVar7,2);
          if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
            (**(code **)(plVar7[1] + 0x30))(plVar7);
          }
          puVar13 = puStack_d8;
          if (cVar2 != '\0') {
            if (*(longlong *)(*(longlong *)(puStack_d8 + 0xe0) + 0x10) == 0) {
LAB_1408c0616:
              FUN_142cd4880(tstate,&plStack_118,classes_const_1786__cv2);
              FUN_1400048d0(tstate,plStack_118);
            }
            else {
              plVar18 = (longlong *)
                        FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(puStack_d8 + 0xe0) + 0x10),
                                      classes_const_1827_cvtColor);
              if (plVar18 == (longlong *)0x0) {
                uVar16 = 0x214c;
                goto LAB_1408c0540;
              }
              if (*(longlong *)(*(longlong *)(puVar13 + 0xe0) + 0x10) == 0) {
                if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                  (**(code **)(plVar18[1] + 0x30))(plVar18);
                }
                goto LAB_1408c0616;
              }
              plVar7 = (longlong *)
                       FUN_142cd7b20(tstate,*(longlong *)(*(longlong *)(puVar13 + 0xe0) + 0x10),
                                     classes_const_1828_COLOR_GRAY2BGR);
              if (plVar7 != (longlong *)0x0) {
                uVar16 = 0x214c;
                *(undefined4 *)(plVar9 + 5) = 0x214c;
                pcStack_88 = pcVar11;
                plStack_80 = plVar7;
                plVar5 = (longlong *)FUN_142cc4ec0(tstate,plVar18,&pcStack_88);
                if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                  (**(code **)(plVar18[1] + 0x30))(plVar18);
                }
                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                }
                plVar18 = plVar5;
                if (plVar5 != (longlong *)0x0) goto LAB_1408c090b;
                goto LAB_1408c0540;
              }
              plStack_118 = *(longlong **)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                (**(code **)(plVar18[1] + 0x30))(plVar18);
                uVar16 = 0x214c;
                plVar7 = plStack_f8;
                plVar18 = plStack_f8;
                plVar5 = plStack_118;
                goto LAB_1408c175c;
              }
            }
            uVar16 = 0x214c;
            plVar7 = plStack_f8;
            plVar18 = plStack_f8;
            plVar5 = plStack_118;
            goto LAB_1408c175c;
          }
          plVar18 = (longlong *)
                    FUN_140008da0(tstate,pcVar11,
                                  classes_const_1829___type____T____items______type_________items____None__None__None_
                                 );
          if (plVar18 == (longlong *)0x0) {
            uVar16 = 0x214e;
          }
          else {
            plVar7 = (longlong *)FUN_142cd7b20(tstate,plVar18,classes_const_1804_copy);
            if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
              (**(code **)(plVar18[1] + 0x30))(plVar18);
            }
            uVar16 = 0x214e;
            if (plVar7 != (longlong *)0x0) {
              *(undefined4 *)(plVar9 + 5) = 0x214e;
              plVar5 = (longlong *)FUN_142cc3220(tstate,plVar7);
              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                (**(code **)(plVar7[1] + 0x30))(plVar7);
              }
              if (plVar5 != (longlong *)0x0) {
                plStack_c0 = plVar5;
                plVar9 = (longlong *)FUN_142cd7b20(tstate,pcVar11,classes_const_1795_shape);
                if (plVar9 == (longlong *)0x0) {
LAB_1408c07f2:
                  uVar16 = 0x214f;
                }
                else {
                  plVar18 = (longlong *)FUN_140008f40(tstate,plVar9,classes_const_605_2,2);
                  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                  }
                  if (plVar18 == (longlong *)0x0) goto LAB_1408c07f2;
                  iVar3 = FUN_142cdf450(plVar18,classes_const_1029_4);
                  if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                  }
                  puVar13 = classes_const_1830_255;
                  if (iVar3 == -1) goto LAB_1408c07f2;
                  plVar18 = plStack_c0;
                  if (iVar3 != 1) {
LAB_1408c090b:
                    plStack_c0 = plVar18;
                    puVar13 = puStack_d8;
                    if (*(longlong *)(*(longlong *)(puStack_d8 + 0xe0) + 0x10) == 0) {
LAB_1408c0922:
                      FUN_142cd4880(tstate,&plStack_118,classes_const_1786__cv2);
LAB_1408c0933:
                      FUN_1400048d0(tstate,plStack_118);
LAB_1408c0940:
                      uVar16 = 0x2151;
                      plVar7 = plStack_f8;
                      plVar18 = plStack_f8;
                      plVar9 = plStack_108;
                      plVar5 = plStack_118;
                      goto LAB_1408c175c;
                    }
                    plVar18 = (longlong *)
                              FUN_142cd7b20(tstate,*(longlong *)
                                                    (*(longlong *)(puStack_d8 + 0xe0) + 0x10),
                                            classes_const_1827_cvtColor);
                    if (plVar18 == (longlong *)0x0) {
                      uVar16 = 0x2151;
                      goto LAB_1408c07f7;
                    }
                    if (plVar5 == (longlong *)0x0) {
                      if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                        (**(code **)(plVar18[1] + 0x30))(plVar18);
                      }
                      FUN_142cd4900(tstate,&plStack_118,classes_const_1832_bgr);
                      goto LAB_1408c0933;
                    }
                    if (*(longlong *)(*(longlong *)(puVar13 + 0xe0) + 0x10) == 0) {
                      if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                        (**(code **)(plVar18[1] + 0x30))(plVar18);
                      }
                      goto LAB_1408c0922;
                    }
                    plVar7 = (longlong *)
                             FUN_142cd7b20(tstate,*(longlong *)
                                                   (*(longlong *)(puVar13 + 0xe0) + 0x10),
                                           classes_const_1833_COLOR_BGR2GRAY);
                    plVar9 = plStack_108;
                    if (plVar7 == (longlong *)0x0) {
                      plStack_118 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                        (**(code **)(plVar18[1] + 0x30))(plVar18);
                      }
                      goto LAB_1408c0940;
                    }
                    uVar16 = 0x2151;
                    *(undefined4 *)(plStack_108 + 5) = 0x2151;
                    plStack_78 = plVar5;
                    plStack_70 = plVar7;
                    plVar5 = (longlong *)FUN_142cc4ec0(tstate,plVar18,&plStack_78);
                    if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                      (**(code **)(plVar18[1] + 0x30))(plVar18);
                    }
                    if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                      (**(code **)(plVar7[1] + 0x30))(plVar7);
                    }
                    puVar13 = puStack_d8;
                    if (plVar5 == (longlong *)0x0) {
                      plVar5 = *(longlong **)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      plVar7 = plStack_f8;
                      plVar18 = plStack_f8;
                    }
                    else {
                      plStack_b8 = plVar5;
                      if (*(longlong *)(*(longlong *)(puStack_d8 + 0xe0) + 0x10) == 0) {
                        FUN_142cd4880(tstate,&plStack_118,classes_const_1786__cv2);
                        FUN_1400048d0(tstate,plStack_118);
                        uVar16 = 0x2152;
                        plVar7 = plStack_f8;
                        plVar18 = plStack_f8;
                        plVar5 = plStack_118;
                      }
                      else {
                        plVar18 = (longlong *)
                                  FUN_142cd7b20(tstate,*(longlong *)
                                                        (*(longlong *)(puStack_d8 + 0xe0) + 0x10),
                                                classes_const_1834_threshold);
                        uVar17 = _DAT_142d9a260;
                        if (plVar18 == (longlong *)0x0) {
                          plVar5 = *(longlong **)(tstate + 0x70);
                          uVar16 = 0x2152;
                          *(undefined8 *)(tstate + 0x70) = 0;
                          plVar7 = plStack_f8;
                          plVar18 = plStack_f8;
                        }
                        else {
                          lVar10 = *(longlong *)(*(longlong *)(puVar13 + 0xe0) + 0x10);
                          if (lVar10 == 0) {
                            if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                              lVar10 = plVar18[1];
                              plVar7 = plVar18;
LAB_1408c0b2f:
                              (**(code **)(lVar10 + 0x30))(plVar7);
                            }
LAB_1408c0b32:
                            FUN_142cd4880(tstate,&plStack_118,classes_const_1786__cv2);
                            FUN_1400048d0(tstate,plStack_118);
LAB_1408c0b53:
                            uVar16 = 0x2153;
                            plVar7 = plStack_f8;
                            plVar18 = plStack_f8;
                            plVar5 = plStack_118;
                          }
                          else {
                            plStack_e8 = (longlong *)classes_const_1830_255;
                            plVar7 = (longlong *)
                                     FUN_142cd7b20(tstate,lVar10,
                                                   classes_const_1835_THRESH_BINARY_INV);
                            if (plVar7 == (longlong *)0x0) {
                              plStack_118 = *(longlong **)(tstate + 0x70);
                              *(undefined8 *)(tstate + 0x70) = 0;
                              if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0))
                              {
                                (**(code **)(plVar18[1] + 0x30))(plVar18);
                              }
                              uVar16 = 0x2153;
                              plVar7 = plStack_f8;
                              plVar18 = plStack_f8;
                              plVar5 = plStack_118;
                            }
                            else {
                              lVar10 = *(longlong *)(*(longlong *)(puVar13 + 0xe0) + 0x10);
                              if (lVar10 == 0) {
                                if ((-1 < (int)*plVar18) &&
                                   (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                  (**(code **)(plVar18[1] + 0x30))(plVar18);
                                }
                                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  lVar10 = plVar7[1];
                                  goto LAB_1408c0b2f;
                                }
                                goto LAB_1408c0b32;
                              }
                              plVar6 = (longlong *)
                                       FUN_142cd7b20(tstate,lVar10,classes_const_1836_THRESH_OTSU);
                              if (plVar6 == (longlong *)0x0) {
                                plStack_118 = *(longlong **)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                                if ((-1 < (int)*plVar18) &&
                                   (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                  (**(code **)(plVar18[1] + 0x30))(plVar18);
                                }
                                if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                  (**(code **)(plVar7[1] + 0x30))(plVar7);
                                }
                                goto LAB_1408c0b53;
                              }
                              plVar9 = (longlong *)FUN_142cbee60(plVar7,plVar6);
                              if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                (**(code **)(plVar7[1] + 0x30))(plVar7);
                              }
                              if ((-1 < (int)*plVar6) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                (**(code **)(plVar6[1] + 0x30))(plVar6);
                              }
                              if (plVar9 == (longlong *)0x0) {
                                plStack_118 = *(longlong **)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                                if ((-1 < (int)*plVar18) &&
                                   (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                  (**(code **)(plVar18[1] + 0x30))(plVar18);
                                }
                                uVar16 = 0x2153;
                                plVar7 = plStack_f8;
                                plVar18 = plStack_f8;
                                plVar9 = plStack_108;
                                plVar5 = plStack_118;
                              }
                              else {
                                uVar16 = 0x2152;
                                uStack_60 = uVar17;
                                *(undefined4 *)(plStack_108 + 5) = 0x2152;
                                plStack_58 = plStack_e8;
                                plStack_68 = plVar5;
                                plStack_50 = plVar9;
                                plVar7 = (longlong *)FUN_142cc6c80(tstate,plVar18,&plStack_68);
                                if ((-1 < (int)*plVar18) &&
                                   (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                  (**(code **)(plVar18[1] + 0x30))(plVar18);
                                }
                                if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                                }
                                if (plVar7 == (longlong *)0x0) {
                                  plVar5 = *(longlong **)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  plVar7 = plStack_f8;
                                  plVar18 = plStack_f8;
                                  plVar9 = plStack_108;
                                }
                                else {
                                  plVar9 = (longlong *)FUN_1400099f0(plVar7);
                                  if ((-1 < (int)*plVar7) && (*plVar7 = *plVar7 + -1, *plVar7 == 0))
                                  {
                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                  }
                                  if (plVar9 == (longlong *)0x0) {
                                    plVar5 = *(longlong **)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                    plVar7 = plStack_f8;
                                    plVar18 = plStack_f8;
                                    plVar9 = plStack_108;
                                  }
                                  else {
                                    plVar7 = (longlong *)0x0;
                                    plVar5 = (longlong *)0x0;
                                    plVar18 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
                                    if (plVar18 == (longlong *)0x0) {
                                      if ((*(longlong *)(tstate + 0x70) != 0) &&
                                         (lVar10 = *(longlong *)(*(longlong *)(tstate + 0x70) + 8),
                                         lVar10 != 0)) {
                                        lVar14 = *(longlong *)(lVar10 + 8);
                                        if ((*(uint *)(*(longlong *)(lVar10 + 8) + 0xa8) &
                                            0x40000000) == 0) {
                                          lVar14 = lVar10;
                                        }
                                        if ((lVar14 != *(longlong *)PyExc_StopIteration_exref) &&
                                           (((plVar18 = plVar7,
                                             -1 < *(int *)(*(longlong *)(lVar14 + 8) + 0xa8) ||
                                             (plVar18 = (longlong *)0x0,
                                             (*(uint *)(lVar14 + 0xa8) & 0x40000000) == 0)) ||
                                            (cVar2 = Nuitka_helper_142cdd950(), cVar2 != '\x01'))))
                                        {
LAB_1408c0e30:
                                          plVar6 = *(longlong **)(tstate + 0x70);
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          plVar8 = plVar7;
                                          goto LAB_1408c1a21;
                                        }
                                        plVar18 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        if (((plVar18 != (longlong *)0x0) && (-1 < (int)*plVar18))
                                           && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                          (**(code **)(plVar18[1] + 0x30))();
                                        }
                                      }
                                      uVar17 = 0;
                                      plVar18 = plVar7;
LAB_1408c0e63:
                                      plVar7 = (longlong *)
                                               PyUnicode_FromFormat(&UNK_142d0b0b0,2,uVar17);
                                      plStack_118 = (longlong *)
                                                    FUN_142ccfd60(tstate,*(undefined8 *)
                                                                          PyExc_ValueError_exref,
                                                                  plVar7);
                                      plVar8 = plVar5;
                                      plVar6 = plStack_118;
                                      if ((-1 < (int)*plVar7) &&
                                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                        (**(code **)(plVar7[1] + 0x30))(plVar7);
                                        plVar6 = plStack_118;
                                      }
                                    }
                                    else {
                                      plVar8 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
                                      plStack_110 = plVar8;
                                      if (plVar8 == (longlong *)0x0) {
                                        if ((*(longlong *)(tstate + 0x70) != 0) &&
                                           (lVar10 = *(longlong *)(*(longlong *)(tstate + 0x70) + 8)
                                           , lVar10 != 0)) {
                                          lVar14 = *(longlong *)(lVar10 + 8);
                                          if ((*(uint *)(*(longlong *)(lVar10 + 8) + 0xa8) &
                                              0x40000000) == 0) {
                                            lVar14 = lVar10;
                                          }
                                          if (lVar14 != *(longlong *)PyExc_StopIteration_exref) {
                                            if ((-1 < *(int *)(*(longlong *)(lVar14 + 8) + 0xa8)) ||
                                               ((*(uint *)(lVar14 + 0xa8) & 0x40000000) == 0))
                                            goto LAB_1408c0e30;
                                            cVar2 = Nuitka_helper_142cdd950();
                                            if (cVar2 != '\x01') {
                                              plVar6 = *(longlong **)(tstate + 0x70);
                                              *(undefined8 *)(tstate + 0x70) = 0;
                                              plVar8 = plVar5;
                                              goto LAB_1408c1a21;
                                            }
                                          }
                                          plVar7 = *(longlong **)(tstate + 0x70);
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7))
                                             && (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                            (**(code **)(plVar7[1] + 0x30))();
                                          }
                                        }
                                        uVar17 = 1;
                                        goto LAB_1408c0e63;
                                      }
                                      plVar7 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
                                      if (plVar7 != (longlong *)0x0) {
                                        if ((-1 < (int)*plVar7) &&
                                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                                        }
                                        plVar7 = (longlong *)PyUnicode_FromFormat(&UNK_142d0b0e8,2);
                                        plStack_118 = (longlong *)
                                                      FUN_142ccfd60(tstate,*(undefined8 *)
                                                                            PyExc_ValueError_exref,
                                                                    plVar7);
                                        plVar6 = plStack_118;
                                        if ((-1 < (int)*plVar7) &&
                                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                                          plVar6 = plStack_118;
                                        }
                                        goto LAB_1408c1a21;
                                      }
                                      if ((*(longlong *)(tstate + 0x70) == 0) ||
                                         (lVar10 = *(longlong *)(*(longlong *)(tstate + 0x70) + 8),
                                         lVar10 == 0)) {
LAB_1408c1005:
                                        if ((-1 < (int)*plVar9) &&
                                           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                          (**(code **)(plVar9[1] + 0x30))(plVar9);
                                        }
                                        iVar4 = (int)*plVar18;
                                        iVar3 = iVar4 + 1;
                                        if (iVar3 != 0) {
                                          *(int *)plVar18 = iVar3;
                                          iVar4 = iVar3;
                                        }
                                        plStack_b0 = plVar18;
                                        if ((-1 < iVar4) &&
                                           (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                          (**(code **)(plVar18[1] + 0x30))(plVar18);
                                        }
                                        iVar4 = (int)*plVar8;
                                        iVar3 = iVar4 + 1;
                                        if (iVar3 != 0) {
                                          *(int *)plVar8 = iVar3;
                                          iVar4 = iVar3;
                                        }
                                        plStack_100 = plVar8;
                                        if ((-1 < iVar4) && (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                        {
                                          (**(code **)(plVar8[1] + 0x30))(plVar8);
                                        }
                                        plVar7 = plVar8;
                                        if (*(longlong *)(*(longlong *)(puStack_d8 + 0xe8) + 0x10)
                                            == 0) {
                                          FUN_142cd4880(tstate,&plStack_118,classes_const_1799__np);
                                          FUN_1400048d0(tstate,plStack_118);
                                          uVar16 = 0x2154;
                                          plVar18 = plStack_f8;
                                          plVar9 = plStack_108;
                                          plVar5 = plStack_118;
                                        }
                                        else {
                                          plVar9 = (longlong *)
                                                   FUN_142cd7b20(tstate,*(longlong *)
                                                                         (*(longlong *)
                                                                           (puStack_d8 + 0xe8) +
                                                                         0x10),
                                                                 classes_const_1837_where);
                                          if (plVar9 == (longlong *)0x0) {
                                            plVar5 = *(longlong **)(tstate + 0x70);
                                            uVar16 = 0x2154;
                                            *(undefined8 *)(tstate + 0x70) = 0;
                                            plVar18 = plStack_f8;
                                            plVar9 = plStack_108;
                                          }
                                          else {
                                            plVar18 = (longlong *)
                                                      FUN_142ce1890(plVar8,_DAT_142d9a260);
                                            if (plVar18 == (longlong *)0x0) {
                                              plStack_118 = *(longlong **)(tstate + 0x70);
                                              *(undefined8 *)(tstate + 0x70) = 0;
                                              if ((-1 < (int)*plVar9) &&
                                                 (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                                              }
                                              uVar16 = 0x2154;
                                              plVar18 = plStack_f8;
                                              plVar9 = plStack_108;
                                              plVar5 = plStack_118;
                                            }
                                            else {
                                              uVar16 = 0x2154;
                                              *(undefined4 *)(plStack_108 + 5) = 0x2154;
                                              plVar5 = (longlong *)
                                                       FUN_142ccfd60(tstate,plVar9,plVar18);
                                              if ((-1 < (int)*plVar9) &&
                                                 (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                                              }
                                              if ((-1 < (int)*plVar18) &&
                                                 (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                (**(code **)(plVar18[1] + 0x30))(plVar18);
                                              }
                                              if (plVar5 == (longlong *)0x0) {
                                                plVar5 = *(longlong **)(tstate + 0x70);
                                                *(undefined8 *)(tstate + 0x70) = 0;
                                                plVar18 = plStack_f8;
                                                plVar9 = plStack_108;
                                              }
                                              else {
                                                plVar9 = (longlong *)FUN_1400099f0(plVar5);
                                                if ((-1 < (int)*plVar5) &&
                                                   (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
                                                  (**(code **)(plVar5[1] + 0x30))(plVar5);
                                                }
                                                if (plVar9 == (longlong *)0x0) {
                                                  plVar5 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  plVar18 = plStack_f8;
                                                  plVar9 = plStack_108;
                                                }
                                                else {
                                                  plVar18 = (longlong *)0x0;
                                                  plVar5 = (longlong *)0x0;
                                                  plVar7 = (longlong *)
                                                           (**(code **)(plVar9[1] + 0xe0))(plVar9);
                                                  plVar6 = plVar5;
                                                  if (plVar7 == (longlong *)0x0) {
                                                    plVar7 = (longlong *)0x0;
                                                    if ((*(longlong *)(tstate + 0x70) != 0) &&
                                                       (lVar10 = *(longlong *)
                                                                  (*(longlong *)(tstate + 0x70) + 8)
                                                       , lVar10 != 0)) {
                                                      lVar14 = *(longlong *)(lVar10 + 8);
                                                      if ((*(uint *)(*(longlong *)(lVar10 + 8) +
                                                                    0xa8) & 0x40000000) == 0) {
                                                        lVar14 = lVar10;
                                                      }
                                                      if ((lVar14 != *(longlong *)
                                                                      PyExc_StopIteration_exref) &&
                                                         (((-1 < *(int *)(*(longlong *)(lVar14 + 8)
                                                                         + 0xa8) ||
                                                           ((*(uint *)(lVar14 + 0xa8) & 0x40000000)
                                                            == 0)) ||
                                                          (cVar2 = Nuitka_helper_142cdd950(),
                                                          cVar2 != '\x01')))) {
                                                        plVar15 = *(longlong **)(tstate + 0x70);
                                                        *(undefined8 *)(tstate + 0x70) = 0;
                                                        plVar6 = plVar18;
                                                        plVar7 = plVar18;
                                                        goto LAB_1408c1963;
                                                      }
                                                      plVar18 = *(longlong **)(tstate + 0x70);
                                                      *(undefined8 *)(tstate + 0x70) = 0;
                                                      if (((plVar18 != (longlong *)0x0) &&
                                                          (-1 < (int)*plVar18)) &&
                                                         (*plVar18 = *plVar18 + -1, *plVar18 == 0))
                                                      {
                                                        (**(code **)(plVar18[1] + 0x30))();
                                                      }
                                                    }
                                                    plVar18 = (longlong *)
                                                              PyUnicode_FromFormat
                                                                        (&UNK_142d0b0b0,2,0);
                                                    plStack_118 = (longlong *)
                                                                  FUN_142ccfd60(tstate,*(undefined8
                                                                                         *)
                                                  PyExc_ValueError_exref,plVar18);
                                                  plVar15 = plStack_118;
                                                  if ((-1 < (int)*plVar18) &&
                                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                    plVar15 = plStack_118;
                                                  }
                                                  }
                                                  else {
                                                    plVar6 = (longlong *)
                                                             (**(code **)(plVar9[1] + 0xe0))(plVar9)
                                                    ;
                                                    if (plVar6 == (longlong *)0x0) {
                                                      if ((*(longlong *)(tstate + 0x70) != 0) &&
                                                         (lVar10 = *(longlong *)
                                                                    (*(longlong *)(tstate + 0x70) +
                                                                    8), lVar10 != 0)) {
                                                        lVar14 = *(longlong *)(lVar10 + 8);
                                                        if ((*(uint *)(*(longlong *)(lVar10 + 8) +
                                                                      0xa8) & 0x40000000) == 0) {
                                                          lVar14 = lVar10;
                                                        }
                                                        if ((lVar14 != *(longlong *)
                                                                        PyExc_StopIteration_exref)
                                                           && (((-1 < *(int *)(*(longlong *)
                                                                                (lVar14 + 8) + 0xa8)
                                                                || ((*(uint *)(lVar14 + 0xa8) &
                                                                    0x40000000) == 0)) ||
                                                               (cVar2 = Nuitka_helper_142cdd950(),
                                                               cVar2 != '\x01')))) {
                                                          plVar15 = *(longlong **)(tstate + 0x70);
                                                          *(undefined8 *)(tstate + 0x70) = 0;
                                                          plVar8 = plStack_100;
                                                          plVar6 = plVar18;
                                                          goto LAB_1408c1963;
                                                        }
                                                        plVar18 = *(longlong **)(tstate + 0x70);
                                                        *(undefined8 *)(tstate + 0x70) = 0;
                                                        if (((plVar18 != (longlong *)0x0) &&
                                                            (-1 < (int)*plVar18)) &&
                                                           (*plVar18 = *plVar18 + -1, *plVar18 == 0)
                                                           ) {
                                                          (**(code **)(plVar18[1] + 0x30))();
                                                        }
                                                      }
                                                      plVar18 = (longlong *)
                                                                PyUnicode_FromFormat
                                                                          (&UNK_142d0b0b0,2,1);
                                                      plStack_118 = (longlong *)
                                                                    FUN_142ccfd60(tstate,*(
                                                  undefined8 *)PyExc_ValueError_exref,plVar18);
                                                  plVar8 = plStack_100;
                                                  plVar6 = plVar5;
                                                  plVar15 = plStack_118;
                                                  if ((-1 < (int)*plVar18) &&
                                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                    plVar8 = plStack_100;
                                                    plVar15 = plStack_118;
                                                  }
                                                  }
                                                  else {
                                                    plVar18 = (longlong *)
                                                              (**(code **)(plVar9[1] + 0xe0))
                                                                        (plVar9);
                                                    if (plVar18 == (longlong *)0x0) {
                                                      if ((*(longlong *)(tstate + 0x70) != 0) &&
                                                         (lVar10 = *(longlong *)
                                                                    (*(longlong *)(tstate + 0x70) +
                                                                    8), lVar10 != 0)) {
                                                        lVar14 = *(longlong *)(lVar10 + 8);
                                                        if ((*(uint *)(*(longlong *)(lVar10 + 8) +
                                                                      0xa8) & 0x40000000) == 0) {
                                                          lVar14 = lVar10;
                                                        }
                                                        if (lVar14 != *(longlong *)
                                                                       PyExc_StopIteration_exref) {
                                                          if ((*(int *)(*(longlong *)(lVar14 + 8) +
                                                                       0xa8) < 0) &&
                                                             ((*(uint *)(lVar14 + 0xa8) & 0x40000000
                                                              ) != 0)) {
                                                            cVar2 = Nuitka_helper_142cdd950
                                                                              (lVar14,*(longlong *)
                                                                                                                                                                              
                                                  PyExc_StopIteration_exref);
                                                  plVar15 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  plVar8 = plStack_100;
                                                  if (cVar2 == '\x01') {
                                                    if (plVar15 == (longlong *)0x0)
                                                    goto LAB_1408c1490;
                                                    goto LAB_1408c147f;
                                                  }
                                                  }
                                                  else {
                                                    plVar15 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    plVar8 = plStack_100;
                                                  }
                                                  goto LAB_1408c1963;
                                                  }
                                                  plVar15 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408c147f:
                                                  if ((-1 < (int)*plVar15) &&
                                                     (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                                                    (**(code **)(plVar15[1] + 0x30))();
                                                  }
                                                  }
LAB_1408c1490:
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  iVar4 = (int)*plVar7;
                                                  iVar3 = iVar4 + 1;
                                                  if (iVar3 != 0) {
                                                    *(int *)plVar7 = iVar3;
                                                    iVar4 = iVar3;
                                                  }
                                                  plStack_c8 = plVar7;
                                                  if ((-1 < iVar4) &&
                                                     (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                  }
                                                  iVar4 = (int)*plVar6;
                                                  iVar3 = iVar4 + 1;
                                                  if (iVar3 != 0) {
                                                    *(int *)plVar6 = iVar3;
                                                    iVar4 = iVar3;
                                                  }
                                                  plStack_f8 = plVar6;
                                                  if ((-1 < iVar4) &&
                                                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                  }
                                                  plVar9 = (longlong *)FUN_142cc1f90(tstate,plVar6);
                                                  plVar18 = plVar6;
                                                  if (plVar9 == (longlong *)0x0) {
                                                    plVar5 = *(longlong **)(tstate + 0x70);
                                                    uVar16 = 0x2155;
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    plVar7 = plStack_100;
                                                    plVar9 = plStack_108;
                                                  }
                                                  else {
                                                    cVar2 = Nuitka_helper_142cdee20(plVar9,0);
                                                    if ((-1 < (int)*plVar9) &&
                                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                    }
                                                    plVar9 = plStack_108;
                                                    if (cVar2 != '\0') {
                                                      pcVar11 = pcStack_d0;
                                                      if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                                                        *(int *)_Py_NoneStruct_exref =
                                                             *(int *)_Py_NoneStruct_exref + 1;
                                                      }
LAB_1408c1822:
                                                      FUN_140008990(tstate);
                                                      if ((-1 < *(int *)pcVar11) &&
                                                         (*(longlong *)pcVar11 =
                                                               *(longlong *)pcVar11 + -1,
                                                         *(longlong *)pcVar11 == 0)) {
                                                        (**(code **)(*(longlong *)(pcVar11 + 8) +
                                                                    0x30))(pcVar11);
                                                      }
                                                      if (((plStack_c0 != (longlong *)0x0) &&
                                                          (-1 < (int)*plStack_c0)) &&
                                                         (*plStack_c0 = *plStack_c0 + -1,
                                                         *plStack_c0 == 0)) {
                                                        (**(code **)(plStack_c0[1] + 0x30))();
                                                      }
                                                      if (((plStack_b8 != (longlong *)0x0) &&
                                                          (-1 < (int)*plStack_b8)) &&
                                                         (*plStack_b8 = *plStack_b8 + -1,
                                                         *plStack_b8 == 0)) {
                                                        (**(code **)(plStack_b8[1] + 0x30))();
                                                      }
                                                      if (((plStack_b0 != (longlong *)0x0) &&
                                                          (-1 < (int)*plStack_b0)) &&
                                                         (*plStack_b0 = *plStack_b0 + -1,
                                                         *plStack_b0 == 0)) {
                                                        (**(code **)(plStack_b0[1] + 0x30))();
                                                      }
                                                      if (((plStack_100 != (longlong *)0x0) &&
                                                          (-1 < (int)*plStack_100)) &&
                                                         (*plStack_100 = *plStack_100 + -1,
                                                         *plStack_100 == 0)) {
                                                        (**(code **)(plStack_100[1] + 0x30))();
                                                      }
                                                      if (((plVar7 != (longlong *)0x0) &&
                                                          (-1 < (int)*plVar7)) &&
                                                         (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                        (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                      }
                                                      if (((plVar6 != (longlong *)0x0) &&
                                                          (-1 < (int)*plVar6)) &&
                                                         (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                        (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                      }
                                                      if ((-1 < (int)*plStack_a8) &&
                                                         (*plStack_a8 = *plStack_a8 + -1,
                                                         *plStack_a8 == 0)) {
                                                        (**(code **)(plStack_a8[1] + 0x30))();
                                                      }
                                                      goto LAB_1408c1cab;
                                                    }
                                                    uVar16 = 0x2157;
                                                    *(undefined4 *)(plStack_108 + 5) = 0x2157;
                                                    plVar8 = (longlong *)
                                                             FUN_142cd06a0(tstate,plVar7,
                                                                           classes_const_612_min);
                                                    if (plVar8 == (longlong *)0x0) {
                                                      plVar5 = *(longlong **)(tstate + 0x70);
                                                      *(undefined8 *)(tstate + 0x70) = 0;
                                                      plVar7 = plStack_100;
                                                    }
                                                    else {
                                                      *(undefined4 *)(plVar9 + 5) = 0x2157;
                                                      plVar9 = (longlong *)
                                                               FUN_142cd06a0(tstate,plVar7,
                                                                             classes_const_228_max);
                                                      if (plVar9 != (longlong *)0x0) {
                                                        plVar7 = (longlong *)
                                                                 FUN_142cbe6d0(plVar9,_DAT_142d9a268
                                                                              );
                                                        if ((-1 < (int)*plVar9) &&
                                                           (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                          (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                        }
                                                        if (plVar7 != (longlong *)0x0) {
                                                          lVar10 = FUN_142cdd880(tstate,plVar8,
                                                                                 plVar7,
                                                  _Py_NoneStruct_exref);
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                  }
                                                  if ((-1 < (int)*plVar7) &&
                                                     (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                  }
                                                  plVar8 = (longlong *)FUN_142cd9440(tstate,2);
                                                  plVar9 = plStack_108;
                                                  plVar8[3] = lVar10;
                                                  *(undefined4 *)(plStack_108 + 5) = 0x2157;
                                                  plVar18 = (longlong *)
                                                            FUN_142cd06a0(tstate,plVar6,
                                                                          classes_const_612_min);
                                                  if (plVar18 == (longlong *)0x0) {
                                                    plStack_118 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                  }
                                                  else {
                                                    *(undefined4 *)(plVar9 + 5) = 0x2157;
                                                    plVar9 = (longlong *)
                                                             FUN_142cd06a0(tstate,plVar6,
                                                                           classes_const_228_max);
                                                    if (plVar9 != (longlong *)0x0) {
                                                      plVar7 = (longlong *)
                                                               FUN_142cbe6d0(plVar9,_DAT_142d9a268);
                                                      if ((-1 < (int)*plVar9) &&
                                                         (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                        (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                      }
                                                      if (plVar7 != (longlong *)0x0) {
                                                        lVar10 = FUN_142cdd880(tstate,plVar18,plVar7
                                                                               ,_Py_NoneStruct_exref
                                                                              );
                                                        if ((-1 < (int)*plVar18) &&
                                                           (*plVar18 = *plVar18 + -1, *plVar18 == 0)
                                                           ) {
                                                          (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                        }
                                                        if ((-1 < (int)*plVar7) &&
                                                           (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                          (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                        }
                                                        plVar8[4] = lVar10;
                                                        lVar10 = FUN_140008da0(tstate,plStack_110,
                                                                               plVar8);
                                                        if ((-1 < (int)*plVar8) &&
                                                           (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                          (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                        }
                                                        pcVar11 = pcStack_d0;
                                                        plVar6 = plStack_f8;
                                                        plVar7 = plStack_c8;
                                                        if (lVar10 != 0) goto LAB_1408c1822;
                                                        plVar5 = *(longlong **)(tstate + 0x70);
                                                        *(undefined8 *)(tstate + 0x70) = 0;
                                                        plVar7 = plStack_100;
                                                        plVar18 = plStack_f8;
                                                        plVar9 = plStack_108;
                                                        goto LAB_1408c175c;
                                                      }
                                                    }
                                                    plStack_118 = *(longlong **)(tstate + 0x70);
                                                    *(undefined8 *)(tstate + 0x70) = 0;
                                                    plVar9 = plStack_108;
                                                    if ((-1 < (int)*plVar18) &&
                                                       (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                      (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                      plVar9 = plStack_108;
                                                    }
                                                  }
                                                  plVar7 = plStack_100;
                                                  plVar18 = plStack_f8;
                                                  plVar5 = plStack_118;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, plVar7 = plStack_100,
                                                     *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    plVar7 = plStack_100;
                                                    plVar18 = plStack_f8;
                                                    plVar5 = plStack_118;
                                                  }
                                                  goto LAB_1408c175c;
                                                  }
                                                  }
                                                  plStack_118 = *(longlong **)(tstate + 0x70);
                                                  *(undefined8 *)(tstate + 0x70) = 0;
                                                  plVar7 = plStack_100;
                                                  plVar9 = plStack_108;
                                                  plVar5 = plStack_118;
                                                  if ((-1 < (int)*plVar8) &&
                                                     (*plVar8 = *plVar8 + -1, plVar7 = plStack_100,
                                                     *plVar8 == 0)) {
                                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                                    plVar7 = plStack_100;
                                                    plVar9 = plStack_108;
                                                    plVar5 = plStack_118;
                                                  }
                                                  }
                                                  }
                                                  goto LAB_1408c175c;
                                                  }
                                                  if ((-1 < (int)*plVar18) &&
                                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                  }
                                                  plVar18 = (longlong *)
                                                            PyUnicode_FromFormat(&UNK_142d0b0e8,2);
                                                  plStack_118 = (longlong *)
                                                                FUN_142ccfd60(tstate,*(undefined8 *)
                                                                                                                                                                            
                                                  PyExc_ValueError_exref,plVar18);
                                                  plVar8 = plStack_100;
                                                  plVar15 = plStack_118;
                                                  if ((-1 < (int)*plVar18) &&
                                                     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                                    (**(code **)(plVar18[1] + 0x30))(plVar18);
                                                    plVar8 = plStack_100;
                                                    plVar15 = plStack_118;
                                                  }
                                                  }
                                                  }
LAB_1408c1963:
                                                  plStack_118 = plVar15;
                                                  plVar5 = plStack_118;
                                                  if ((-1 < (int)*plVar9) &&
                                                     (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                                    (**(code **)(plVar9[1] + 0x30))(plVar9);
                                                  }
                                                  if (((plVar7 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar7)) &&
                                                     (*plVar7 = *plVar7 + -1, *plVar7 == 0)) {
                                                    (**(code **)(plVar7[1] + 0x30))(plVar7);
                                                  }
                                                  plVar7 = plVar8;
                                                  plVar18 = plStack_f8;
                                                  plVar9 = plStack_108;
                                                  if (((plVar6 != (longlong *)0x0) &&
                                                      (-1 < (int)*plVar6)) &&
                                                     (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                                    (**(code **)(plVar6[1] + 0x30))(plVar6);
                                                    plVar18 = plStack_f8;
                                                    plVar9 = plStack_108;
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                        goto LAB_1408c175c;
                                      }
                                      lVar14 = *(longlong *)(lVar10 + 8);
                                      if ((*(uint *)(*(longlong *)(lVar10 + 8) + 0xa8) & 0x40000000)
                                          == 0) {
                                        lVar14 = lVar10;
                                      }
                                      if (lVar14 == *(longlong *)PyExc_StopIteration_exref) {
                                        plVar6 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408c0ff4:
                                        if ((-1 < (int)*plVar6) &&
                                           (*plVar6 = *plVar6 + -1, *plVar6 == 0)) {
                                          (**(code **)(plVar6[1] + 0x30))();
                                        }
                                        goto LAB_1408c1005;
                                      }
                                      if ((*(int *)(*(longlong *)(lVar14 + 8) + 0xa8) < 0) &&
                                         ((*(uint *)(lVar14 + 0xa8) & 0x40000000) != 0)) {
                                        cVar2 = Nuitka_helper_142cdd950
                                                          (lVar14,*(longlong *)
                                                                   PyExc_StopIteration_exref);
                                        plVar6 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        if (cVar2 == '\x01') {
                                          if (plVar6 == (longlong *)0x0) goto LAB_1408c1005;
                                          goto LAB_1408c0ff4;
                                        }
                                      }
                                      else {
                                        plVar6 = *(longlong **)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                      }
                                    }
LAB_1408c1a21:
                                    plStack_118 = plVar6;
                                    plVar5 = plStack_118;
                                    if ((-1 < (int)*plVar9) &&
                                       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                                    }
                                    if (((plVar18 != (longlong *)0x0) && (-1 < (int)*plVar18)) &&
                                       (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                                      (**(code **)(plVar18[1] + 0x30))(plVar18);
                                    }
                                    plVar7 = plStack_f8;
                                    plVar18 = plStack_f8;
                                    plVar9 = plStack_108;
                                    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                                       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                                      plVar7 = plStack_f8;
                                      plVar18 = plStack_f8;
                                      plVar9 = plStack_108;
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    goto LAB_1408c175c;
                  }
                  plVar9 = (longlong *)
                           FUN_140008da0(tstate,pcVar11,
                                         classes_const_1831___type____T____items______type_________items____None__None__None_
                                        );
                  if (plVar9 != (longlong *)0x0) {
                    plVar18 = (longlong *)FUN_142ce2520(plVar9,classes_const_1278_80);
                    if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                      (**(code **)(plVar9[1] + 0x30))(plVar9);
                    }
                    if (plVar18 != (longlong *)0x0) {
                      cVar2 = FUN_140029450(tstate,plVar5,plVar18,puVar13);
                      if ((-1 < (int)*plVar18) && (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
                        (**(code **)(plVar18[1] + 0x30))(plVar18);
                      }
                      plVar18 = plStack_c0;
                      if (cVar2 != '\0') goto LAB_1408c090b;
                    }
                  }
                  uVar16 = 0x2150;
                }
LAB_1408c07f7:
                plVar5 = *(longlong **)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                plVar7 = plStack_f8;
                plVar18 = plStack_f8;
                plVar9 = plStack_108;
                goto LAB_1408c175c;
              }
            }
          }
        }
LAB_1408c0540:
        plVar5 = *(longlong **)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        plVar7 = plStack_f8;
        plVar18 = plStack_f8;
      }
    }
  }
LAB_1408c175c:
  plStack_118 = plVar5;
  piVar1 = (int *)plStack_118[5];
  if (piVar1 == (int *)0x0) {
    pcVar11 = (code *)FUN_142cd9160(plVar9,uVar16);
    bVar19 = pcVar11 == _Py_NoneStruct_exref;
LAB_1408c1ab4:
    plVar5 = (longlong *)plStack_118[5];
    if (bVar19) {
      pcVar12 = (code *)0x0;
    }
    else {
      pcVar12 = pcVar11;
      if ((pcVar11 != (code *)0x0) && (*(int *)pcVar11 + 1 != 0)) {
        *(int *)pcVar11 = *(int *)pcVar11 + 1;
      }
    }
    plStack_118[5] = (longlong)pcVar12;
    if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
       (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))();
    }
    if (((pcVar11 != (code *)0x0) && (-1 < *(int *)pcVar11)) &&
       (*(longlong *)pcVar11 = *(longlong *)pcVar11 + -1, *(longlong *)pcVar11 == 0)) {
      (**(code **)(*(longlong *)(pcVar11 + 8) + 0x30))(pcVar11);
    }
  }
  else if (*(longlong **)(piVar1 + 6) != plVar9) {
    pcVar11 = (code *)FUN_142cd9160(plVar9,uVar16);
    *(int **)(pcVar11 + 0x10) = piVar1;
    if (*piVar1 + 1 != 0) {
      *piVar1 = *piVar1 + 1;
    }
    bVar19 = pcVar11 == _Py_NoneStruct_exref;
    goto LAB_1408c1ab4;
  }
  plVar8 = plStack_c0;
  plVar6 = plStack_c8;
  uStack_120 = *(undefined8 *)(puStack_d8 + 0xe8);
  uStack_128 = *(undefined8 *)(puStack_d8 + 0xe0);
  plStack_138 = plStack_c8;
  plStack_148 = plStack_b0;
  plStack_150 = plStack_b8;
  plStack_158 = plStack_c0;
  plStack_140 = plVar7;
  plStack_130 = plVar18;
  FUN_142cdb370(plVar9,&UNK_142d0d460,plStack_a8,pcStack_a0);
  plVar5 = _DAT_142dea758;
  if (plVar9 == _DAT_142dea758) {
    if ((-1 < (int)*_DAT_142dea758) && (*_DAT_142dea758 = *_DAT_142dea758 + -1, *plVar5 == 0)) {
      (**(code **)(plVar5[1] + 0x30))();
    }
    _DAT_142dea758 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  plVar9 = plStack_118;
  plStack_118 = (longlong *)0x0;
  if (((pcStack_a0 != (code *)0x0) && (-1 < *(int *)pcStack_a0)) &&
     (*(longlong *)pcStack_a0 = *(longlong *)pcStack_a0 + -1, *(longlong *)pcStack_a0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_a0 + 8) + 0x30))();
  }
  if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)
     ) {
    (**(code **)(plVar8[1] + 0x30))(plVar8);
  }
  if (((plStack_b8 != (longlong *)0x0) && (-1 < (int)*plStack_b8)) &&
     (*plStack_b8 = *plStack_b8 + -1, *plStack_b8 == 0)) {
    (**(code **)(plStack_b8[1] + 0x30))();
  }
  if (((plStack_b0 != (longlong *)0x0) && (-1 < (int)*plStack_b0)) &&
     (*plStack_b0 = *plStack_b0 + -1, *plStack_b0 == 0)) {
    (**(code **)(plStack_b0[1] + 0x30))();
  }
  if (((plVar7 != (longlong *)0x0) && (-1 < (int)*plVar7)) && (*plVar7 = *plVar7 + -1, *plVar7 == 0)
     ) {
    (**(code **)(plVar7[1] + 0x30))(plVar7);
  }
  if (((plVar6 != (longlong *)0x0) && (-1 < (int)*plVar6)) && (*plVar6 = *plVar6 + -1, *plVar6 == 0)
     ) {
    (**(code **)(plVar6[1] + 0x30))(plVar6);
  }
  if (((plVar18 != (longlong *)0x0) && (-1 < (int)*plVar18)) &&
     (*plVar18 = *plVar18 + -1, *plVar18 == 0)) {
    (**(code **)(plVar18[1] + 0x30))(plVar18);
  }
  plStack_118 = plVar9;
  if ((-1 < (int)*plStack_a8) && (*plStack_a8 = *plStack_a8 + -1, *plStack_a8 == 0)) {
    (**(code **)(plStack_a8[1] + 0x30))();
  }
  plVar9 = *(longlong **)(tstate + 0x70);
  *(longlong **)(tstate + 0x70) = plStack_118;
  if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)
     ) {
    (**(code **)(plVar9[1] + 0x30))();
  }
LAB_1408c1cab:
  puVar13 = (undefined *)FUN_142cfc380(uStack_48 ^ (ulonglong)auStack_178);
  return puVar13;
}

