
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _achar_figuras_na_foto(undefined *tstate,undefined *self,undefined **python_pars)

{
  int *piVar1;
  undefined8 uVar2;
  undefined *puVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  code *pcVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong lVar17;
  code *pcVar18;
  undefined *puVar19;
  code *pcVar20;
  longlong *plVar21;
  undefined4 uVar22;
  bool bVar23;
  undefined1 auStack_478 [32];
  code *pcStack_458;
  longlong *plStack_450;
  longlong *plStack_448;
  longlong *plStack_440;
  longlong *plStack_438;
  longlong **pplStack_430;
  code *pcStack_428;
  longlong *plStack_420;
  code *pcStack_418;
  longlong *plStack_410;
  code *pcStack_408;
  code *pcStack_400;
  longlong *plStack_3f8;
  longlong *plStack_3f0;
  longlong *plStack_3e8;
  longlong *plStack_3e0;
  longlong *plStack_3d8;
  longlong *plStack_3d0;
  code *pcStack_3c8;
  longlong *plStack_3c0;
  longlong *plStack_3b8;
  longlong *plStack_3b0;
  longlong *plStack_3a8;
  longlong *plStack_3a0;
  longlong *plStack_398;
  longlong *plStack_390;
  longlong *plStack_388;
  code *pcStack_380;
  longlong *plStack_378;
  code *pcStack_370;
  longlong *plStack_368;
  code *pcStack_360;
  longlong *plStack_358;
  longlong *plStack_350;
  longlong *plStack_348;
  longlong *plStack_340;
  longlong *plStack_338;
  longlong *plStack_330;
  longlong *plStack_328;
  longlong *plStack_320;
  longlong lStack_318;
  undefined4 uStack_310;
  longlong *plStack_308;
  longlong *plStack_300;
  longlong *plStack_2f8;
  undefined *puStack_2f0;
  longlong *plStack_2e8;
  longlong *plStack_2e0;
  longlong *plStack_2d8;
  longlong *plStack_2d0;
  code *pcStack_2c8;
  longlong *plStack_2c0;
  longlong *plStack_2b8;
  longlong *plStack_2b0;
  code *pcStack_2a8;
  code *pcStack_2a0;
  longlong *plStack_298;
  longlong *plStack_290;
  longlong *plStack_288;
  code *pcStack_280;
  longlong *plStack_278;
  longlong *plStack_270;
  code *pcStack_268;
  longlong *plStack_260;
  code *pcStack_258;
  longlong *plStack_250;
  longlong *plStack_248;
  longlong *plStack_240;
  longlong *plStack_238;
  longlong *plStack_230;
  code *pcStack_228;
  longlong *plStack_220;
  longlong *plStack_218;
  longlong *plStack_210;
  longlong *plStack_208;
  longlong *plStack_200;
  longlong *plStack_1f8;
  longlong *plStack_1f0;
  longlong *plStack_1e8;
  longlong *plStack_1e0;
  longlong *plStack_1d8;
  code *pcStack_1d0;
  longlong *plStack_1c8;
  longlong *plStack_1c0;
  longlong *plStack_1b8;
  code *pcStack_1b0;
  longlong *plStack_1a8;
  longlong *plStack_1a0;
  longlong *plStack_198;
  longlong *plStack_190;
  longlong *plStack_188;
  longlong *plStack_180;
  longlong *plStack_178;
  code *pcStack_170;
  longlong **pplStack_168;
  longlong *plStack_160;
  longlong *plStack_158;
  longlong *plStack_150;
  longlong *plStack_148;
  code *pcStack_140;
  longlong *plStack_138;
  longlong *plStack_130;
  longlong *plStack_128;
  longlong *plStack_120;
  longlong *plStack_118;
  longlong *plStack_110;
  longlong *plStack_108;
  longlong *plStack_100;
  longlong *plStack_f8;
  code *pcStack_f0;
  longlong *plStack_e8;
  code *pcStack_e0;
  code *pcStack_d8;
  longlong *plStack_d0;
  longlong *plStack_c8;
  undefined *puStack_c0;
  longlong *plStack_b8;
  longlong *plStack_b0;
  longlong *plStack_a8;
  longlong *plStack_a0;
  longlong *plStack_98;
  longlong *plStack_90;
  longlong *plStack_88;
  undefined *puStack_80;
  longlong *plStack_78;
  longlong *plStack_70;
  longlong *plStack_68;
  undefined *puStack_60;
  undefined *puStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_142d9a1c0 ^ (ulonglong)auStack_478;
  plStack_138 = (longlong *)*python_pars;
  plStack_148 = (longlong *)python_pars[1];
  pcStack_140 = (code *)python_pars[2];
  puStack_2f0 = tstate;
  plVar8 = (longlong *)FUN_142cdae50();
  plStack_198 = plVar8;
  plVar9 = (longlong *)FUN_142cdae50();
  plVar13 = _DAT_142dea748;
  pcVar14 = (code *)0x0;
  pcVar20 = (code *)0x0;
  lStack_318 = 0;
  plStack_178 = (longlong *)0x0;
  plStack_1a0 = (longlong *)0x0;
  pplStack_168 = (longlong **)0x0;
  pcStack_258 = (code *)0x0;
  plStack_158 = (longlong *)0x0;
  pcStack_2c8 = (code *)0x0;
  plStack_208 = (longlong *)0x0;
  pcStack_1d0 = (code *)0x0;
  pcStack_280 = (code *)0x0;
  plStack_200 = (longlong *)0x0;
  plStack_1c8 = (longlong *)0x0;
  plStack_210 = (longlong *)0x0;
  plStack_240 = (longlong *)0x0;
  plStack_238 = (longlong *)0x0;
  plStack_230 = (longlong *)0x0;
  pcStack_228 = (code *)0x0;
  plStack_220 = (longlong *)0x0;
  plStack_250 = (longlong *)0x0;
  plStack_1c0 = (longlong *)0x0;
  plStack_248 = (longlong *)0x0;
  plStack_218 = (longlong *)0x0;
  plStack_1f8 = (longlong *)0x0;
  plStack_1f0 = (longlong *)0x0;
  plStack_150 = (longlong *)0x0;
  pcStack_2a0 = (code *)0x0;
  plStack_1e8 = (longlong *)0x0;
  pcStack_2a8 = (code *)0x0;
  plStack_290 = (longlong *)0x0;
  pcStack_268 = (code *)0x0;
  plStack_1e0 = (longlong *)0x0;
  plStack_1d8 = (longlong *)0x0;
  plStack_278 = (longlong *)0x0;
  plStack_160 = (longlong *)0x0;
  plStack_180 = (longlong *)0x0;
  plStack_1b8 = (longlong *)0x0;
  plStack_190 = (longlong *)0x0;
  plStack_188 = (longlong *)0x0;
  plStack_2d8 = _DAT_142dea748;
  plStack_2d0 = plVar9;
  if (_DAT_142dea748 == (longlong *)0x0) {
LAB_1408ba59d:
    _DAT_142dea748 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9958,_DAT_142f2aaf0,0x150);
  }
  else if ((1 < *_DAT_142dea748) || (_DAT_142dea748[2] != 0)) {
    if ((_DAT_142dea748 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea748 && (*_DAT_142dea748 = *_DAT_142dea748 + -1, *plVar13 == 0)))) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    goto LAB_1408ba59d;
  }
  plVar13 = _DAT_142dea748;
  plStack_2d8 = _DAT_142dea748;
  Nuitka_helper_140008a00(tstate,_DAT_142dea748);
  uVar2 = _DAT_142f2aae8;
  puVar19 = classes_const_1774_numpy;
  plStack_450 = _DAT_142d9a260;
  pcStack_458 = _Py_NoneStruct_exref;
  *(undefined4 *)(plVar13 + 5) = 0x213c;
  lVar10 = FUN_142cd5880(tstate,puVar19,uVar2);
  if (lVar10 == 0) {
    lVar10 = *(longlong *)(tstate + 0x70);
    *(undefined8 *)(tstate + 0x70) = 0;
    uVar22 = 0x213c;
  }
  else {
    plVar8[2] = lVar10;
    uVar2 = _DAT_142f2aae8;
    puVar19 = classes_const_1775_cv2;
    plStack_450 = _DAT_142d9a260;
    pcStack_458 = _Py_NoneStruct_exref;
    *(undefined4 *)(plVar13 + 5) = 0x213d;
    lVar10 = FUN_142cd5880(tstate,puVar19,uVar2);
    if (lVar10 == 0) {
      lVar10 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      uVar22 = 0x213d;
    }
    else {
      plVar9[2] = lVar10;
      uVar2 = _DAT_142f2aae8;
      puVar19 = classes_const_1776_itertools;
      plStack_450 = _DAT_142d9a260;
      pcStack_458 = _Py_NoneStruct_exref;
      *(undefined4 *)(plVar13 + 5) = 0x213e;
      plStack_300 = (longlong *)FUN_142cd5880(tstate,puVar19,uVar2);
      if (plStack_300 == (longlong *)0x0) {
        lVar10 = *(longlong *)(tstate + 0x70);
        *(undefined8 *)(tstate + 0x70) = 0;
        pcVar14 = (code *)0x0;
        uVar22 = 0x213e;
      }
      else {
        iVar5 = (int)*plVar9 + 1;
        if (iVar5 != 0) {
          *(int *)plVar9 = iVar5;
        }
        pplStack_430 = &plStack_130;
        pcStack_428 = (code *)0x1;
        plStack_438 = (longlong *)0x0;
        plStack_440 = _DAT_142f2aaf0;
        plStack_448 = (longlong *)0x0;
        plStack_450 = (longlong *)0x0;
        pcStack_458 = (code *)0x0;
        plStack_178 = plStack_300;
        plStack_130 = plVar9;
        plStack_1a0 = (longlong *)
                      FUN_142cdb550(_grad,classes_const_1777__grad,
                                    classes_const_1778_Navegacao__achar_figuras_na_foto__locals___grad
                                    ,_DAT_142de9ba0);
        iVar5 = (int)*plVar9 + 1;
        if (iVar5 != 0) {
          *(int *)plVar9 = iVar5;
        }
        iVar5 = (int)*plVar8 + 1;
        if (iVar5 != 0) {
          *(int *)plVar8 = iVar5;
        }
        pplStack_430 = &plStack_120;
        pcStack_428 = (code *)0x2;
        plStack_438 = (longlong *)0x0;
        plStack_440 = _DAT_142f2aaf0;
        plStack_448 = (longlong *)0x0;
        plStack_450 = (longlong *)0x0;
        pcStack_458 = (code *)0x0;
        plStack_120 = plVar9;
        plStack_118 = plVar8;
        pplStack_168 = (longlong **)
                       FUN_142cdb550(_mascara,classes_const_1779__mascara,
                                     classes_const_1780_Navegacao__achar_figuras_na_foto__locals___mascara
                                     ,_DAT_142de9bf0);
        plVar11 = (longlong *)FUN_142cd7b20(tstate,plVar9[2],classes_const_1781_imdecode);
        if (plVar11 == (longlong *)0x0) {
          lVar10 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          pcVar14 = pcVar20;
          uVar22 = 0x2159;
        }
        else {
          plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar8[2],classes_const_1782_frombuffer);
          if (plVar8 == (longlong *)0x0) {
            lStack_318 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
              (**(code **)(plVar11[1] + 0x30))(plVar11);
            }
            pcVar14 = pcVar20;
            uVar22 = 0x2159;
            lVar10 = lStack_318;
          }
          else {
            plVar9 = (longlong *)FUN_142cd7b20(tstate,plStack_198[2],classes_const_1783_uint8);
            if (plVar9 == (longlong *)0x0) {
              lStack_318 = *(longlong *)(tstate + 0x70);
              *(undefined8 *)(tstate + 0x70) = 0;
              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                (**(code **)(plVar11[1] + 0x30))(plVar11);
              }
              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))(plVar8);
              }
              plVar9 = plStack_2d0;
              uVar22 = 0x2159;
              lVar10 = lStack_318;
            }
            else {
              uVar22 = 0x2159;
              *(undefined4 *)(plVar13 + 5) = 0x2159;
              plStack_110 = plStack_148;
              plStack_108 = plVar9;
              plVar12 = (longlong *)FUN_142cc4ec0(tstate,plVar8,&plStack_110);
              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))(plVar8);
              }
              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                (**(code **)(plVar9[1] + 0x30))(plVar9);
              }
              plVar9 = plStack_2d0;
              if (plVar12 == (longlong *)0x0) {
                lStack_318 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                plVar13 = plStack_2d8;
                lVar10 = lStack_318;
                if ((-1 < (int)*plVar11) &&
                   (*plVar11 = *plVar11 + -1, pcVar14 = pcVar20, *plVar11 == 0)) {
                  (**(code **)(plVar11[1] + 0x30))(plVar11);
                  plVar13 = plStack_2d8;
                  plVar9 = plStack_2d0;
                  lVar10 = lStack_318;
                }
              }
              else {
                plVar13 = (longlong *)
                          FUN_142cd7b20(tstate,plStack_2d0[2],classes_const_1784_IMREAD_GRAYSCALE);
                if (plVar13 == (longlong *)0x0) {
                  lStack_318 = *(longlong *)(tstate + 0x70);
                  *(undefined8 *)(tstate + 0x70) = 0;
                  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                    (**(code **)(plVar11[1] + 0x30))(plVar11);
                  }
                  plVar13 = plStack_2d8;
                  pcVar14 = pcVar20;
                  lVar10 = lStack_318;
                  if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                    (**(code **)(plVar12[1] + 0x30))(plVar12);
                    plVar13 = plStack_2d8;
                    lVar10 = lStack_318;
                  }
                }
                else {
                  *(undefined4 *)(plStack_2d8 + 5) = 0x2159;
                  plStack_100 = plVar12;
                  plStack_f8 = plVar13;
                  pcStack_1b0 = (code *)FUN_142cc4ec0(tstate,plVar11,&plStack_100);
                  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                    (**(code **)(plVar11[1] + 0x30))(plVar11);
                  }
                  if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                    (**(code **)(plVar12[1] + 0x30))(plVar12);
                  }
                  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                    (**(code **)(plVar13[1] + 0x30))(plVar13);
                  }
                  plVar13 = plStack_2d8;
                  if (pcStack_1b0 == (code *)0x0) {
                    lVar10 = *(longlong *)(tstate + 0x70);
                    *(undefined8 *)(tstate + 0x70) = 0;
                    pcVar14 = pcVar20;
                  }
                  else {
                    pcStack_258 = pcStack_1b0;
                    if (pcStack_1b0 == _Py_NoneStruct_exref) {
                      pcVar18 = pcVar14;
                      if (*(int *)classes_const_1357___type____T____items____None__None__ + 1 != 0)
                      {
                        *(int *)classes_const_1357___type____T____items____None__None__ =
                             *(int *)classes_const_1357___type____T____items____None__None__ + 1;
                        pcVar14 = (code *)0x0;
                        pcVar18 = pcVar20;
                      }
                      goto LAB_1408bca80;
                    }
                    *(undefined4 *)(plStack_2d8 + 5) = 0x215c;
                    plStack_1a8 = (longlong *)FUN_142ccfd60(tstate,plStack_1a0,pcStack_1b0);
                    if (plStack_1a8 == (longlong *)0x0) {
                      lVar10 = *(longlong *)(tstate + 0x70);
                      *(undefined8 *)(tstate + 0x70) = 0;
                      pcVar14 = pcVar20;
                      uVar22 = 0x215c;
                    }
                    else {
                      plStack_158 = plStack_1a8;
                      pcVar14 = (code *)FUN_142cd8f90(tstate,0);
                      pcStack_2c8 = pcVar14;
                      plStack_270 = (longlong *)FUN_140009850(tstate,pcStack_140);
                      if (plStack_270 == (longlong *)0x0) {
                        lVar10 = *(longlong *)(tstate + 0x70);
                        *(undefined8 *)(tstate + 0x70) = 0;
                        uVar22 = 0x215e;
                      }
                      else {
                        plVar9 = (longlong *)(tstate + 0x70);
                        uStack_310 = 0x216e;
                        plVar8 = (longlong *)0x0;
                        plStack_2f8 = plVar9;
                        plStack_2c0 = plVar9;
                        do {
                          plVar11 = plStack_270;
                          if (*(code **)(plStack_270[1] + 0xe0) == (code *)0x0) {
                            Nuitka_helper_142ce5050(&UNK_142d0adb0,plStack_270);
                            plVar9 = (longlong *)(tstate + 0x70);
                            plStack_2f8 = plVar9;
LAB_1408bcfe8:
                            plVar12 = (longlong *)*plVar9;
                            if (plVar12 != (longlong *)0x0) {
                              cVar4 = FUN_140008d40(tstate,plVar12,
                                                    *(undefined8 *)PyExc_StopIteration_exref);
                              if (cVar4 == '\0') {
                                lVar10 = *plVar9;
                                *plVar9 = 0;
                                uVar22 = 0x215e;
                                lStack_318 = 0;
                                if (plVar8 != (longlong *)0x0) goto LAB_1408bd16d;
                                goto LAB_1408bd183;
                              }
                              *plVar9 = 0;
                              if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0))
                              {
                                (**(code **)(plVar12[1] + 0x30))(plVar12);
                              }
                            }
                            if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                               (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                            }
                            if (pcVar14 == (code *)0x0) {
                              FUN_142cd4900(tstate,&lStack_318,classes_const_1810_picos);
                              FUN_1400048d0(tstate,lStack_318);
                              plVar9 = plStack_2d0;
                              uVar22 = 0x217a;
                              lVar10 = lStack_318;
                              goto LAB_1408bef49;
                            }
                            plVar8 = (longlong *)FUN_142cc1f90(tstate,pcVar14);
                            tstate = puStack_2f0;
                            plStack_2e8 = plVar8;
                            if (plVar8 == (longlong *)0x0) {
                              lVar10 = *plVar9;
                              *plVar9 = 0;
                              plVar9 = plStack_2d0;
                              uVar22 = 0x217a;
                              goto LAB_1408bef49;
                            }
                            pcStack_2a0 = _Py_NoneStruct_exref;
                            if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                              *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                            }
                            plStack_150 = plVar8;
                            plVar13 = (longlong *)
                                      FUN_142cd7b20(puStack_2f0,plStack_178,
                                                    classes_const_1811_product);
                            if (plVar13 == (longlong *)0x0) {
                              lVar10 = *plVar9;
                              *plVar9 = 0;
                              plVar13 = plStack_2d8;
                              plVar9 = plStack_2d0;
                              uVar22 = 0x217c;
                              goto LAB_1408bef49;
                            }
                            uStack_310 = 0x217c;
                            *(undefined4 *)(plStack_2d8 + 5) = 0x217c;
                            pcStack_458 = (code *)
                                          classes_const_1813___type____T____items_____repeat___;
                            plStack_128 = plVar8;
                            plVar11 = (longlong *)
                                      FUN_142ccd5b0(tstate,plVar13,
                                                                                                        
                                                  classes_const_1812___type____T____items______type_________items____0__6__1____
                                                  ,&plStack_128);
                            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                              (**(code **)(plVar13[1] + 0x30))(plVar13);
                            }
                            if (plVar11 == (longlong *)0x0) {
                              lVar10 = *plVar9;
                              *plVar9 = 0;
                              plVar13 = plStack_2d8;
                              plVar9 = plStack_2d0;
                              uVar22 = uStack_310;
                              goto LAB_1408bef49;
                            }
                            plVar12 = (longlong *)FUN_140009850(tstate,plVar11);
                            plStack_2c0 = plVar12;
                            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                            }
                            if (plVar12 == (longlong *)0x0) {
                              lVar10 = *plVar9;
                              *plVar9 = 0;
                              plVar13 = plStack_2d8;
                              pcVar14 = pcStack_2c8;
                              plVar9 = plStack_2d0;
                              uVar22 = uStack_310;
                              goto LAB_1408bef49;
                            }
                            plVar13 = (longlong *)0x0;
                            goto LAB_1408bd2f0;
                          }
                          plVar15 = (longlong *)(**(code **)(plStack_270[1] + 0xe0))(plStack_270);
                          plVar12 = plStack_208;
                          pcVar14 = pcStack_2c8;
                          plStack_308 = plVar15;
                          if (plVar15 == (longlong *)0x0) goto LAB_1408bcfe8;
                          plStack_2b0 = plVar15;
                          if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                             (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                            (**(code **)(plVar8[1] + 0x30))();
                          }
                          iVar5 = (int)*plVar15 + 1;
                          if (iVar5 != 0) {
                            *(int *)plVar15 = iVar5;
                          }
                          plStack_208 = plVar15;
                          if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
                             (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                            (**(code **)(plVar12[1] + 0x30))();
                          }
                          plVar8 = plVar15;
                          if (pplStack_168 == (longlong **)0x0) {
                            FUN_142cd4900(tstate,&lStack_318,classes_const_1779__mascara);
                            FUN_1400048d0(tstate,lStack_318);
                            lVar10 = lStack_318;
                            uVar22 = 0x215f;
                            goto LAB_1408bd16d;
                          }
                          *(undefined4 *)(plVar13 + 5) = 0x215f;
                          pcVar20 = (code *)FUN_142ccfd60(tstate,pplStack_168,plVar15);
                          pcVar14 = pcStack_1d0;
                          pcStack_170 = pcVar20;
                          if (pcVar20 == (code *)0x0) {
                            lVar10 = *(longlong *)(tstate + 0x70);
                            *(undefined8 *)(tstate + 0x70) = 0;
                            plVar13 = plStack_2d8;
                            uVar22 = 0x215f;
                            goto LAB_1408bd16d;
                          }
                          pcVar18 = pcVar20;
                          if (((pcStack_1d0 != (code *)0x0) && (-1 < *(int *)pcStack_1d0)) &&
                             (*(longlong *)pcStack_1d0 = *(longlong *)pcStack_1d0 + -1,
                             *(longlong *)pcStack_1d0 == 0)) {
                            pcVar18 = pcStack_1d0 + 8;
                            pcStack_1d0 = pcVar20;
                            (**(code **)(*(longlong *)pcVar18 + 0x30))(pcVar14);
                            pcVar18 = pcStack_1d0;
                          }
                          pcStack_1d0 = pcVar18;
                          pcVar14 = pcStack_280;
                          if (pcVar20 == _Py_NoneStruct_exref) {
LAB_1408bca2d:
                            if (*(int *)classes_const_1357___type____T____items____None__None__ + 1
                                != 0) {
                              *(int *)classes_const_1357___type____T____items____None__None__ =
                                   *(int *)classes_const_1357___type____T____items____None__None__ +
                                   1;
                            }
                            if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                              (**(code **)(plVar15[1] + 0x30))(plVar15);
                            }
                            pcVar14 = pcStack_2a8;
                            pcVar18 = pcStack_2a8;
                            plVar9 = plStack_2d0;
                            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                              (**(code **)(plVar11[1] + 0x30))(plVar11);
                              pcVar14 = pcStack_2a8;
                              pcVar18 = pcStack_2a8;
                              plVar9 = plStack_2d0;
                            }
                            goto LAB_1408bca80;
                          }
                          pcStack_280 = _Py_NoneStruct_exref;
                          if (*(int *)_Py_NoneStruct_exref + 1 != 0) {
                            *(int *)_Py_NoneStruct_exref = *(int *)_Py_NoneStruct_exref + 1;
                          }
                          if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                             (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1,
                             *(longlong *)pcVar14 == 0)) {
                            (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14,pcVar14);
                          }
                          plVar13 = (longlong *)
                                    FUN_140009960(
                                                 classes_const_1785___type_________items____22__48__6__
                                                 );
                          plStack_298 = plVar13;
                          plStack_288 = plVar13;
                          plVar9 = (longlong *)(**(code **)(plVar13[1] + 0xe0))();
                          plStack_2b8 = (longlong *)0x0;
                          if (plVar9 != (longlong *)0x0) {
                            plStack_2b8 = (longlong *)0x0;
                            do {
                              plVar13 = plStack_200;
                              plVar8 = plVar9;
                              if (((plStack_2b8 != (longlong *)0x0) && (-1 < (int)*plStack_2b8)) &&
                                 (*plStack_2b8 = *plStack_2b8 + -1, *plStack_2b8 == 0)) {
                                plVar8 = plStack_2b8 + 1;
                                plStack_2b8 = plVar9;
                                (**(code **)(*plVar8 + 0x30))();
                                plVar8 = plStack_2b8;
                              }
                              plStack_2b8 = plVar8;
                              iVar5 = (int)*plVar9 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar9 = iVar5;
                              }
                              plStack_200 = plVar9;
                              if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
                                 (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                (**(code **)(plVar13[1] + 0x30))();
                              }
                              if (plStack_2d0[2] == 0) {
                                FUN_142cd4900(tstate,&lStack_318,classes_const_1786__cv2);
                                FUN_1400048d0(tstate,lStack_318);
                                uStack_310 = 0x2164;
                                lVar10 = lStack_318;
                                goto LAB_1408bc713;
                              }
                              plVar13 = (longlong *)
                                        FUN_142cd7b20(tstate,plStack_2d0[2],
                                                      classes_const_1787_resize);
                              if (plVar13 == (longlong *)0x0) {
LAB_1408bc6b9:
                                lVar10 = *(longlong *)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                                uStack_310 = 0x2164;
                                goto LAB_1408bc713;
                              }
                              plVar8 = (longlong *)FUN_142cd9440(tstate,2);
                              iVar5 = (int)*plVar9 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar9 = iVar5;
                              }
                              plVar8[3] = (longlong)plVar9;
                              iVar5 = (int)*plVar9 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar9 = iVar5;
                              }
                              plVar8[4] = (longlong)plVar9;
                              *(undefined4 *)(plStack_2d8 + 5) = 0x2164;
                              pcStack_f0 = pcVar20;
                              plStack_e8 = plVar8;
                              plVar11 = (longlong *)FUN_142cc4ec0(tstate,plVar13,&pcStack_f0);
                              plStack_260 = plVar11;
                              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0))
                              {
                                (**(code **)(plVar13[1] + 0x30))(plVar13);
                              }
                              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                (**(code **)(plVar8[1] + 0x30))(plVar8);
                              }
                              if (plVar11 == (longlong *)0x0) goto LAB_1408bc6b9;
                              if (((plStack_1c8 != (longlong *)0x0) && (-1 < (int)*plStack_1c8)) &&
                                 (*plStack_1c8 = *plStack_1c8 + -1, *plStack_1c8 == 0)) {
                                plVar13 = plStack_1c8 + 1;
                                plStack_1c8 = plVar11;
                                (**(code **)(*plVar13 + 0x30))();
                                plVar11 = plStack_1c8;
                              }
                              plStack_1c8 = plVar11;
                              plStack_2f8 = (longlong *)
                                            FUN_140009960(
                                                  classes_const_1789___type_________items____0__360__15__
                                                  );
                              plVar13 = (longlong *)0x0;
LAB_1408badc0:
                              plVar8 = plStack_2f8;
                              plVar11 = (longlong *)
                                        (**(code **)(plStack_2f8[1] + 0xe0))(plStack_2f8);
                              if (plVar11 != (longlong *)0x0) {
                                plStack_2e0 = plVar11;
                                if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
                                   (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                                }
                                iVar5 = (int)*plVar11 + 1;
                                if (iVar5 != 0) {
                                  *(int *)plVar11 = iVar5;
                                }
                                plVar13 = plVar11;
                                if (((plStack_210 != (longlong *)0x0) && (-1 < (int)*plStack_210))
                                   && (*plStack_210 = *plStack_210 + -1, *plStack_210 == 0)) {
                                  plVar13 = plStack_210 + 1;
                                  plStack_210 = plVar11;
                                  (**(code **)(*plVar13 + 0x30))();
                                  plVar13 = plStack_210;
                                }
                                plStack_210 = plVar13;
                                if (plStack_2d0[2] == 0) {
                                  FUN_142cd4900(tstate,&lStack_318,classes_const_1786__cv2);
                                  FUN_1400048d0(tstate,lStack_318);
LAB_1408bc5eb:
                                  uStack_310 = 0x2166;
                                  lVar10 = lStack_318;
                                }
                                else {
                                  plVar13 = (longlong *)
                                            FUN_142cd7b20(tstate,plStack_2d0[2],
                                                          classes_const_1790_getRotationMatrix2D);
                                  if (plVar13 == (longlong *)0x0) {
                                    lVar10 = *(longlong *)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                    uStack_310 = 0x2166;
                                  }
                                  else {
                                    lVar10 = FUN_142cc1420(plVar9,classes_const_1792_2_0);
                                    if (lVar10 == 0) {
                                      lStack_318 = *(longlong *)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                      if ((-1 < (int)*plVar13) &&
                                         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                        (**(code **)(plVar13[1] + 0x30))(plVar13);
                                      }
                                      goto LAB_1408bc5eb;
                                    }
                                    plVar12 = (longlong *)FUN_142cd9440(tstate,2);
                                    plVar12[3] = lVar10;
                                    lVar10 = FUN_142cc1420(plVar9,classes_const_1792_2_0);
                                    if (lVar10 == 0) {
                                      lStack_318 = *(longlong *)(tstate + 0x70);
                                      *(undefined8 *)(tstate + 0x70) = 0;
                                      uStack_310 = 0x2166;
                                      if ((-1 < (int)*plVar13) &&
                                         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                        (**(code **)(plVar13[1] + 0x30))(plVar13);
                                      }
                                      lVar10 = lStack_318;
                                      plVar8 = plStack_2f8;
                                      if ((-1 < (int)*plVar12) &&
                                         (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                        (**(code **)(plVar12[1] + 0x30))(plVar12);
                                        lVar10 = lStack_318;
                                        plVar8 = plStack_2f8;
                                      }
                                    }
                                    else {
                                      plVar12[4] = lVar10;
                                      puStack_c0 = classes_const_1793_1_0;
                                      *(undefined4 *)(plStack_2d8 + 5) = 0x2166;
                                      plStack_d0 = plVar12;
                                      plStack_c8 = plVar11;
                                      plVar8 = (longlong *)FUN_142cc5e90(tstate,plVar13,&plStack_d0)
                                      ;
                                      if ((-1 < (int)*plVar13) &&
                                         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                        (**(code **)(plVar13[1] + 0x30))();
                                      }
                                      if ((-1 < (int)*plVar12) &&
                                         (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                        (**(code **)(plVar12[1] + 0x30))();
                                      }
                                      plVar13 = plStack_240;
                                      if (plVar8 == (longlong *)0x0) {
                                        lVar10 = *(longlong *)(tstate + 0x70);
                                        *(undefined8 *)(tstate + 0x70) = 0;
                                        uStack_310 = 0x2166;
                                        plVar8 = plStack_2f8;
                                      }
                                      else {
                                        plVar12 = plVar8;
                                        if (((plStack_240 != (longlong *)0x0) &&
                                            (-1 < (int)*plStack_240)) &&
                                           (*plStack_240 = *plStack_240 + -1, *plStack_240 == 0)) {
                                          plVar12 = plStack_240 + 1;
                                          plStack_240 = plVar8;
                                          (**(code **)(*plVar12 + 0x30))(plVar13);
                                          plVar12 = plStack_240;
                                        }
                                        plStack_240 = plVar12;
                                        puVar19 = classes_const_1777__grad;
                                        if ((plStack_1a0 == (longlong *)0x0) ||
                                           (puVar19 = classes_const_1786__cv2, plStack_2d0[2] == 0))
                                        {
                                          FUN_142cd4900(tstate,&lStack_318,puVar19);
                                          FUN_1400048d0(tstate,lStack_318);
                                          uStack_310 = 0x2167;
                                          lVar10 = lStack_318;
                                          plVar8 = plStack_2f8;
                                        }
                                        else {
                                          plVar13 = (longlong *)
                                                    FUN_142cd7b20(tstate,plStack_2d0[2],
                                                                  classes_const_1794_warpAffine);
                                          if (plVar13 != (longlong *)0x0) {
                                            plVar15 = (longlong *)FUN_142cd9440(tstate,2);
                                            plVar12 = plStack_2d8;
                                            iVar5 = (int)*plVar9 + 1;
                                            if (iVar5 != 0) {
                                              *(int *)plVar9 = iVar5;
                                            }
                                            plVar15[3] = (longlong)plVar9;
                                            iVar5 = (int)*plVar9 + 1;
                                            if (iVar5 != 0) {
                                              *(int *)plVar9 = iVar5;
                                            }
                                            plVar15[4] = (longlong)plVar9;
                                            *(undefined4 *)(plStack_2d8 + 5) = 0x2167;
                                            plStack_b8 = plStack_260;
                                            plStack_b0 = plVar8;
                                            plStack_a8 = plVar15;
                                            plVar8 = (longlong *)
                                                     FUN_142cc5e90(tstate,plVar13,&plStack_b8);
                                            if ((-1 < (int)*plVar13) &&
                                               (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                              (**(code **)(plVar13[1] + 0x30))();
                                            }
                                            if ((-1 < (int)*plVar15) &&
                                               (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                                              (**(code **)(plVar15[1] + 0x30))();
                                            }
                                            if (plVar8 == (longlong *)0x0) goto LAB_1408bc4b6;
                                            *(undefined4 *)(plVar12 + 5) = 0x2167;
                                            plVar12 = (longlong *)
                                                      FUN_142ccfd60(tstate,plStack_1a0,plVar8);
                                            if ((-1 < (int)*plVar8) &&
                                               (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                              (**(code **)(plVar8[1] + 0x30))();
                                            }
                                            plVar13 = plStack_238;
                                            if (plVar12 == (longlong *)0x0) goto LAB_1408bc4b6;
                                            plVar8 = plVar12;
                                            if (((plStack_238 != (longlong *)0x0) &&
                                                (-1 < (int)*plStack_238)) &&
                                               (*plStack_238 = *plStack_238 + -1, *plStack_238 == 0)
                                               ) {
                                              plVar8 = plStack_238 + 1;
                                              plStack_238 = plVar12;
                                              (**(code **)(*plVar8 + 0x30))(plVar13);
                                              plVar8 = plStack_238;
                                            }
                                            plStack_238 = plVar8;
                                            plVar13 = (longlong *)
                                                      FUN_142cd7b20(tstate,plVar12,
                                                                    classes_const_1795_shape);
                                            if (plVar13 != (longlong *)0x0) {
                                              plVar15 = (longlong *)
                                                        FUN_140008f40(tstate,plVar13,_DAT_142d9a260)
                                              ;
                                              if ((-1 < (int)*plVar13) &&
                                                 (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                (**(code **)(plVar13[1] + 0x30))();
                                              }
                                              if (plVar15 == (longlong *)0x0) goto LAB_1408bc48f;
                                              plVar13 = (longlong *)
                                                        FUN_142cd7b20(tstate,plStack_1a8,
                                                                      classes_const_1795_shape);
                                              if (plVar13 != (longlong *)0x0) {
                                                plVar8 = (longlong *)
                                                         FUN_140008f40(tstate,plVar13,_DAT_142d9a260
                                                                      );
                                                if ((-1 < (int)*plVar13) &&
                                                   (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                                  (**(code **)(plVar13[1] + 0x30))();
                                                }
                                                if (plVar8 == (longlong *)0x0) goto LAB_1408bc469;
                                                iVar5 = FUN_142ce08d0(plVar15,plVar8);
                                                if ((-1 < (int)*plVar15) &&
                                                   (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                                                  (**(code **)(plVar15[1] + 0x30))();
                                                }
                                                if ((-1 < (int)*plVar8) &&
                                                   (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                                  (**(code **)(plVar8[1] + 0x30))();
                                                }
                                                plVar8 = plStack_2f8;
                                                if (iVar5 != -1) goto code_r0x0001408bb15f;
                                                goto LAB_1408bc446;
                                              }
                                              goto LAB_1408bc469;
                                            }
LAB_1408bc48f:
                                            lStack_318 = *(longlong *)(tstate + 0x70);
                                            *(undefined8 *)(tstate + 0x70) = 0;
                                            goto LAB_1408bc49d;
                                          }
LAB_1408bc4b6:
                                          lVar10 = *(longlong *)(tstate + 0x70);
                                          *(undefined8 *)(tstate + 0x70) = 0;
                                          uStack_310 = 0x2167;
                                          plVar8 = plStack_2f8;
                                        }
                                      }
                                    }
                                  }
                                }
                                goto LAB_1408bc669;
                              }
                              plVar11 = *(longlong **)(tstate + 0x70);
                              if (plVar11 != (longlong *)0x0) {
                                cVar4 = FUN_140008d40(tstate,plVar11,
                                                      *(undefined8 *)PyExc_StopIteration_exref);
                                if (cVar4 == '\0') {
                                  lVar10 = *(longlong *)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  lStack_318 = 0;
                                  uStack_310 = 0x2165;
                                  plVar11 = plVar13;
                                  if (plVar13 != (longlong *)0x0) {
LAB_1408bc669:
                                    lStack_318 = 0;
                                    if ((-1 < (int)*plVar11) &&
                                       (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                                      (**(code **)(plVar11[1] + 0x30))(plVar11);
                                    }
                                  }
                                  plVar9 = plStack_2b8;
                                  if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0))
                                  {
                                    (**(code **)(plVar8[1] + 0x30))(plVar8);
                                    plVar9 = plStack_2b8;
                                  }
                                  goto LAB_1408bc713;
                                }
                                *(undefined8 *)(tstate + 0x70) = 0;
                                if ((-1 < (int)*plVar11) &&
                                   (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                                  (**(code **)(plVar11[1] + 0x30))(plVar11);
                                }
                              }
                              if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
                                 (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                (**(code **)(plVar13[1] + 0x30))(plVar13);
                              }
                              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                (**(code **)(plVar8[1] + 0x30))(plVar8);
                              }
                              cVar4 = FUN_140008af0(tstate);
                              plVar13 = plStack_288;
                              if (cVar4 == '\0') {
                                lVar10 = *(longlong *)(tstate + 0x70);
                                *(undefined8 *)(tstate + 0x70) = 0;
                                uStack_310 = 0x2163;
                                goto LAB_1408bc713;
                              }
                              plVar9 = (longlong *)(**(code **)(plStack_288[1] + 0xe0))(plStack_288)
                              ;
                              pcVar20 = pcStack_170;
                              plVar15 = plStack_308;
                            } while (plVar9 != (longlong *)0x0);
                          }
                          plVar11 = plStack_2b8;
                          plVar8 = *(longlong **)(tstate + 0x70);
                          plVar9 = (longlong *)(tstate + 0x70);
                          plStack_2f8 = plVar9;
                          if (plVar8 != (longlong *)0x0) {
                            cVar4 = FUN_140008d40(tstate,plVar8,
                                                  *(undefined8 *)PyExc_StopIteration_exref);
                            if (cVar4 == '\0') {
                              lVar10 = *plVar9;
                              uStack_310 = 0x2163;
                              *plVar9 = 0;
                              plVar9 = plStack_2b8;
LAB_1408bc713:
                              lStack_318 = lVar10;
                              lVar10 = lStack_318;
                              lStack_318 = 0;
                              if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
                                 (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                              }
                              plVar13 = plStack_2d8;
                              plVar11 = plStack_270;
                              plVar8 = plStack_2b0;
                              uVar22 = uStack_310;
                              if ((-1 < (int)*plStack_288) &&
                                 (*plStack_288 = *plStack_288 + -1, *plStack_288 == 0)) {
                                (**(code **)(plStack_288[1] + 0x30))();
                                plVar13 = plStack_2d8;
                                plVar11 = plStack_270;
                                plVar8 = plStack_2b0;
                                uVar22 = uStack_310;
                              }
                              goto LAB_1408bd16d;
                            }
                            *plVar9 = 0;
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                          }
                          if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                             (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                          }
                          if ((-1 < (int)*plStack_298) &&
                             (*plStack_298 = *plStack_298 + -1, *plStack_298 == 0)) {
                            (**(code **)(plVar13[1] + 0x30))(plVar13);
                          }
                          if (pcStack_280 == (code *)0x0) {
                            FUN_142cd4900(tstate,&lStack_318,classes_const_1634_mapa);
                            FUN_1400048d0(tstate,lStack_318);
                            lVar10 = lStack_318;
                            plVar13 = plStack_2d8;
                            plVar11 = plStack_270;
                            plVar8 = plStack_2b0;
                            uVar22 = 0x216f;
                            goto LAB_1408bd16d;
                          }
                          plVar11 = plStack_270;
                          if (pcStack_280 == _Py_NoneStruct_exref) goto LAB_1408bca2d;
                          plVar8 = (longlong *)
                                   FUN_142cd7b20(tstate,pcStack_280,classes_const_1804_copy);
                          plVar13 = plStack_2d8;
                          if (plVar8 == (longlong *)0x0) {
LAB_1408bca00:
                            lVar10 = *plVar9;
                            *plVar9 = 0;
                            plVar11 = plStack_270;
                            plVar8 = plStack_2b0;
                            uVar22 = 0x2172;
                            goto LAB_1408bd16d;
                          }
                          *(undefined4 *)(plStack_2d8 + 5) = 0x2172;
                          plVar11 = (longlong *)FUN_142cc3220(tstate,plVar8);
                          plStack_260 = plVar11;
                          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                            (**(code **)(plVar8[1] + 0x30))();
                          }
                          plVar8 = plStack_248;
                          if (plVar11 == (longlong *)0x0) goto LAB_1408bca00;
                          plVar13 = plVar11;
                          if (((plStack_1c0 != (longlong *)0x0) && (-1 < (int)*plStack_1c0)) &&
                             (*plStack_1c0 = *plStack_1c0 + -1, *plStack_1c0 == 0)) {
                            plVar13 = plStack_1c0 + 1;
                            plStack_1c0 = plVar11;
                            (**(code **)(*plVar13 + 0x30))();
                            plVar13 = plStack_1c0;
                          }
                          plStack_1c0 = plVar13;
                          plStack_248 = (longlong *)FUN_142cd8f90(tstate,0);
                          if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
                             (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                          }
                          plVar13 = (longlong *)
                                    FUN_140009960(
                                                 classes_const_1805___type_________items____0__6__1__
                                                 );
                          plStack_288 = plVar13;
                          plVar8 = (longlong *)(**(code **)(plVar13[1] + 0xe0))();
                          plStack_2b8 = (longlong *)0x0;
                          if (plVar8 != (longlong *)0x0) {
                            plStack_2b8 = (longlong *)0x0;
                            do {
                              plVar13 = plStack_218;
                              plVar9 = plVar8;
                              if (((plStack_2b8 != (longlong *)0x0) && (-1 < (int)*plStack_2b8)) &&
                                 (*plStack_2b8 = *plStack_2b8 + -1, *plStack_2b8 == 0)) {
                                plVar9 = plStack_2b8 + 1;
                                plStack_2b8 = plVar8;
                                (**(code **)(*plVar9 + 0x30))();
                                plVar9 = plStack_2b8;
                              }
                              plStack_2b8 = plVar9;
                              iVar5 = (int)*plVar8 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar8 = iVar5;
                              }
                              plStack_218 = plVar8;
                              if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
                                 (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                (**(code **)(plVar13[1] + 0x30))();
                              }
                              tstate = puStack_2f0;
                              if (plStack_2d0[2] == 0) {
                                FUN_142cd4900(puStack_2f0,&lStack_318,classes_const_1786__cv2);
                                FUN_1400048d0(tstate,lStack_318);
                                uStack_310 = 0x2175;
                                lVar10 = lStack_318;
                                goto LAB_1408bc958;
                              }
                              plVar13 = (longlong *)
                                        FUN_142cd7b20(puStack_2f0,plStack_2d0[2],
                                                      classes_const_1806_minMaxLoc);
                              if (plVar13 == (longlong *)0x0) {
LAB_1408bc8ee:
                                uStack_310 = 0x2175;
                                lVar10 = *plStack_2f8;
                                *plStack_2f8 = 0;
                                goto LAB_1408bc958;
                              }
                              *(undefined4 *)(plStack_2d8 + 5) = 0x2175;
                              plVar9 = (longlong *)FUN_142ccfd60(tstate,plVar13,plVar11);
                              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0))
                              {
                                (**(code **)(plVar13[1] + 0x30))(plVar13);
                              }
                              if (plVar9 == (longlong *)0x0) goto LAB_1408bc8ee;
                              plVar13 = (longlong *)FUN_1400099f0(plVar9);
                              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                              }
                              if (plVar13 == (longlong *)0x0) goto LAB_1408bc8ee;
                              pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,4);
                              plVar9 = (longlong *)FUN_140009d90(tstate,&lStack_318,plVar13,0);
                              if (plVar9 == (longlong *)0x0) {
                                plVar9 = (longlong *)0x0;
LAB_1408bc84b:
                                plVar11 = (longlong *)0x0;
LAB_1408bc84e:
                                plVar12 = (longlong *)0x0;
LAB_1408bc851:
                                plVar15 = (longlong *)0x0;
LAB_1408bc854:
                                lVar10 = lStack_318;
                                uStack_310 = 0x2175;
                                if ((-1 < (int)*plVar13) &&
                                   (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                                }
                                if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
                                   (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                                }
                                if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                                   (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                                  (**(code **)(plVar11[1] + 0x30))(plVar11);
                                }
                                if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
                                   (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                  (**(code **)(plVar12[1] + 0x30))(plVar12);
                                }
                                tstate = puStack_2f0;
                                if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
                                   (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                                  (**(code **)(plVar15[1] + 0x30))(plVar15);
                                  tstate = puStack_2f0;
                                }
                                goto LAB_1408bc958;
                              }
                              pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,4);
                              plVar11 = (longlong *)FUN_140009d90(tstate,&lStack_318,plVar13,1);
                              if (plVar11 == (longlong *)0x0) goto LAB_1408bc84b;
                              pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,4);
                              plVar12 = (longlong *)FUN_140009d90(tstate,&lStack_318,plVar13,2);
                              if (plVar12 == (longlong *)0x0) goto LAB_1408bc84e;
                              pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,4);
                              plVar15 = (longlong *)FUN_140009d90(tstate,&lStack_318,plVar13,3);
                              if (plVar15 == (longlong *)0x0) goto LAB_1408bc851;
                              cVar4 = FUN_140009c30(puStack_2f0,&lStack_318,plVar13,4);
                              plVar16 = plStack_1f8;
                              if (cVar4 == '\0') goto LAB_1408bc854;
                              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0))
                              {
                                (**(code **)(plVar13[1] + 0x30))(plVar13);
                              }
                              iVar6 = (int)*plVar9;
                              iVar5 = iVar6 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar9 = iVar5;
                                iVar6 = iVar5;
                              }
                              if (-1 < (int)*plVar8) {
                                *plVar8 = *plVar8 + -1;
                                if (*plVar8 == 0) {
                                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                                }
                                iVar6 = (int)*plVar9;
                              }
                              if ((-1 < iVar6) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                              }
                              iVar5 = (int)*plVar11 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar11 = iVar5;
                              }
                              plStack_1f8 = plVar11;
                              if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
                                 (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                                (**(code **)(plVar16[1] + 0x30))();
                              }
                              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0))
                              {
                                (**(code **)(plVar11[1] + 0x30))(plVar11);
                              }
                              iVar5 = (int)*plVar12 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar12 = iVar5;
                              }
                              plStack_218 = plVar12;
                              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                              }
                              if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0))
                              {
                                (**(code **)(plVar12[1] + 0x30))(plVar12);
                              }
                              iVar5 = (int)*plVar15 + 1;
                              if (iVar5 != 0) {
                                *(int *)plVar15 = iVar5;
                              }
                              plVar13 = plVar15;
                              if (((plStack_1f0 != (longlong *)0x0) && (-1 < (int)*plStack_1f0)) &&
                                 (*plStack_1f0 = *plStack_1f0 + -1, *plStack_1f0 == 0)) {
                                plVar13 = plStack_1f0 + 1;
                                plStack_1f0 = plVar15;
                                (**(code **)(*plVar13 + 0x30))();
                                plVar13 = plStack_1f0;
                              }
                              plStack_1f0 = plVar13;
                              if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0))
                              {
                                (**(code **)(plVar15[1] + 0x30))(plVar15);
                              }
                              plVar13 = plStack_248;
                              tstate = puStack_2f0;
                              if (plStack_248 == (longlong *)0x0) {
                                FUN_142cd4900(puStack_2f0,&lStack_318,classes_const_1808_lista);
                                FUN_1400048d0(tstate,lStack_318);
                                uStack_310 = 0x2176;
                                lVar10 = lStack_318;
                                goto LAB_1408bc958;
                              }
                              lVar10 = Nuitka_helper_142ce5200(plVar11);
                              tstate = puStack_2f0;
                              if (lVar10 == 0) {
                                lVar10 = *plStack_2f8;
                                uStack_310 = 0x2176;
                                *plStack_2f8 = 0;
                                goto LAB_1408bc958;
                              }
                              plVar9 = (longlong *)FUN_142cd9440(puStack_2f0,3);
                              plVar9[3] = lVar10;
                              lVar10 = FUN_140008f40(tstate,plVar15,_DAT_142d9a260,0);
                              if (lVar10 == 0) {
LAB_1408bc7cc:
                                uStack_310 = 0x2176;
                                lStack_318 = *plStack_2f8;
                                *plStack_2f8 = 0;
                                lVar10 = lStack_318;
                                if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                  (**(code **)(plVar9[1] + 0x30))(plVar9);
                                  lVar10 = lStack_318;
                                }
                                goto LAB_1408bc958;
                              }
                              plVar9[4] = lVar10;
                              lVar10 = FUN_140008f40(tstate,plVar15,_DAT_142d9a268);
                              if (lVar10 == 0) goto LAB_1408bc7cc;
                              plVar9[5] = lVar10;
                              FUN_142cd71a0(plVar13,plVar9);
                              if (plStack_2d0[2] == 0) {
                                FUN_142cd4900(tstate,&lStack_318,classes_const_1786__cv2);
                                FUN_1400048d0(tstate,lStack_318);
                                uStack_310 = 0x2177;
                                lVar10 = lStack_318;
                                goto LAB_1408bc958;
                              }
                              plVar13 = (longlong *)
                                        FUN_142cd7b20(tstate,plStack_2d0[2],
                                                      classes_const_1809_circle);
                              plVar11 = plStack_260;
                              puVar3 = classes_const_1801__9_0;
                              puVar19 = classes_const_1231_30;
                              uVar2 = _DAT_142d9a270;
                              if (plVar13 == (longlong *)0x0) {
LAB_1408bc775:
                                uStack_310 = 0x2177;
                                lVar10 = *plStack_2f8;
                                *plStack_2f8 = 0;
                                goto LAB_1408bc958;
                              }
                              *(undefined4 *)(plStack_2d8 + 5) = 0x2177;
                              puStack_60 = puVar19;
                              puStack_58 = puVar3;
                              uStack_50 = uVar2;
                              plStack_70 = plStack_260;
                              plStack_68 = plVar15;
                              plVar9 = (longlong *)FUN_142cc7b00(tstate,plVar13,&plStack_70);
                              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0))
                              {
                                (**(code **)(plVar13[1] + 0x30))(plVar13);
                              }
                              if (plVar9 == (longlong *)0x0) goto LAB_1408bc775;
                              if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
                                (**(code **)(plVar9[1] + 0x30))(plVar9);
                              }
                              cVar4 = FUN_140008af0(tstate);
                              plVar13 = plStack_288;
                              if (cVar4 == '\0') {
                                uStack_310 = 0x2174;
                                lVar10 = *plStack_2f8;
                                *plStack_2f8 = 0;
                                goto LAB_1408bc958;
                              }
                              plVar8 = (longlong *)(**(code **)(plStack_288[1] + 0xe0))(plStack_288)
                              ;
                              plVar9 = plStack_2f8;
                            } while (plVar8 != (longlong *)0x0);
                          }
                          plVar11 = plStack_2b8;
                          tstate = puStack_2f0;
                          plVar8 = (longlong *)*plVar9;
                          if (plVar8 != (longlong *)0x0) {
                            cVar4 = FUN_140008d40(puStack_2f0,plVar8,
                                                  *(undefined8 *)PyExc_StopIteration_exref);
                            if (cVar4 == '\0') {
                              lVar10 = *plVar9;
                              uStack_310 = 0x2174;
                              *plVar9 = 0;
LAB_1408bc958:
                              lStack_318 = lVar10;
                              lVar10 = lStack_318;
                              lStack_318 = 0;
                              if (((plStack_2b8 != (longlong *)0x0) && (-1 < (int)*plStack_2b8)) &&
                                 (*plStack_2b8 = *plStack_2b8 + -1, *plStack_2b8 == 0)) {
                                (**(code **)(plStack_2b8[1] + 0x30))();
                              }
                              plVar13 = plStack_2d8;
                              plVar11 = plStack_270;
                              plVar8 = plStack_2b0;
                              uVar22 = uStack_310;
                              if ((-1 < (int)*plStack_288) &&
                                 (*plStack_288 = *plStack_288 + -1, *plStack_288 == 0)) {
                                (**(code **)(plStack_288[1] + 0x30))(plStack_288);
                                plVar13 = plStack_2d8;
                                plVar11 = plStack_270;
                                plVar8 = plStack_2b0;
                                uVar22 = uStack_310;
                              }
                              goto LAB_1408bd16d;
                            }
                            *plVar9 = 0;
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                          }
                          if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
                             (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                            (**(code **)(plVar11[1] + 0x30))(plVar11);
                          }
                          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                            (**(code **)(plVar13[1] + 0x30))(plVar13);
                          }
                          pcVar14 = pcStack_2c8;
                          puVar19 = classes_const_1810_picos;
                          if ((pcStack_2c8 == (code *)0x0) ||
                             (puVar19 = classes_const_1808_lista, plStack_248 == (longlong *)0x0)) {
                            FUN_142cd4900(tstate,&lStack_318,puVar19);
                            FUN_1400048d0(tstate,lStack_318);
                            lVar10 = lStack_318;
                            plVar13 = plStack_2d8;
                            plVar11 = plStack_270;
                            plVar8 = plStack_2b0;
                            uVar22 = 0x2178;
                            goto LAB_1408bd16d;
                          }
                          FUN_142cd7140(pcStack_2c8,plStack_248);
                          cVar4 = FUN_140008af0();
                          plVar13 = plStack_2d8;
                          plVar8 = plStack_2b0;
                        } while (cVar4 != '\0');
                        lVar10 = *plVar9;
                        *plVar9 = 0;
                        plVar11 = plStack_270;
                        uVar22 = 0x215e;
LAB_1408bd16d:
                        lStack_318 = 0;
                        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                          (**(code **)(plVar8[1] + 0x30))(plVar8);
                        }
LAB_1408bd183:
                        pcVar14 = pcStack_2c8;
                        plVar9 = plStack_2d0;
                        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))(plVar11);
                          pcVar14 = pcStack_2c8;
                          plVar9 = plStack_2d0;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  goto LAB_1408bef49;
joined_r0x0001408be85c:
  plStack_290 = plVar15;
  if (plVar8 == (longlong *)0x0) goto LAB_1408bebbb;
  plStack_2b0 = plVar8;
  if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
     (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
    (**(code **)(plVar12[1] + 0x30))(plVar12);
  }
  iVar5 = (int)*plVar8 + 1;
  if (iVar5 != 0) {
    *(int *)plVar8 = iVar5;
  }
  plStack_290 = plVar8;
  if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
     (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
    (**(code **)(plVar15[1] + 0x30))();
  }
  plVar13 = (longlong *)FUN_140008da0(tstate,pcStack_2c8,plVar8);
  if (plVar13 == (longlong *)0x0) goto LAB_1408bed33;
  plVar9 = (longlong *)FUN_140008f40(tstate,pcStack_2a0,_DAT_142d9a268,1);
  if (plVar9 == (longlong *)0x0) {
LAB_1408bed58:
    lStack_318 = *plStack_2f8;
    *plStack_2f8 = 0;
    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    uVar22 = 0x2191;
    lVar10 = lStack_318;
    goto LAB_1408beef9;
  }
  plVar11 = (longlong *)FUN_140008da0(tstate,plVar9,plVar8);
  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if (plVar11 == (longlong *)0x0) goto LAB_1408bed58;
  plVar9 = (longlong *)FUN_140008da0(tstate,plVar13,plVar11);
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
    (**(code **)(plVar11[1] + 0x30))(plVar11);
  }
  if (plVar9 == (longlong *)0x0) {
LAB_1408bed33:
    lVar10 = *plStack_2f8;
    *plStack_2f8 = 0;
    uVar22 = 0x2191;
    goto LAB_1408beef9;
  }
  plVar13 = (longlong *)FUN_1400099f0(plVar9);
  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if (plVar13 == (longlong *)0x0) goto LAB_1408bed33;
  pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,3);
  plVar9 = (longlong *)FUN_140009d90(tstate,&lStack_318,plVar13,0);
  if (plVar9 == (longlong *)0x0) {
    plVar9 = (longlong *)0x0;
LAB_1408becab:
    plVar11 = (longlong *)0x0;
LAB_1408becae:
    plVar12 = (longlong *)0x0;
LAB_1408becb9:
    lVar10 = lStack_318;
    uStack_310 = 0x2191;
    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    if (((plVar9 != (longlong *)0x0) && (-1 < (int)*plVar9)) &&
       (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
      (**(code **)(plVar9[1] + 0x30))(plVar9);
    }
    if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
       (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
    tstate = puStack_2f0;
    uVar22 = uStack_310;
    if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
       (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
      (**(code **)(plVar12[1] + 0x30))(plVar12);
      tstate = puStack_2f0;
      uVar22 = uStack_310;
    }
    goto LAB_1408beef9;
  }
  pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,3);
  plVar11 = (longlong *)FUN_140009d90(tstate,&lStack_318,plVar13,1);
  if (plVar11 == (longlong *)0x0) goto LAB_1408becab;
  pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,3);
  plVar12 = (longlong *)FUN_140009d90(tstate,&lStack_318,plVar13,2);
  if (plVar12 == (longlong *)0x0) goto LAB_1408becae;
  cVar4 = FUN_140009c30(puStack_2f0,&lStack_318,plVar13,3);
  plVar21 = plStack_188;
  plVar16 = plStack_190;
  plVar15 = plStack_1b8;
  if (cVar4 == '\0') goto LAB_1408becb9;
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  iVar5 = (int)*plVar9 + 1;
  if (iVar5 != 0) {
    *(int *)plVar9 = iVar5;
  }
  plStack_1b8 = plVar9;
  if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
     (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
    (**(code **)(plVar15[1] + 0x30))();
  }
  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  iVar5 = (int)*plVar11 + 1;
  if (iVar5 != 0) {
    *(int *)plVar11 = iVar5;
  }
  plStack_190 = plVar11;
  if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
     (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
    (**(code **)(plVar16[1] + 0x30))();
  }
  if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
    (**(code **)(plVar11[1] + 0x30))(plVar11);
  }
  iVar5 = (int)*plVar12 + 1;
  if (iVar5 != 0) {
    *(int *)plVar12 = iVar5;
  }
  plStack_188 = plVar12;
  if (((plVar21 != (longlong *)0x0) && (-1 < (int)*plVar21)) &&
     (*plVar21 = *plVar21 + -1, *plVar21 == 0)) {
    (**(code **)(plVar21[1] + 0x30))();
  }
  if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
    (**(code **)(plVar12[1] + 0x30))(plVar12);
  }
  plVar13 = plStack_160;
  tstate = puStack_2f0;
  if (plStack_160 == (longlong *)0x0) {
    FUN_142cd4900(puStack_2f0,&lStack_318,classes_const_1816_pontos);
    FUN_1400048d0(tstate,lStack_318);
    uVar22 = 0x2192;
    plVar8 = plStack_2b0;
    lVar10 = lStack_318;
    goto LAB_1408beef9;
  }
  lVar10 = FUN_142cd9440(puStack_2f0,2);
  iVar5 = (int)*plVar11 + 1;
  if (iVar5 != 0) {
    *(int *)plVar11 = iVar5;
  }
  *(longlong **)(lVar10 + 0x18) = plVar11;
  iVar5 = (int)*plVar12 + 1;
  if (iVar5 != 0) {
    *(int *)plVar12 = iVar5;
  }
  *(longlong **)(lVar10 + 0x20) = plVar12;
  FUN_142cd71a0(plVar13,lVar10);
  if (plStack_180 == (longlong *)0x0) {
    FUN_142cd4900(tstate,&lStack_318,classes_const_1817_notas);
    FUN_1400048d0(tstate,lStack_318);
    uVar22 = 0x2193;
    plVar8 = plStack_2b0;
    lVar10 = lStack_318;
    goto LAB_1408beef9;
  }
  FUN_142cd7140(plStack_180,plVar9);
  cVar4 = FUN_140008af0(tstate);
  plVar11 = plStack_288;
  if (cVar4 == '\0') {
    lStack_318 = *plStack_2f8;
    *plStack_2f8 = 0;
    goto LAB_1408beeef;
  }
  plVar8 = (longlong *)(**(code **)(plStack_288[1] + 0xe0))(plStack_288);
  plVar12 = plStack_2b0;
  plVar9 = plStack_2f8;
  plVar15 = plStack_290;
  goto joined_r0x0001408be85c;
LAB_1408bebbb:
  cVar4 = FUN_140009ec0(tstate,*(undefined8 *)PyExc_StopIteration_exref);
  if (cVar4 == '\0') {
    lStack_318 = *plVar9;
    *plVar9 = 0;
LAB_1408beeef:
    uVar22 = 0x2190;
    plVar8 = plStack_2b0;
    lVar10 = lStack_318;
LAB_1408beef9:
    lStack_318 = lVar10;
    lVar10 = lStack_318;
    lStack_318 = 0;
    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))(plVar8);
    }
    plVar13 = plStack_2d8;
    pcVar14 = pcStack_2c8;
    plVar9 = plStack_2d0;
    if ((-1 < (int)*plStack_288) && (*plStack_288 = *plStack_288 + -1, *plStack_288 == 0)) {
      (**(code **)(plStack_288[1] + 0x30))();
      plVar13 = plStack_2d8;
      pcVar14 = pcStack_2c8;
      plVar9 = plStack_2d0;
    }
  }
  else {
    if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
       (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
      (**(code **)(plVar12[1] + 0x30))(plVar12);
    }
    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
    if (plVar13 != (longlong *)0x0) {
      plVar8 = (longlong *)FUN_142cd9440(tstate,2);
      pcVar14 = pcStack_258;
      iVar5 = (int)*plVar13 + 1;
      if (iVar5 != 0) {
        *(int *)plVar13 = iVar5;
      }
      plVar8[3] = (longlong)plVar13;
      plVar13 = (longlong *)FUN_142cd7b20(tstate,pcStack_258,classes_const_1795_shape);
      if (plVar13 == (longlong *)0x0) {
LAB_1408bedce:
        lStack_318 = *plVar9;
        *plVar9 = 0;
        uVar22 = 0x2194;
LAB_1408beeaf:
        plVar13 = plStack_2d8;
        pcVar14 = pcStack_2c8;
        plVar9 = plStack_2d0;
        lVar10 = lStack_318;
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
          plVar13 = plStack_2d8;
          pcVar14 = pcStack_2c8;
          plVar9 = plStack_2d0;
          lVar10 = lStack_318;
        }
        goto LAB_1408bef49;
      }
      lVar10 = FUN_140008f40(tstate,plVar13,_DAT_142d9a268,1);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      if (lVar10 == 0) goto LAB_1408bedce;
      plVar13 = (longlong *)FUN_142cd9440(tstate,2);
      plVar13[3] = lVar10;
      plVar11 = (longlong *)FUN_142cd7b20(tstate,pcVar14,classes_const_1795_shape);
      if (plVar11 == (longlong *)0x0) {
LAB_1408bee7e:
        uStack_310 = 0x2194;
        lStack_318 = *plVar9;
        *plVar9 = 0;
        uVar22 = uStack_310;
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
          uVar22 = uStack_310;
        }
        goto LAB_1408beeaf;
      }
      lVar10 = FUN_140008f40(tstate,plVar11,_DAT_142d9a260,0);
      if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
        (**(code **)(plVar11[1] + 0x30))(plVar11);
      }
      if (lVar10 == 0) goto LAB_1408bee7e;
      plVar13[4] = lVar10;
      plVar8[4] = (longlong)plVar13;
      pcVar14 = pcStack_2a0;
      pcVar18 = pcStack_2a8;
      plVar9 = plStack_2d0;
LAB_1408bca80:
      pcVar20 = pcStack_1b0;
      FUN_140008990(tstate);
      if ((-1 < (int)*plStack_198) && (*plStack_198 = *plStack_198 + -1, *plStack_198 == 0)) {
        (**(code **)(plStack_198[1] + 0x30))();
      }
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      if ((-1 < (int)*plStack_300) && (*plStack_300 = *plStack_300 + -1, *plStack_300 == 0)) {
        (**(code **)(plStack_178[1] + 0x30))();
      }
      if (((plStack_1a0 != (longlong *)0x0) && (-1 < (int)*plStack_1a0)) &&
         (*plStack_1a0 = *plStack_1a0 + -1, *plStack_1a0 == 0)) {
        (**(code **)(plStack_1a0[1] + 0x30))();
      }
      if (((pplStack_168 != (longlong **)0x0) && (-1 < *(int *)pplStack_168)) &&
         (*pplStack_168 = (longlong *)((longlong)*pplStack_168 + -1),
         *pplStack_168 == (longlong *)0x0)) {
        (*(code *)pplStack_168[1][6])();
      }
      if ((-1 < *(int *)pcVar20) &&
         (*(longlong *)pcVar20 = *(longlong *)pcVar20 + -1, *(longlong *)pcVar20 == 0)) {
        (**(code **)(*(longlong *)(pcVar20 + 8) + 0x30))(pcVar20);
      }
      if (((plStack_158 != (longlong *)0x0) && (-1 < (int)*plStack_158)) &&
         (*plStack_158 = *plStack_158 + -1, *plStack_158 == 0)) {
        (**(code **)(plStack_158[1] + 0x30))();
      }
      if (((pcStack_2c8 != (code *)0x0) && (-1 < *(int *)pcStack_2c8)) &&
         (*(longlong *)pcStack_2c8 = *(longlong *)pcStack_2c8 + -1, *(longlong *)pcStack_2c8 == 0))
      {
        (**(code **)(*(longlong *)(pcStack_2c8 + 8) + 0x30))();
      }
      if (((plStack_208 != (longlong *)0x0) && (-1 < (int)*plStack_208)) &&
         (*plStack_208 = *plStack_208 + -1, *plStack_208 == 0)) {
        (**(code **)(plStack_208[1] + 0x30))();
      }
      if (((pcStack_1d0 != (code *)0x0) && (-1 < *(int *)pcStack_1d0)) &&
         (*(longlong *)pcStack_1d0 = *(longlong *)pcStack_1d0 + -1, *(longlong *)pcStack_1d0 == 0))
      {
        (**(code **)(*(longlong *)(pcStack_1d0 + 8) + 0x30))();
      }
      if (((pcStack_280 != (code *)0x0) && (-1 < *(int *)pcStack_280)) &&
         (*(longlong *)pcStack_280 = *(longlong *)pcStack_280 + -1, *(longlong *)pcStack_280 == 0))
      {
        (**(code **)(*(longlong *)(pcStack_280 + 8) + 0x30))();
      }
      if (((plStack_200 != (longlong *)0x0) && (-1 < (int)*plStack_200)) &&
         (*plStack_200 = *plStack_200 + -1, *plStack_200 == 0)) {
        (**(code **)(plStack_200[1] + 0x30))();
      }
      if (((plStack_1c8 != (longlong *)0x0) && (-1 < (int)*plStack_1c8)) &&
         (*plStack_1c8 = *plStack_1c8 + -1, *plStack_1c8 == 0)) {
        (**(code **)(plStack_1c8[1] + 0x30))();
      }
      if (((plStack_210 != (longlong *)0x0) && (-1 < (int)*plStack_210)) &&
         (*plStack_210 = *plStack_210 + -1, *plStack_210 == 0)) {
        (**(code **)(plStack_210[1] + 0x30))();
      }
      if (((plStack_240 != (longlong *)0x0) && (-1 < (int)*plStack_240)) &&
         (*plStack_240 = *plStack_240 + -1, *plStack_240 == 0)) {
        (**(code **)(plStack_240[1] + 0x30))();
      }
      if (((plStack_238 != (longlong *)0x0) && (-1 < (int)*plStack_238)) &&
         (*plStack_238 = *plStack_238 + -1, *plStack_238 == 0)) {
        (**(code **)(plStack_238[1] + 0x30))();
      }
      if (((plStack_230 != (longlong *)0x0) && (-1 < (int)*plStack_230)) &&
         (*plStack_230 = *plStack_230 + -1, *plStack_230 == 0)) {
        (**(code **)(plStack_230[1] + 0x30))();
      }
      if (((pcStack_228 != (code *)0x0) && (-1 < *(int *)pcStack_228)) &&
         (*(longlong *)pcStack_228 = *(longlong *)pcStack_228 + -1, *(longlong *)pcStack_228 == 0))
      {
        (**(code **)(*(longlong *)(pcStack_228 + 8) + 0x30))();
      }
      if (((plStack_220 != (longlong *)0x0) && (-1 < (int)*plStack_220)) &&
         (*plStack_220 = *plStack_220 + -1, *plStack_220 == 0)) {
        (**(code **)(plStack_220[1] + 0x30))();
      }
      if (((plStack_250 != (longlong *)0x0) && (-1 < (int)*plStack_250)) &&
         (*plStack_250 = *plStack_250 + -1, *plStack_250 == 0)) {
        (**(code **)(plStack_250[1] + 0x30))();
      }
      if (((plStack_1c0 != (longlong *)0x0) && (-1 < (int)*plStack_1c0)) &&
         (*plStack_1c0 = *plStack_1c0 + -1, *plStack_1c0 == 0)) {
        (**(code **)(plStack_1c0[1] + 0x30))();
      }
      if (((plStack_248 != (longlong *)0x0) && (-1 < (int)*plStack_248)) &&
         (*plStack_248 = *plStack_248 + -1, *plStack_248 == 0)) {
        (**(code **)(plStack_248[1] + 0x30))();
      }
      if (((plStack_218 != (longlong *)0x0) && (-1 < (int)*plStack_218)) &&
         (*plStack_218 = *plStack_218 + -1, *plStack_218 == 0)) {
        (**(code **)(plStack_218[1] + 0x30))();
      }
      if (((plStack_1f8 != (longlong *)0x0) && (-1 < (int)*plStack_1f8)) &&
         (*plStack_1f8 = *plStack_1f8 + -1, *plStack_1f8 == 0)) {
        (**(code **)(plStack_1f8[1] + 0x30))();
      }
      if (((plStack_1f0 != (longlong *)0x0) && (-1 < (int)*plStack_1f0)) &&
         (*plStack_1f0 = *plStack_1f0 + -1, *plStack_1f0 == 0)) {
        (**(code **)(plStack_1f0[1] + 0x30))();
      }
      if (((plStack_150 != (longlong *)0x0) && (-1 < (int)*plStack_150)) &&
         (*plStack_150 = *plStack_150 + -1, *plStack_150 == 0)) {
        (**(code **)(plStack_150[1] + 0x30))();
      }
      if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
         (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
        (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
      }
      if (((plStack_1e8 != (longlong *)0x0) && (-1 < (int)*plStack_1e8)) &&
         (*plStack_1e8 = *plStack_1e8 + -1, *plStack_1e8 == 0)) {
        (**(code **)(plStack_1e8[1] + 0x30))();
      }
      if (((pcVar18 != (code *)0x0) && (-1 < *(int *)pcVar18)) &&
         (*(longlong *)pcVar18 = *(longlong *)pcVar18 + -1, *(longlong *)pcVar18 == 0)) {
        (**(code **)(*(longlong *)(pcVar18 + 8) + 0x30))(pcVar18);
      }
      if (((plStack_290 != (longlong *)0x0) && (-1 < (int)*plStack_290)) &&
         (*plStack_290 = *plStack_290 + -1, *plStack_290 == 0)) {
        (**(code **)(plStack_290[1] + 0x30))();
      }
      if (((pcStack_268 != (code *)0x0) && (-1 < *(int *)pcStack_268)) &&
         (*(longlong *)pcStack_268 = *(longlong *)pcStack_268 + -1, *(longlong *)pcStack_268 == 0))
      {
        (**(code **)(*(longlong *)(pcStack_268 + 8) + 0x30))();
      }
      if (((plStack_1e0 != (longlong *)0x0) && (-1 < (int)*plStack_1e0)) &&
         (*plStack_1e0 = *plStack_1e0 + -1, *plStack_1e0 == 0)) {
        (**(code **)(plStack_1e0[1] + 0x30))();
      }
      if (((plStack_1d8 != (longlong *)0x0) && (-1 < (int)*plStack_1d8)) &&
         (*plStack_1d8 = *plStack_1d8 + -1, *plStack_1d8 == 0)) {
        (**(code **)(plStack_1d8[1] + 0x30))();
      }
      if (((plStack_278 != (longlong *)0x0) && (-1 < (int)*plStack_278)) &&
         (*plStack_278 = *plStack_278 + -1, *plStack_278 == 0)) {
        (**(code **)(plStack_278[1] + 0x30))();
      }
      if (((plStack_160 != (longlong *)0x0) && (-1 < (int)*plStack_160)) &&
         (*plStack_160 = *plStack_160 + -1, *plStack_160 == 0)) {
        (**(code **)(plStack_160[1] + 0x30))();
      }
      if (((plStack_180 != (longlong *)0x0) && (-1 < (int)*plStack_180)) &&
         (*plStack_180 = *plStack_180 + -1, *plStack_180 == 0)) {
        (**(code **)(plStack_180[1] + 0x30))();
      }
      if (((plStack_1b8 != (longlong *)0x0) && (-1 < (int)*plStack_1b8)) &&
         (*plStack_1b8 = *plStack_1b8 + -1, *plStack_1b8 == 0)) {
        (**(code **)(plStack_1b8[1] + 0x30))();
      }
      if (((plStack_190 != (longlong *)0x0) && (-1 < (int)*plStack_190)) &&
         (*plStack_190 = *plStack_190 + -1, *plStack_190 == 0)) {
        (**(code **)(plStack_190[1] + 0x30))();
      }
      if (((plStack_188 != (longlong *)0x0) && (-1 < (int)*plStack_188)) &&
         (*plStack_188 = *plStack_188 + -1, *plStack_188 == 0)) {
        (**(code **)(plStack_188[1] + 0x30))();
      }
      if ((-1 < (int)*plStack_138) && (*plStack_138 = *plStack_138 + -1, *plStack_138 == 0)) {
        (**(code **)(plStack_138[1] + 0x30))();
      }
      if ((-1 < (int)*plStack_148) && (*plStack_148 = *plStack_148 + -1, *plStack_148 == 0)) {
        (**(code **)(plStack_148[1] + 0x30))();
      }
      if ((-1 < *(int *)pcStack_140) &&
         (*(longlong *)pcStack_140 = *(longlong *)pcStack_140 + -1, *(longlong *)pcStack_140 == 0))
      {
        (**(code **)(*(longlong *)(pcStack_140 + 8) + 0x30))(pcStack_140);
      }
      goto LAB_1408bf751;
    }
    FUN_142cd4900(tstate,&lStack_318,classes_const_1816_pontos);
    FUN_1400048d0(tstate,lStack_318);
    uVar22 = 0x2194;
    plVar13 = plStack_2d8;
    pcVar14 = pcStack_2c8;
    plVar9 = plStack_2d0;
    lVar10 = lStack_318;
  }
  goto LAB_1408bef49;
code_r0x0001408bb15f:
  plVar13 = plVar11;
  if (iVar5 == 1) goto LAB_1408badc0;
  plVar16 = (longlong *)FUN_142cd7b20(tstate,plVar12,classes_const_1795_shape);
  if (plVar16 != (longlong *)0x0) {
    plVar15 = (longlong *)FUN_140008f40(tstate,plVar16,_DAT_142d9a268,1);
    if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
      (**(code **)(plVar16[1] + 0x30))();
    }
    if (plVar15 != (longlong *)0x0) {
      plVar16 = (longlong *)FUN_142cd7b20(tstate,plStack_1a8,classes_const_1795_shape);
      if (plVar16 != (longlong *)0x0) {
        plVar8 = (longlong *)FUN_140008f40(tstate,plVar16,_DAT_142d9a268);
        if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
          (**(code **)(plVar16[1] + 0x30))();
        }
        if (plVar8 == (longlong *)0x0) {
LAB_1408bc469:
          lStack_318 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
            (**(code **)(plVar15[1] + 0x30))();
          }
LAB_1408bc49d:
          uStack_310 = 0x2168;
          lVar10 = lStack_318;
          plVar8 = plStack_2f8;
          goto LAB_1408bc669;
        }
        iVar5 = FUN_142ce08d0(plVar15,plVar8);
        if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))();
        }
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))();
        }
        plVar8 = plStack_2d0;
        if (iVar5 == -1) {
          lVar10 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
          uStack_310 = 0x2168;
          plVar8 = plStack_2f8;
          goto LAB_1408bc669;
        }
        if (iVar5 == 1) goto LAB_1408badc0;
        if (plStack_2d0[2] != 0) {
          plVar13 = (longlong *)
                    FUN_142cd7b20(tstate,plStack_2d0[2],classes_const_1797_matchTemplate);
          if (plVar13 == (longlong *)0x0) {
            lVar10 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            uStack_310 = 0x216a;
            plVar8 = plStack_2f8;
            goto LAB_1408bc669;
          }
          if (plVar8[2] != 0) {
            plVar15 = (longlong *)
                      FUN_142cd7b20(tstate,plVar8[2],classes_const_1798_TM_CCOEFF_NORMED);
            plVar8 = plStack_1a8;
            if (plVar15 != (longlong *)0x0) {
              *(undefined4 *)(plStack_2d8 + 5) = 0x216a;
              plStack_a0 = plStack_1a8;
              plStack_98 = plVar12;
              plStack_90 = plVar15;
              plVar11 = (longlong *)FUN_142cc5e90(tstate,plVar13,&plStack_a0);
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))();
              }
              if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
                (**(code **)(plVar15[1] + 0x30))();
              }
              plVar13 = plStack_230;
              if (plVar11 == (longlong *)0x0) {
                lVar10 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                uStack_310 = 0x216a;
                plVar8 = plStack_2f8;
                plVar11 = plStack_2e0;
                goto LAB_1408bc669;
              }
              plVar12 = plVar11;
              if (((plStack_230 != (longlong *)0x0) && (-1 < (int)*plStack_230)) &&
                 (*plStack_230 = *plStack_230 + -1, *plStack_230 == 0)) {
                plVar12 = plStack_230 + 1;
                plStack_230 = plVar11;
                (**(code **)(*plVar12 + 0x30))(plVar13);
                plVar12 = plStack_230;
              }
              plStack_230 = plVar12;
              plVar13 = plStack_198;
              if (plStack_198[2] == 0) {
LAB_1408bc2ae:
                FUN_142cd4900(tstate,&lStack_318,classes_const_1799__np);
                FUN_1400048d0(tstate,lStack_318);
                uStack_310 = 0x216b;
                lVar10 = lStack_318;
                plVar8 = plStack_2f8;
                plVar11 = plStack_2e0;
                goto LAB_1408bc669;
              }
              plVar12 = (longlong *)FUN_142cd7b20(tstate,plStack_198[2],classes_const_1800_full);
              if (plVar12 == (longlong *)0x0) {
                lVar10 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                uStack_310 = 0x216b;
                plVar8 = plStack_2f8;
                plVar11 = plStack_2e0;
                goto LAB_1408bc669;
              }
              plVar8 = (longlong *)FUN_142cd7b20(tstate,plVar8,classes_const_1795_shape);
              puVar19 = classes_const_1801__9_0;
              if (plVar8 == (longlong *)0x0) {
                lStack_318 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                  (**(code **)(plVar12[1] + 0x30))(plVar12);
                  uStack_310 = 0x216b;
                  lVar10 = lStack_318;
                  plVar8 = plStack_2f8;
                  plVar11 = plStack_2e0;
                  goto LAB_1408bc669;
                }
LAB_1408bc271:
                uStack_310 = 0x216b;
                lVar10 = lStack_318;
                plVar8 = plStack_2f8;
                plVar11 = plStack_2e0;
                goto LAB_1408bc669;
              }
              if (plVar13[2] == 0) {
                if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                  (**(code **)(plVar12[1] + 0x30))(plVar12);
                }
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                goto LAB_1408bc2ae;
              }
              plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar13[2],classes_const_1802_float32);
              if (plVar13 == (longlong *)0x0) {
                lStack_318 = *(longlong *)(tstate + 0x70);
                *(undefined8 *)(tstate + 0x70) = 0;
                if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                  (**(code **)(plVar12[1] + 0x30))(plVar12);
                }
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                goto LAB_1408bc271;
              }
              *(undefined4 *)(plStack_2d8 + 5) = 0x216b;
              puStack_80 = puVar19;
              plStack_88 = plVar8;
              plStack_78 = plVar13;
              pcVar14 = (code *)FUN_142cc5e90(tstate,plVar12,&plStack_88);
              if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                (**(code **)(plVar12[1] + 0x30))();
              }
              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))();
              }
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))();
              }
              pcVar20 = pcStack_228;
              if (pcVar14 == (code *)0x0) {
                uStack_310 = 0x216b;
                lStack_318 = *plStack_2c0;
LAB_1408bc218:
                *plStack_2c0 = 0;
                lVar10 = lStack_318;
                plVar8 = plStack_2f8;
                plVar11 = plStack_2e0;
                tstate = puStack_2f0;
                goto LAB_1408bc669;
              }
              pcVar18 = pcVar14;
              if (((pcStack_228 != (code *)0x0) && (-1 < *(int *)pcStack_228)) &&
                 (*(longlong *)pcStack_228 = *(longlong *)pcStack_228 + -1,
                 *(longlong *)pcStack_228 == 0)) {
                pcVar18 = pcStack_228 + 8;
                pcStack_228 = pcVar14;
                (**(code **)(*(longlong *)pcVar18 + 0x30))(pcVar20);
                pcVar18 = pcStack_228;
              }
              pcStack_228 = pcVar18;
              plVar13 = (longlong *)FUN_142cd7b20(puStack_2f0,plVar11,classes_const_1795_shape);
              if (plVar13 == (longlong *)0x0) {
LAB_1408bc1d4:
                uStack_310 = 0x216c;
                lVar10 = *plStack_2c0;
                *plStack_2c0 = 0;
                plVar8 = plStack_2f8;
                plVar11 = plStack_2e0;
                tstate = puStack_2f0;
                goto LAB_1408bc669;
              }
              plVar8 = (longlong *)FUN_1400099f0(plVar13);
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              puVar19 = puStack_2f0;
              if (plVar8 == (longlong *)0x0) goto LAB_1408bc1d4;
              pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,2);
              plVar13 = (longlong *)FUN_140009d90(puStack_2f0,&lStack_318,plVar8,0);
              if (plVar13 == (longlong *)0x0) {
                plVar13 = (longlong *)0x0;
              }
              else {
                pcStack_458 = (code *)CONCAT44(pcStack_458._4_4_,2);
                plVar12 = (longlong *)FUN_140009d90(puVar19,&lStack_318,plVar8,1);
                if (plVar12 != (longlong *)0x0) {
                  cVar4 = FUN_140009c30(puVar19,&lStack_318,plVar8,2);
                  if (cVar4 != '\0') {
                    if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                      (**(code **)(plVar8[1] + 0x30))(plVar8);
                    }
                    iVar5 = (int)*plVar13 + 1;
                    if (iVar5 != 0) {
                      *(int *)plVar13 = iVar5;
                    }
                    plVar8 = plVar13;
                    if (((plStack_220 != (longlong *)0x0) && (-1 < (int)*plStack_220)) &&
                       (*plStack_220 = *plStack_220 + -1, *plStack_220 == 0)) {
                      plVar8 = plStack_220 + 1;
                      plStack_220 = plVar13;
                      (**(code **)(*plVar8 + 0x30))();
                      plVar8 = plStack_220;
                    }
                    plStack_220 = plVar8;
                    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                      (**(code **)(plVar13[1] + 0x30))(plVar13);
                    }
                    iVar5 = (int)*plVar12 + 1;
                    if (iVar5 != 0) {
                      *(int *)plVar12 = iVar5;
                    }
                    plVar8 = plVar12;
                    if (((plStack_250 != (longlong *)0x0) && (-1 < (int)*plStack_250)) &&
                       (*plStack_250 = *plStack_250 + -1, *plStack_250 == 0)) {
                      plVar8 = plStack_250 + 1;
                      plStack_250 = plVar12;
                      (**(code **)(*plVar8 + 0x30))();
                      plVar8 = plStack_250;
                    }
                    plStack_250 = plVar8;
                    if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                      (**(code **)(plVar12[1] + 0x30))(plVar12);
                    }
                    plVar8 = (longlong *)FUN_142cbf590(plVar9,classes_const_605_2);
                    if (plVar8 != (longlong *)0x0) {
                      plVar11 = (longlong *)FUN_142cbf590(plVar9,classes_const_605_2);
                      if (plVar11 != (longlong *)0x0) {
                        plVar13 = (longlong *)FUN_142cbe7f0(plVar11,plVar13);
                        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                          (**(code **)(plVar11[1] + 0x30))();
                        }
                        puVar19 = puStack_2f0;
                        if (plVar13 != (longlong *)0x0) {
                          lVar10 = FUN_142cdd880(puStack_2f0,plVar8,plVar13,_Py_NoneStruct_exref);
                          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                            (**(code **)(plVar8[1] + 0x30))(plVar8);
                          }
                          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                            (**(code **)(plVar13[1] + 0x30))(plVar13);
                          }
                          plVar13 = (longlong *)FUN_142cd9440(puVar19,2);
                          plVar13[3] = lVar10;
                          plVar8 = (longlong *)FUN_142cbf590(plVar9,classes_const_605_2);
                          if (plVar8 == (longlong *)0x0) {
                            lStack_318 = *plStack_2c0;
                            *plStack_2c0 = 0;
                          }
                          else {
                            plVar11 = (longlong *)FUN_142cbf590(plVar9,classes_const_605_2);
                            if (plVar11 != (longlong *)0x0) {
                              plVar12 = (longlong *)FUN_142cbe7f0(plVar11,plStack_250);
                              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0))
                              {
                                (**(code **)(plVar11[1] + 0x30))(plVar11);
                              }
                              if (plVar12 != (longlong *)0x0) {
                                lVar10 = FUN_142cdd880(puStack_2f0,plVar8,plVar12,
                                                       _Py_NoneStruct_exref);
                                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                                }
                                if ((-1 < (int)*plVar12) &&
                                   (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                                  (**(code **)(plVar12[1] + 0x30))(plVar12);
                                }
                                tstate = puStack_2f0;
                                plVar13[4] = lVar10;
                                cVar4 = FUN_140029450(puStack_2f0,pcVar14,plVar13);
                                if ((-1 < (int)*plVar13) &&
                                   (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                  (**(code **)(plVar13[1] + 0x30))();
                                }
                                pcVar20 = pcStack_280;
                                if (cVar4 == '\0') {
                                  uStack_310 = 0x216d;
                                  lVar10 = *plStack_2c0;
                                  *plStack_2c0 = 0;
                                  plVar8 = plStack_2f8;
                                  plVar11 = plStack_2e0;
                                  goto LAB_1408bc669;
                                }
                                if (pcStack_280 == (code *)0x0) {
                                  FUN_142cd4900(tstate,&lStack_318,classes_const_1634_mapa);
                                  FUN_1400048d0(tstate,lStack_318);
                                  lVar10 = lStack_318;
                                  plVar8 = plStack_2f8;
                                  plVar11 = plStack_2e0;
                                  goto LAB_1408bc669;
                                }
                                if (pcStack_280 == _Py_NoneStruct_exref) {
                                  if (*(int *)pcVar14 + 1 != 0) {
                                    *(int *)pcVar14 = *(int *)pcVar14 + 1;
                                  }
                                }
                                else {
                                  if (plStack_198[2] == 0) {
                                    FUN_142cd4900(tstate,&lStack_318,classes_const_1799__np);
                                    FUN_1400048d0(tstate,lStack_318);
                                    lVar10 = lStack_318;
                                    plVar8 = plStack_2f8;
                                    plVar11 = plStack_2e0;
                                    goto LAB_1408bc669;
                                  }
                                  plVar13 = (longlong *)
                                            FUN_142cd7b20(tstate,plStack_198[2],
                                                          classes_const_1803_maximum);
                                  if (plVar13 == (longlong *)0x0) {
                                    lVar10 = *plStack_2c0;
                                    *plStack_2c0 = 0;
                                    plVar8 = plStack_2f8;
                                    plVar11 = plStack_2e0;
                                    goto LAB_1408bc669;
                                  }
                                  *(undefined4 *)(plStack_2d8 + 5) = 0x216e;
                                  pcStack_e0 = pcVar20;
                                  pcStack_d8 = pcVar14;
                                  pcVar14 = (code *)FUN_142cc4ec0(tstate,plVar13,&pcStack_e0);
                                  if ((-1 < (int)*plVar13) &&
                                     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                                    (**(code **)(plVar13[1] + 0x30))();
                                  }
                                  if (pcVar14 == (code *)0x0) {
                                    lVar10 = *(longlong *)(tstate + 0x70);
                                    *(undefined8 *)(tstate + 0x70) = 0;
                                    plVar8 = plStack_2f8;
                                    plVar11 = plStack_2e0;
                                    goto LAB_1408bc669;
                                  }
                                }
                                pcStack_280 = pcVar14;
                                if ((-1 < *(int *)pcVar20) &&
                                   (*(longlong *)pcVar20 = *(longlong *)pcVar20 + -1,
                                   *(longlong *)pcVar20 == 0)) {
                                  (**(code **)(*(longlong *)(pcVar20 + 8) + 0x30))();
                                }
                                cVar4 = FUN_140008af0();
                                plVar13 = plStack_2e0;
                                if (cVar4 == '\0') {
                                  lVar10 = *(longlong *)(tstate + 0x70);
                                  *(undefined8 *)(tstate + 0x70) = 0;
                                  uStack_310 = 0x2165;
                                  plVar8 = plStack_2f8;
                                  plVar11 = plStack_2e0;
                                  goto LAB_1408bc669;
                                }
                                goto LAB_1408badc0;
                              }
                            }
                            lStack_318 = *plStack_2c0;
                            *plStack_2c0 = 0;
                            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                              (**(code **)(plVar8[1] + 0x30))(plVar8);
                            }
                          }
                          uStack_310 = 0x216d;
                          lVar10 = lStack_318;
                          plVar8 = plStack_2f8;
                          plVar11 = plStack_2e0;
                          tstate = puStack_2f0;
                          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                            (**(code **)(plVar13[1] + 0x30))(plVar13);
                            lVar10 = lStack_318;
                            plVar8 = plStack_2f8;
                            plVar11 = plStack_2e0;
                            tstate = puStack_2f0;
                          }
                          goto LAB_1408bc669;
                        }
                      }
                      lStack_318 = *plStack_2c0;
                      *plStack_2c0 = 0;
                      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                        (**(code **)(plVar8[1] + 0x30))();
                      }
                      uStack_310 = 0x216d;
                      lVar10 = lStack_318;
                      plVar8 = plStack_2f8;
                      plVar11 = plStack_2e0;
                      tstate = puStack_2f0;
                      goto LAB_1408bc669;
                    }
                    lStack_318 = *plStack_2c0;
                    uStack_310 = 0x216d;
                    goto LAB_1408bc218;
                  }
                  goto LAB_1408bc16d;
                }
              }
              plVar12 = (longlong *)0x0;
LAB_1408bc16d:
              lVar10 = lStack_318;
              uStack_310 = 0x216c;
              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))(plVar8);
              }
              if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
                 (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              plVar8 = plStack_2f8;
              plVar11 = plStack_2e0;
              tstate = puStack_2f0;
              if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
                 (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
                (**(code **)(plVar12[1] + 0x30))(plVar12);
                plVar8 = plStack_2f8;
                plVar11 = plStack_2e0;
                tstate = puStack_2f0;
              }
              goto LAB_1408bc669;
            }
            lStack_318 = *(longlong *)(tstate + 0x70);
            *(undefined8 *)(tstate + 0x70) = 0;
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
              uStack_310 = 0x216a;
              lVar10 = lStack_318;
              plVar8 = plStack_2f8;
              goto LAB_1408bc669;
            }
            goto LAB_1408bc3cc;
          }
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
        }
        FUN_142cd4900(tstate,&lStack_318,classes_const_1786__cv2);
        FUN_1400048d0(tstate,lStack_318);
LAB_1408bc3cc:
        uStack_310 = 0x216a;
        lVar10 = lStack_318;
        plVar8 = plStack_2f8;
        goto LAB_1408bc669;
      }
      lStack_318 = *(longlong *)(tstate + 0x70);
      *(undefined8 *)(tstate + 0x70) = 0;
      if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
        (**(code **)(plVar15[1] + 0x30))();
      }
      goto LAB_1408bc454;
    }
  }
LAB_1408bc446:
  lStack_318 = *(longlong *)(tstate + 0x70);
  *(undefined8 *)(tstate + 0x70) = 0;
LAB_1408bc454:
  uStack_310 = 0x2168;
  lVar10 = lStack_318;
  goto LAB_1408bc669;
LAB_1408bd2f0:
  do {
    do {
      if (*(code **)(plVar12[1] + 0xe0) == (code *)0x0) {
        Nuitka_helper_142ce5050(&UNK_142d0adb0,plVar12);
        puVar19 = tstate;
LAB_1408be618:
        plVar11 = (longlong *)*plVar9;
        if (plVar11 != (longlong *)0x0) {
          cVar4 = FUN_140008d40(puVar19,plVar11,*(undefined8 *)PyExc_StopIteration_exref);
          if (cVar4 == '\0') {
            lVar10 = *plVar9;
            *plVar9 = 0;
            lStack_318 = 0;
            uVar22 = uStack_310;
            if (plVar13 != (longlong *)0x0) goto LAB_1408be73b;
            goto LAB_1408be751;
          }
          *plVar9 = 0;
          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
            (**(code **)(plVar11[1] + 0x30))(plVar11);
          }
        }
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
          (**(code **)(plVar12[1] + 0x30))(plVar12);
        }
        tstate = puStack_2f0;
        if (pcStack_2a0 == (code *)0x0) {
          FUN_142cd4900(puStack_2f0,&lStack_318,classes_const_1255_melhor);
          FUN_1400048d0(tstate,lStack_318);
          uVar22 = 0x218c;
          plVar13 = plStack_2d8;
          pcVar14 = pcStack_2c8;
          plVar9 = plStack_2d0;
          lVar10 = lStack_318;
          goto LAB_1408bef49;
        }
        if (pcStack_2a0 == _Py_NoneStruct_exref) {
          pcVar14 = pcStack_2a0;
          pcVar18 = pcStack_2a8;
          plVar9 = plStack_2d0;
          if (*(int *)classes_const_1357___type____T____items____None__None__ + 1 != 0) {
            *(int *)classes_const_1357___type____T____items____None__None__ =
                 *(int *)classes_const_1357___type____T____items____None__None__ + 1;
          }
          goto LAB_1408bca80;
        }
        plVar13 = (longlong *)FUN_142cd8f90(puVar19,0);
        plStack_160 = plVar13;
        plStack_180 = (longlong *)FUN_142cd8f90(puVar19,0);
        tstate = puStack_2f0;
        plVar8 = (longlong *)FUN_142cc2e30(puStack_2f0,plVar8);
        if (plVar8 == (longlong *)0x0) {
          lVar10 = *plVar9;
          *plVar9 = 0;
          uVar22 = 0x2190;
          plVar13 = plStack_2d8;
          pcVar14 = pcStack_2c8;
          plVar9 = plStack_2d0;
          goto LAB_1408bef49;
        }
        plVar11 = (longlong *)FUN_140009850(tstate,plVar8);
        plStack_288 = plVar11;
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if (plVar11 != (longlong *)0x0) {
          plStack_2b0 = (longlong *)0x0;
          plVar8 = (longlong *)(**(code **)(plVar11[1] + 0xe0))(plVar11);
          plVar12 = (longlong *)0x0;
          plVar15 = plStack_290;
          goto joined_r0x0001408be85c;
        }
        lVar10 = *plVar9;
        *plVar9 = 0;
        uVar22 = 0x2190;
        plVar13 = plStack_2d8;
        pcVar14 = pcStack_2c8;
        plVar9 = plStack_2d0;
        goto LAB_1408bef49;
      }
      plVar11 = (longlong *)(**(code **)(plVar12[1] + 0xe0))(plVar12);
      plVar15 = plStack_1e8;
      pcVar14 = pcStack_2a8;
      puVar19 = puStack_2f0;
      plStack_2b8 = plVar11;
      if (plVar11 == (longlong *)0x0) goto LAB_1408be618;
      plStack_2e0 = plVar11;
      if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))();
      }
      iVar5 = (int)*plVar11 + 1;
      if (iVar5 != 0) {
        *(int *)plVar11 = iVar5;
      }
      plStack_1e8 = plVar11;
      if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
         (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
        (**(code **)(plVar15[1] + 0x30))();
      }
      pcStack_2a8 = (code *)FUN_142cd8f90(puStack_2f0,0);
      if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
         (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
        (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
      }
      puVar19 = puStack_2f0;
      plVar15 = (longlong *)FUN_142cc2e30(puStack_2f0,plVar8);
      plVar13 = plVar11;
      if (plVar15 == (longlong *)0x0) {
        lVar10 = *plVar9;
        *plVar9 = 0;
        uVar22 = 0x217e;
        goto LAB_1408be73b;
      }
      plVar9 = (longlong *)FUN_140009850(puVar19,plVar15);
      if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
        (**(code **)(plVar15[1] + 0x30))();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar10 = *plStack_2f8;
        *plStack_2f8 = 0;
        uVar22 = 0x217e;
        goto LAB_1408be73b;
      }
      plVar16 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
      plVar13 = (longlong *)0x0;
      plVar12 = plStack_2f8;
      plVar15 = plStack_290;
      while (plVar21 = plVar16, plStack_2f8 = plVar12, plStack_290 = plVar15,
            plVar21 != (longlong *)0x0) {
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))();
        }
        iVar5 = (int)*plVar21 + 1;
        if (iVar5 != 0) {
          *(int *)plVar21 = iVar5;
        }
        plStack_290 = plVar21;
        if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
           (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))();
        }
        if (pcStack_2a8 == (code *)0x0) {
          FUN_142cd4900(puVar19,&lStack_318,classes_const_1814_pts);
          FUN_1400048d0(puVar19,lStack_318);
          uStack_310 = 0x217f;
          goto LAB_1408be182;
        }
        plVar13 = (longlong *)FUN_140008da0(puVar19,pcStack_2c8,plVar21);
        if (plVar13 == (longlong *)0x0) goto LAB_1408be103;
        plVar8 = (longlong *)FUN_140008da0(puVar19,plVar11,plVar21);
        if (plVar8 == (longlong *)0x0) {
          lStack_318 = *plStack_2f8;
          *plStack_2f8 = 0;
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          uStack_310 = 0x217f;
          goto LAB_1408be182;
        }
        plVar11 = (longlong *)FUN_140008da0(puStack_2f0,plVar13,plVar8);
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        puVar19 = puStack_2f0;
        if (plVar11 == (longlong *)0x0) {
LAB_1408be103:
          lStack_318 = *plStack_2f8;
          uStack_310 = 0x217f;
          plVar12 = plStack_2f8;
          goto LAB_1408be17b;
        }
        lVar10 = FUN_140008f40(puStack_2f0,plVar11,_DAT_142d9a268,1);
        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
          (**(code **)(plVar11[1] + 0x30))(plVar11);
        }
        if (lVar10 == 0) goto LAB_1408be103;
        plVar13 = (longlong *)FUN_142cd9440(puVar19,2);
        plVar13[3] = lVar10;
        plVar8 = (longlong *)FUN_140008da0(puVar19,pcStack_2c8,plVar21);
        if (plVar8 == (longlong *)0x0) {
LAB_1408be0c9:
          lStack_318 = *plStack_2f8;
LAB_1408be0dc:
          *plStack_2f8 = 0;
LAB_1408be0e3:
          uStack_310 = 0x217f;
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          goto LAB_1408be182;
        }
        plVar11 = (longlong *)FUN_140008da0(puVar19,plStack_2b8,plVar21);
        if (plVar11 == (longlong *)0x0) {
          lStack_318 = *plStack_2f8;
          *plStack_2f8 = 0;
          if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
            (**(code **)(plVar8[1] + 0x30))(plVar8);
          }
          goto LAB_1408be0e3;
        }
        plVar12 = (longlong *)FUN_140008da0(puStack_2f0,plVar8,plVar11);
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
          (**(code **)(plVar11[1] + 0x30))(plVar11);
        }
        puVar19 = puStack_2f0;
        if (plVar12 == (longlong *)0x0) goto LAB_1408be0c9;
        lVar10 = FUN_140008f40(puStack_2f0,plVar12,classes_const_605_2,2);
        if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
          (**(code **)(plVar12[1] + 0x30))(plVar12);
        }
        if (lVar10 == 0) {
          lStack_318 = *plStack_2f8;
          goto LAB_1408be0dc;
        }
        plVar13[4] = lVar10;
        FUN_142cd71a0(pcStack_2a8,plVar13);
        cVar4 = FUN_140008af0(puVar19);
        if (cVar4 == '\0') {
          uStack_310 = 0x217e;
          lStack_318 = *plStack_2f8;
          plVar12 = plStack_2f8;
          goto LAB_1408be17b;
        }
        plVar16 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
        plVar11 = plStack_2b8;
        plVar13 = plVar21;
        plVar8 = plStack_2e8;
        plVar12 = plStack_2f8;
        plVar15 = plStack_290;
      }
      plVar11 = (longlong *)*plVar12;
      if (plVar11 != (longlong *)0x0) {
        cVar4 = FUN_140008d40(puVar19,plVar11,*(undefined8 *)PyExc_StopIteration_exref);
        if (cVar4 != '\0') {
          *plVar12 = 0;
          if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
            (**(code **)(plVar11[1] + 0x30))(plVar11);
          }
          goto LAB_1408bd677;
        }
        lStack_318 = *plVar12;
        uStack_310 = 0x217e;
        plVar21 = plVar13;
LAB_1408be17b:
        *plVar12 = 0;
LAB_1408be182:
        lVar10 = lStack_318;
        lStack_318 = 0;
        if (((plVar21 != (longlong *)0x0) && (-1 < (int)*plVar21)) &&
           (*plVar21 = *plVar21 + -1, *plVar21 == 0)) {
          (**(code **)(plVar21[1] + 0x30))(plVar21);
        }
        plVar12 = plStack_2c0;
        plVar13 = plStack_2e0;
        uVar22 = uStack_310;
        if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
          lVar17 = plVar9[1];
LAB_1408be358:
          (**(code **)(lVar17 + 0x30))(plVar9);
          plVar12 = plStack_2c0;
          plVar13 = plStack_2e0;
          uVar22 = uStack_310;
        }
        goto LAB_1408be73b;
      }
LAB_1408bd677:
      pcVar14 = pcStack_268;
      if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
        (**(code **)(plVar9[1] + 0x30))(plVar9);
      }
      pcVar20 = _Py_FalseStruct_exref;
      pcStack_268 = _Py_FalseStruct_exref;
      if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
        *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
      }
      if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
         (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
        (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))();
      }
      plVar13 = (longlong *)FUN_142cc2e30(puVar19,plVar8);
      if (plVar13 == (longlong *)0x0) {
LAB_1408be592:
        lVar10 = *plVar12;
        *plVar12 = 0;
        plVar12 = plStack_2c0;
        plVar13 = plStack_2e0;
        uVar22 = 0x2181;
        goto LAB_1408be73b;
      }
      plVar11 = (longlong *)FUN_140009850(puVar19,plVar13);
      plStack_2b0 = plVar11;
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      if (plVar11 == (longlong *)0x0) goto LAB_1408be592;
      plVar13 = (longlong *)(**(code **)(plVar11[1] + 0xe0))(plVar11);
      plVar12 = (longlong *)0x0;
      plStack_1a8 = (longlong *)0x0;
      plVar9 = plStack_2f8;
      tstate = puStack_2f0;
      plVar15 = plStack_1e0;
      while (plStack_2f8 = plVar9, puStack_2f0 = tstate, plStack_288 = plVar13,
            plStack_1e0 = plVar15, plVar13 != (longlong *)0x0) {
        plStack_1a8 = plVar13;
        if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
           (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
          (**(code **)(plVar12[1] + 0x30))();
        }
        iVar5 = (int)*plVar13 + 1;
        if (iVar5 != 0) {
          *(int *)plVar13 = iVar5;
        }
        plStack_1e0 = plVar13;
        if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
           (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))();
        }
        plVar9 = (longlong *)FUN_142cbe6d0(plVar13,_DAT_142d9a268);
        puVar19 = puStack_2f0;
        if (plVar9 == (longlong *)0x0) {
LAB_1408be2ea:
          lVar10 = *plStack_2f8;
          uStack_310 = 0x2182;
          *plStack_2f8 = 0;
          goto LAB_1408be31b;
        }
        plVar8 = (longlong *)Nuitka_helper_142cc2f20(puStack_2f0,plVar9,plVar8);
        if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
          (**(code **)(plVar9[1] + 0x30))(plVar9);
        }
        if (plVar8 == (longlong *)0x0) goto LAB_1408be2ea;
        plVar9 = (longlong *)FUN_140009850(puVar19,plVar8);
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if (plVar9 == (longlong *)0x0) goto LAB_1408be2ea;
        plVar11 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
        plVar15 = (longlong *)0x0;
        puVar19 = puStack_2f0;
        plVar8 = plVar15;
        plVar12 = plVar13;
        if (plVar11 != (longlong *)0x0) {
LAB_1408bd850:
          plVar15 = plVar11;
          plVar11 = plStack_1d8;
          if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
             (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
            (**(code **)(plVar8[1] + 0x30))();
          }
          iVar5 = (int)*plVar15 + 1;
          if (iVar5 != 0) {
            *(int *)plVar15 = iVar5;
          }
          plStack_1d8 = plVar15;
          if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
             (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
            (**(code **)(plVar11[1] + 0x30))();
          }
          if (pcStack_2a8 == (code *)0x0) {
            FUN_142cd4900(puVar19,&lStack_318,classes_const_1814_pts);
            FUN_1400048d0(puVar19,lStack_318);
            uStack_310 = 0x2183;
            goto LAB_1408be28b;
          }
          plVar13 = (longlong *)FUN_140008da0(puVar19,pcStack_2a8,plVar13);
          if (plVar13 != (longlong *)0x0) {
            plVar8 = (longlong *)FUN_140008f40(puVar19,plVar13,_DAT_142d9a260,0);
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
            }
            if (plVar8 == (longlong *)0x0) goto LAB_1408be1ec;
            plVar13 = (longlong *)FUN_140008da0(puVar19,pcStack_2a8,plVar15);
            if (plVar13 == (longlong *)0x0) {
LAB_1408be208:
              lStack_318 = *plStack_2f8;
              *plStack_2f8 = 0;
              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))(plVar8);
              }
              uStack_310 = 0x2183;
              goto LAB_1408be28b;
            }
            plVar11 = (longlong *)FUN_140008f40(puVar19,plVar13,_DAT_142d9a260,0);
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
            }
            if (plVar11 == (longlong *)0x0) goto LAB_1408be208;
            plVar13 = (longlong *)FUN_142cc11d0(plVar8,plVar11);
            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))(plVar8);
            }
            if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
              (**(code **)(plVar11[1] + 0x30))(plVar11);
            }
            if (plVar13 == (longlong *)0x0) goto LAB_1408be1ec;
            plVar8 = (longlong *)Nuitka_helper_142cc1650(plVar13);
            if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
              (**(code **)(plVar13[1] + 0x30))(plVar13);
            }
            if (plVar8 == (longlong *)0x0) goto LAB_1408be1ec;
            iVar5 = FUN_142ce2c80(plVar8,classes_const_1093_25);
            if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
              (**(code **)(plVar8[1] + 0x30))(plVar8);
            }
            pcVar14 = pcStack_2a8;
            puVar19 = puStack_2f0;
            if (iVar5 == -1) goto LAB_1408be1ec;
            if (iVar5 != 1) {
LAB_1408bdb7b:
              puVar19 = puStack_2f0;
              cVar4 = FUN_140008af0(puStack_2f0);
              if (cVar4 == '\0') {
                uStack_310 = 0x2182;
                lStack_318 = *plStack_2f8;
                *plStack_2f8 = 0;
                goto LAB_1408be28b;
              }
              plVar11 = (longlong *)(**(code **)(plVar9[1] + 0xe0))(plVar9);
              plVar13 = plStack_288;
              plVar8 = plVar15;
              plVar12 = plStack_1a8;
              if (plVar11 == (longlong *)0x0) goto LAB_1408bdbb3;
              goto LAB_1408bd850;
            }
            plVar13 = (longlong *)FUN_140008da0(puStack_2f0,pcStack_2a8,plStack_288);
            if (plVar13 != (longlong *)0x0) {
              plVar8 = (longlong *)FUN_140008f40(puVar19,plVar13,_DAT_142d9a268,1);
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              if (plVar8 == (longlong *)0x0) goto LAB_1408be1ec;
              plVar13 = (longlong *)FUN_140008da0(puVar19,pcVar14,plVar15);
              if (plVar13 == (longlong *)0x0) goto LAB_1408be208;
              plVar11 = (longlong *)FUN_140008f40(puVar19,plVar13,_DAT_142d9a268,1);
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              if (plVar11 == (longlong *)0x0) goto LAB_1408be208;
              plVar13 = (longlong *)FUN_142cc11d0(plVar8,plVar11);
              if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                (**(code **)(plVar8[1] + 0x30))(plVar8);
              }
              if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
                (**(code **)(plVar11[1] + 0x30))(plVar11);
              }
              if (plVar13 != (longlong *)0x0) {
                plVar8 = (longlong *)Nuitka_helper_142cc1650(plVar13);
                if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                }
                if (plVar8 == (longlong *)0x0) goto LAB_1408be1ec;
                iVar5 = FUN_142ce2c80(plVar8,classes_const_1093_25);
                if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
                  (**(code **)(plVar8[1] + 0x30))(plVar8);
                }
                pcVar14 = pcStack_268;
                if (iVar5 != -1) {
                  if (iVar5 == 1) {
                    pcStack_268 = _Py_TrueStruct_exref;
                    if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
                      *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
                    }
                    if (((pcVar14 != (code *)0x0) && (-1 < *(int *)pcVar14)) &&
                       (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)
                       ) {
                      (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14,pcVar14);
                    }
                  }
                  goto LAB_1408bdb7b;
                }
                uStack_310 = 0x2183;
                lStack_318 = *plStack_2f8;
                *plStack_2f8 = 0;
                goto LAB_1408be28b;
              }
            }
          }
LAB_1408be1ec:
          lStack_318 = *plStack_2f8;
          uStack_310 = 0x2183;
          *plStack_2f8 = 0;
          goto LAB_1408be28b;
        }
LAB_1408bdbb3:
        puVar19 = puStack_2f0;
        plVar8 = plStack_2f8;
        plVar13 = (longlong *)*plStack_2f8;
        if (plVar13 != (longlong *)0x0) {
          cVar4 = FUN_140008d40(puStack_2f0,plVar13,*(undefined8 *)PyExc_StopIteration_exref);
          if (cVar4 == '\0') {
            lStack_318 = *plVar8;
            uStack_310 = 0x2182;
            *plVar8 = 0;
LAB_1408be28b:
            lVar10 = lStack_318;
            lStack_318 = 0;
            if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
               (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
              (**(code **)(plVar15[1] + 0x30))(plVar15);
            }
            if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
              (**(code **)(plVar9[1] + 0x30))(plVar9);
            }
            goto LAB_1408be31b;
          }
          *plVar8 = 0;
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
        }
        if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
           (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
          (**(code **)(plVar15[1] + 0x30))(plVar15);
        }
        if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
          (**(code **)(plVar9[1] + 0x30))(plVar9);
        }
        cVar4 = FUN_140008af0(puVar19);
        plVar11 = plStack_2b0;
        if (cVar4 == '\0') {
          lVar10 = *plVar8;
          *plVar8 = 0;
          uStack_310 = 0x2181;
          goto LAB_1408be31b;
        }
        plVar13 = (longlong *)(**(code **)(plStack_2b0[1] + 0xe0))(plStack_2b0);
        plVar8 = plStack_2e8;
        pcVar20 = pcStack_268;
        plVar9 = plStack_2f8;
        tstate = puStack_2f0;
        plVar15 = plStack_1e0;
      }
      plVar13 = (longlong *)*plVar9;
      if (plVar13 != (longlong *)0x0) {
        cVar4 = FUN_140008d40(tstate,plVar13,*(undefined8 *)PyExc_StopIteration_exref);
        if (cVar4 == '\0') {
          lVar10 = *plVar9;
          uStack_310 = 0x2181;
          *plVar9 = 0;
LAB_1408be31b:
          lStack_318 = lVar10;
          lVar10 = lStack_318;
          lStack_318 = 0;
          if (((plStack_1a8 != (longlong *)0x0) && (-1 < (int)*plStack_1a8)) &&
             (*plStack_1a8 = *plStack_1a8 + -1, *plStack_1a8 == 0)) {
            (**(code **)(plStack_1a8[1] + 0x30))();
          }
          plVar12 = plStack_2c0;
          plVar13 = plStack_2e0;
          uVar22 = uStack_310;
          if ((-1 < (int)*plStack_2b0) && (*plStack_2b0 = *plStack_2b0 + -1, *plStack_2b0 == 0)) {
            lVar17 = plStack_2b0[1];
            plVar9 = plStack_2b0;
            goto LAB_1408be358;
          }
          goto LAB_1408be73b;
        }
        *plVar9 = 0;
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
      }
      if (((plVar12 != (longlong *)0x0) && (-1 < (int)*plVar12)) &&
         (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
        (**(code **)(plVar12[1] + 0x30))(plVar12);
      }
      if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
        (**(code **)(plVar11[1] + 0x30))(plVar11);
      }
      if (pcVar20 == (code *)0x0) {
        FUN_142cd4900(tstate,&lStack_318,classes_const_1815_juntos);
        FUN_1400048d0(tstate,lStack_318);
        lVar10 = lStack_318;
        plVar12 = plStack_2c0;
        plVar13 = plStack_2e0;
        uVar22 = 0x2185;
        goto LAB_1408be73b;
      }
      iVar5 = FUN_140004970();
      plVar11 = plStack_278;
      plVar12 = plStack_2c0;
      plVar13 = plStack_2e0;
      if (iVar5 == -1) {
        lVar10 = *plVar9;
        *plVar9 = 0;
        uVar22 = 0x2185;
        goto LAB_1408be73b;
      }
    } while (iVar5 != 0);
    plStack_278 = (longlong *)classes_const_717___float_special___0_;
    if (*(int *)classes_const_717___float_special___0_ + 1 != 0) {
      *(int *)classes_const_717___float_special___0_ =
           *(int *)classes_const_717___float_special___0_ + 1;
    }
    if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
       (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
      (**(code **)(plVar11[1] + 0x30))();
    }
    plVar8 = (longlong *)FUN_142cc2e30(tstate,plVar8);
    if (plVar8 == (longlong *)0x0) {
LAB_1408be512:
      lVar10 = *plVar9;
      *plVar9 = 0;
      uVar22 = 0x2188;
      goto LAB_1408be73b;
    }
    plVar11 = (longlong *)FUN_140009850(tstate,plVar8);
    if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    if (plVar11 == (longlong *)0x0) goto LAB_1408be512;
    plVar15 = (longlong *)(**(code **)(plVar11[1] + 0xe0))(plVar11);
    plVar12 = plStack_2b8;
    plVar13 = (longlong *)0x0;
    plVar8 = plStack_290;
    while (plVar16 = plVar15, plStack_290 = plVar8, plVar16 != (longlong *)0x0) {
      if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))();
      }
      iVar5 = (int)*plVar16 + 1;
      if (iVar5 != 0) {
        *(int *)plVar16 = iVar5;
      }
      plStack_290 = plVar16;
      if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
         (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))();
      }
      if (plStack_278 == (longlong *)0x0) {
        FUN_142cd4900(tstate,&lStack_318,classes_const_950_soma);
        FUN_1400048d0(tstate,lStack_318);
        uStack_310 = 0x2189;
        goto LAB_1408be4c3;
      }
      plVar13 = (longlong *)FUN_140008da0(tstate,pcStack_2c8,plVar16);
      if (plVar13 == (longlong *)0x0) goto LAB_1408be39c;
      plVar8 = (longlong *)FUN_140008da0(tstate,plVar12,plVar16);
      if (plVar8 == (longlong *)0x0) {
        lStack_318 = *plVar9;
        *plVar9 = 0;
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        uStack_310 = 0x2189;
        goto LAB_1408be4c3;
      }
      plVar15 = (longlong *)FUN_140008da0(tstate,plVar13,plVar8);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
      }
      if (plVar15 == (longlong *)0x0) {
LAB_1408be39c:
        lStack_318 = *plVar9;
        uStack_310 = 0x2189;
        goto LAB_1408be4bb;
      }
      plVar13 = (longlong *)FUN_140008f40(puStack_2f0,plVar15,_DAT_142d9a260,0);
      if ((-1 < (int)*plVar15) && (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
        (**(code **)(plVar15[1] + 0x30))(plVar15);
      }
      plVar8 = plStack_278;
      if (plVar13 == (longlong *)0x0) goto LAB_1408be39c;
      plVar15 = (longlong *)FUN_142cbe7f0(plStack_278,plVar13);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      if (plVar15 == (longlong *)0x0) {
        lStack_318 = *plVar9;
        uStack_310 = 0x2189;
        goto LAB_1408be4bb;
      }
      plStack_278 = plVar15;
      if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
        (**(code **)(plVar8[1] + 0x30))(plVar8);
      }
      tstate = puStack_2f0;
      cVar4 = FUN_140008af0(puStack_2f0);
      if (cVar4 == '\0') {
        lStack_318 = *plVar9;
        uStack_310 = 0x2188;
        goto LAB_1408be4bb;
      }
      plVar15 = (longlong *)(**(code **)(plVar11[1] + 0xe0))(plVar11);
      plVar13 = plVar16;
      plVar8 = plStack_290;
    }
    cVar4 = FUN_140009ec0(tstate,*(undefined8 *)PyExc_StopIteration_exref);
    if (cVar4 == '\0') {
      lStack_318 = *plVar9;
      uStack_310 = 0x2188;
      plVar16 = plVar13;
LAB_1408be4bb:
      *plVar9 = 0;
LAB_1408be4c3:
      lVar10 = lStack_318;
      lStack_318 = 0;
      if (((plVar16 != (longlong *)0x0) && (-1 < (int)*plVar16)) &&
         (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
        (**(code **)(plVar16[1] + 0x30))(plVar16);
      }
      plVar12 = plStack_2c0;
      plVar13 = plStack_2e0;
      uVar22 = uStack_310;
      if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
        (**(code **)(plVar11[1] + 0x30))(plVar11);
        plVar12 = plStack_2c0;
        plVar13 = plStack_2e0;
        uVar22 = uStack_310;
      }
      goto LAB_1408be73b;
    }
    if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
       (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    if ((-1 < (int)*plVar11) && (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
      (**(code **)(plVar11[1] + 0x30))(plVar11);
    }
    plVar13 = plStack_278;
    puVar19 = classes_const_1255_melhor;
    if (pcStack_2a0 == (code *)0x0) {
LAB_1408be477:
      FUN_142cd4900(tstate,&lStack_318,puVar19);
      FUN_1400048d0(tstate,lStack_318);
LAB_1408be48c:
      lVar10 = lStack_318;
      plVar12 = plStack_2c0;
      plVar13 = plStack_2e0;
      uVar22 = 0x218a;
      goto LAB_1408be73b;
    }
    uVar7 = (uint)(pcStack_2a0 == _Py_NoneStruct_exref);
    if (pcStack_2a0 != _Py_NoneStruct_exref) {
      puVar19 = classes_const_950_soma;
      if (plStack_278 == (longlong *)0x0) goto LAB_1408be477;
      plVar8 = (longlong *)FUN_140008f40(tstate,pcStack_2a0,_DAT_142d9a260,0);
      if (plVar8 != (longlong *)0x0) {
        uVar7 = FUN_142ce13d0(plVar13,plVar8);
        if ((-1 < (int)*plVar8) && (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
          (**(code **)(plVar8[1] + 0x30))(plVar8);
        }
        if (uVar7 != 0xffffffff) goto LAB_1408bdff6;
      }
      lStack_318 = *plVar9;
      *plVar9 = 0;
      goto LAB_1408be48c;
    }
LAB_1408bdff6:
    plVar13 = plStack_278;
    pcVar14 = pcStack_2a0;
    if (uVar7 == 1) {
      if (plStack_278 == (longlong *)0x0) {
        FUN_142cd4900(tstate,&lStack_318,classes_const_950_soma);
        FUN_1400048d0(tstate,lStack_318);
        lVar10 = lStack_318;
        plVar12 = plStack_2c0;
        plVar13 = plStack_2e0;
        uVar22 = 0x218b;
        goto LAB_1408be73b;
      }
      pcStack_2a0 = (code *)FUN_142cd9440(tstate,2);
      iVar5 = (int)*plVar13 + 1;
      if (iVar5 != 0) {
        *(int *)plVar13 = iVar5;
      }
      *(longlong **)(pcStack_2a0 + 0x18) = plVar13;
      iVar5 = (int)*plVar12 + 1;
      if (iVar5 != 0) {
        *(int *)plVar12 = iVar5;
      }
      *(longlong **)(pcStack_2a0 + 0x20) = plVar12;
      if ((-1 < *(int *)pcVar14) &&
         (*(longlong *)pcVar14 = *(longlong *)pcVar14 + -1, *(longlong *)pcVar14 == 0)) {
        (**(code **)(*(longlong *)(pcVar14 + 8) + 0x30))(pcVar14);
      }
    }
    cVar4 = FUN_140008af0(tstate);
    plVar12 = plStack_2c0;
    plVar13 = plStack_2e0;
    plVar8 = plStack_2e8;
  } while (cVar4 != '\0');
  lVar10 = *plVar9;
  *plVar9 = 0;
  uVar22 = uStack_310;
LAB_1408be73b:
  lStack_318 = 0;
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
LAB_1408be751:
  plVar13 = plStack_2d8;
  pcVar14 = pcStack_2c8;
  plVar9 = plStack_2d0;
  tstate = puStack_2f0;
  if ((-1 < (int)*plVar12) && (*plVar12 = *plVar12 + -1, *plVar12 == 0)) {
    (**(code **)(plVar12[1] + 0x30))(plVar12);
    plVar13 = plStack_2d8;
    pcVar14 = pcStack_2c8;
    plVar9 = plStack_2d0;
    tstate = puStack_2f0;
  }
LAB_1408bef49:
  lStack_318 = lVar10;
  piVar1 = *(int **)(lStack_318 + 0x28);
  if (piVar1 == (int *)0x0) {
    pcVar20 = (code *)FUN_142cd9160(plVar13,uVar22);
    bVar23 = pcVar20 == _Py_NoneStruct_exref;
LAB_1408bef95:
    plVar8 = *(longlong **)(lStack_318 + 0x28);
    if (bVar23) {
      pcVar18 = (code *)0x0;
    }
    else {
      pcVar18 = pcVar20;
      if ((pcVar20 != (code *)0x0) && (*(int *)pcVar20 + 1 != 0)) {
        *(int *)pcVar20 = *(int *)pcVar20 + 1;
      }
    }
    *(code **)(lStack_318 + 0x28) = pcVar18;
    if (((plVar8 != (longlong *)0x0) && (-1 < (int)*plVar8)) &&
       (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    if (((pcVar20 != (code *)0x0) && (-1 < *(int *)pcVar20)) &&
       (*(longlong *)pcVar20 = *(longlong *)pcVar20 + -1, *(longlong *)pcVar20 == 0)) {
      (**(code **)(*(longlong *)(pcVar20 + 8) + 0x30))(pcVar20);
    }
  }
  else if (*(longlong **)(piVar1 + 6) != plVar13) {
    pcVar20 = (code *)FUN_142cd9160(plVar13,uVar22);
    *(int **)(pcVar20 + 0x10) = piVar1;
    if (*piVar1 + 1 != 0) {
      *piVar1 = *piVar1 + 1;
    }
    bVar23 = pcVar20 == _Py_NoneStruct_exref;
    goto LAB_1408bef95;
  }
  plVar11 = plStack_1a0;
  pcVar18 = pcStack_280;
  pcVar20 = pcStack_2a8;
  plStack_320 = plStack_188;
  plStack_328 = plStack_190;
  plStack_330 = plStack_1b8;
  plStack_338 = plStack_180;
  plStack_340 = plStack_160;
  plStack_348 = plStack_278;
  plStack_350 = plStack_1d8;
  plStack_358 = plStack_1e0;
  pcStack_360 = pcStack_268;
  plStack_368 = plStack_290;
  pcStack_370 = pcStack_2a8;
  plStack_378 = plStack_1e8;
  pcStack_380 = pcStack_2a0;
  plStack_388 = plStack_150;
  plStack_390 = plStack_1f0;
  plStack_398 = plStack_1f8;
  plStack_3a0 = plStack_218;
  plStack_3a8 = plStack_248;
  plStack_3b0 = plStack_1c0;
  plStack_3b8 = plStack_250;
  plStack_3c0 = plStack_220;
  pcStack_3c8 = pcStack_228;
  plStack_3d0 = plStack_230;
  plStack_3d8 = plStack_238;
  plStack_3e0 = plStack_240;
  plStack_3e8 = plStack_210;
  plStack_3f0 = plStack_1c8;
  plStack_3f8 = plStack_200;
  pcStack_400 = pcStack_280;
  pcStack_408 = pcStack_1d0;
  plStack_410 = plStack_208;
  plStack_420 = plStack_158;
  pcStack_428 = pcStack_258;
  pplStack_430 = pplStack_168;
  plStack_438 = plStack_1a0;
  plStack_440 = plStack_178;
  plStack_450 = plStack_198;
  pcStack_458 = pcStack_140;
  plStack_448 = plVar9;
  pcStack_418 = pcVar14;
  FUN_142cdb370(plVar13,&UNK_142d0d430,plStack_138,plStack_148);
  plVar8 = _DAT_142dea748;
  if (plVar13 == _DAT_142dea748) {
    if ((-1 < (int)*_DAT_142dea748) && (*_DAT_142dea748 = *_DAT_142dea748 + -1, *plVar8 == 0)) {
      (**(code **)(plVar8[1] + 0x30))();
    }
    _DAT_142dea748 = (longlong *)0x0;
  }
  plVar13 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
  *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
  *(undefined4 *)(plVar13 + 10) = 0xfffffffe;
  plVar8 = (longlong *)plVar13[2];
  if (((plVar8 != (longlong *)0x0) && (plVar13[2] = 0, -1 < (int)*plVar8)) &&
     (*plVar8 = *plVar8 + -1, *plVar8 == 0)) {
    (**(code **)(plVar8[1] + 0x30))();
  }
  if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))(plVar13);
  }
  lVar10 = lStack_318;
  plVar13[0xc] = 0;
  lStack_318 = 0;
  if ((-1 < (int)*plStack_198) && (*plStack_198 = *plStack_198 + -1, *plStack_198 == 0)) {
    (**(code **)(plStack_198[1] + 0x30))();
  }
  if ((-1 < (int)*plVar9) && (*plVar9 = *plVar9 + -1, *plVar9 == 0)) {
    (**(code **)(plVar9[1] + 0x30))(plVar9);
  }
  if (((plStack_178 != (longlong *)0x0) && (-1 < (int)*plStack_178)) &&
     (*plStack_178 = *plStack_178 + -1, *plStack_178 == 0)) {
    (**(code **)(plStack_178[1] + 0x30))();
  }
  if (((plVar11 != (longlong *)0x0) && (-1 < (int)*plVar11)) &&
     (*plVar11 = *plVar11 + -1, *plVar11 == 0)) {
    (**(code **)(plVar11[1] + 0x30))(plVar11);
  }
  if (((pplStack_168 != (longlong **)0x0) && (-1 < *(int *)pplStack_168)) &&
     (*pplStack_168 = (longlong *)((longlong)*pplStack_168 + -1), *pplStack_168 == (longlong *)0x0))
  {
    (*(code *)pplStack_168[1][6])();
  }
  if (((pcStack_258 != (code *)0x0) && (-1 < *(int *)pcStack_258)) &&
     (*(longlong *)pcStack_258 = *(longlong *)pcStack_258 + -1, *(longlong *)pcStack_258 == 0)) {
    (**(code **)(*(longlong *)(pcStack_258 + 8) + 0x30))();
  }
  if (((plStack_158 != (longlong *)0x0) && (-1 < (int)*plStack_158)) &&
     (*plStack_158 = *plStack_158 + -1, *plStack_158 == 0)) {
    (**(code **)(plStack_158[1] + 0x30))();
  }
  if (((pcStack_2c8 != (code *)0x0) && (-1 < *(int *)pcStack_2c8)) &&
     (*(longlong *)pcStack_2c8 = *(longlong *)pcStack_2c8 + -1, *(longlong *)pcStack_2c8 == 0)) {
    (**(code **)(*(longlong *)(pcStack_2c8 + 8) + 0x30))();
  }
  if (((plStack_208 != (longlong *)0x0) && (-1 < (int)*plStack_208)) &&
     (*plStack_208 = *plStack_208 + -1, *plStack_208 == 0)) {
    (**(code **)(plStack_208[1] + 0x30))();
  }
  if (((pcStack_1d0 != (code *)0x0) && (-1 < *(int *)pcStack_1d0)) &&
     (*(longlong *)pcStack_1d0 = *(longlong *)pcStack_1d0 + -1, *(longlong *)pcStack_1d0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_1d0 + 8) + 0x30))();
  }
  if (((pcVar18 != (code *)0x0) && (-1 < *(int *)pcVar18)) &&
     (*(longlong *)pcVar18 = *(longlong *)pcVar18 + -1, *(longlong *)pcVar18 == 0)) {
    (**(code **)(*(longlong *)(pcVar18 + 8) + 0x30))(pcVar18);
  }
  if (((plStack_200 != (longlong *)0x0) && (-1 < (int)*plStack_200)) &&
     (*plStack_200 = *plStack_200 + -1, *plStack_200 == 0)) {
    (**(code **)(plStack_200[1] + 0x30))();
  }
  if (((plStack_1c8 != (longlong *)0x0) && (-1 < (int)*plStack_1c8)) &&
     (*plStack_1c8 = *plStack_1c8 + -1, *plStack_1c8 == 0)) {
    (**(code **)(plStack_1c8[1] + 0x30))();
  }
  if (((plStack_210 != (longlong *)0x0) && (-1 < (int)*plStack_210)) &&
     (*plStack_210 = *plStack_210 + -1, *plStack_210 == 0)) {
    (**(code **)(plStack_210[1] + 0x30))();
  }
  if (((plStack_240 != (longlong *)0x0) && (-1 < (int)*plStack_240)) &&
     (*plStack_240 = *plStack_240 + -1, *plStack_240 == 0)) {
    (**(code **)(plStack_240[1] + 0x30))();
  }
  if (((plStack_238 != (longlong *)0x0) && (-1 < (int)*plStack_238)) &&
     (*plStack_238 = *plStack_238 + -1, *plStack_238 == 0)) {
    (**(code **)(plStack_238[1] + 0x30))();
  }
  if (((plStack_230 != (longlong *)0x0) && (-1 < (int)*plStack_230)) &&
     (*plStack_230 = *plStack_230 + -1, *plStack_230 == 0)) {
    (**(code **)(plStack_230[1] + 0x30))();
  }
  if (((pcStack_228 != (code *)0x0) && (-1 < *(int *)pcStack_228)) &&
     (*(longlong *)pcStack_228 = *(longlong *)pcStack_228 + -1, *(longlong *)pcStack_228 == 0)) {
    (**(code **)(*(longlong *)(pcStack_228 + 8) + 0x30))();
  }
  if (((plStack_220 != (longlong *)0x0) && (-1 < (int)*plStack_220)) &&
     (*plStack_220 = *plStack_220 + -1, *plStack_220 == 0)) {
    (**(code **)(plStack_220[1] + 0x30))();
  }
  if (((plStack_250 != (longlong *)0x0) && (-1 < (int)*plStack_250)) &&
     (*plStack_250 = *plStack_250 + -1, *plStack_250 == 0)) {
    (**(code **)(plStack_250[1] + 0x30))();
  }
  if (((plStack_1c0 != (longlong *)0x0) && (-1 < (int)*plStack_1c0)) &&
     (*plStack_1c0 = *plStack_1c0 + -1, *plStack_1c0 == 0)) {
    (**(code **)(plStack_1c0[1] + 0x30))();
  }
  if (((plStack_248 != (longlong *)0x0) && (-1 < (int)*plStack_248)) &&
     (*plStack_248 = *plStack_248 + -1, *plStack_248 == 0)) {
    (**(code **)(plStack_248[1] + 0x30))();
  }
  if (((plStack_218 != (longlong *)0x0) && (-1 < (int)*plStack_218)) &&
     (*plStack_218 = *plStack_218 + -1, *plStack_218 == 0)) {
    (**(code **)(plStack_218[1] + 0x30))();
  }
  if (((plStack_1f8 != (longlong *)0x0) && (-1 < (int)*plStack_1f8)) &&
     (*plStack_1f8 = *plStack_1f8 + -1, *plStack_1f8 == 0)) {
    (**(code **)(plStack_1f8[1] + 0x30))();
  }
  if (((plStack_1f0 != (longlong *)0x0) && (-1 < (int)*plStack_1f0)) &&
     (*plStack_1f0 = *plStack_1f0 + -1, *plStack_1f0 == 0)) {
    (**(code **)(plStack_1f0[1] + 0x30))();
  }
  if (((plStack_150 != (longlong *)0x0) && (-1 < (int)*plStack_150)) &&
     (*plStack_150 = *plStack_150 + -1, *plStack_150 == 0)) {
    (**(code **)(plStack_150[1] + 0x30))();
  }
  if (((pcStack_2a0 != (code *)0x0) && (-1 < *(int *)pcStack_2a0)) &&
     (*(longlong *)pcStack_2a0 = *(longlong *)pcStack_2a0 + -1, *(longlong *)pcStack_2a0 == 0)) {
    (**(code **)(*(longlong *)(pcStack_2a0 + 8) + 0x30))();
  }
  if (((plStack_1e8 != (longlong *)0x0) && (-1 < (int)*plStack_1e8)) &&
     (*plStack_1e8 = *plStack_1e8 + -1, *plStack_1e8 == 0)) {
    (**(code **)(plStack_1e8[1] + 0x30))();
  }
  if (((pcVar20 != (code *)0x0) && (-1 < *(int *)pcVar20)) &&
     (*(longlong *)pcVar20 = *(longlong *)pcVar20 + -1, *(longlong *)pcVar20 == 0)) {
    (**(code **)(*(longlong *)(pcVar20 + 8) + 0x30))(pcVar20);
  }
  if (((plStack_290 != (longlong *)0x0) && (-1 < (int)*plStack_290)) &&
     (*plStack_290 = *plStack_290 + -1, *plStack_290 == 0)) {
    (**(code **)(plStack_290[1] + 0x30))();
  }
  if (((pcStack_268 != (code *)0x0) && (-1 < *(int *)pcStack_268)) &&
     (*(longlong *)pcStack_268 = *(longlong *)pcStack_268 + -1, *(longlong *)pcStack_268 == 0)) {
    (**(code **)(*(longlong *)(pcStack_268 + 8) + 0x30))();
  }
  if (((plStack_1e0 != (longlong *)0x0) && (-1 < (int)*plStack_1e0)) &&
     (*plStack_1e0 = *plStack_1e0 + -1, *plStack_1e0 == 0)) {
    (**(code **)(plStack_1e0[1] + 0x30))();
  }
  if (((plStack_1d8 != (longlong *)0x0) && (-1 < (int)*plStack_1d8)) &&
     (*plStack_1d8 = *plStack_1d8 + -1, *plStack_1d8 == 0)) {
    (**(code **)(plStack_1d8[1] + 0x30))();
  }
  if (((plStack_278 != (longlong *)0x0) && (-1 < (int)*plStack_278)) &&
     (*plStack_278 = *plStack_278 + -1, *plStack_278 == 0)) {
    (**(code **)(plStack_278[1] + 0x30))();
  }
  if (((plStack_160 != (longlong *)0x0) && (-1 < (int)*plStack_160)) &&
     (*plStack_160 = *plStack_160 + -1, *plStack_160 == 0)) {
    (**(code **)(plStack_160[1] + 0x30))();
  }
  if (((plStack_180 != (longlong *)0x0) && (-1 < (int)*plStack_180)) &&
     (*plStack_180 = *plStack_180 + -1, *plStack_180 == 0)) {
    (**(code **)(plStack_180[1] + 0x30))();
  }
  if (((plStack_1b8 != (longlong *)0x0) && (-1 < (int)*plStack_1b8)) &&
     (*plStack_1b8 = *plStack_1b8 + -1, *plStack_1b8 == 0)) {
    (**(code **)(plStack_1b8[1] + 0x30))();
  }
  if (((plStack_190 != (longlong *)0x0) && (-1 < (int)*plStack_190)) &&
     (*plStack_190 = *plStack_190 + -1, *plStack_190 == 0)) {
    (**(code **)(plStack_190[1] + 0x30))();
  }
  if (((plStack_188 != (longlong *)0x0) && (-1 < (int)*plStack_188)) &&
     (*plStack_188 = *plStack_188 + -1, *plStack_188 == 0)) {
    (**(code **)(plStack_188[1] + 0x30))();
  }
  lStack_318 = lVar10;
  if ((-1 < (int)*plStack_138) && (*plStack_138 = *plStack_138 + -1, *plStack_138 == 0)) {
    (**(code **)(plStack_138[1] + 0x30))();
  }
  if ((-1 < (int)*plStack_148) && (*plStack_148 = *plStack_148 + -1, *plStack_148 == 0)) {
    (**(code **)(plStack_148[1] + 0x30))();
  }
  if ((-1 < *(int *)pcStack_140) &&
     (*(longlong *)pcStack_140 = *(longlong *)pcStack_140 + -1, *(longlong *)pcStack_140 == 0)) {
    (**(code **)(*(longlong *)(pcStack_140 + 8) + 0x30))();
  }
  plVar13 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStack_318;
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))();
  }
LAB_1408bf751:
  puVar19 = (undefined *)FUN_142cfc380(uStack_48 ^ (ulonglong)auStack_478);
  return puVar19;
}

