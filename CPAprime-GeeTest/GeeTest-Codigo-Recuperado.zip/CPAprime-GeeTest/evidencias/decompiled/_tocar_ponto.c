
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

undefined * _tocar_ponto(undefined *tstate,undefined *self,undefined **python_pars)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  int *piVar4;
  longlong *plVar5;
  longlong lVar6;
  int *piVar7;
  undefined *puVar8;
  undefined *puVar9;
  undefined *puVar10;
  char cVar11;
  int iVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong lVar17;
  code *pcVar18;
  code *pcVar19;
  undefined8 uVar20;
  longlong lStackX_20;
  undefined *puStack_50;
  longlong *plStack_48;
  
  plVar5 = _DAT_142dea710;
  plVar15 = (longlong *)0x0;
  plVar1 = (longlong *)python_pars[1];
  plVar2 = (longlong *)python_pars[2];
  plVar3 = (longlong *)*python_pars;
  lStackX_20 = 0;
  if (_DAT_142dea710 == (longlong *)0x0) {
LAB_1408b570d:
    _DAT_142dea710 = (longlong *)FUN_142cd81e0(tstate,_DAT_142de9dc8,_DAT_142f2aaf0,0x20);
  }
  else if ((1 < *_DAT_142dea710) || (_DAT_142dea710[2] != 0)) {
    if ((_DAT_142dea710 != (longlong *)0x0) &&
       ((-1 < (int)*_DAT_142dea710 && (*_DAT_142dea710 = *_DAT_142dea710 + -1, *plVar5 == 0)))) {
      (**(code **)(plVar5[1] + 0x30))(plVar5);
    }
    goto LAB_1408b570d;
  }
  plVar5 = _DAT_142dea710;
  Nuitka_helper_140008a00(tstate,_DAT_142dea710);
  plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar3,classes_const_170_driver);
  if (plVar13 == (longlong *)0x0) {
LAB_1408b5758:
    lVar17 = *(longlong *)(tstate + 0x70);
    uVar20 = 0x203f;
    *(undefined8 *)(tstate + 0x70) = 0;
  }
  else {
    iVar12 = FUN_140004970(plVar13);
    if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))(plVar13);
    }
    puVar8 = classes_const_309_x;
    pcVar19 = _Py_FalseStruct_exref;
    if (iVar12 == -1) goto LAB_1408b5758;
    if (iVar12 == 0) {
      if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
        *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
      }
LAB_1408b5c31:
      plVar5 = *(longlong **)(*(longlong *)(tstate + 0x48) + 0x30);
      *(undefined8 *)(tstate + 0x48) = *(undefined8 *)(*(longlong *)(tstate + 0x48) + 8);
      *(undefined4 *)(plVar5 + 10) = 0xfffffffe;
      plVar13 = (longlong *)plVar5[2];
      if (((plVar13 != (longlong *)0x0) && (plVar5[2] = 0, -1 < (int)*plVar13)) &&
         (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))();
      }
      if ((-1 < (int)*plVar5) && (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
        (**(code **)(plVar5[1] + 0x30))(plVar5);
      }
      plVar5[0xc] = 0;
LAB_1408b5eca:
      if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
         (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
        (**(code **)(plVar15[1] + 0x30))(plVar15);
      }
      if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
        (**(code **)(plVar3[1] + 0x30))(plVar3);
      }
      if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
        (**(code **)(plVar1[1] + 0x30))();
      }
      if ((int)*plVar2 < 0) {
        return pcVar19;
      }
      *plVar2 = *plVar2 + -1;
      if (*plVar2 != 0) {
        return pcVar19;
      }
      (**(code **)(plVar2[1] + 0x30))(plVar2);
      return pcVar19;
    }
    plVar13 = (longlong *)Nuitka_helper_142ce5200(plVar1);
    if (plVar13 == (longlong *)0x0) {
      lVar17 = *(longlong *)(tstate + 0x70);
      uVar20 = 0x2041;
      *(undefined8 *)(tstate + 0x70) = 0;
    }
    else {
      plVar14 = (longlong *)_PyDict_NewPresized(5);
      PyDict_SetItem(plVar14,puVar8,plVar13);
      if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
        (**(code **)(plVar13[1] + 0x30))(plVar13);
      }
      puVar8 = classes_const_310_y;
      plVar13 = (longlong *)Nuitka_helper_142ce5200(plVar2);
      if (plVar13 == (longlong *)0x0) {
        lStackX_20 = *(longlong *)(tstate + 0x70);
        uVar20 = 0x2041;
        *(undefined8 *)(tstate + 0x70) = 0;
        lVar17 = lStackX_20;
        if ((-1 < (int)*plVar14) &&
           (*plVar14 = *plVar14 + -1, plVar15 = (longlong *)0x0, *plVar14 == 0)) {
          (**(code **)(plVar14[1] + 0x30))(plVar14);
          lVar17 = lStackX_20;
        }
      }
      else {
        PyDict_SetItem(plVar14,puVar8,plVar13);
        if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))(plVar13);
        }
        PyDict_SetItem(plVar14,classes_const_1740_radiusX,classes_const_1250_12);
        PyDict_SetItem(plVar14,classes_const_1741_radiusY,classes_const_1250_12);
        PyDict_SetItem(plVar14,classes_const_1742_force,_DAT_142d9a268);
        plVar15 = (longlong *)FUN_142cd8f90(tstate,1);
        *(longlong **)plVar15[3] = plVar14;
        plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar3,classes_const_170_driver);
        puVar10 = classes_const_1744_touchStart;
        puVar9 = classes_const_1743_Input_dispatchTouchEvent;
        puVar8 = classes_const_984_type;
        if (plVar13 == (longlong *)0x0) {
          uVar20 = 0x2043;
LAB_1408b5add:
          lVar17 = *(longlong *)(tstate + 0x70);
          *(undefined8 *)(tstate + 0x70) = 0;
        }
        else {
          plVar14 = (longlong *)_PyDict_NewPresized(2);
          PyDict_SetItem(plVar14,puVar8,puVar10);
          PyDict_SetItem(plVar14,classes_const_1745_touchPoints,plVar15);
          puStack_50 = puVar9;
          uVar20 = 0x2043;
          *(undefined4 *)(plVar5 + 5) = 0x2043;
          plStack_48 = plVar14;
          plVar16 = (longlong *)
                    FUN_142cd07f0(tstate,plVar13,classes_const_300_execute_cdp_cmd,&puStack_50);
          if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
            (**(code **)(plVar13[1] + 0x30))(plVar13);
          }
          if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
            (**(code **)(plVar14[1] + 0x30))(plVar14);
          }
          if (plVar16 == (longlong *)0x0) goto LAB_1408b5add;
          if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
            (**(code **)(plVar16[1] + 0x30))(plVar16);
          }
          lVar17 = FUN_140a3b210(tstate);
          if (lVar17 != 0) {
            uVar20 = 0x2045;
            *(undefined4 *)(plVar5 + 5) = 0x2045;
            plVar13 = (longlong *)
                      FUN_142cd12f0(tstate,lVar17,classes_const_77_sleep,
                                    *(undefined8 *)
                                     (classes_const_1746___type____T____items____0_05__ + 0x18));
            if (plVar13 != (longlong *)0x0) {
              if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                (**(code **)(plVar13[1] + 0x30))(plVar13);
              }
              plVar13 = (longlong *)FUN_142cd7b20(tstate,plVar3,classes_const_170_driver);
              puVar8 = classes_const_1743_Input_dispatchTouchEvent;
              if (plVar13 == (longlong *)0x0) {
                uVar20 = 0x2046;
              }
              else {
                plVar14 = (longlong *)
                          FUN_142cd3400(tstate,
                                        classes_const_1747___type____D____keys_____type____touchPoints_____values_____touchE
                                       );
                uVar20 = 0x2046;
                *(undefined4 *)(plVar5 + 5) = 0x2046;
                puStack_50 = puVar8;
                plStack_48 = plVar14;
                plVar16 = (longlong *)
                          FUN_142cd07f0(tstate,plVar13,classes_const_300_execute_cdp_cmd,&puStack_50
                                       );
                if ((-1 < (int)*plVar13) && (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
                  (**(code **)(plVar13[1] + 0x30))(plVar13);
                }
                if ((-1 < (int)*plVar14) && (*plVar14 = *plVar14 + -1, *plVar14 == 0)) {
                  (**(code **)(plVar14[1] + 0x30))();
                }
                if (plVar16 != (longlong *)0x0) {
                  if ((-1 < (int)*plVar16) && (*plVar16 = *plVar16 + -1, *plVar16 == 0)) {
                    (**(code **)(plVar16[1] + 0x30))(plVar16);
                  }
                  FUN_140008990(tstate);
                  pcVar19 = _Py_TrueStruct_exref;
                  if (*(int *)_Py_TrueStruct_exref + 1 != 0) {
                    *(int *)_Py_TrueStruct_exref = *(int *)_Py_TrueStruct_exref + 1;
                  }
                  goto LAB_1408b5eca;
                }
              }
            }
            goto LAB_1408b5add;
          }
          FUN_142cde870(tstate,&lStackX_20,classes_const_76_time);
          uVar20 = 0x2045;
          lVar17 = lStackX_20;
        }
        piVar7 = *(int **)(tstate + 0xf8);
        lStackX_20 = 0;
        if ((piVar7 != (int *)0x0) && (*piVar7 + 1 != 0)) {
          *piVar7 = *piVar7 + 1;
        }
        piVar4 = *(int **)(lVar17 + 0x28);
        if (piVar4 == (int *)0x0) {
          pcVar19 = (code *)FUN_142cd9160(plVar5,uVar20);
          plVar13 = *(longlong **)(lVar17 + 0x28);
          if (pcVar19 == _Py_NoneStruct_exref) {
            pcVar18 = (code *)0x0;
          }
          else {
            pcVar18 = pcVar19;
            if (pcVar19 != (code *)0x0) {
              iVar12 = *(int *)pcVar19;
LAB_1408b5b6f:
              pcVar18 = pcVar19;
              if (iVar12 + 1 != 0) {
                *(int *)pcVar19 = iVar12 + 1;
              }
            }
          }
        }
        else {
          pcVar19 = (code *)FUN_142cd9160(plVar5,uVar20);
          *(int **)(pcVar19 + 0x10) = piVar4;
          if (*piVar4 + 1 != 0) {
            *piVar4 = *piVar4 + 1;
          }
          plVar13 = *(longlong **)(lVar17 + 0x28);
          if (pcVar19 == _Py_NoneStruct_exref) {
            pcVar18 = (code *)0x0;
          }
          else {
            pcVar18 = pcVar19;
            if (pcVar19 != (code *)0x0) {
              iVar12 = *(int *)pcVar19;
              goto LAB_1408b5b6f;
            }
          }
        }
        *(code **)(lVar17 + 0x28) = pcVar18;
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))();
        }
        if (((pcVar19 != (code *)0x0) && (-1 < *(int *)pcVar19)) &&
           (*(longlong *)pcVar19 = *(longlong *)pcVar19 + -1, *(longlong *)pcVar19 == 0)) {
          (**(code **)(*(longlong *)(pcVar19 + 8) + 0x30))(pcVar19);
        }
        plVar13 = *(longlong **)(tstate + 0xf8);
        *(longlong *)(tstate + 0xf8) = lVar17;
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))();
        }
        iVar12 = FUN_140008b90(tstate,*(undefined8 *)(*(longlong *)(tstate + 0xf8) + 8),
                               *(undefined8 *)PyExc_Exception_exref);
        pcVar19 = _Py_FalseStruct_exref;
        if (iVar12 != 0) {
          if (*(int *)_Py_FalseStruct_exref + 1 != 0) {
            *(int *)_Py_FalseStruct_exref = *(int *)_Py_FalseStruct_exref + 1;
          }
          plVar5 = *(longlong **)(tstate + 0xf8);
          *(int **)(tstate + 0xf8) = piVar7;
          if (((plVar5 != (longlong *)0x0) && (-1 < (int)*plVar5)) &&
             (*plVar5 = *plVar5 + -1, *plVar5 == 0)) {
            (**(code **)(plVar5[1] + 0x30))();
          }
          goto LAB_1408b5c31;
        }
        cVar11 = FUN_142cded30(tstate,&lStackX_20);
        lVar17 = lStackX_20;
        uVar20 = 0x2042;
        if (cVar11 != '\0') {
          uVar20 = 0;
        }
        lVar6 = *(longlong *)(lStackX_20 + 0x28);
        if ((lVar6 != 0) && (*(longlong **)(lVar6 + 0x18) == plVar5)) {
          *(undefined4 *)(plVar5 + 5) = *(undefined4 *)(lVar6 + 0x24);
        }
        lStackX_20 = 0;
        plVar13 = *(longlong **)(tstate + 0xf8);
        *(int **)(tstate + 0xf8) = piVar7;
        if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
           (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
          (**(code **)(plVar13[1] + 0x30))();
        }
      }
    }
  }
  lStackX_20 = lVar17;
  piVar7 = *(int **)(lStackX_20 + 0x28);
  if (piVar7 == (int *)0x0) {
    pcVar19 = (code *)FUN_142cd9160(plVar5,uVar20);
    plVar13 = *(longlong **)(lStackX_20 + 0x28);
    if (pcVar19 == _Py_NoneStruct_exref) {
      pcVar18 = (code *)0x0;
    }
    else {
      pcVar18 = pcVar19;
      if (pcVar19 != (code *)0x0) {
        iVar12 = *(int *)pcVar19;
LAB_1408b5d70:
        pcVar18 = pcVar19;
        if (iVar12 + 1 != 0) {
          *(int *)pcVar19 = iVar12 + 1;
        }
      }
    }
  }
  else {
    if (*(longlong **)(piVar7 + 6) == plVar5) goto LAB_1408b5daf;
    pcVar19 = (code *)FUN_142cd9160(plVar5,uVar20);
    *(int **)(pcVar19 + 0x10) = piVar7;
    if (*piVar7 + 1 != 0) {
      *piVar7 = *piVar7 + 1;
    }
    plVar13 = *(longlong **)(lStackX_20 + 0x28);
    if (pcVar19 == _Py_NoneStruct_exref) {
      pcVar18 = (code *)0x0;
    }
    else {
      pcVar18 = pcVar19;
      if (pcVar19 != (code *)0x0) {
        iVar12 = *(int *)pcVar19;
        goto LAB_1408b5d70;
      }
    }
  }
  *(code **)(lStackX_20 + 0x28) = pcVar18;
  if (((plVar13 != (longlong *)0x0) && (-1 < (int)*plVar13)) &&
     (*plVar13 = *plVar13 + -1, *plVar13 == 0)) {
    (**(code **)(plVar13[1] + 0x30))();
  }
  if (((pcVar19 != (code *)0x0) && (-1 < *(int *)pcVar19)) &&
     (*(longlong *)pcVar19 = *(longlong *)pcVar19 + -1, *(longlong *)pcVar19 == 0)) {
    (**(code **)(*(longlong *)(pcVar19 + 8) + 0x30))(pcVar19);
  }
LAB_1408b5daf:
  FUN_142cdb370(plVar5,&UNK_142d0b528,plVar3,plVar1,plVar2,plVar15);
  plVar13 = _DAT_142dea710;
  if (plVar5 == _DAT_142dea710) {
    if ((-1 < (int)*_DAT_142dea710) && (*_DAT_142dea710 = *_DAT_142dea710 + -1, *plVar13 == 0)) {
      (**(code **)(plVar13[1] + 0x30))();
    }
    _DAT_142dea710 = (longlong *)0x0;
  }
  FUN_140008990(tstate);
  lVar17 = lStackX_20;
  lStackX_20 = 0;
  if (((plVar15 != (longlong *)0x0) && (-1 < (int)*plVar15)) &&
     (*plVar15 = *plVar15 + -1, *plVar15 == 0)) {
    (**(code **)(plVar15[1] + 0x30))(plVar15);
  }
  lStackX_20 = lVar17;
  if ((-1 < (int)*plVar3) && (*plVar3 = *plVar3 + -1, *plVar3 == 0)) {
    (**(code **)(plVar3[1] + 0x30))(plVar3);
  }
  if ((-1 < (int)*plVar1) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)) {
    (**(code **)(plVar1[1] + 0x30))(plVar1);
  }
  if ((-1 < (int)*plVar2) && (*plVar2 = *plVar2 + -1, *plVar2 == 0)) {
    (**(code **)(plVar2[1] + 0x30))(plVar2);
  }
  plVar1 = *(longlong **)(tstate + 0x70);
  *(longlong *)(tstate + 0x70) = lStackX_20;
  if (((plVar1 != (longlong *)0x0) && (-1 < (int)*plVar1)) && (*plVar1 = *plVar1 + -1, *plVar1 == 0)
     ) {
    (**(code **)(plVar1[1] + 0x30))();
  }
  return (undefined *)0x0;
}

